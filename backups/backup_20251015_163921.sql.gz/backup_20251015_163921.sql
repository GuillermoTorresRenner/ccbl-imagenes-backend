--
-- PostgreSQL database dump
--

\restrict dYqZECjTP8XkDbkVPRQLUQE6RdlpW3P6Q1wnNnGuJSdAIkf7VJ77PK4G6ktVMoI

-- Dumped from database version 17.6 (Debian 17.6-1.pgdg13+1)
-- Dumped by pg_dump version 17.6 (Debian 17.6-1.pgdg13+1)

-- Started on 2025-10-15 19:39:21 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.image_variants DROP CONSTRAINT IF EXISTS "image_variants_imageId_fkey";
DROP INDEX IF EXISTS public.users_email_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.images DROP CONSTRAINT IF EXISTS images_pkey;
ALTER TABLE IF EXISTS ONLY public.image_variants DROP CONSTRAINT IF EXISTS image_variants_pkey;
ALTER TABLE IF EXISTS ONLY public._prisma_migrations DROP CONSTRAINT IF EXISTS _prisma_migrations_pkey;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.images;
DROP TABLE IF EXISTS public.image_variants;
DROP TABLE IF EXISTS public._prisma_migrations;
DROP TYPE IF EXISTS public.role;
-- *not* dropping schema, since initdb creates it
--
-- TOC entry 5 (class 2615 OID 25027)
-- Name: public; Type: SCHEMA; Schema: -; Owner: ccbl
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO ccbl;

--
-- TOC entry 3457 (class 0 OID 0)
-- Dependencies: 5
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: ccbl
--

COMMENT ON SCHEMA public IS '';


--
-- TOC entry 852 (class 1247 OID 25040)
-- Name: role; Type: TYPE; Schema: public; Owner: ccbl
--

CREATE TYPE public.role AS ENUM (
    'ADMIN',
    'USER'
);


ALTER TYPE public.role OWNER TO ccbl;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 217 (class 1259 OID 25030)
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: ccbl
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO ccbl;

--
-- TOC entry 218 (class 1259 OID 25045)
-- Name: image_variants; Type: TABLE; Schema: public; Owner: ccbl
--

CREATE TABLE public.image_variants (
    id text NOT NULL,
    url text NOT NULL,
    width integer,
    height integer,
    format text,
    quality integer,
    "sizeBytes" integer,
    "imageId" text NOT NULL
);


ALTER TABLE public.image_variants OWNER TO ccbl;

--
-- TOC entry 219 (class 1259 OID 25052)
-- Name: images; Type: TABLE; Schema: public; Owner: ccbl
--

CREATE TABLE public.images (
    id text NOT NULL,
    title text,
    "altText" text,
    description text,
    notes text,
    people text,
    year text,
    decade text,
    zone text,
    previous_data text,
    patrimonial_value integer,
    owner text,
    cultural_fund text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.images OWNER TO ccbl;

--
-- TOC entry 220 (class 1259 OID 25060)
-- Name: users; Type: TABLE; Schema: public; Owner: ccbl
--

CREATE TABLE public.users (
    id text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    name text,
    surname text,
    role public.role DEFAULT 'USER'::public.role NOT NULL,
    "lastConnection" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "refreshToken" text
);


ALTER TABLE public.users OWNER TO ccbl;

--
-- TOC entry 3448 (class 0 OID 25030)
-- Dependencies: 217
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: ccbl
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
e483bf6e-02b4-49b1-8325-bb82910473ef	bb957c6c23f330662877911ed4952dc20a7bfcca147afe0d62e84286fbefd309	2025-10-15 15:59:49.090108+00	20251015155949_init	\N	\N	2025-10-15 15:59:49.07307+00	1
\.


--
-- TOC entry 3449 (class 0 OID 25045)
-- Dependencies: 218
-- Data for Name: image_variants; Type: TABLE DATA; Schema: public; Owner: ccbl
--

COPY public.image_variants (id, url, width, height, format, quality, "sizeBytes", "imageId") FROM stdin;
cmgsagakp028kh9i66r72uv2s	/public/images/thumbnails/0ecb3b80-9b85-4e97-ac91-de0475272565-1760550714311.webp	150	150	webp	80	8522	cmgsagakn028ih9i6ns3aptqf
cmgsagvra028vh9i6xc9ldijc	/public/images/full/babf83b3-4237-46b8-b105-7f73f4677e48-1760550736914.webp	8158	5934	webp	90	5836368	cmgsagvr7028ph9i6iorm34yv
cmgsagyxv0291h9i6ogac27re	/public/images/medium/69c79137-90c3-4fb0-aa09-b5f54ddd4509-1760550764351.webp	800	574	webp	85	122528	cmgsagyxr028wh9i6r9j80odt
cmgsah02w0299h9i6dw05vyin	/public/images/thumbnails/6ab05657-8514-4097-8880-30dd849f6c38-1760550768466.webp	150	150	webp	80	9146	cmgsah02t0293h9i65dr1f4ir
cmgsah1bz029eh9i62woq042e	/public/images/medium/faf69ee1-4118-4e32-bc6e-a2feccb97658-1760550769951.webp	800	999	webp	85	121598	cmgsah1bv029ah9i6pzf695ry
cmgsah434029nh9i65bsj1prk	/public/images/thumbnails/80ba4d8d-a51d-4c4b-9fcf-52a2a1282bdf-1760550771574.webp	150	150	webp	80	8990	cmgsah430029hh9i6fir2xefg
cmgsah5kp029sh9i67winh9lx	/public/images/full/e5c67cbe-c114-4d20-a2ca-c05f14e28a7a-1760550775145.webp	3607	2573	webp	90	1046650	cmgsah5kl029oh9i63gjpgi0g
cmgsah70c02a1h9i6pz24y81v	/public/images/full/29cf577a-c8c6-48cc-8ecd-4a3fb27f3083-1760550777067.webp	3545	2605	webp	90	938322	cmgsah70a029vh9i6asbbbzuo
cmgsah8m802a7h9i6dgioygf2	/public/images/medium/a08b693e-27e5-4d10-a5f3-b990d3795ac4-1760550778931.webp	800	564	webp	85	158354	cmgsah8m202a2h9i6l9fuvlo1
cmgsahalw02adh9i6hwrhzosz	/public/images/full/14b7e918-57ef-45db-98cb-5b9668a17d49-1760550781015.webp	4341	3057	webp	90	1209992	cmgsahals02a9h9i64to2izqx
cmgsahcik02alh9i6xtulouuh	/public/images/full/a0a29f16-dc80-40eb-8f4a-b6fe51aa39e7-1760550783596.webp	2904	4258	webp	90	1167582	cmgsahcii02agh9i6bmm91ei7
cmgsahybv02ash9i6ehw4bbb2	/public/images/medium/8a77180d-0104-4a86-a602-26f398420721-1760550786082.webp	800	1074	webp	85	252188	cmgsahybr02anh9i69v2n7cez
cmgsai0uv02azh9i6rs8ovkid	/public/images/thumbnails/15758358-bb33-4ed0-90c0-e8c459cfa0d8-1760550814343.webp	150	150	webp	80	9958	cmgsai0ut02auh9i6cj0zktoq
cmgsai3rd02b7h9i6wm6yld45	/public/images/medium/1b57020b-7486-4226-b7de-9631f42daa36-1760550817625.webp	800	590	webp	85	150518	cmgsai3r902b1h9i6prs653z2
cmgsai56x02bch9i6e48fhdll	/public/images/medium/483d5722-aa84-4ad1-b9fc-1f09796fcc0d-1760550821370.webp	800	574	webp	85	90000	cmgsai56u02b8h9i63g7k2zem
cmgs9ge5v0002h9i60zujcfy8	/public/images/thumbnails/92d4404e-d168-49f3-b00c-e48ccd7b7547-1760549057518.webp	150	150	webp	80	9170	cmgs9ge5p0000h9i635tq7c53
cmgs9ge6p0004h9i6d8aayn8d	/public/images/medium/92d4404e-d168-49f3-b00c-e48ccd7b7547-1760549057518.webp	800	1117	webp	85	197252	cmgs9ge5p0000h9i635tq7c53
cmgs9ge6s0006h9i6dvusua11	/public/images/full/92d4404e-d168-49f3-b00c-e48ccd7b7547-1760549057518.webp	3759	5247	webp	90	2126448	cmgs9ge5p0000h9i635tq7c53
cmgs9gfh6000ch9i6xbvtddzb	/public/images/medium/35eb0df1-2d91-4c7f-9388-508448e66592-1760549061986.webp	800	741	webp	85	65970	cmgs9gfh20007h9i6xs9c9mgw
cmgs9gfh6000dh9i6435y1794	/public/images/full/35eb0df1-2d91-4c7f-9388-508448e66592-1760549061986.webp	2875	2663	webp	90	394452	cmgs9gfh20007h9i6xs9c9mgw
cmgs9gfh6000bh9i6a4aagzfc	/public/images/thumbnails/35eb0df1-2d91-4c7f-9388-508448e66592-1760549061986.webp	150	150	webp	80	6004	cmgs9gfh20007h9i6xs9c9mgw
cmgs9gh16000ih9i6ti0s0d3c	/public/images/thumbnails/890be1ce-9c82-439c-a9c1-4c0205cffd49-1760549063639.webp	150	150	webp	80	5244	cmgs9gh13000eh9i65dpfsuop
cmgs9gh16000jh9i6ssagmasl	/public/images/medium/890be1ce-9c82-439c-a9c1-4c0205cffd49-1760549063639.webp	800	589	webp	85	78972	cmgs9gh13000eh9i65dpfsuop
cmgs9gh16000kh9i664g4ekt1	/public/images/full/890be1ce-9c82-439c-a9c1-4c0205cffd49-1760549063639.webp	3685	2714	webp	90	758944	cmgs9gh13000eh9i65dpfsuop
cmgs9gjsh000rh9i61110tnm7	/public/images/full/30fa3f23-25ae-451c-a90a-f0e852286f31-1760549065653.webp	5122	3775	webp	90	1277762	cmgs9gjsf000lh9i644nbhhpe
cmgs9gjsh000ph9i6vl8lj5kh	/public/images/medium/30fa3f23-25ae-451c-a90a-f0e852286f31-1760549065653.webp	800	589	webp	85	85292	cmgs9gjsf000lh9i644nbhhpe
cmgs9gjsh000qh9i6v20rns28	/public/images/thumbnails/30fa3f23-25ae-451c-a90a-f0e852286f31-1760549065653.webp	150	150	webp	80	8128	cmgs9gjsf000lh9i644nbhhpe
cmgs9h4te000uh9i6xo1z0wik	/public/images/thumbnails/3596ef6f-3462-4e9a-babc-6ff0825a5bca-1760549069263.webp	150	150	webp	80	8960	cmgs9h4tb000sh9i6mqpcnp0c
cmgs9h4te000xh9i6u0va4kxw	/public/images/full/3596ef6f-3462-4e9a-babc-6ff0825a5bca-1760549069263.webp	8158	5809	webp	90	4309752	cmgs9h4tb000sh9i6mqpcnp0c
cmgs9h4te000yh9i61ha6vjxs	/public/images/medium/3596ef6f-3462-4e9a-babc-6ff0825a5bca-1760549069263.webp	800	570	webp	85	101512	cmgs9h4tb000sh9i6mqpcnp0c
cmgs9h7rd0014h9i6aqmo912o	/public/images/medium/22d1ba66-adcc-4688-8734-a1f192233377-1760549096481.webp	800	578	webp	85	119298	cmgs9h7r7000zh9i64ym196gq
cmgs9h7rd0015h9i6st7jzblj	/public/images/full/22d1ba66-adcc-4688-8734-a1f192233377-1760549096481.webp	5184	3744	webp	90	1477222	cmgs9h7r7000zh9i64ym196gq
cmgs9h7rd0013h9i68sle35pu	/public/images/thumbnails/22d1ba66-adcc-4688-8734-a1f192233377-1760549096481.webp	150	150	webp	80	8438	cmgs9h7r7000zh9i64ym196gq
cmgs9h8qo0019h9i60zkyf2pe	/public/images/thumbnails/0a68f4bf-4445-42b7-b653-f0e6275b6f14-1760549100291.webp	150	150	webp	80	6518	cmgs9h8ql0016h9i6kjybjss0
cmgs9h8qo001ch9i6lxeue2w9	/public/images/full/0a68f4bf-4445-42b7-b653-f0e6275b6f14-1760549100291.webp	2623	2121	webp	90	411310	cmgs9h8ql0016h9i6kjybjss0
cmgs9h8qo001bh9i6fl13g6ad	/public/images/medium/0a68f4bf-4445-42b7-b653-f0e6275b6f14-1760549100291.webp	800	647	webp	85	73388	cmgs9h8ql0016h9i6kjybjss0
cmgs9havv001jh9i6lsi93tx7	/public/images/full/f1f72caa-2fde-4c26-b9af-36cd22b2a6bd-1760549101575.webp	2576	4420	webp	90	1849752	cmgs9havp001dh9i6ypxqo9jh
cmgs9havv001ih9i6t3j7w421	/public/images/medium/f1f72caa-2fde-4c26-b9af-36cd22b2a6bd-1760549101575.webp	800	1373	webp	85	355574	cmgs9havp001dh9i6ypxqo9jh
cmgs9havv001hh9i6njye71ny	/public/images/thumbnails/f1f72caa-2fde-4c26-b9af-36cd22b2a6bd-1760549101575.webp	150	150	webp	80	9592	cmgs9havp001dh9i6ypxqo9jh
cmgs9hdr9001oh9i6wwpw3apk	/public/images/thumbnails/26706b0f-ec13-49aa-a176-27a300f40192-1760549104354.webp	150	150	webp	80	8352	cmgs9hdr7001kh9i6ztwhykwu
cmgs9hdr9001qh9i65xc4v5n2	/public/images/full/26706b0f-ec13-49aa-a176-27a300f40192-1760549104354.webp	3309	5070	webp	90	2085736	cmgs9hdr7001kh9i6ztwhykwu
cmgs9hdr9001ph9i6rto63in7	/public/images/medium/26706b0f-ec13-49aa-a176-27a300f40192-1760549104354.webp	800	1226	webp	85	231198	cmgs9hdr7001kh9i6ztwhykwu
cmgs9hfbu001vh9i630v8uiam	/public/images/full/65962894-ffe0-4923-a54c-fe3906f1f1cf-1760549108059.webp	3623	2605	webp	90	991654	cmgs9hfbp001rh9i6c349woud
cmgs9hfbu001xh9i66pvqlpjb	/public/images/thumbnails/65962894-ffe0-4923-a54c-fe3906f1f1cf-1760549108059.webp	150	150	webp	80	6182	cmgs9hfbp001rh9i6c349woud
cmgs9hgwa0020h9i6jm8bkpxs	/public/images/thumbnails/220cc2bb-e5bc-43c2-a901-6eca3750fe49-1760549110093.webp	150	150	webp	80	7666	cmgs9hgw8001yh9i65d225co7
cmgs9hijm0029h9i6rq8yzf9u	/public/images/full/0d8a9395-caa9-4d1d-b79b-6bdd14ec3fa3-1760549112122.webp	2555	3624	webp	90	809728	cmgs9hiji0025h9i6w26vl5c6
cmgs9hjjg002gh9i6wq3kjapo	/public/images/thumbnails/bb572cb5-147d-4904-bd18-4b81c5071522-1760549114264.webp	150	150	webp	80	7974	cmgs9hjjd002ch9i6eaunp29w
cmgs9hl0r002ph9i6dygqpkjl	/public/images/medium/40641c33-c00e-4612-88c5-132ad977ee34-1760549115558.webp	800	593	webp	85	102926	cmgs9hl0o002jh9i68p7b7mme
cmgs9hn1k002uh9i6da8j2o11	/public/images/thumbnails/2f6a067d-e47a-448e-94c4-0ad2a576fdfd-1760549117480.webp	150	150	webp	80	10822	cmgs9hn1g002qh9i6e3u22wvz
cmgs9hp0v0031h9i6ybu2q2wn	/public/images/thumbnails/b3775365-a72c-4d84-a35a-1751cd790a0e-1760549120107.webp	150	150	webp	80	10508	cmgs9hp0t002xh9i6wofv0jbz
cmgs9hrnu0038h9i60y9ooo6m	/public/images/thumbnails/6e4585b0-dd64-462e-89ba-f087c5ae2977-1760549122661.webp	150	150	webp	80	8896	cmgs9hrns0034h9i6apv8wjg6
cmgs9hshm003dh9i6m2l1jp53	/public/images/medium/8d3b866c-f5f4-41f3-8780-a049e520d93d-1760549126074.webp	800	781	webp	85	118346	cmgs9hshi003bh9i640c5a29s
cmgs9htuq003oh9i6j7tlywr5	/public/images/thumbnails/87b31d8e-ba5f-4b4f-9403-cacea84dd593-1760549127157.webp	150	150	webp	80	5470	cmgs9htuk003ih9i6nf5rdfc6
cmgs9hwcu003vh9i66yiyglt5	/public/images/full/4e5246bd-71f6-48b8-8b22-338ebd9c3b39-1760549128919.webp	3623	5049	webp	90	1150646	cmgs9hwcq003ph9i6iwfaukav
cmgs9hxmx0042h9i61eyrhg4i	/public/images/full/be20efc0-c78a-4f59-9565-501fe4d32019-1760549132175.webp	3279	2386	webp	90	737924	cmgs9hxmr003wh9i6k3r15d3y
cmgs9i02t0048h9i69lrmv1d7	/public/images/thumbnails/a34cd757-e6e3-409d-a66c-1f9830d0bdb3-1760549133831.webp	150	150	webp	80	9508	cmgs9i02n0043h9i62tpp5rfo
cmgs9i1p0004gh9i6ftuerurr	/public/images/thumbnails/2b10d78f-677f-4ea5-9bf3-cbb2864449f5-1760549136997.webp	150	150	webp	80	6742	cmgs9i1ox004ah9i6825vym2z
cmgs9i37o004mh9i66hsm8gmf	/public/images/thumbnails/2ea62948-ec76-4003-b41f-d47f32a64445-1760549139086.webp	150	150	webp	80	9040	cmgs9i37j004hh9i6zehgrdqk
cmgs9i4pb004th9i6vslbh4px	/public/images/full/173c3be6-8d6e-42ac-955d-be6034f0a81c-1760549141047.webp	3591	2620	webp	90	969588	cmgs9i4p6004oh9i6oj7hzxca
cmgs9i68k004xh9i6dokr3fxf	/public/images/thumbnails/70890a63-17f8-490f-9cfc-637685015254-1760549142988.webp	150	150	webp	80	9032	cmgs9i68e004vh9i6wt4gh0zi
cmgs9i8y30058h9i6i90382wi	/public/images/full/5346383e-1bcb-4d12-a7b3-f7132ba8e98e-1760549144973.webp	5028	3634	webp	90	1909990	cmgs9i8y10052h9i61ql0uah7
cmgs9ia9l005eh9i6boex5a2e	/public/images/full/7ff0ab91-41ed-4d72-bdff-68d6dc430cad-1760549148489.webp	2922	2674	webp	90	686572	cmgs9ia9i0059h9i6yw5sy4nh
cmgs9ibjx005mh9i6c5fbjjcd	/public/images/thumbnails/18566361-3eda-496a-ac10-4d9d306d7795-1760549150194.webp	150	150	webp	80	7444	cmgs9ibju005gh9i6kmdt7q7u
cmgsagakq028mh9i6uk4i92nj	/public/images/full/0ecb3b80-9b85-4e97-ac91-de0475272565-1760550714311.webp	7771	5447	webp	90	3904540	cmgsagakn028ih9i6ns3aptqf
cmgsagvra028uh9i6u3fpp2rj	/public/images/medium/babf83b3-4237-46b8-b105-7f73f4677e48-1760550736914.webp	800	582	webp	85	134076	cmgsagvr7028ph9i6iorm34yv
cmgsagyxv0292h9i66o4o98ht	/public/images/thumbnails/69c79137-90c3-4fb0-aa09-b5f54ddd4509-1760550764351.webp	150	150	webp	80	10814	cmgsagyxr028wh9i6r9j80odt
cmgsah02w0298h9i63pprxte0	/public/images/medium/6ab05657-8514-4097-8880-30dd849f6c38-1760550768466.webp	800	1101	webp	85	193610	cmgsah02t0293h9i65dr1f4ir
cmgsah1bz029fh9i66g35w6ub	/public/images/full/faf69ee1-4118-4e32-bc6e-a2feccb97658-1760550769951.webp	2623	3275	webp	90	619840	cmgsah1bv029ah9i6pzf695ry
cmgsah434029mh9i6q0akcmvr	/public/images/full/80ba4d8d-a51d-4c4b-9fcf-52a2a1282bdf-1760550771574.webp	5153	3822	webp	90	1432940	cmgsah430029hh9i6fir2xefg
cmgsah5kp029th9i6p9nyaepp	/public/images/thumbnails/e5c67cbe-c114-4d20-a2ca-c05f14e28a7a-1760550775145.webp	150	150	webp	80	6816	cmgsah5kl029oh9i63gjpgi0g
cmgsah70c029zh9i6e020qxyz	/public/images/thumbnails/29cf577a-c8c6-48cc-8ecd-4a3fb27f3083-1760550777067.webp	150	150	webp	80	9408	cmgsah70a029vh9i6asbbbzuo
cmgsah8m802a4h9i6l507t9no	/public/images/thumbnails/a08b693e-27e5-4d10-a5f3-b990d3795ac4-1760550778931.webp	150	150	webp	80	11524	cmgsah8m202a2h9i6l9fuvlo1
cmgsahalw02aeh9i6e75a2cj4	/public/images/medium/14b7e918-57ef-45db-98cb-5b9668a17d49-1760550781015.webp	800	563	webp	85	105104	cmgsahals02a9h9i64to2izqx
cmgsahcik02akh9i6e5hwbxsc	/public/images/medium/a0a29f16-dc80-40eb-8f4a-b6fe51aa39e7-1760550783596.webp	800	1173	webp	85	185222	cmgsahcii02agh9i6bmm91ei7
cmgsahybv02aph9i6z4umdwaj	/public/images/thumbnails/8a77180d-0104-4a86-a602-26f398420721-1760550786082.webp	150	150	webp	80	10758	cmgsahybr02anh9i69v2n7cez
cmgsai0uv02b0h9i6pzr8chgg	/public/images/full/15758358-bb33-4ed0-90c0-e8c459cfa0d8-1760550814343.webp	4981	3588	webp	90	1380986	cmgsai0ut02auh9i6cj0zktoq
cmgsai3rd02b6h9i6gn7wg0t4	/public/images/full/1b57020b-7486-4226-b7de-9631f42daa36-1760550817625.webp	5012	3697	webp	90	2056258	cmgsai3r902b1h9i6prs653z2
cmgsai56x02bdh9i6ka49c57m	/public/images/thumbnails/483d5722-aa84-4ad1-b9fc-1f09796fcc0d-1760550821370.webp	150	150	webp	80	9954	cmgsai56u02b8h9i63g7k2zem
cmgsai7wl02blh9i63a71hagz	/public/images/full/58c624fd-2988-4da2-b275-0fefa8fa069d-1760550823228.webp	5059	3744	webp	90	1440214	cmgsai7wi02bfh9i6bvht5tfx
cmgsai9rt02bsh9i6daa55fmm	/public/images/medium/ac1f0d50-1b10-43d8-8ec2-15d524214e03-1760550826749.webp	800	561	webp	85	95678	cmgsai9rq02bmh9i6rfb2y88j
cmgsaica602bvh9i6r5bfctzx	/public/images/medium/8ec5d5ff-01d3-4750-8be8-77bf7be5f17b-1760550829169.webp	800	591	webp	85	93910	cmgsaica202bth9i61xsxibns
cmgsaiezo02c6h9i6o3aonqt2	/public/images/full/f5b34b10-aadb-4cfa-ab58-bb4408cdc1f7-1760550832417.webp	5122	3712	webp	90	1625738	cmgsaiezl02c0h9i6b0pdalpk
cmgsaigkp02cbh9i6h9ksi4nw	/public/images/medium/3ed2c9c8-92e1-4b76-8a47-a9009c60ab23-1760550835932.webp	800	579	webp	85	83734	cmgsaigkm02c7h9i6czqvkau4
cmgsaq7mr030mh9i61fvhjm6w	/public/images/full/7bc0318a-506d-45d4-a2fa-428375b8e34c-1760551198366.webp	2660	2157	webp	90	455624	cmgsaq7lv030ih9i6ricnfu5v
cmgsaq904030vh9i65k5amm2g	/public/images/thumbnails/378d27af-f4f8-40a1-bd14-be23fa32f4ae-1760551199646.webp	150	150	webp	80	5822	cmgsaq900030ph9i6kee946d0
cmgsaqblb0311h9i64c7ta53m	/public/images/thumbnails/bc799cce-d8ff-4212-8d80-c3821143809b-1760551201423.webp	150	150	webp	80	6818	cmgsaqbl6030wh9i6efxbmud8
cmgs9hfbu001wh9i6o6zpcovt	/public/images/medium/65962894-ffe0-4923-a54c-fe3906f1f1cf-1760549108059.webp	800	575	webp	85	80346	cmgs9hfbp001rh9i6c349woud
cmgs9hgwb0024h9i6s3kmogwf	/public/images/medium/220cc2bb-e5bc-43c2-a901-6eca3750fe49-1760549110093.webp	800	576	webp	85	98960	cmgs9hgw8001yh9i65d225co7
cmgs9hijm002bh9i6dru0eukx	/public/images/thumbnails/0d8a9395-caa9-4d1d-b79b-6bdd14ec3fa3-1760549112122.webp	150	150	webp	80	6976	cmgs9hiji0025h9i6w26vl5c6
cmgs9hjjg002hh9i6l2qqiiri	/public/images/medium/bb572cb5-147d-4904-bd18-4b81c5071522-1760549114264.webp	800	658	webp	85	96818	cmgs9hjjd002ch9i6eaunp29w
cmgs9hl0r002oh9i6lvdhip3t	/public/images/thumbnails/40641c33-c00e-4612-88c5-132ad977ee34-1760549115558.webp	150	150	webp	80	8796	cmgs9hl0o002jh9i68p7b7mme
cmgs9hn1k002wh9i6lw7o5a6k	/public/images/medium/2f6a067d-e47a-448e-94c4-0ad2a576fdfd-1760549117480.webp	800	534	webp	85	129296	cmgs9hn1g002qh9i6e3u22wvz
cmgs9hp0v0030h9i6lgaah0au	/public/images/medium/b3775365-a72c-4d84-a35a-1751cd790a0e-1760549120107.webp	800	547	webp	85	140848	cmgs9hp0t002xh9i6wofv0jbz
cmgs9hrnv003ah9i6myptjcs5	/public/images/full/6e4585b0-dd64-462e-89ba-f087c5ae2977-1760549122661.webp	5091	3619	webp	90	1698682	cmgs9hrns0034h9i6apv8wjg6
cmgs9hshn003gh9i6kdlpvkon	/public/images/thumbnails/8d3b866c-f5f4-41f3-8780-a049e520d93d-1760549126074.webp	150	150	webp	80	7750	cmgs9hshi003bh9i640c5a29s
cmgs9htuq003nh9i63sz7e2lp	/public/images/medium/87b31d8e-ba5f-4b4f-9403-cacea84dd593-1760549127157.webp	800	626	webp	85	78158	cmgs9htuk003ih9i6nf5rdfc6
cmgs9hwcu003uh9i6twztxn01	/public/images/thumbnails/4e5246bd-71f6-48b8-8b22-338ebd9c3b39-1760549128919.webp	150	150	webp	80	9248	cmgs9hwcq003ph9i6iwfaukav
cmgs9hxmx0041h9i60tk8wwtt	/public/images/thumbnails/be20efc0-c78a-4f59-9565-501fe4d32019-1760549132175.webp	150	150	webp	80	8732	cmgs9hxmr003wh9i6k3r15d3y
cmgs9i02t0047h9i6j0yd5mx1	/public/images/medium/a34cd757-e6e3-409d-a66c-1f9830d0bdb3-1760549133831.webp	800	548	webp	85	103144	cmgs9i02n0043h9i62tpp5rfo
cmgs9i1p0004fh9i6h5zyok61	/public/images/full/2b10d78f-677f-4ea5-9bf3-cbb2864449f5-1760549136997.webp	4294	2667	webp	90	805512	cmgs9i1ox004ah9i6825vym2z
cmgs9i37o004lh9i6lbh992nl	/public/images/full/2ea62948-ec76-4003-b41f-d47f32a64445-1760549139086.webp	3623	2605	webp	90	749796	cmgs9i37j004hh9i6zehgrdqk
cmgs9i4pb004uh9i65yh94765	/public/images/medium/173c3be6-8d6e-42ac-955d-be6034f0a81c-1760549141047.webp	800	584	webp	85	92710	cmgs9i4p6004oh9i6oj7hzxca
cmgs9i68k0050h9i607gnar3x	/public/images/full/70890a63-17f8-490f-9cfc-637685015254-1760549142988.webp	3591	2620	webp	90	1036882	cmgs9i68e004vh9i6wt4gh0zi
cmgs9i8y30057h9i655xufemk	/public/images/thumbnails/5346383e-1bcb-4d12-a7b3-f7132ba8e98e-1760549144973.webp	150	150	webp	80	7906	cmgs9i8y10052h9i61ql0uah7
cmgs9ia9l005fh9i6n8cvtagc	/public/images/thumbnails/7ff0ab91-41ed-4d72-bdff-68d6dc430cad-1760549148489.webp	150	150	webp	80	9136	cmgs9ia9i0059h9i6yw5sy4nh
cmgs9ibjx005jh9i63z7s371f	/public/images/medium/18566361-3eda-496a-ac10-4d9d306d7795-1760549150194.webp	800	641	webp	85	78504	cmgs9ibju005gh9i6kmdt7q7u
cmgsagakq028oh9i6hxbqxyc3	/public/images/medium/0ecb3b80-9b85-4e97-ac91-de0475272565-1760550714311.webp	800	560	webp	85	126734	cmgsagakn028ih9i6ns3aptqf
cmgsagvr9028rh9i6sbzck8ho	/public/images/thumbnails/babf83b3-4237-46b8-b105-7f73f4677e48-1760550736914.webp	150	150	webp	80	9852	cmgsagvr7028ph9i6iorm34yv
cmgsagyxv0290h9i66wsnhdsm	/public/images/full/69c79137-90c3-4fb0-aa09-b5f54ddd4509-1760550764351.webp	5216	3743	webp	90	1648188	cmgsagyxr028wh9i6r9j80odt
cmgsah02w0297h9i6mj35xphb	/public/images/full/6ab05657-8514-4097-8880-30dd849f6c38-1760550768466.webp	2108	2901	webp	90	764430	cmgsah02t0293h9i65dr1f4ir
cmgsah1bz029gh9i65s63q924	/public/images/thumbnails/faf69ee1-4118-4e32-bc6e-a2feccb97658-1760550769951.webp	150	150	webp	80	8044	cmgsah1bv029ah9i6pzf695ry
cmgsah434029lh9i68zzl8trs	/public/images/medium/80ba4d8d-a51d-4c4b-9fcf-52a2a1282bdf-1760550771574.webp	800	593	webp	85	102960	cmgsah430029hh9i6fir2xefg
cmgsah5kp029uh9i6oyi5l5zh	/public/images/medium/e5c67cbe-c114-4d20-a2ca-c05f14e28a7a-1760550775145.webp	800	571	webp	85	107566	cmgsah5kl029oh9i63gjpgi0g
cmgsah70c02a0h9i6sq0m6pfh	/public/images/medium/29cf577a-c8c6-48cc-8ecd-4a3fb27f3083-1760550777067.webp	800	588	webp	85	117836	cmgsah70a029vh9i6asbbbzuo
cmgsah8m802a8h9i6oqf5oqic	/public/images/full/a08b693e-27e5-4d10-a5f3-b990d3795ac4-1760550778931.webp	3607	2542	webp	90	1173502	cmgsah8m202a2h9i6l9fuvlo1
cmgsahalw02afh9i6ohcbkvip	/public/images/thumbnails/14b7e918-57ef-45db-98cb-5b9668a17d49-1760550781015.webp	150	150	webp	80	10060	cmgsahals02a9h9i64to2izqx
cmgsahcik02amh9i6zogec5sh	/public/images/thumbnails/a0a29f16-dc80-40eb-8f4a-b6fe51aa39e7-1760550783596.webp	150	150	webp	80	10250	cmgsahcii02agh9i6bmm91ei7
cmgsahybv02ath9i6amsaqlx1	/public/images/full/8a77180d-0104-4a86-a602-26f398420721-1760550786082.webp	5778	7753	webp	90	7917386	cmgsahybr02anh9i69v2n7cez
cmgsai0uv02axh9i6gwzopoli	/public/images/medium/15758358-bb33-4ed0-90c0-e8c459cfa0d8-1760550814343.webp	800	576	webp	85	85744	cmgsai0ut02auh9i6cj0zktoq
cmgsai3rd02b5h9i6jhhivb95	/public/images/thumbnails/1b57020b-7486-4226-b7de-9631f42daa36-1760550817625.webp	150	150	webp	80	11724	cmgsai3r902b1h9i6prs653z2
cmgsai56x02beh9i6cittdnt5	/public/images/full/483d5722-aa84-4ad1-b9fc-1f09796fcc0d-1760550821370.webp	3654	2620	webp	90	713958	cmgsai56u02b8h9i63g7k2zem
cmgsai7wl02bjh9i6581vat0f	/public/images/medium/58c624fd-2988-4da2-b275-0fefa8fa069d-1760550823228.webp	800	592	webp	85	74088	cmgsai7wi02bfh9i6bvht5tfx
cmgsai9rt02bph9i6tszdjfmc	/public/images/thumbnails/ac1f0d50-1b10-43d8-8ec2-15d524214e03-1760550826749.webp	150	150	webp	80	6778	cmgsai9rq02bmh9i6rfb2y88j
cmgsaica602bxh9i6g3sm80tl	/public/images/thumbnails/8ec5d5ff-01d3-4750-8be8-77bf7be5f17b-1760550829169.webp	150	150	webp	80	9618	cmgsaica202bth9i61xsxibns
cmgsaiezo02c4h9i6jmk9vtkx	/public/images/thumbnails/f5b34b10-aadb-4cfa-ab58-bb4408cdc1f7-1760550832417.webp	150	150	webp	80	7026	cmgsaiezl02c0h9i6b0pdalpk
cmgsaigkp02cdh9i67txycn8a	/public/images/thumbnails/3ed2c9c8-92e1-4b76-8a47-a9009c60ab23-1760550835932.webp	150	150	webp	80	8532	cmgsaigkm02c7h9i6czqvkau4
cmgsaq7mw030oh9i6ensutkjh	/public/images/medium/7bc0318a-506d-45d4-a2fa-428375b8e34c-1760551198366.webp	800	648	webp	85	64766	cmgsaq7lv030ih9i6ricnfu5v
cmgsaq904030uh9i6cvw0zeg6	/public/images/medium/378d27af-f4f8-40a1-bd14-be23fa32f4ae-1760551199646.webp	800	579	webp	85	63468	cmgsaq900030ph9i6kee946d0
cmgsaqblb0312h9i6zfbzpwfb	/public/images/full/bc799cce-d8ff-4212-8d80-c3821143809b-1760551201423.webp	4981	3416	webp	90	1759808	cmgsaqbl6030wh9i6efxbmud8
cmgs9hgwb0022h9i68be39d5h	/public/images/full/220cc2bb-e5bc-43c2-a901-6eca3750fe49-1760549110093.webp	3638	2620	webp	90	973506	cmgs9hgw8001yh9i65d225co7
cmgs9hijm002ah9i6im1sxnia	/public/images/medium/0d8a9395-caa9-4d1d-b79b-6bdd14ec3fa3-1760549112122.webp	800	1135	webp	85	142726	cmgs9hiji0025h9i6w26vl5c6
cmgs9hjjg002ih9i6tqjeq4fo	/public/images/full/bb572cb5-147d-4904-bd18-4b81c5071522-1760549114264.webp	2597	2136	webp	90	616838	cmgs9hjjd002ch9i6eaunp29w
cmgs9hl0r002nh9i6xqt9tfde	/public/images/full/40641c33-c00e-4612-88c5-132ad977ee34-1760549115558.webp	3513	2605	webp	90	816486	cmgs9hl0o002jh9i68p7b7mme
cmgs9hn1k002vh9i6bmloxzve	/public/images/full/2f6a067d-e47a-448e-94c4-0ad2a576fdfd-1760549117480.webp	4278	2854	webp	90	1510200	cmgs9hn1g002qh9i6e3u22wvz
cmgs9hp0v0033h9i6d2hilyoe	/public/images/full/b3775365-a72c-4d84-a35a-1751cd790a0e-1760549120107.webp	4310	2948	webp	90	1400046	cmgs9hp0t002xh9i6wofv0jbz
cmgs9hrnv0039h9i6tbzfbv98	/public/images/medium/6e4585b0-dd64-462e-89ba-f087c5ae2977-1760549122661.webp	800	569	webp	85	85192	cmgs9hrns0034h9i6apv8wjg6
cmgs9hshn003hh9i663kq11p4	/public/images/full/8d3b866c-f5f4-41f3-8780-a049e520d93d-1760549126074.webp	2077	2027	webp	90	418612	cmgs9hshi003bh9i640c5a29s
cmgs9htuq003mh9i67eg5hcnq	/public/images/full/87b31d8e-ba5f-4b4f-9403-cacea84dd593-1760549127157.webp	3326	2605	webp	90	657766	cmgs9htuk003ih9i6nf5rdfc6
cmgs9hwcu003th9i6r8i8rlil	/public/images/medium/4e5246bd-71f6-48b8-8b22-338ebd9c3b39-1760549128919.webp	800	1115	webp	85	129104	cmgs9hwcq003ph9i6iwfaukav
cmgs9hxmx0040h9i6ahtqhyjz	/public/images/medium/be20efc0-c78a-4f59-9565-501fe4d32019-1760549132175.webp	800	582	webp	85	95498	cmgs9hxmr003wh9i6k3r15d3y
cmgs9i02t0049h9i6238xkdva	/public/images/full/a34cd757-e6e3-409d-a66c-1f9830d0bdb3-1760549133831.webp	4919	3369	webp	90	1482520	cmgs9i02n0043h9i62tpp5rfo
cmgs9i1p0004eh9i6rl9f5ee4	/public/images/medium/2b10d78f-677f-4ea5-9bf3-cbb2864449f5-1760549136997.webp	800	497	webp	85	59726	cmgs9i1ox004ah9i6825vym2z
cmgs9i37o004nh9i656njm8pj	/public/images/medium/2ea62948-ec76-4003-b41f-d47f32a64445-1760549139086.webp	800	575	webp	85	79484	cmgs9i37j004hh9i6zehgrdqk
cmgs9i4pa004qh9i6kxun1mbo	/public/images/thumbnails/173c3be6-8d6e-42ac-955d-be6034f0a81c-1760549141047.webp	150	150	webp	80	6352	cmgs9i4p6004oh9i6oj7hzxca
cmgs9i68k0051h9i6mrv4uoli	/public/images/medium/70890a63-17f8-490f-9cfc-637685015254-1760549142988.webp	800	584	webp	85	124410	cmgs9i68e004vh9i6wt4gh0zi
cmgs9i8y30055h9i69vfv0gpm	/public/images/medium/5346383e-1bcb-4d12-a7b3-f7132ba8e98e-1760549144973.webp	800	578	webp	85	98536	cmgs9i8y10052h9i61ql0uah7
cmgs9ia9l005dh9i6lfrgo9io	/public/images/medium/7ff0ab91-41ed-4d72-bdff-68d6dc430cad-1760549148489.webp	800	732	webp	85	124512	cmgs9ia9i0059h9i6yw5sy4nh
cmgs9ibjx005lh9i6uo7mzdsu	/public/images/full/18566361-3eda-496a-ac10-4d9d306d7795-1760549150194.webp	3248	2605	webp	90	555022	cmgs9ibju005gh9i6kmdt7q7u
cmgs9isif005ph9i6dpon8a0i	/public/images/medium/cb1a9b28-a090-43eb-bbbe-5570f96c2f9f-1760549151876.webp	800	600	webp	85	68820	cmgs9isia005nh9i6ic7x38ns
cmgs9isig005th9i6t7ouxm8t	/public/images/thumbnails/cb1a9b28-a090-43eb-bbbe-5570f96c2f9f-1760549151876.webp	150	150	webp	80	7228	cmgs9isia005nh9i6ic7x38ns
cmgs9isig005sh9i6rwiuy4om	/public/images/full/cb1a9b28-a090-43eb-bbbe-5570f96c2f9f-1760549151876.webp	7540	5656	webp	90	3322414	cmgs9isia005nh9i6ic7x38ns
cmgs9ix0v005yh9i6p4sxg5jv	/public/images/full/f87baa0d-e1a2-4a24-8c2a-ed07c4bc98e7-1760549173858.webp	7738	4819	webp	90	1797826	cmgs9ix0q005uh9i6zhofbuma
cmgs9ix0v005zh9i60z4auoim	/public/images/thumbnails/f87baa0d-e1a2-4a24-8c2a-ed07c4bc98e7-1760549173858.webp	150	150	webp	80	4644	cmgs9ix0q005uh9i6zhofbuma
cmgs9ix0v0060h9i6jvh1fc08	/public/images/medium/f87baa0d-e1a2-4a24-8c2a-ed07c4bc98e7-1760549173858.webp	800	498	webp	85	42902	cmgs9ix0q005uh9i6zhofbuma
cmgs9izsq0067h9i6e69vjodc	/public/images/full/2f17f5c5-b70c-4a39-98ad-20c4e14fa378-1760549179689.webp	5044	3587	webp	90	1960478	cmgs9izsn0061h9i6jdqawzyn
cmgs9izsq0065h9i61n2o71le	/public/images/medium/2f17f5c5-b70c-4a39-98ad-20c4e14fa378-1760549179689.webp	800	568	webp	85	84072	cmgs9izsn0061h9i6jdqawzyn
cmgs9izsq0066h9i6bqkwbt77	/public/images/thumbnails/2f17f5c5-b70c-4a39-98ad-20c4e14fa378-1760549179689.webp	150	150	webp	80	7446	cmgs9izsn0061h9i6jdqawzyn
cmgs9j0y4006eh9i6psbq4n5f	/public/images/thumbnails/86951895-9c72-4f48-9a39-f129fc79925c-1760549183287.webp	150	150	webp	80	4688	cmgs9j0xz0068h9i6dalfhvoq
cmgs9j0y4006dh9i61b9qm2am	/public/images/medium/86951895-9c72-4f48-9a39-f129fc79925c-1760549183287.webp	800	582	webp	85	70302	cmgs9j0xz0068h9i6dalfhvoq
cmgs9j0y4006ch9i6tph90u2a	/public/images/full/86951895-9c72-4f48-9a39-f129fc79925c-1760549183287.webp	3079	2241	webp	90	699584	cmgs9j0xz0068h9i6dalfhvoq
cmgs9j2ig006jh9i6g7iznj4v	/public/images/full/86b1f193-5325-47a9-b3a7-75a93a51bc8a-1760549184770.webp	4044	2589	webp	90	873666	cmgs9j2id006fh9i6iuxbdr58
cmgs9j2ig006lh9i6obi45dg8	/public/images/thumbnails/86b1f193-5325-47a9-b3a7-75a93a51bc8a-1760549184770.webp	150	150	webp	80	7850	cmgs9j2id006fh9i6iuxbdr58
cmgs9j2ig006kh9i6i7dzus9z	/public/images/medium/86b1f193-5325-47a9-b3a7-75a93a51bc8a-1760549184770.webp	800	512	webp	85	80608	cmgs9j2id006fh9i6iuxbdr58
cmgs9j3ym006rh9i6v55xl0b3	/public/images/thumbnails/51c3ee52-10e6-496d-921e-fb9ff7abe20d-1760549186800.webp	150	150	webp	80	6626	cmgs9j3yj006mh9i615ovqet2
cmgs9j3ym006qh9i699if3qjh	/public/images/medium/51c3ee52-10e6-496d-921e-fb9ff7abe20d-1760549186800.webp	800	616	webp	85	108496	cmgs9j3yj006mh9i615ovqet2
cmgs9j3ym006sh9i6wzm4hosv	/public/images/full/51c3ee52-10e6-496d-921e-fb9ff7abe20d-1760549186800.webp	3482	2683	webp	90	906180	cmgs9j3yj006mh9i615ovqet2
cmgs9j6px006vh9i60561skra	/public/images/thumbnails/3c5d6d39-dfa0-4773-b6d6-d5909e4f73d0-1760549188681.webp	150	150	webp	80	7394	cmgs9j6pt006th9i68mzdhkgq
cmgs9j6py006xh9i65zm67xsz	/public/images/full/3c5d6d39-dfa0-4773-b6d6-d5909e4f73d0-1760549188681.webp	5059	3634	webp	90	1974538	cmgs9j6pt006th9i68mzdhkgq
cmgs9j6q0006zh9i6fp3ksa5f	/public/images/medium/3c5d6d39-dfa0-4773-b6d6-d5909e4f73d0-1760549188681.webp	800	575	webp	85	107910	cmgs9j6pt006th9i68mzdhkgq
cmgs9jmms0072h9i6lr15yx52	/public/images/thumbnails/84522217-eb2b-44f0-9469-5979ea28c38c-1760549192253.webp	150	150	webp	80	4834	cmgs9jmmo0070h9i68wcf3561
cmgs9jmmt0075h9i6p60xwg18	/public/images/medium/84522217-eb2b-44f0-9469-5979ea28c38c-1760549192253.webp	800	538	webp	85	71824	cmgs9jmmo0070h9i68wcf3561
cmgs9jmmt0076h9i69mrb3tfv	/public/images/full/84522217-eb2b-44f0-9469-5979ea28c38c-1760549192253.webp	7578	5099	webp	90	3147448	cmgs9jmmo0070h9i68wcf3561
cmgs9k1s90079h9i69dp81ekh	/public/images/thumbnails/b656abaa-bc12-4d5c-b376-09cf3a705822-1760549212887.webp	150	150	webp	80	7538	cmgs9k1s60077h9i6x29jv17v
cmgs9klfx007kh9i68av0gm8m	/public/images/full/30b3db40-6fa4-4e7f-bcea-420b32165d8f-1760549232529.webp	8174	5934	webp	90	3944498	cmgs9klfr007eh9i6lzk2vxua
cmgs9l4cs007qh9i6kbnvq3tc	/public/images/medium/3e1e627a-001a-4647-bb00-1b9c3428e851-1760549258002.webp	800	581	webp	85	81884	cmgs9l4cq007lh9i6ec1a72wv
cmgs9l6y9007wh9i608uzylqu	/public/images/thumbnails/1b4f4eaa-dcc6-4350-b720-c86df9897245-1760549282508.webp	150	150	webp	80	5948	cmgs9l6y6007sh9i6je61g624
cmgs9l9r20085h9i6mxov238r	/public/images/full/5f09065a-d550-4f05-8621-2f1401b79057-1760549285869.webp	3697	5340	webp	90	1397872	cmgs9l9r0007zh9i6qfz8z7r2
cmgs9lcir008bh9i6t7svlsqi	/public/images/thumbnails/9c25c302-dcbf-421d-b656-85470694320a-1760549289505.webp	150	150	webp	80	6654	cmgs9lcim0086h9i6qpqoy6jl
cmgs9lfd9008jh9i6a3yd0l18	/public/images/thumbnails/623bfa53-58a8-4e8f-a531-7a3157765029-1760549293080.webp	150	150	webp	80	9816	cmgs9lfd5008dh9i6n1gokvbb
cmgs9li0g008mh9i60mh5er6w	/public/images/thumbnails/180dd959-7fab-4993-aeec-2d28a1b73cc1-1760549296779.webp	150	150	webp	80	10720	cmgs9li0e008kh9i67vsfkqzh
cmgs9lku2008xh9i6eq0vktnb	/public/images/medium/bf67f494-c57f-4ee5-a05f-344f447137bf-1760549300204.webp	800	573	webp	85	122420	cmgs9lktz008rh9i6zdyba80v
cmgs9lndi0092h9i67sjoh77a	/public/images/full/5e97f0bc-f698-4fce-9840-974524f34d6b-1760549303862.webp	5184	3697	webp	90	1238852	cmgs9lndd008yh9i6w5sjl48w
cmgs9lq78009bh9i6dv7a4iw9	/public/images/full/e8f2959b-d91c-455e-a62a-07a23dce86d7-1760549307151.webp	5153	3822	webp	90	1470762	cmgs9lq750095h9i6scqd7t0a
cmgs9lt3u009hh9i6ti3cgro7	/public/images/medium/7760e8df-8cba-44ae-91b6-1d1537d23d02-1760549310815.webp	800	1086	webp	85	129646	cmgs9lt3s009ch9i6mqzjkhyt
cmgs9lw0i009oh9i6gv6h8aie	/public/images/medium/64b6e68a-f705-4bb7-8d0f-5e62b165aecf-1760549314586.webp	800	1079	webp	85	206508	cmgs9lw0g009jh9i6t8046ob2
cmgsai7wl02bih9i610vfhsmq	/public/images/thumbnails/58c624fd-2988-4da2-b275-0fefa8fa069d-1760550823228.webp	150	150	webp	80	8564	cmgsai7wi02bfh9i6bvht5tfx
cmgsai9rt02brh9i697l7f1bs	/public/images/full/ac1f0d50-1b10-43d8-8ec2-15d524214e03-1760550826749.webp	4247	2979	webp	90	1191022	cmgsai9rq02bmh9i6rfb2y88j
cmgsaica702bzh9i6hbo412vs	/public/images/full/8ec5d5ff-01d3-4750-8be8-77bf7be5f17b-1760550829169.webp	5028	3712	webp	90	1472418	cmgsaica202bth9i61xsxibns
cmgsaiezo02c5h9i6323off74	/public/images/medium/f5b34b10-aadb-4cfa-ab58-bb4408cdc1f7-1760550832417.webp	800	580	webp	85	86922	cmgsaiezl02c0h9i6b0pdalpk
cmgsaigkp02cch9i6m5nuvv53	/public/images/full/3ed2c9c8-92e1-4b76-8a47-a9009c60ab23-1760550835932.webp	3685	2667	webp	90	823528	cmgsaigkm02c7h9i6czqvkau4
cmgsaqdv90315h9i6fybyh2h1	/public/images/medium/a0a880ec-1cca-4757-80ae-ea3b104d69fe-1760551204779.webp	800	647	webp	85	77722	cmgsaqdv60313h9i6f2ic4owx
cmgsaqgig031eh9i619ao8rou	/public/images/thumbnails/f33421a9-081c-4ce2-804b-4b50b92aa4d3-1760551207728.webp	150	150	webp	80	5546	cmgsaqgid031ah9i62vkqbx3k
cmgsaqxez031mh9i6quev6nw6	/public/images/medium/15f310c4-1c4e-4af7-8ab3-b77aac74dd63-1760551211181.webp	800	601	webp	85	122972	cmgsaqxew031hh9i6q37c51ag
cmgsar05o031rh9i68doxnqlb	/public/images/medium/8a769182-2880-4b35-8de9-abcf0d8bbbf5-1760551233056.webp	800	533	webp	85	69258	cmgsar05i031oh9i6y8uwvaoq
cmgsar2rm0321h9i6emroo7su	/public/images/full/882b35d5-f349-4b8b-aefe-80445e1bf1fe-1760551236612.webp	3307	4919	webp	90	1723972	cmgsar2rj031vh9i65uqhtyga
cmgsar56s0326h9i6l0ad5p9i	/public/images/full/11753bfb-9591-4883-9803-5df264b531ef-1760551239987.webp	3494	5091	webp	90	1020344	cmgsar56m0322h9i6vyft5ybr
cmgsar7k3032fh9i6r8vtef6y	/public/images/medium/2a704439-37cc-44b7-a1c2-50ac74d1e320-1760551243130.webp	800	1216	webp	85	126622	cmgsar7k00329h9i6bsx0p3v8
cmgsara15032ih9i6ybj6sp2v	/public/images/thumbnails/6c3a59ee-88db-4d78-a320-d10998925240-1760551246198.webp	150	150	webp	80	8476	cmgsara12032gh9i680ct0oid
cmgsarclo032th9i6je47evvj	/public/images/full/b074c884-2dcf-48bd-93e1-372f32406dcc-1760551249416.webp	3351	4923	webp	90	1424964	cmgsarclk032nh9i6mx73z8zy
cmgsardrb0330h9i6eqgfqxi1	/public/images/full/6bcc390c-2be3-4cff-a0fa-f8fecaab6d5a-1760551252738.webp	2608	2589	webp	90	612148	cmgsardr9032uh9i6aj3lc9qr
cmgsarew40335h9i60qc7im57	/public/images/thumbnails/0234bf59-84ea-4147-9763-44bd933abac5-1760551254233.webp	150	150	webp	80	7160	cmgsarew20331h9i6yxogsojb
cmgsarg19033eh9i6jt4h5fp3	/public/images/full/f2d88f86-b7b7-4c4f-af5d-8c47c58f0672-1760551255701.webp	2608	2636	webp	90	472724	cmgsarg150338h9i6y90ltdsa
cmgsargz4033kh9i65n4bkv5y	/public/images/medium/facd4e72-c8d1-4101-9bd2-9666fb095782-1760551257183.webp	800	762	webp	85	60354	cmgsargyz033fh9i6vmvyf3rw
cmgsaribu033sh9i6w4cw0ncm	/public/images/thumbnails/a937a959-56ce-449f-b6ac-d20265d18aa8-1760551258406.webp	150	150	webp	80	6212	cmgsaribq033mh9i6q1ih2g85
cmgsas686033zh9i6b02wigze	/public/images/medium/36f5bf04-fc2a-4fc5-ba1a-6a810e07131a-1760551260174.webp	800	582	webp	85	137354	cmgsas683033th9i60ri2354f
cmgsas89g0344h9i68ncw0bet	/public/images/medium/47068c6e-e25b-43b5-9053-2ea6c953184a-1760551290191.webp	800	1172	webp	85	223504	cmgsas89d0340h9i62izt0uwz
cmgsasb4z034dh9i6do2x83po	/public/images/full/7cf040d1-b35e-4472-8f97-876c15accc2a-1760551293778.webp	3393	5237	webp	90	2004276	cmgsasb4u0347h9i6gcvvdevp
cmgsasdwr034jh9i64e954p0l	/public/images/thumbnails/f2892191-f363-498b-9398-5800415f8e35-1760551297498.webp	150	150	webp	80	8046	cmgsasdwn034eh9i6r47tf2q0
cmgsasfi1034qh9i6desxkick	/public/images/medium/2f25fcdd-962d-4cd9-a6f2-446e943e6ee6-1760551301084.webp	800	561	webp	85	76220	cmgsasfhz034lh9i6tbamb39u
cmgsashs5034wh9i6zls25oey	/public/images/thumbnails/80fc5692-e905-4c24-8a1c-0382d54cc4a9-1760551303150.webp	150	150	webp	80	8630	cmgsashs2034sh9i6lwb6r4wq
cmgsasj600355h9i6xf106p5s	/public/images/thumbnails/8c5417e5-14ee-4950-89df-ed8f425e45c5-1760551306109.webp	150	150	webp	80	7908	cmgsasj5x034zh9i62646f70m
cmgsaskfl035bh9i6azehqx3g	/public/images/thumbnails/aaa09157-70c9-46b5-98f8-9dbb91e20938-1760551307892.webp	150	150	webp	80	9138	cmgsaskfh0356h9i6drf8g5uq
cmgsaslrg035hh9i6m3565pwy	/public/images/full/a5c7be90-deab-4c67-94d7-9d32bd1d84e0-1760551309542.webp	3295	2573	webp	90	664568	cmgsaslre035dh9i67zukssbv
cmgsaso6z035ph9i6jxbcmvyb	/public/images/thumbnails/2543163c-a89f-4562-b56b-61458a6cfc75-1760551311264.webp	150	150	webp	80	8184	cmgsaso6v035kh9i6xrm9heg2
cmgsasple035wh9i607x7ucls	/public/images/thumbnails/8b03174f-b891-4785-8ece-b6cd74be5479-1760551314415.webp	150	150	webp	80	5602	cmgsasplb035rh9i6sqnqyry1
cmgs9k1sa007ch9i6melkpvly	/public/images/full/b656abaa-bc12-4d5c-b376-09cf3a705822-1760549212887.webp	7578	4819	webp	90	2976698	cmgs9k1s60077h9i6x29jv17v
cmgs9klfx007jh9i674trgadi	/public/images/medium/30b3db40-6fa4-4e7f-bcea-420b32165d8f-1760549232529.webp	800	581	webp	85	62346	cmgs9klfr007eh9i6lzk2vxua
cmgs9l4cs007nh9i6x3c033vt	/public/images/thumbnails/3e1e627a-001a-4647-bb00-1b9c3428e851-1760549258002.webp	150	150	webp	80	7188	cmgs9l4cq007lh9i6ec1a72wv
cmgs9l6y9007yh9i647xyvnso	/public/images/medium/1b4f4eaa-dcc6-4350-b720-c86df9897245-1760549282508.webp	800	569	webp	85	57304	cmgs9l6y6007sh9i6je61g624
cmgs9l9r20083h9i6a34o5sgq	/public/images/thumbnails/5f09065a-d550-4f05-8621-2f1401b79057-1760549285869.webp	150	150	webp	80	10518	cmgs9l9r0007zh9i6qfz8z7r2
cmgs9lcir008ah9i6yph5blvj	/public/images/full/9c25c302-dcbf-421d-b656-85470694320a-1760549289505.webp	3697	5340	webp	90	1284674	cmgs9lcim0086h9i6qpqoy6jl
cmgs9lfd9008ih9i6pnxl1biq	/public/images/medium/623bfa53-58a8-4e8f-a531-7a3157765029-1760549293080.webp	800	557	webp	85	93288	cmgs9lfd5008dh9i6n1gokvbb
cmgs9li0g008oh9i6vx0ezgej	/public/images/full/180dd959-7fab-4993-aeec-2d28a1b73cc1-1760549296779.webp	5247	3681	webp	90	1497324	cmgs9li0e008kh9i67vsfkqzh
cmgs9lku2008vh9i69wmwgra9	/public/images/thumbnails/bf67f494-c57f-4ee5-a05f-344f447137bf-1760549300204.webp	150	150	webp	80	9852	cmgs9lktz008rh9i6zdyba80v
cmgs9lndi0094h9i61qcxlhvb	/public/images/medium/5e97f0bc-f698-4fce-9840-974524f34d6b-1760549303862.webp	800	570	webp	85	56826	cmgs9lndd008yh9i6w5sjl48w
cmgs9lq780099h9i6gbhh5rkk	/public/images/medium/e8f2959b-d91c-455e-a62a-07a23dce86d7-1760549307151.webp	800	593	webp	85	90020	cmgs9lq750095h9i6scqd7t0a
cmgs9lt3u009gh9i6nme8cous	/public/images/thumbnails/7760e8df-8cba-44ae-91b6-1d1537d23d02-1760549310815.webp	150	150	webp	80	8510	cmgs9lt3s009ch9i6mqzjkhyt
cmgs9lw0i009lh9i6729038gv	/public/images/thumbnails/64b6e68a-f705-4bb7-8d0f-5e62b165aecf-1760549314586.webp	150	150	webp	80	9326	cmgs9lw0g009jh9i6t8046ob2
cmgs9lz0h009uh9i6a1be1tst	/public/images/full/1e91cfb4-e8c3-4d60-bb7e-433dc12e5445-1760549318346.webp	3854	5279	webp	90	1771460	cmgs9lz0d009qh9i6jolx0f5r
cmgs9m12z00a3h9i6gufg9icj	/public/images/medium/430f025b-af99-4c6d-988d-c1bb95d5607f-1760549322254.webp	800	557	webp	85	89560	cmgs9m12u009xh9i6pi3bxv00
cmgs9m2h700a9h9i6np221b6q	/public/images/full/f8b66540-3a8d-46b9-9bc3-37109a29d0dc-1760549324908.webp	3654	2714	webp	90	576266	cmgs9m2h100a4h9i6vdw4ptra
cmgs9m4h800agh9i6e2vffxk9	/public/images/medium/6867af8b-f22c-4533-8a68-bd8e886a525d-1760549326722.webp	800	508	webp	85	90992	cmgs9m4h300abh9i6u04otk50
cmgs9m71u00anh9i6phefet7r	/public/images/thumbnails/61d88328-6e37-4e90-b0f4-1b23f98c2891-1760549329326.webp	150	150	webp	80	10396	cmgs9m71q00aih9i6lge5ctr0
cmgs9m8x800avh9i6hqm3jbac	/public/images/full/81bba4b4-e201-4d1f-86ff-8184b48de931-1760549332656.webp	4029	2973	webp	90	1232788	cmgs9m8x500aph9i6onu38nxf
cmgs9maax00b1h9i60hsy84bd	/public/images/full/ced4ff9c-d65c-417a-8c04-333d7d8b7310-1760549335068.webp	3279	2636	webp	90	733142	cmgs9maav00awh9i63qrvkcgw
cmgsaiicr02ckh9i616i528ov	/public/images/full/0f724629-8326-43e6-9834-c8ef792572da-1760550837981.webp	4357	3073	webp	90	759108	cmgsaiico02ceh9i6jgaggcdd
cmgsaiicr02cjh9i6fyvr0spo	/public/images/medium/0f724629-8326-43e6-9834-c8ef792572da-1760550837981.webp	800	564	webp	85	51478	cmgsaiico02ceh9i6jgaggcdd
cmgsaiicr02chh9i6iyx9w321	/public/images/thumbnails/0f724629-8326-43e6-9834-c8ef792572da-1760550837981.webp	150	150	webp	80	6098	cmgsaiico02ceh9i6jgaggcdd
cmgsaijqa02cph9i62f7mw4lx	/public/images/thumbnails/66088a66-a523-480f-8a6f-b748c5491b65-1760550840291.webp	150	150	webp	80	10092	cmgsaijq602clh9i6855pjfep
cmgsaijqa02crh9i69g7wvzqg	/public/images/full/66088a66-a523-480f-8a6f-b748c5491b65-1760550840291.webp	3560	2371	webp	90	895808	cmgsaijq602clh9i6855pjfep
cmgsaijqa02cqh9i6jqj21jov	/public/images/medium/66088a66-a523-480f-8a6f-b748c5491b65-1760550840291.webp	800	533	webp	85	135742	cmgsaijq602clh9i6855pjfep
cmgsaimc002cwh9i6phsnxd2o	/public/images/medium/97504b45-2211-4eb2-984a-46fbb76aae05-1760550842081.webp	800	539	webp	85	69786	cmgsaimbw02csh9i64xhm479y
cmgsaimc002cyh9i66khip15a	/public/images/full/97504b45-2211-4eb2-984a-46fbb76aae05-1760550842081.webp	5075	3416	webp	90	1592236	cmgsaimbw02csh9i64xhm479y
cmgsainqz02d4h9i6fo8yebnx	/public/images/full/e5dbc709-f044-4bf7-82bc-ee346e01a53c-1760550845447.webp	3420	2823	webp	90	674484	cmgsainqw02czh9i6pjkq4zzd
cmgsainqz02d5h9i68wgl965m	/public/images/thumbnails/e5dbc709-f044-4bf7-82bc-ee346e01a53c-1760550845447.webp	150	150	webp	80	7354	cmgsainqw02czh9i6pjkq4zzd
cmgsaip3a02dbh9i6c8c7r1lw	/public/images/full/c696eec3-bdb2-4f30-a9c0-db58015c6a63-1760550847275.webp	3326	2698	webp	90	661452	cmgsaip3502d6h9i6v6czgp7h
cmgsaip3a02dch9i6nzu3iztx	/public/images/medium/c696eec3-bdb2-4f30-a9c0-db58015c6a63-1760550847275.webp	800	649	webp	85	84528	cmgsaip3502d6h9i6v6czgp7h
cmgsaiqbh02dhh9i6lkfdapav	/public/images/full/c316ac4c-6608-4caa-b277-39babe7d30ae-1760550849012.webp	3326	2605	webp	90	706170	cmgsaiqbb02ddh9i6m31jn43q
cmgsaiqbh02dih9i60bv7lvd1	/public/images/thumbnails/c316ac4c-6608-4caa-b277-39babe7d30ae-1760550849012.webp	150	150	webp	80	9712	cmgsaiqbb02ddh9i6m31jn43q
cmgsairqd02doh9i64a44jtgd	/public/images/medium/506dac98-ca22-4831-bb05-609c9a691566-1760550850612.webp	800	649	webp	85	96548	cmgsairq802dkh9i620lzjqq8
cmgsairqd02dqh9i6gzaxssnd	/public/images/full/506dac98-ca22-4831-bb05-609c9a691566-1760550850612.webp	3326	2698	webp	90	708602	cmgsairq802dkh9i620lzjqq8
cmgsaisw702dth9i69w3f8hsp	/public/images/medium/41bcfb70-269a-4740-bfec-bf1fae941a5a-1760550852436.webp	800	785	webp	85	121008	cmgsaisw202drh9i6jpj67qy4
cmgsaisw702dvh9i60sps2nxz	/public/images/full/41bcfb70-269a-4740-bfec-bf1fae941a5a-1760550852436.webp	2608	2558	webp	90	671022	cmgsaisw202drh9i6jpj67qy4
cmgsaiudw02e2h9i69vusgs58	/public/images/full/7a71f8b6-dadf-4e15-b76b-127eb12d5b78-1760550853946.webp	2608	3447	webp	90	771780	cmgsaiudu02dyh9i6vausjrpb
cmgsaiudw02e3h9i6hzcunmg9	/public/images/medium/7a71f8b6-dadf-4e15-b76b-127eb12d5b78-1760550853946.webp	800	1057	webp	85	177374	cmgsaiudu02dyh9i6vausjrpb
cmgsaivoi02eah9i6sci3c7el	/public/images/thumbnails/940bbe04-7140-482a-ad56-a969c741427c-1760550855880.webp	150	150	webp	80	9656	cmgsaivoc02e5h9i60j4z2zs8
cmgsaivoi02e9h9i64o0bv8ej	/public/images/medium/940bbe04-7140-482a-ad56-a969c741427c-1760550855880.webp	800	659	webp	85	91288	cmgsaivoc02e5h9i60j4z2zs8
cmgsaiwzt02eih9i61hpr0rz7	/public/images/full/e7bfa00b-cc85-4b3d-8414-7369dffbe76d-1760550857554.webp	3623	2589	webp	90	696810	cmgsaiwzq02ech9i6ugff8wkj
cmgs9k1sa007dh9i61s7ek177	/public/images/medium/b656abaa-bc12-4d5c-b376-09cf3a705822-1760549212887.webp	800	509	webp	85	111334	cmgs9k1s60077h9i6x29jv17v
cmgs9klfw007gh9i6gexlaqb4	/public/images/thumbnails/30b3db40-6fa4-4e7f-bcea-420b32165d8f-1760549232529.webp	150	150	webp	80	5736	cmgs9klfr007eh9i6lzk2vxua
cmgs9l4cs007rh9i6b6mref0i	/public/images/full/3e1e627a-001a-4647-bb00-1b9c3428e851-1760549258002.webp	8174	5934	webp	90	2832886	cmgs9l4cq007lh9i6ec1a72wv
cmgs9l6y9007xh9i6129xzu69	/public/images/full/1b4f4eaa-dcc6-4350-b720-c86df9897245-1760549282508.webp	5262	3744	webp	90	1195140	cmgs9l6y6007sh9i6je61g624
cmgs9l9r20084h9i60r2byjcw	/public/images/medium/5f09065a-d550-4f05-8621-2f1401b79057-1760549285869.webp	800	1156	webp	85	168778	cmgs9l9r0007zh9i6qfz8z7r2
cmgs9lcir008ch9i6w62g7rux	/public/images/medium/9c25c302-dcbf-421d-b656-85470694320a-1760549289505.webp	800	1156	webp	85	111280	cmgs9lcim0086h9i6qpqoy6jl
cmgs9lfd9008hh9i6m057423v	/public/images/full/623bfa53-58a8-4e8f-a531-7a3157765029-1760549293080.webp	5465	3806	webp	90	1479424	cmgs9lfd5008dh9i6n1gokvbb
cmgs9li0g008qh9i6nmoz13rw	/public/images/medium/180dd959-7fab-4993-aeec-2d28a1b73cc1-1760549296779.webp	800	561	webp	85	109768	cmgs9li0e008kh9i67vsfkqzh
cmgs9lku2008wh9i6635c6qgx	/public/images/full/bf67f494-c57f-4ee5-a05f-344f447137bf-1760549300204.webp	5247	3759	webp	90	1588780	cmgs9lktz008rh9i6zdyba80v
cmgs9lndi0093h9i6uw9tn4au	/public/images/thumbnails/5e97f0bc-f698-4fce-9840-974524f34d6b-1760549303862.webp	150	150	webp	80	6666	cmgs9lndd008yh9i6w5sjl48w
cmgs9lq78009ah9i6jihhxdz6	/public/images/thumbnails/e8f2959b-d91c-455e-a62a-07a23dce86d7-1760549307151.webp	150	150	webp	80	6128	cmgs9lq750095h9i6scqd7t0a
cmgs9lt3u009ih9i6eofuao9t	/public/images/full/7760e8df-8cba-44ae-91b6-1d1537d23d02-1760549310815.webp	3875	5258	webp	90	1353746	cmgs9lt3s009ch9i6mqzjkhyt
cmgs9lw0i009ph9i6w22xodjq	/public/images/full/64b6e68a-f705-4bb7-8d0f-5e62b165aecf-1760549314586.webp	3791	5111	webp	90	1759484	cmgs9lw0g009jh9i6t8046ob2
cmgs9lz0h009sh9i6ej130m4s	/public/images/thumbnails/1e91cfb4-e8c3-4d60-bb7e-433dc12e5445-1760549318346.webp	150	150	webp	80	9246	cmgs9lz0d009qh9i6jolx0f5r
cmgs9lz14009wh9i6if7ff83b	/public/images/medium/1e91cfb4-e8c3-4d60-bb7e-433dc12e5445-1760549318346.webp	800	1096	webp	85	206638	cmgs9lz0d009qh9i6jolx0f5r
cmgs9m12z00a1h9i6au90vylk	/public/images/full/430f025b-af99-4c6d-988d-c1bb95d5607f-1760549322254.webp	4544	3166	webp	90	989356	cmgs9m12u009xh9i6pi3bxv00
cmgs9m12z00a2h9i63tg1l3y6	/public/images/thumbnails/430f025b-af99-4c6d-988d-c1bb95d5607f-1760549322254.webp	150	150	webp	80	8584	cmgs9m12u009xh9i6pi3bxv00
cmgs9m2h700aah9i6jr915zo1	/public/images/thumbnails/f8b66540-3a8d-46b9-9bc3-37109a29d0dc-1760549324908.webp	150	150	webp	80	6742	cmgs9m2h100a4h9i6vdw4ptra
cmgs9m2h700a8h9i656b41bbu	/public/images/medium/f8b66540-3a8d-46b9-9bc3-37109a29d0dc-1760549324908.webp	800	594	webp	85	62998	cmgs9m2h100a4h9i6vdw4ptra
cmgs9m4h800afh9i6o6sfcqxd	/public/images/full/6867af8b-f22c-4533-8a68-bd8e886a525d-1760549326722.webp	4372	2776	webp	90	1505630	cmgs9m4h300abh9i6u04otk50
cmgs9m4h800ahh9i6h2z5lakk	/public/images/thumbnails/6867af8b-f22c-4533-8a68-bd8e886a525d-1760549326722.webp	150	150	webp	80	8854	cmgs9m4h300abh9i6u04otk50
cmgs9m71u00amh9i6cy2xzsvn	/public/images/full/61d88328-6e37-4e90-b0f4-1b23f98c2891-1760549329326.webp	4771	3443	webp	90	1903716	cmgs9m71q00aih9i6lge5ctr0
cmgs9m71u00aoh9i6jldmwuui	/public/images/medium/61d88328-6e37-4e90-b0f4-1b23f98c2891-1760549329326.webp	800	577	webp	85	136606	cmgs9m71q00aih9i6lge5ctr0
cmgs9m8x700ash9i69e44u0bo	/public/images/thumbnails/81bba4b4-e201-4d1f-86ff-8184b48de931-1760549332656.webp	150	150	webp	80	8540	cmgs9m8x500aph9i6onu38nxf
cmgs9m8x700ath9i658mkcdnr	/public/images/medium/81bba4b4-e201-4d1f-86ff-8184b48de931-1760549332656.webp	800	590	webp	85	70704	cmgs9m8x500aph9i6onu38nxf
cmgs9maax00b0h9i6fy2deq8k	/public/images/medium/ced4ff9c-d65c-417a-8c04-333d7d8b7310-1760549335068.webp	800	643	webp	85	103312	cmgs9maav00awh9i63qrvkcgw
cmgs9maax00b2h9i6kayjzo5l	/public/images/thumbnails/ced4ff9c-d65c-417a-8c04-333d7d8b7310-1760549335068.webp	150	150	webp	80	10872	cmgs9maav00awh9i63qrvkcgw
cmgs9mbly00b6h9i614sirk9d	/public/images/thumbnails/0974834e-ead4-4b2d-b350-e809b60a992d-1760549336863.webp	150	150	webp	80	6208	cmgs9mblv00b3h9i6gnb7oakt
cmgs9mbly00b7h9i66cfu6y1o	/public/images/full/0974834e-ead4-4b2d-b350-e809b60a992d-1760549336863.webp	3326	2605	webp	90	618268	cmgs9mblv00b3h9i6gnb7oakt
cmgs9mbly00b9h9i6w2lqw62h	/public/images/medium/0974834e-ead4-4b2d-b350-e809b60a992d-1760549336863.webp	800	626	webp	85	77880	cmgs9mblv00b3h9i6gnb7oakt
cmgs9mdsw00bfh9i6tg8abve1	/public/images/thumbnails/51f298c6-6e79-43b8-a3aa-32071194a1a5-1760549338562.webp	150	150	webp	80	10602	cmgs9mdst00bah9i6bczbsf3s
cmgs9mdsw00beh9i648ymmrc7	/public/images/medium/51f298c6-6e79-43b8-a3aa-32071194a1a5-1760549338562.webp	800	1178	webp	85	212944	cmgs9mdst00bah9i6bczbsf3s
cmgs9mdsw00bgh9i6shgtvn19	/public/images/full/51f298c6-6e79-43b8-a3aa-32071194a1a5-1760549338562.webp	3016	4441	webp	90	1188052	cmgs9mdst00bah9i6bczbsf3s
cmgs9mfxf00bnh9i6ugjyaqoj	/public/images/medium/1df40c04-2740-4bf9-850b-aa218531690c-1760549341393.webp	800	543	webp	85	89774	cmgs9mfx900bhh9i6g15uh38l
cmgs9mfxf00bkh9i6rmnh4vo6	/public/images/thumbnails/1df40c04-2740-4bf9-850b-aa218531690c-1760549341393.webp	150	150	webp	80	7140	cmgs9mfx900bhh9i6g15uh38l
cmgs9mfxf00blh9i65xlk367o	/public/images/full/1df40c04-2740-4bf9-850b-aa218531690c-1760549341393.webp	4441	3016	webp	90	997228	cmgs9mfx900bhh9i6g15uh38l
cmgs9mhzu00bsh9i6wnd18t2n	/public/images/medium/c92b340e-734e-442f-868d-cc9346627cf5-1760549344161.webp	800	544	webp	85	86804	cmgs9mhzr00boh9i60mgah0f4
cmgs9mhzu00bth9i6liilxngx	/public/images/thumbnails/c92b340e-734e-442f-868d-cc9346627cf5-1760549344161.webp	150	150	webp	80	8382	cmgs9mhzr00boh9i60mgah0f4
cmgs9mhzu00buh9i6dzv9p09d	/public/images/full/c92b340e-734e-442f-868d-cc9346627cf5-1760549344161.webp	4399	2995	webp	90	944892	cmgs9mhzr00boh9i60mgah0f4
cmgs9mjsh00bxh9i6yxom8opv	/public/images/thumbnails/7a19d769-8ed7-4fd2-9bc6-e9e80507d4ff-1760549346828.webp	150	150	webp	80	8136	cmgs9mjsf00bvh9i6115ymr6y
cmgs9mjsh00bzh9i66xah8ssb	/public/images/medium/7a19d769-8ed7-4fd2-9bc6-e9e80507d4ff-1760549346828.webp	800	537	webp	85	121900	cmgs9mjsf00bvh9i6115ymr6y
cmgs9mjsh00c1h9i65dunu7q5	/public/images/full/7a19d769-8ed7-4fd2-9bc6-e9e80507d4ff-1760549346828.webp	3997	2683	webp	90	1265532	cmgs9mjsf00bvh9i6115ymr6y
cmgs9mnq100c4h9i659bm71fx	/public/images/thumbnails/f3abfeea-d6a1-4cdb-9d63-34b28ffe55b4-1760549349172.webp	150	150	webp	80	8420	cmgs9mnpv00c2h9i63hskq66c
cmgs9mnq100c6h9i676xj2cq0	/public/images/full/f3abfeea-d6a1-4cdb-9d63-34b28ffe55b4-1760549349172.webp	6015	4069	webp	90	2073892	cmgs9mnpv00c2h9i63hskq66c
cmgs9mpii00ceh9i6y4u73xnx	/public/images/thumbnails/ffba0830-7a7e-42a5-94e6-e370eff093a8-1760549354248.webp	150	150	webp	80	9440	cmgs9mpif00c9h9i6pry3p0en
cmgs9ms6h00cmh9i6s0gka8k9	/public/images/medium/aefcd4e4-0295-4404-9602-6f18caf889fd-1760549356590.webp	800	540	webp	85	137150	cmgs9ms6e00cgh9i6dejgm64n
cmgsaimc002cxh9i6brt8d6gh	/public/images/thumbnails/97504b45-2211-4eb2-984a-46fbb76aae05-1760550842081.webp	150	150	webp	80	5538	cmgsaimbw02csh9i64xhm479y
cmgsainqz02d3h9i6mu1zhnpg	/public/images/medium/e5dbc709-f044-4bf7-82bc-ee346e01a53c-1760550845447.webp	800	660	webp	85	68970	cmgsainqw02czh9i6pjkq4zzd
cmgsaip3902d8h9i6avjzyz7o	/public/images/thumbnails/c696eec3-bdb2-4f30-a9c0-db58015c6a63-1760550847275.webp	150	150	webp	80	7858	cmgsaip3502d6h9i6v6czgp7h
cmgsaiqbh02djh9i61pyn8amx	/public/images/medium/c316ac4c-6608-4caa-b277-39babe7d30ae-1760550849012.webp	800	626	webp	85	98526	cmgsaiqbb02ddh9i6m31jn43q
cmgsairqd02dph9i6m4lh1nqj	/public/images/thumbnails/506dac98-ca22-4831-bb05-609c9a691566-1760550850612.webp	150	150	webp	80	9262	cmgsairq802dkh9i620lzjqq8
cmgsaisw702dxh9i6k9at34l9	/public/images/thumbnails/41bcfb70-269a-4740-bfec-bf1fae941a5a-1760550852436.webp	150	150	webp	80	9450	cmgsaisw202drh9i6jpj67qy4
cmgsaiudw02e4h9i6f4fxxgww	/public/images/thumbnails/7a71f8b6-dadf-4e15-b76b-127eb12d5b78-1760550853946.webp	150	150	webp	80	8600	cmgsaiudu02dyh9i6vausjrpb
cmgsaivoi02ebh9i6j1rasymv	/public/images/full/940bbe04-7140-482a-ad56-a969c741427c-1760550855880.webp	3123	2573	webp	90	727422	cmgsaivoc02e5h9i60j4z2zs8
cmgsaiwzt02efh9i6iuyfefl8	/public/images/thumbnails/e7bfa00b-cc85-4b3d-8414-7369dffbe76d-1760550857554.webp	150	150	webp	80	7860	cmgsaiwzq02ech9i6ugff8wkj
cmgsaiy6u02eph9i6bbbvgskd	/public/images/medium/f03e6b8a-dcb7-4bae-9dde-0a3c73762480-1760550859262.webp	800	845	webp	85	75302	cmgsaiy6p02ejh9i68g2d4n7y
cmgsaiyyq02euh9i674fz6y7z	/public/images/full/c7419c2e-a9b2-4e86-a45e-23379ea1de14-1760550860806.webp	1530	1528	webp	90	267606	cmgsaiyyg02eqh9i6n078md32
cmgsaj19h02f0h9i6l8c0rmzk	/public/images/thumbnails/9dac6cb3-bf76-4f2e-9f94-26add37fde09-1760550861828.webp	150	150	webp	80	7980	cmgsaj19902exh9i6cl4v9ki4
cmgsaj3po02f9h9i6k38l9tod	/public/images/thumbnails/a4887661-e396-4ff7-ad9d-2cda8a185e01-1760550864810.webp	150	150	webp	80	10714	cmgsaj3ph02f4h9i69nla49nh
cmgsaj5ya02fgh9i6m20tbgy6	/public/images/thumbnails/7a259061-1116-4d89-b361-3aec47c3832c-1760550867985.webp	150	150	webp	80	7694	cmgsaj5y702fbh9i6rufc52fs
cmgsaj79q02fmh9i6n22gr9jf	/public/images/medium/1ccd8ff8-1ff1-4f07-9a2c-7d452b8df544-1760550870868.webp	800	920	webp	85	91342	cmgsaj79k02fih9i642eu08ys
cmgsaj95j02fuh9i6y8t377dn	/public/images/medium/53d723c0-ed12-4cf7-9077-f5cbeb12834e-1760550872578.webp	800	1173	webp	85	96530	cmgsaj95f02fph9i6j1h4wqh7
cmgsajb0l02g2h9i6p5l1dnch	/public/images/thumbnails/9952d0e8-9609-45ac-8743-c44de6fe3c11-1760550875021.webp	150	150	webp	80	10532	cmgsajb0h02fwh9i6mw1b11cn
cmgsajcgh02g6h9i68jxoergc	/public/images/thumbnails/ac94f5f9-3f4e-4c7a-b9be-cb02dd1f438d-1760550877435.webp	150	150	webp	80	9442	cmgsajcgd02g3h9i67j7c5azu
cmgsajdnu02geh9i6d96c9nng	/public/images/full/ecdfac52-ab1e-43ed-874f-8ecf765c07dc-1760550879297.webp	3011	2206	webp	90	511074	cmgsajdnq02gah9i6lg2arlch
cmgsajh5b02gmh9i61ifaa2b0	/public/images/medium/3264663e-314b-48a7-a8a5-d301f6c1d1c3-1760550880867.webp	800	974	webp	85	199142	cmgsajh5802ghh9i6e68mdlnn
cmgsajj8n02guh9i6og7q67g6	/public/images/full/869efe4e-a0f9-4135-bd95-b9a8231bd9ae-1760550885382.webp	2896	3807	webp	90	1673158	cmgsajj8h02goh9i6wxljji9t
cmgsajkua02gyh9i60n5ycdla	/public/images/thumbnails/1af0e4e5-91b9-4378-99ee-ed8da8b9e122-1760550888094.webp	150	150	webp	80	9694	cmgsajku702gvh9i6plga5xrk
cmgsajmes02h8h9i6uf533uy3	/public/images/thumbnails/420a1b92-10f6-4fa2-90cf-314b196be508-1760550890169.webp	150	150	webp	80	10616	cmgsajmeo02h2h9i6k0uqsgya
cmgsajnze02hdh9i65a5dobb6	/public/images/thumbnails/2d7fed67-a2aa-4236-af11-0564edb85afd-1760550892203.webp	150	150	webp	80	10364	cmgsajnz902h9h9i6vvzf1wpw
cmgsajpq602hih9i6p0ravanl	/public/images/thumbnails/8ff7a3e9-8c18-4354-bbb9-baea6b62e4ec-1760550894234.webp	150	150	webp	80	6202	cmgsajpq302hgh9i6v1z203v0
cmgsajrkg02hrh9i65i98sjfq	/public/images/full/ca59bf7b-982e-4d25-9c5f-7aa95521f62f-1760550896495.webp	2732	3666	webp	90	1350194	cmgsajrkc02hnh9i6l97jkkxm
cmgsaju5j02i0h9i6n9uh1z9a	/public/images/full/926130bc-701e-4335-b4e0-e1d0bcb277e3-1760550898901.webp	5075	3744	webp	90	1304158	cmgsaju5g02huh9i63pe2athb
cmgsajvcj02i6h9i6rm0u5hfc	/public/images/thumbnails/58df0916-590d-463b-826a-501b0ea4928c-1760550902233.webp	150	150	webp	80	8786	cmgsajvcf02i1h9i6m4kl7uqb
cmgsajwif02idh9i6x5bq5je7	/public/images/full/b42e0dcd-dafe-4119-bdf6-851eff795894-1760550903782.webp	3170	2027	webp	90	916210	cmgsajwib02i8h9i6fq2o8tjk
cmgsajz1302ijh9i6ouoicgf3	/public/images/full/8f5c216b-0add-4498-bb40-682ed8619042-1760550905296.webp	5012	3509	webp	90	1531718	cmgsajz1002ifh9i6caudywxd
cmgsak1le02ish9i6rga7qywr	/public/images/thumbnails/b9a85601-c086-46a7-9bae-4853d1906678-1760550908569.webp	150	150	webp	80	9394	cmgsak1l802imh9i6rg56vei9
cmgsak32802izh9i6oh97vkbr	/public/images/medium/e8a4e3da-384a-47d7-b3c4-4db773465393-1760550911871.webp	800	575	webp	85	100996	cmgsak32602ith9i65ry6b83v
cmgsak4i402j2h9i6w17ez5i7	/public/images/medium/4f066ca4-2ced-4e0f-a7bc-af2c07a668f7-1760550913779.webp	800	966	webp	85	78016	cmgsak4i202j0h9i6ia801t1g
cmgsak5yr02jdh9i6cckewf4q	/public/images/full/f804a47e-3632-4b3e-9f2c-b2d901af1616-1760550915649.webp	3591	2667	webp	90	807652	cmgsak5yo02j7h9i6cobx2zxb
cmgsak7f502jih9i6w6czgk6u	/public/images/thumbnails/0812991a-1453-4dd1-b14b-7655f1eff7fa-1760550917534.webp	150	150	webp	80	9450	cmgsak7f302jeh9i6277g390r
cmgsaka0z02jph9i6uv5zl4e2	/public/images/full/c1e92ef5-fec6-4283-9c97-503cd19fe330-1760550919433.webp	5012	3619	webp	90	1522824	cmgsaka0u02jlh9i65saeyb2u
cmgsakcrg02jwh9i6h61vhy1g	/public/images/thumbnails/642a74a1-78f5-4b08-ac0f-510f4ff8efa9-1760550922814.webp	150	150	webp	80	5620	cmgsakcrb02jsh9i6bttujrt2
cmgsakfgp02k4h9i654j7xxy5	/public/images/medium/85a3b8c8-549f-4128-8292-0a1aa427c668-1760550926350.webp	800	1120	webp	85	123200	cmgsakfgn02jzh9i6vq6brhnc
cmgsaki7502k8h9i6ynz2t2vc	/public/images/thumbnails/c372b696-6157-4c04-80f0-e3fe10ae281c-1760550929854.webp	150	150	webp	80	7252	cmgsaki7202k6h9i6xtyjn18s
cmgsakjok02kjh9i6svzx17f0	/public/images/thumbnails/05e9055b-e71b-43eb-a56f-5615ac032544-1760550933392.webp	150	150	webp	80	9754	cmgsakjof02kdh9i6qyxar91x
cmgs9mnq100c8h9i68kfnetlg	/public/images/medium/f3abfeea-d6a1-4cdb-9d63-34b28ffe55b4-1760549349172.webp	800	541	webp	85	97022	cmgs9mnpv00c2h9i63hskq66c
cmgs9mpii00cdh9i6mh0w9cwo	/public/images/full/ffba0830-7a7e-42a5-94e6-e370eff093a8-1760549354248.webp	3888	2480	webp	90	1451114	cmgs9mpif00c9h9i6pry3p0en
cmgs9ms6h00clh9i6nhp1jt4r	/public/images/thumbnails/aefcd4e4-0295-4404-9602-6f18caf889fd-1760549356590.webp	150	150	webp	80	12202	cmgs9ms6e00cgh9i6dejgm64n
cmgs9mvaw00cqh9i67l9ufctz	/public/images/medium/c758798a-0678-4895-b556-68053607731e-1760549360027.webp	800	551	webp	85	130246	cmgs9mvaq00cnh9i61nbsmd43
cmgs9mxaa00cyh9i6tuapsust	/public/images/medium/bcfe1862-f64c-44e5-a8be-02a624e7d640-1760549364107.webp	800	654	webp	85	56166	cmgs9mxa500cuh9i6cmskig4r
cmgs9myv100d5h9i6esr8t6cp	/public/images/full/fdd24cac-30dc-4931-8259-3bb92abe2c66-1760549366644.webp	3333	3249	webp	90	654126	cmgs9myuz00d1h9i6c2o7v6hk
cmgs9n0el00deh9i6x22nkn7q	/public/images/full/edcb0992-89c8-4fd8-8335-9b31fd4386d7-1760549368688.webp	3685	2652	webp	90	888384	cmgs9n0ei00d8h9i6sslffg75
cmgs9n1lp00dhh9i6tueexjnn	/public/images/thumbnails/4b760236-a044-4f8a-b6ed-faefdccddb59-1760549370691.webp	150	150	webp	80	6128	cmgs9n1ln00dfh9i6jphtp5ll
cmgs9n2jm00dsh9i6mzo0nrve	/public/images/full/8fd6ce19-8397-403d-8b98-23fd75ebf97a-1760549372243.webp	2342	2215	webp	90	330194	cmgs9n2ji00dmh9i6drv3wjub
cmgs9n3s700dxh9i61q3shht1	/public/images/full/2a8fd181-3a16-4c2a-83de-17e2668d934f-1760549373458.webp	2806	2954	webp	90	463668	cmgs9n3s200dth9i64ywg64gi
cmgs9n5ay00e4h9i6jzxa0cld	/public/images/medium/ddbb0018-98d6-434b-97d3-84e48825a476-1760549375060.webp	800	522	webp	85	57830	cmgs9n5aw00e0h9i6ab4l0x4f
cmgs9n6xs00ebh9i6p8uu6m1t	/public/images/full/e5cf10ca-041f-48e4-a519-856c61b20e1f-1760549377046.webp	2529	3946	webp	90	820376	cmgs9n6xq00e7h9i6b50wma8q
cmgs9n9fd00ehh9i6u3q48zq9	/public/images/thumbnails/4c479f3c-e1f0-459f-ae00-d02b13294ca2-1760549379168.webp	150	150	webp	80	9436	cmgs9n9f800eeh9i6wop308js
cmgs9naw200eqh9i6kvnltv8i	/public/images/full/16ecf41b-98bc-4082-a038-fa35c91c6225-1760549382385.webp	3232	2573	webp	90	985442	cmgs9navy00elh9i6q2oj31ux
cmgs9ncau00exh9i6n1ay25jt	/public/images/thumbnails/1dd66e56-a52c-4a29-ba68-ff15ad91ba6f-1760549384283.webp	150	150	webp	80	9820	cmgs9ncar00esh9i62jra23iy
cmgs9ndp600f3h9i6u8b75j9e	/public/images/thumbnails/77665f03-fd5a-4633-8b31-6fac16068c95-1760549386109.webp	150	150	webp	80	10834	cmgs9ndp100ezh9i6d60bn2x2
cmgs9o28l00fch9i6pq0xhgd4	/public/images/medium/4ddfef84-a4e5-49ef-b6cb-4032a1cb39d0-1760549387991.webp	800	1048	webp	85	195886	cmgs9o28d00f6h9i62lrn5noo
cmgs9o2hc00fjh9i6gnzb8t1k	/public/images/thumbnails/b7fb5b84-2d8f-4b14-a268-bc171bd39d21-1760549417998.webp	150	150	webp	80	7256	cmgs9o2h800fdh9i6kjt674wk
cmgs9o51k00fqh9i698hpkoyp	/public/images/medium/0de50c83-331d-45e6-a6f8-79b5a729ebb6-1760549420047.webp	800	551	webp	85	81530	cmgs9o51i00fkh9i6sf9yvfvu
cmgs9oklt00fwh9i6s935raoo	/public/images/full/ad907110-8276-4de3-acf0-55eb4d9c56eb-1760549423374.webp	6817	5091	webp	90	4161906	cmgs9oklr00frh9i6859zc3mi
cmgs9omj200g4h9i6t280xu6q	/public/images/full/8af43465-1bf7-4dde-ace9-a1c36996604d-1760549443523.webp	4497	2674	webp	90	1142128	cmgs9omiy00fyh9i6jd5xlzn4
cmgs9ooqi00gah9i6nfet7761	/public/images/medium/993ee57c-233b-40fc-9ebc-a22288521e36-1760549446014.webp	800	536	webp	85	86154	cmgs9ooqe00g5h9i60d6tw5cd
cmgs9ot2100gih9i6g72zpn21	/public/images/medium/59f02a30-7203-4257-b1ba-e19cd1d7ab8f-1760549448884.webp	800	595	webp	85	69580	cmgs9ot1z00gch9i6v799nizk
cmgsaiwzt02ehh9i6z813y6ng	/public/images/medium/e7bfa00b-cc85-4b3d-8414-7369dffbe76d-1760550857554.webp	800	572	webp	85	72030	cmgsaiwzq02ech9i6ugff8wkj
cmgsaiy6u02emh9i6m34fpwxd	/public/images/thumbnails/f03e6b8a-dcb7-4bae-9dde-0a3c73762480-1760550859262.webp	150	150	webp	80	6248	cmgsaiy6p02ejh9i68g2d4n7y
cmgsaiyyq02ewh9i6l45bpn95	/public/images/thumbnails/c7419c2e-a9b2-4e86-a45e-23379ea1de14-1760550860806.webp	150	150	webp	80	4620	cmgsaiyyg02eqh9i6n078md32
cmgsaj19j02f3h9i6x1bhgyvg	/public/images/full/9dac6cb3-bf76-4f2e-9f94-26add37fde09-1760550861828.webp	2561	3712	webp	90	837438	cmgsaj19902exh9i6cl4v9ki4
cmgsaj3po02fah9i6n6ekgpem	/public/images/full/a4887661-e396-4ff7-ad9d-2cda8a185e01-1760550864810.webp	3591	2589	webp	90	1138652	cmgsaj3ph02f4h9i69nla49nh
cmgsaj5ya02fhh9i62egsh2i1	/public/images/full/7a259061-1116-4d89-b361-3aec47c3832c-1760550867985.webp	2967	4305	webp	90	1111064	cmgsaj5y702fbh9i6rufc52fs
cmgsaj79q02foh9i6n863ir1j	/public/images/full/1ccd8ff8-1ff1-4f07-9a2c-7d452b8df544-1760550870868.webp	2701	3104	webp	90	600462	cmgsaj79k02fih9i642eu08ys
cmgsaj95j02fth9i6c13gqfs4	/public/images/thumbnails/53d723c0-ed12-4cf7-9077-f5cbeb12834e-1760550872578.webp	150	150	webp	80	5850	cmgsaj95f02fph9i6j1h4wqh7
cmgsajb0k02g0h9i6aw18j27d	/public/images/medium/9952d0e8-9609-45ac-8743-c44de6fe3c11-1760550875021.webp	800	563	webp	85	113876	cmgsajb0h02fwh9i6mw1b11cn
cmgsajcgh02g8h9i6wkvn6bhp	/public/images/medium/ac94f5f9-3f4e-4c7a-b9be-cb02dd1f438d-1760550877435.webp	800	551	webp	85	105378	cmgsajcgd02g3h9i67j7c5azu
cmgsajdnu02gdh9i6t04zetc2	/public/images/medium/ecdfac52-ab1e-43ed-874f-8ecf765c07dc-1760550879297.webp	800	586	webp	85	93228	cmgsajdnq02gah9i6lg2arlch
cmgsajh5b02glh9i6r7x0d21w	/public/images/full/3264663e-314b-48a7-a8a5-d301f6c1d1c3-1760550880867.webp	4279	5207	webp	90	2196182	cmgsajh5802ghh9i6e68mdlnn
cmgsajj8m02gth9i6yj65w4qu	/public/images/thumbnails/869efe4e-a0f9-4135-bd95-b9a8231bd9ae-1760550885382.webp	150	150	webp	80	5014	cmgsajj8h02goh9i6wxljji9t
cmgsajkua02h1h9i6zzqqjk3i	/public/images/full/1af0e4e5-91b9-4378-99ee-ed8da8b9e122-1760550888094.webp	3591	2605	webp	90	1157782	cmgsajku702gvh9i6plga5xrk
cmgsajmes02h7h9i6bf5vd5ep	/public/images/full/420a1b92-10f6-4fa2-90cf-314b196be508-1760550890169.webp	3576	2573	webp	90	1024846	cmgsajmeo02h2h9i6k0uqsgya
cmgsajnze02hch9i6o4wdz7v8	/public/images/medium/2d7fed67-a2aa-4236-af11-0564edb85afd-1760550892203.webp	800	578	webp	85	131576	cmgsajnz902h9h9i6vvzf1wpw
cmgsajpq702hmh9i65055jfyt	/public/images/full/8ff7a3e9-8c18-4354-bbb9-baea6b62e4ec-1760550894234.webp	4310	2792	webp	90	1012762	cmgsajpq302hgh9i6v1z203v0
cmgsaqdv90317h9i6bckiaq2r	/public/images/thumbnails/a0a880ec-1cca-4757-80ae-ea3b104d69fe-1760551204779.webp	150	150	webp	80	6640	cmgsaqdv60313h9i6f2ic4owx
cmgsaqgig031gh9i6a0rvwx7w	/public/images/medium/f33421a9-081c-4ce2-804b-4b50b92aa4d3-1760551207728.webp	800	1101	webp	85	162030	cmgsaqgid031ah9i62vkqbx3k
cmgsaqxez031jh9i6fg6ikc6h	/public/images/thumbnails/15f310c4-1c4e-4af7-8ab3-b77aac74dd63-1760551211181.webp	150	150	webp	80	8658	cmgsaqxew031hh9i6q37c51ag
cmgs9mpii00cfh9i6vau68173	/public/images/medium/ffba0830-7a7e-42a5-94e6-e370eff093a8-1760549354248.webp	800	510	webp	85	125568	cmgs9mpif00c9h9i6pry3p0en
cmgs9ms6h00ckh9i69h3xrzt7	/public/images/full/aefcd4e4-0295-4404-9602-6f18caf889fd-1760549356590.webp	5091	3435	webp	90	1786254	cmgs9ms6e00cgh9i6dejgm64n
cmgs9mvaw00crh9i6ndrwumb3	/public/images/thumbnails/c758798a-0678-4895-b556-68053607731e-1760549360027.webp	150	150	webp	80	10094	cmgs9mvaq00cnh9i61nbsmd43
cmgs9mvbf00cth9i6soghqp7s	/public/images/full/c758798a-0678-4895-b556-68053607731e-1760549360027.webp	5075	3494	webp	90	2614722	cmgs9mvaq00cnh9i61nbsmd43
cmgs9mxaa00czh9i68kni0e9u	/public/images/thumbnails/bcfe1862-f64c-44e5-a8be-02a624e7d640-1760549364107.webp	150	150	webp	80	3604	cmgs9mxa500cuh9i6cmskig4r
cmgs9mxaa00d0h9i6ytvhzxp0	/public/images/full/bcfe1862-f64c-44e5-a8be-02a624e7d640-1760549364107.webp	4096	3349	webp	90	947286	cmgs9mxa500cuh9i6cmskig4r
cmgs9myv100d6h9i6rqmn5l7w	/public/images/medium/fdd24cac-30dc-4931-8259-3bb92abe2c66-1760549366644.webp	800	780	webp	85	83682	cmgs9myuz00d1h9i6c2o7v6hk
cmgs9myv100d7h9i6qtwrnejm	/public/images/thumbnails/fdd24cac-30dc-4931-8259-3bb92abe2c66-1760549366644.webp	150	150	webp	80	7314	cmgs9myuz00d1h9i6c2o7v6hk
cmgs9n0ek00dbh9i6j1lxq61a	/public/images/thumbnails/edcb0992-89c8-4fd8-8335-9b31fd4386d7-1760549368688.webp	150	150	webp	80	6180	cmgs9n0ei00d8h9i6sslffg75
cmgs9n0ek00dch9i6jdc5vsiv	/public/images/medium/edcb0992-89c8-4fd8-8335-9b31fd4386d7-1760549368688.webp	800	576	webp	85	72388	cmgs9n0ei00d8h9i6sslffg75
cmgs9n1lp00djh9i6m2bdct1r	/public/images/medium/4b760236-a044-4f8a-b6ed-faefdccddb59-1760549370691.webp	800	604	webp	85	78010	cmgs9n1ln00dfh9i6jphtp5ll
cmgs9n1lp00dlh9i67wyu5kxt	/public/images/full/4b760236-a044-4f8a-b6ed-faefdccddb59-1760549370691.webp	3138	2371	webp	90	613900	cmgs9n1ln00dfh9i6jphtp5ll
cmgs9n2jm00dph9i6lil2oy64	/public/images/thumbnails/8fd6ce19-8397-403d-8b98-23fd75ebf97a-1760549372243.webp	150	150	webp	80	5718	cmgs9n2ji00dmh9i6drv3wjub
cmgs9n2jm00dqh9i6tmvrfvm7	/public/images/medium/8fd6ce19-8397-403d-8b98-23fd75ebf97a-1760549372243.webp	800	757	webp	85	71006	cmgs9n2ji00dmh9i6drv3wjub
cmgs9n3s700dzh9i6yq6zkyue	/public/images/thumbnails/2a8fd181-3a16-4c2a-83de-17e2668d934f-1760549373458.webp	150	150	webp	80	4588	cmgs9n3s200dth9i64ywg64gi
cmgs9n3s700dyh9i6qx47ccwv	/public/images/medium/2a8fd181-3a16-4c2a-83de-17e2668d934f-1760549373458.webp	800	842	webp	85	59478	cmgs9n3s200dth9i64ywg64gi
cmgs9n5ay00e5h9i6cz6zk1ip	/public/images/thumbnails/ddbb0018-98d6-434b-97d3-84e48825a476-1760549375060.webp	150	150	webp	80	6668	cmgs9n5aw00e0h9i6ab4l0x4f
cmgs9n5ay00e6h9i6e11r3jlh	/public/images/full/ddbb0018-98d6-434b-97d3-84e48825a476-1760549375060.webp	3980	2597	webp	90	670396	cmgs9n5aw00e0h9i6ab4l0x4f
cmgs9n6xs00eah9i6br1w3tmh	/public/images/thumbnails/e5cf10ca-041f-48e4-a519-856c61b20e1f-1760549377046.webp	150	150	webp	80	7262	cmgs9n6xq00e7h9i6b50wma8q
cmgs9n6xs00edh9i6v12bjcwt	/public/images/medium/e5cf10ca-041f-48e4-a519-856c61b20e1f-1760549377046.webp	800	1249	webp	85	155524	cmgs9n6xq00e7h9i6b50wma8q
cmgs9n9fd00ekh9i6dz4b3yek	/public/images/full/4c479f3c-e1f0-459f-ae00-d02b13294ca2-1760549379168.webp	4903	3338	webp	90	1504696	cmgs9n9f800eeh9i6wop308js
cmgs9n9fd00eih9i6kmxnghjm	/public/images/medium/4c479f3c-e1f0-459f-ae00-d02b13294ca2-1760549379168.webp	800	545	webp	85	78980	cmgs9n9f800eeh9i6wop308js
cmgs9naw200erh9i6xflzhpi4	/public/images/thumbnails/16ecf41b-98bc-4082-a038-fa35c91c6225-1760549382385.webp	150	150	webp	80	9430	cmgs9navy00elh9i6q2oj31ux
cmgs9naw200eph9i6hutsxniu	/public/images/medium/16ecf41b-98bc-4082-a038-fa35c91c6225-1760549382385.webp	800	637	webp	85	119736	cmgs9navy00elh9i6q2oj31ux
cmgs9ncau00ewh9i6pi03h5ad	/public/images/full/1dd66e56-a52c-4a29-ba68-ff15ad91ba6f-1760549384283.webp	3232	2573	webp	90	930418	cmgs9ncar00esh9i62jra23iy
cmgs9ncau00eyh9i6bqkpqwma	/public/images/medium/1dd66e56-a52c-4a29-ba68-ff15ad91ba6f-1760549384283.webp	800	637	webp	85	117188	cmgs9ncar00esh9i62jra23iy
cmgs9ndp600f4h9i6t9p2jk3e	/public/images/full/77665f03-fd5a-4633-8b31-6fac16068c95-1760549386109.webp	3107	2573	webp	90	979032	cmgs9ndp100ezh9i6d60bn2x2
cmgs9ndp600f5h9i6gyabpt0m	/public/images/medium/77665f03-fd5a-4633-8b31-6fac16068c95-1760549386109.webp	800	662	webp	85	129830	cmgs9ndp100ezh9i6d60bn2x2
cmgs9o28j00f8h9i6vwey3j0o	/public/images/thumbnails/4ddfef84-a4e5-49ef-b6cb-4032a1cb39d0-1760549387991.webp	150	150	webp	80	6668	cmgs9o28d00f6h9i62lrn5noo
cmgs9o28l00fah9i6j9ipuv9e	/public/images/full/4ddfef84-a4e5-49ef-b6cb-4032a1cb39d0-1760549387991.webp	5918	7753	webp	90	10156836	cmgs9o28d00f6h9i62lrn5noo
cmgs9o2hc00fih9i6mcakb4q0	/public/images/full/b7fb5b84-2d8f-4b14-a268-bc171bd39d21-1760549417998.webp	2534	3896	webp	90	1011732	cmgs9o2h800fdh9i6kjt674wk
cmgs9o2hc00fhh9i6009ks1s5	/public/images/medium/b7fb5b84-2d8f-4b14-a268-bc171bd39d21-1760549417998.webp	800	1230	webp	85	208820	cmgs9o2h800fdh9i6kjt674wk
cmgs9o51k00foh9i6barqrtrw	/public/images/full/0de50c83-331d-45e6-a6f8-79b5a729ebb6-1760549420047.webp	5028	3463	webp	90	1592034	cmgs9o51i00fkh9i6sf9yvfvu
cmgs9o51k00fph9i67uxm1e0b	/public/images/thumbnails/0de50c83-331d-45e6-a6f8-79b5a729ebb6-1760549420047.webp	150	150	webp	80	7486	cmgs9o51i00fkh9i6sf9yvfvu
cmgs9oklt00fth9i6pe6he9wj	/public/images/thumbnails/ad907110-8276-4de3-acf0-55eb4d9c56eb-1760549423374.webp	150	150	webp	80	10656	cmgs9oklr00frh9i6859zc3mi
cmgs9oklt00fxh9i6ndxgv83k	/public/images/medium/ad907110-8276-4de3-acf0-55eb4d9c56eb-1760549423374.webp	800	597	webp	85	150590	cmgs9oklr00frh9i6859zc3mi
cmgs9omj200g2h9i664mddfgm	/public/images/medium/8af43465-1bf7-4dde-ace9-a1c36996604d-1760549443523.webp	800	475	webp	85	89126	cmgs9omiy00fyh9i6jd5xlzn4
cmgs9omj200g3h9i6rw2cuums	/public/images/thumbnails/8af43465-1bf7-4dde-ace9-a1c36996604d-1760549443523.webp	150	150	webp	80	8750	cmgs9omiy00fyh9i6jd5xlzn4
cmgs9ooqi00gbh9i63j7v0q97	/public/images/full/993ee57c-233b-40fc-9ebc-a22288521e36-1760549446014.webp	4551	3048	webp	90	1383084	cmgs9ooqe00g5h9i60d6tw5cd
cmgs9ooqi00g9h9i6lzb4jrau	/public/images/thumbnails/993ee57c-233b-40fc-9ebc-a22288521e36-1760549446014.webp	150	150	webp	80	7784	cmgs9ooqe00g5h9i60d6tw5cd
cmgs9ot2100ghh9i6ezk19any	/public/images/thumbnails/59f02a30-7203-4257-b1ba-e19cd1d7ab8f-1760549448884.webp	150	150	webp	80	6430	cmgs9ot1z00gch9i6v799nizk
cmgs9ot2100ggh9i6gmnze80h	/public/images/full/59f02a30-7203-4257-b1ba-e19cd1d7ab8f-1760549448884.webp	6489	4825	webp	90	2306336	cmgs9ot1z00gch9i6v799nizk
cmgs9ovpd00gnh9i6agbr3gdp	/public/images/medium/47b2556a-ed2b-460a-b6f6-95e4d94ac77b-1760549454476.webp	800	541	webp	85	115838	cmgs9ovpb00gjh9i6stafnz0w
cmgs9ovpd00goh9i6ae2xbgne	/public/images/thumbnails/47b2556a-ed2b-460a-b6f6-95e4d94ac77b-1760549454476.webp	150	150	webp	80	9942	cmgs9ovpb00gjh9i6stafnz0w
cmgs9oxyo00gsh9i6llipe06u	/public/images/medium/ac13a25f-33cf-495d-824e-d868a01f7ed7-1760549457908.webp	800	522	webp	85	129608	cmgs9oxyj00gqh9i6ndbg7rcu
cmgs9p0j300h1h9i6umvu8w6q	/public/images/full/1cea5028-45c8-473a-a846-a76d6b1cbe89-1760549460842.webp	5012	3541	webp	90	1466634	cmgs9p0iz00gxh9i6pk77wzil
cmgs9p33100h8h9i6i6yw5idn	/public/images/medium/f7ea2f56-1fdb-49b7-93f5-3c2f32141527-1760549464175.webp	800	560	webp	85	89262	cmgs9p32z00h4h9i62gb2j26u
cmgs9p49800hfh9i6tv7llzbx	/public/images/medium/2594e3e6-0f5e-4d5e-9405-b766b6106461-1760549467471.webp	800	1000	webp	85	151018	cmgs9p49600hbh9i6lhtswx0j
cmgs9p57r00hmh9i624pjyggq	/public/images/full/54b586a5-e703-47e2-9e29-1761901a94fa-1760549468995.webp	1778	2623	webp	90	413528	cmgs9p57m00hih9i655qvvrl0
cmgs9p7ok00hvh9i6xjvha7dw	/public/images/thumbnails/d95a871a-df08-4d87-89e6-f2ceabef1af3-1760549470241.webp	150	150	webp	80	6464	cmgs9p7of00hph9i6o6du1vx2
cmgs9pa7w00hyh9i6bl72b36y	/public/images/full/ad1e9dfb-60f2-4bed-bcf1-388483ec879a-1760549473435.webp	4950	3400	webp	90	1273090	cmgs9pa7q00hwh9i6aizrwfuq
cmgs9pcqk00i7h9i6ss4dd2j4	/public/images/full/0a1ec9e6-25fb-4ec7-aa16-b283c2e96379-1760549476729.webp	5216	3556	webp	90	1161064	cmgs9pcqe00i3h9i64dc3rkg4
cmgs9pgrc00ifh9i6qo06xw4g	/public/images/medium/2f3f6715-ebb2-4efb-87c0-0112bc943a69-1760549479987.webp	800	776	webp	85	122400	cmgs9pgra00iah9i6v01c3byc
cmgs9pj9l00imh9i6ugid8ed2	/public/images/thumbnails/0d2e6aee-5118-43b6-9198-a5abcef200dc-1760549485208.webp	150	150	webp	80	7834	cmgs9pj9h00ihh9i6f9w1a68s
cmgs9pln600ish9i6y7zryy1s	/public/images/thumbnails/24b867f7-4abe-45ac-bce7-c80568038638-1760549488455.webp	150	150	webp	80	8346	cmgs9pln400ioh9i6in6xcxb9
cmgs9q0er00ixh9i69fo49zqa	/public/images/medium/8f4cfcc8-be88-4a23-876c-df58b97cace0-1760549491532.webp	800	614	webp	85	80408	cmgs9q0eo00ivh9i6hxev2a5z
cmgs9qey600j8h9i661gzswxb	/public/images/full/418df027-8ca8-448e-bebe-0cee806ce926-1760549510682.webp	6754	5184	webp	90	2741394	cmgs9qexy00j2h9i6dnykprxz
cmgs9qgfl00jfh9i6vr3blrj0	/public/images/full/5b5c1c5f-8016-4282-a2ad-940e3fc1b955-1760549529512.webp	3587	2592	webp	90	973220	cmgs9qgfh00j9h9i61j6jboey
cmgs9qi2o00jjh9i65vjrmduy	/public/images/thumbnails/895a6277-e353-45b7-b9c1-82f326af3b47-1760549531430.webp	150	150	webp	80	11594	cmgs9qi2m00jgh9i6ow8q5ltb
cmgs9qjnt00jrh9i6zwr2mps2	/public/images/full/636f1ae6-4a74-4f29-8a0f-a5b32b4aa50d-1760549533553.webp	3669	2636	webp	90	807900	cmgs9qjno00jnh9i6pxmzkn4l
cmgs9qm8800k0h9i6k7mz0ak0	/public/images/full/0cedb7c0-31fe-458b-ad9c-145ab1e7722c-1760549535624.webp	5122	3603	webp	90	1393104	cmgs9qm8600juh9i6mhss83si
cmgs9qp5d00k5h9i6bq0vmik7	/public/images/thumbnails/cfd4b464-e630-4e1c-8d97-33a84b31244e-1760549538941.webp	150	150	webp	80	5816	cmgs9qp5900k1h9i6p03oewv0
cmgs9qqz500kch9i6pv61od8f	/public/images/full/197a536a-8b31-453f-a4f1-0a54095c82f1-1760549542725.webp	4357	2745	webp	90	1036568	cmgs9qqz100k8h9i6bxqnm09i
cmgs9r82000klh9i6vyqlcley	/public/images/medium/b6f2e23a-22a5-4fdc-8d24-23ef8271295b-1760549545107.webp	800	596	webp	85	146204	cmgs9r81w00kfh9i6si5d80wh
cmgs9rbyr00krh9i6y88k7h78	/public/images/thumbnails/e1133d5d-9237-42a4-8ff9-8c5b00d60962-1760549567241.webp	150	150	webp	80	7128	cmgs9rbym00kmh9i60ezi1nxf
cmgs9rdrb00kyh9i69d3feu40	/public/images/full/ec39e6e1-6953-4021-9940-80dfa7a458d5-1760549572296.webp	4060	2651	webp	90	1451872	cmgs9rdr500kth9i6cqv4so3p
cmgs9rfic00l6h9i6vi8klo8s	/public/images/thumbnails/ad3cd44f-3375-4531-84e3-d933196a76ca-1760549574616.webp	150	150	webp	80	7724	cmgs9rfi400l0h9i6jflyze0j
cmgs9rhhg00lbh9i693mimbg9	/public/images/medium/1fffb9ee-2e3d-4564-b880-5c8346cc3013-1760549576883.webp	800	562	webp	85	93450	cmgs9rhhe00l7h9i6jn7yzma8
cmgs9riun00lkh9i6l9gvpdkm	/public/images/thumbnails/89360b44-5789-45af-9ea6-69233284ed07-1760549579451.webp	150	150	webp	80	4184	cmgs9riuh00leh9i6nyfpzrqr
cmgs9rjz900lnh9i6tl14mjus	/public/images/medium/f039c190-c0ca-457d-934c-e9b267fb5af4-1760549581215.webp	800	819	webp	85	68628	cmgs9rjz500llh9i68qf46vje
cmgs9rl6500lxh9i64j3a1atn	/public/images/medium/e2318d76-1eef-48f2-ab61-09f4bd907175-1760549582687.webp	800	817	webp	85	64752	cmgs9rl6200lsh9i6m79cd6g6
cmgs9rmmg00m3h9i6nf9gfs63	/public/images/medium/81312702-f11d-425d-90b1-13ae57f0d6ea-1760549584224.webp	800	566	webp	85	75952	cmgs9rmme00lzh9i675uf9mn1
cmgs9roqg00mah9i6wdcbs8je	/public/images/full/cca0c7d3-df49-45f5-a95a-f525f2d8b300-1760549586115.webp	4385	3032	webp	90	1486418	cmgs9roqd00m6h9i62q1ub2i2
cmgs9rrbm00mjh9i65nrinw05	/public/images/medium/70beb6d2-9c73-4bf8-bd8a-3d7aba8d7880-1760549588854.webp	800	557	webp	85	110912	cmgs9rrbj00mdh9i6hbloq3is
cmgs9rue900mqh9i6t7860v5s	/public/images/full/14d6eb87-c4eb-4f6b-bfd4-207b47d620c6-1760549592201.webp	5220	3867	webp	90	1512614	cmgs9rue500mkh9i6f1q8c54b
cmgs9ryse00mth9i67lz6nkpb	/public/images/thumbnails/50e3b3b9-8ea8-49a7-bae5-00a6e289aff1-1760549596203.webp	150	150	webp	80	9118	cmgs9rysc00mrh9i6d4uyif8l
cmgs9s16k00n3h9i6ozgh84al	/public/images/full/530703ff-7dba-4277-a5a4-d370f49c5480-1760549601875.webp	5153	3681	webp	90	863428	cmgs9s16h00myh9i6qq05ivpu
cmgs9s3x500nah9i62csc3rc2	/public/images/medium/87cf1384-4edb-4d5b-a6a8-0a8e013cf4aa-1760549604981.webp	800	584	webp	85	96352	cmgs9s3x300n5h9i6pl9b1gal
cmgs9s62600nfh9i665cxx4y9	/public/images/thumbnails/263f57de-bef9-4814-9b9d-754872a2e432-1760549608533.webp	150	150	webp	80	7460	cmgs9s62200nch9i654yoxl2t
cmgs9s81a00noh9i6nrafzwv5	/public/images/medium/81a2f8d2-9392-4893-9c56-d1041a755bb8-1760549611297.webp	800	517	webp	85	60680	cmgs9s81600njh9i6h1x3e5hv
cmgs9s9vl00nuh9i6ubb85r9q	/public/images/medium/5da159a9-f7ae-451a-89cd-66e4141ffae5-1760549613857.webp	800	538	webp	85	77946	cmgs9s9vh00nqh9i6gs15w5us
cmgs9sctg00o3h9i6skih94he	/public/images/full/b79cae65-e6b3-49ba-9a96-71466449c439-1760549616249.webp	5091	3790	webp	90	1849196	cmgs9scta00nxh9i6n5lse4c5
cmgs9sfsl00o7h9i6lcs5fuxb	/public/images/thumbnails/1395bb81-7b81-4733-ae20-742f8157e243-1760549620068.webp	150	150	webp	80	9908	cmgs9sfsi00o4h9i6mn0n9mz1
cmgs9sinf00ogh9i68e1buvkq	/public/images/full/7ec704e2-1d05-4d35-a388-ccd0477f1d78-1760549623948.webp	5137	3728	webp	90	1645058	cmgs9sina00obh9i6jp2myxdp
cmgs9slcm00omh9i62f2rae1j	/public/images/medium/26046848-8f40-43ac-9390-cb0a2dd404d3-1760549627616.webp	800	555	webp	85	95038	cmgs9slcj00oih9i60msybon3
cmgs9snzn00ovh9i6tlyrx70o	/public/images/full/f2d97f64-9dab-4c4d-b14e-0c59e414dea7-1760549631109.webp	5237	3728	webp	90	1153460	cmgs9snzi00oph9i6w9mldn85
cmgs9ovpd00gph9i6p7u7ibjz	/public/images/full/47b2556a-ed2b-460a-b6f6-95e4d94ac77b-1760549454476.webp	5075	3432	webp	90	1707428	cmgs9ovpb00gjh9i6stafnz0w
cmgs9oxyp00gwh9i67f719kla	/public/images/full/ac13a25f-33cf-495d-824e-d868a01f7ed7-1760549457908.webp	4591	2995	webp	90	2007840	cmgs9oxyj00gqh9i6ndbg7rcu
cmgs9p0j300h3h9i6sqha9uoe	/public/images/thumbnails/1cea5028-45c8-473a-a846-a76d6b1cbe89-1760549460842.webp	150	150	webp	80	9414	cmgs9p0iz00gxh9i6pk77wzil
cmgs9p33100hah9i6905g38vn	/public/images/thumbnails/f7ea2f56-1fdb-49b7-93f5-3c2f32141527-1760549464175.webp	150	150	webp	80	8988	cmgs9p32z00h4h9i62gb2j26u
cmgs9p49800hgh9i62j9akwwv	/public/images/full/2594e3e6-0f5e-4d5e-9405-b766b6106461-1760549467471.webp	2233	2792	webp	90	625214	cmgs9p49600hbh9i6lhtswx0j
cmgs9p57r00hnh9i67p1dy4t5	/public/images/medium/54b586a5-e703-47e2-9e29-1761901a94fa-1760549468995.webp	800	1180	webp	85	134996	cmgs9p57m00hih9i655qvvrl0
cmgs9p7ok00huh9i6vsopcjzd	/public/images/medium/d95a871a-df08-4d87-89e6-f2ceabef1af3-1760549470241.webp	800	565	webp	85	57624	cmgs9p7of00hph9i6o6du1vx2
cmgs9pa7w00i2h9i6ozg80ns2	/public/images/medium/ad1e9dfb-60f2-4bed-bcf1-388483ec879a-1760549473435.webp	800	550	webp	85	91656	cmgs9pa7q00hwh9i6aizrwfuq
cmgs9pcqk00i9h9i6xqt2z12f	/public/images/medium/0a1ec9e6-25fb-4ec7-aa16-b283c2e96379-1760549476729.webp	800	545	webp	85	80054	cmgs9pcqe00i3h9i64dc3rkg4
cmgs9pgrc00ieh9i6fp93q03o	/public/images/thumbnails/2f3f6715-ebb2-4efb-87c0-0112bc943a69-1760549479987.webp	150	150	webp	80	8052	cmgs9pgra00iah9i6v01c3byc
cmgs9pj9l00inh9i6hss1khmw	/public/images/medium/0d2e6aee-5118-43b6-9198-a5abcef200dc-1760549485208.webp	800	548	webp	85	84918	cmgs9pj9h00ihh9i6f9w1a68s
cmgs9pln600iuh9i62he5ieyc	/public/images/full/24b867f7-4abe-45ac-bce7-c80568038638-1760549488455.webp	4934	3509	webp	90	1194142	cmgs9pln400ioh9i6in6xcxb9
cmgs9q0er00j1h9i6o22cmj8y	/public/images/full/8f4cfcc8-be88-4a23-876c-df58b97cace0-1760549491532.webp	6754	5184	webp	90	2740566	cmgs9q0eo00ivh9i6hxev2a5z
cmgs9qey500j4h9i63ud82pyn	/public/images/medium/418df027-8ca8-448e-bebe-0cee806ce926-1760549510682.webp	800	614	webp	85	91136	cmgs9qexy00j2h9i6dnykprxz
cmgs9qgfl00jdh9i6axndmsbg	/public/images/medium/5b5c1c5f-8016-4282-a2ad-940e3fc1b955-1760549529512.webp	800	578	webp	85	114174	cmgs9qgfh00j9h9i61j6jboey
cmgs9qi2o00jmh9i6y2wpe67t	/public/images/full/895a6277-e353-45b7-b9c1-82f326af3b47-1760549531430.webp	3607	2589	webp	90	1146278	cmgs9qi2m00jgh9i6ow8q5ltb
cmgs9qjnt00jth9i6bl5jk2ub	/public/images/medium/636f1ae6-4a74-4f29-8a0f-a5b32b4aa50d-1760549533553.webp	800	575	webp	85	105840	cmgs9qjno00jnh9i6pxmzkn4l
cmgs9qm8800jyh9i6kpep490a	/public/images/thumbnails/0cedb7c0-31fe-458b-ad9c-145ab1e7722c-1760549535624.webp	150	150	webp	80	8096	cmgs9qm8600juh9i6mhss83si
cmgs9qp5d00k7h9i6g4toqa5z	/public/images/medium/cfd4b464-e630-4e1c-8d97-33a84b31244e-1760549538941.webp	800	1094	webp	85	106630	cmgs9qp5900k1h9i6p03oewv0
cmgs9qqz500keh9i6y6hji6j4	/public/images/thumbnails/197a536a-8b31-453f-a4f1-0a54095c82f1-1760549542725.webp	150	150	webp	80	7006	cmgs9qqz100k8h9i6bxqnm09i
cmgs9r81z00khh9i6xsuw3uno	/public/images/thumbnails/b6f2e23a-22a5-4fdc-8d24-23ef8271295b-1760549545107.webp	150	150	webp	80	10376	cmgs9r81w00kfh9i6si5d80wh
cmgs9rbyr00ksh9i63j8jzg2t	/public/images/full/e1133d5d-9237-42a4-8ff9-8c5b00d60962-1760549567241.webp	6472	4713	webp	90	1483008	cmgs9rbym00kmh9i60ezi1nxf
cmgs9rdrb00kxh9i6y5hm7qmc	/public/images/thumbnails/ec39e6e1-6953-4021-9940-80dfa7a458d5-1760549572296.webp	150	150	webp	80	9106	cmgs9rdr500kth9i6cqv4so3p
cmgs9rfic00l4h9i64kotkdzn	/public/images/medium/ad3cd44f-3375-4531-84e3-d933196a76ca-1760549574616.webp	800	541	webp	85	78352	cmgs9rfi400l0h9i6jflyze0j
cmgs9rhhg00ldh9i6c0bjuein	/public/images/full/1fffb9ee-2e3d-4564-b880-5c8346cc3013-1760549576883.webp	4419	3104	webp	90	1025838	cmgs9rhhe00l7h9i6jn7yzma8
cmgs9riun00lih9i6m0tnt8vj	/public/images/full/89360b44-5789-45af-9ea6-69233284ed07-1760549579451.webp	3710	2599	webp	90	589972	cmgs9riuh00leh9i6nyfpzrqr
cmgs9rjzb00lrh9i650m2j1bp	/public/images/full/f039c190-c0ca-457d-934c-e9b267fb5af4-1760549581215.webp	2586	2647	webp	90	499802	cmgs9rjz500llh9i68qf46vje
cmgs9rl6500lyh9i6ei1g99uc	/public/images/thumbnails/e2318d76-1eef-48f2-ab61-09f4bd907175-1760549582687.webp	150	150	webp	80	5092	cmgs9rl6200lsh9i6m79cd6g6
cmgs9rmmg00m5h9i6tt58z4iv	/public/images/full/81312702-f11d-425d-90b1-13ae57f0d6ea-1760549584224.webp	3630	2567	webp	90	699522	cmgs9rmme00lzh9i675uf9mn1
cmgs9roqg00mch9i6wja92vdv	/public/images/thumbnails/cca0c7d3-df49-45f5-a95a-f525f2d8b300-1760549586115.webp	150	150	webp	80	10184	cmgs9roqd00m6h9i62q1ub2i2
cmgs9rrbm00mhh9i6zh8vl52h	/public/images/full/70beb6d2-9c73-4bf8-bd8a-3d7aba8d7880-1760549588854.webp	5049	3513	webp	90	1606752	cmgs9rrbj00mdh9i6hbloq3is
cmgs9rue900mph9i6a7j00u8c	/public/images/medium/14d6eb87-c4eb-4f6b-bfd4-207b47d620c6-1760549592201.webp	800	592	webp	85	98384	cmgs9rue500mkh9i6f1q8c54b
cmgs9rysf00mxh9i667gcqnkf	/public/images/medium/50e3b3b9-8ea8-49a7-bae5-00a6e289aff1-1760549596203.webp	800	583	webp	85	101042	cmgs9rysc00mrh9i6d4uyif8l
cmgs9s16k00n4h9i6xykr73ax	/public/images/medium/530703ff-7dba-4277-a5a4-d370f49c5480-1760549601875.webp	800	571	webp	85	42074	cmgs9s16h00myh9i6qq05ivpu
cmgs9s3x500nbh9i6fqv0ao7i	/public/images/full/87cf1384-4edb-4d5b-a6a8-0a8e013cf4aa-1760549604981.webp	5106	3728	webp	90	1444006	cmgs9s3x300n5h9i6pl9b1gal
cmgs9s62600ngh9i6lmg47k8g	/public/images/medium/263f57de-bef9-4814-9b9d-754872a2e432-1760549608533.webp	800	1192	webp	85	98924	cmgs9s62200nch9i654yoxl2t
cmgs9s81a00nph9i6gda1yfyb	/public/images/full/81a2f8d2-9392-4893-9c56-d1041a755bb8-1760549611297.webp	4560	2948	webp	90	729492	cmgs9s81600njh9i6h1x3e5hv
cmgs9s9vl00nvh9i664e8t8h2	/public/images/full/5da159a9-f7ae-451a-89cd-66e4141ffae5-1760549613857.webp	4450	2995	webp	90	801198	cmgs9s9vh00nqh9i6gs15w5us
cmgs9sctg00o2h9i6j62h8nqv	/public/images/medium/b79cae65-e6b3-49ba-9a96-71466449c439-1760549616249.webp	800	596	webp	85	104210	cmgs9scta00nxh9i6n5lse4c5
cmgsaiy6u02enh9i6bceae27e	/public/images/full/f03e6b8a-dcb7-4bae-9dde-0a3c73762480-1760550859262.webp	2732	2886	webp	90	484152	cmgsaiy6p02ejh9i68g2d4n7y
cmgsaiyyq02evh9i6a5isua2i	/public/images/medium/c7419c2e-a9b2-4e86-a45e-23379ea1de14-1760550860806.webp	800	799	webp	85	103660	cmgsaiyyg02eqh9i6n078md32
cmgsaj19h02f1h9i6ud2v74e7	/public/images/medium/9dac6cb3-bf76-4f2e-9f94-26add37fde09-1760550861828.webp	800	1160	webp	85	149142	cmgsaj19902exh9i6cl4v9ki4
cmgsaj3po02f8h9i6ln3ply8p	/public/images/medium/a4887661-e396-4ff7-ad9d-2cda8a185e01-1760550864810.webp	800	577	webp	85	150186	cmgsaj3ph02f4h9i69nla49nh
cmgs9oxyp00gvh9i6pjhulb7d	/public/images/thumbnails/ac13a25f-33cf-495d-824e-d868a01f7ed7-1760549457908.webp	150	150	webp	80	8776	cmgs9oxyj00gqh9i6ndbg7rcu
cmgs9p0j300h2h9i6kj0e1ssf	/public/images/medium/1cea5028-45c8-473a-a846-a76d6b1cbe89-1760549460842.webp	800	565	webp	85	101848	cmgs9p0iz00gxh9i6pk77wzil
cmgs9p33100h9h9i69mb7t26i	/public/images/full/f7ea2f56-1fdb-49b7-93f5-3c2f32141527-1760549464175.webp	5012	3509	webp	90	1449650	cmgs9p32z00h4h9i62gb2j26u
cmgs9p49800hhh9i6i5xx1lq8	/public/images/thumbnails/2594e3e6-0f5e-4d5e-9405-b766b6106461-1760549467471.webp	150	150	webp	80	8968	cmgs9p49600hbh9i6lhtswx0j
cmgs9p57r00hoh9i6ne33wrd5	/public/images/thumbnails/54b586a5-e703-47e2-9e29-1761901a94fa-1760549468995.webp	150	150	webp	80	6754	cmgs9p57m00hih9i655qvvrl0
cmgs9p7oj00hth9i6pd45jcod	/public/images/full/d95a871a-df08-4d87-89e6-f2ceabef1af3-1760549470241.webp	5012	3541	webp	90	879596	cmgs9p7of00hph9i6o6du1vx2
cmgs9pa7w00i1h9i601389umz	/public/images/thumbnails/ad1e9dfb-60f2-4bed-bcf1-388483ec879a-1760549473435.webp	150	150	webp	80	9526	cmgs9pa7q00hwh9i6aizrwfuq
cmgs9pcqk00i8h9i64lnlrlz9	/public/images/thumbnails/0a1ec9e6-25fb-4ec7-aa16-b283c2e96379-1760549476729.webp	150	150	webp	80	7904	cmgs9pcqe00i3h9i64dc3rkg4
cmgs9pgrc00igh9i66x8lfjw3	/public/images/full/2f3f6715-ebb2-4efb-87c0-0112bc943a69-1760549479987.webp	5387	5225	webp	90	2609732	cmgs9pgra00iah9i6v01c3byc
cmgs9pj9l00ilh9i61if2038u	/public/images/full/0d2e6aee-5118-43b6-9198-a5abcef200dc-1760549485208.webp	5122	3509	webp	90	1359068	cmgs9pj9h00ihh9i6f9w1a68s
cmgs9pln600ith9i65dni600u	/public/images/medium/24b867f7-4abe-45ac-bce7-c80568038638-1760549488455.webp	800	569	webp	85	93362	cmgs9pln400ioh9i6in6xcxb9
cmgs9q0er00j0h9i6jylobxp5	/public/images/thumbnails/8f4cfcc8-be88-4a23-876c-df58b97cace0-1760549491532.webp	150	150	webp	80	6188	cmgs9q0eo00ivh9i6hxev2a5z
cmgs9qey500j6h9i6mwtkff7b	/public/images/thumbnails/418df027-8ca8-448e-bebe-0cee806ce926-1760549510682.webp	150	150	webp	80	5328	cmgs9qexy00j2h9i6dnykprxz
cmgs9qgfl00jeh9i65iwkypvf	/public/images/thumbnails/5b5c1c5f-8016-4282-a2ad-940e3fc1b955-1760549529512.webp	150	150	webp	80	10142	cmgs9qgfh00j9h9i61j6jboey
cmgs9qi2o00jlh9i6hqettfaw	/public/images/medium/895a6277-e353-45b7-b9c1-82f326af3b47-1760549531430.webp	800	574	webp	85	167860	cmgs9qi2m00jgh9i6ow8q5ltb
cmgs9qjnt00jsh9i6w8jjfrlp	/public/images/thumbnails/636f1ae6-4a74-4f29-8a0f-a5b32b4aa50d-1760549533553.webp	150	150	webp	80	8618	cmgs9qjno00jnh9i6pxmzkn4l
cmgs9qm8800jzh9i6mdntzmbi	/public/images/medium/0cedb7c0-31fe-458b-ad9c-145ab1e7722c-1760549535624.webp	800	563	webp	85	76274	cmgs9qm8600juh9i6mhss83si
cmgs9qp5d00k6h9i6bdf7noi4	/public/images/full/cfd4b464-e630-4e1c-8d97-33a84b31244e-1760549538941.webp	3937	5384	webp	90	1244428	cmgs9qp5900k1h9i6p03oewv0
cmgs9qqz400kah9i661by1ccz	/public/images/medium/197a536a-8b31-453f-a4f1-0a54095c82f1-1760549542725.webp	800	504	webp	85	66854	cmgs9qqz100k8h9i6bxqnm09i
cmgs9r82000kjh9i6gily22ja	/public/images/full/b6f2e23a-22a5-4fdc-8d24-23ef8271295b-1760549545107.webp	7121	5300	webp	90	4313316	cmgs9r81w00kfh9i6si5d80wh
cmgs9rbyr00kqh9i6qv7pagc7	/public/images/medium/e1133d5d-9237-42a4-8ff9-8c5b00d60962-1760549567241.webp	800	582	webp	85	57858	cmgs9rbym00kmh9i60ezi1nxf
cmgs9rdrb00kzh9i68iz4aqmu	/public/images/medium/ec39e6e1-6953-4021-9940-80dfa7a458d5-1760549572296.webp	800	522	webp	85	116464	cmgs9rdr500kth9i6cqv4so3p
cmgs9rfic00l5h9i6672n4fsv	/public/images/full/ad3cd44f-3375-4531-84e3-d933196a76ca-1760549574616.webp	4060	2745	webp	90	1205634	cmgs9rfi400l0h9i6jflyze0j
cmgs9rhhg00lah9i6bsofk09r	/public/images/thumbnails/1fffb9ee-2e3d-4564-b880-5c8346cc3013-1760549576883.webp	150	150	webp	80	9374	cmgs9rhhe00l7h9i6jn7yzma8
cmgs9riun00lhh9i6fyc5b1d8	/public/images/medium/89360b44-5789-45af-9ea6-69233284ed07-1760549579451.webp	800	560	webp	85	47314	cmgs9riuh00leh9i6nyfpzrqr
cmgs9rjza00lph9i6td7qcj3j	/public/images/thumbnails/f039c190-c0ca-457d-934c-e9b267fb5af4-1760549581215.webp	150	150	webp	80	5944	cmgs9rjz500llh9i68qf46vje
cmgs9rl6500lwh9i6mo1zdhr8	/public/images/full/e2318d76-1eef-48f2-ab61-09f4bd907175-1760549582687.webp	2746	2807	webp	90	399006	cmgs9rl6200lsh9i6m79cd6g6
cmgs9rmmg00m2h9i67ucotext	/public/images/thumbnails/81312702-f11d-425d-90b1-13ae57f0d6ea-1760549584224.webp	150	150	webp	80	6556	cmgs9rmme00lzh9i675uf9mn1
cmgs9roqg00mbh9i6b9ix34cv	/public/images/medium/cca0c7d3-df49-45f5-a95a-f525f2d8b300-1760549586115.webp	800	553	webp	85	129280	cmgs9roqd00m6h9i62q1ub2i2
cmgs9rrbm00mih9i69dqmo31a	/public/images/thumbnails/70beb6d2-9c73-4bf8-bd8a-3d7aba8d7880-1760549588854.webp	150	150	webp	80	8586	cmgs9rrbj00mdh9i6hbloq3is
cmgs9rue900moh9i62orqv97q	/public/images/thumbnails/14d6eb87-c4eb-4f6b-bfd4-207b47d620c6-1760549592201.webp	150	150	webp	80	8118	cmgs9rue500mkh9i6f1q8c54b
cmgs9rysf00mwh9i6zh6nwnm3	/public/images/full/50e3b3b9-8ea8-49a7-bae5-00a6e289aff1-1760549596203.webp	5862	4268	webp	90	4533072	cmgs9rysc00mrh9i6d4uyif8l
cmgs9s16k00n2h9i6scqxw9ot	/public/images/thumbnails/530703ff-7dba-4277-a5a4-d370f49c5480-1760549601875.webp	150	150	webp	80	4972	cmgs9s16h00myh9i6qq05ivpu
cmgs9s3x500n9h9i6axnq2sq8	/public/images/thumbnails/87cf1384-4edb-4d5b-a6a8-0a8e013cf4aa-1760549604981.webp	150	150	webp	80	7232	cmgs9s3x300n5h9i6pl9b1gal
cmgs9s62600nih9i6n3g12lj0	/public/images/full/263f57de-bef9-4814-9b9d-754872a2e432-1760549608533.webp	3079	4588	webp	90	810300	cmgs9s62200nch9i654yoxl2t
cmgs9s81a00nnh9i6xoyynfic	/public/images/thumbnails/81a2f8d2-9392-4893-9c56-d1041a755bb8-1760549611297.webp	150	150	webp	80	7310	cmgs9s81600njh9i6h1x3e5hv
cmgs9s9vl00nwh9i61phdq3jp	/public/images/thumbnails/5da159a9-f7ae-451a-89cd-66e4141ffae5-1760549613857.webp	150	150	webp	80	7938	cmgs9s9vh00nqh9i6gs15w5us
cmgs9sctf00nzh9i6671utwv3	/public/images/thumbnails/b79cae65-e6b3-49ba-9a96-71466449c439-1760549616249.webp	150	150	webp	80	8652	cmgs9scta00nxh9i6n5lse4c5
cmgs9sfsl00o8h9i6djda385h	/public/images/full/1395bb81-7b81-4733-ae20-742f8157e243-1760549620068.webp	3770	5258	webp	90	1701628	cmgs9sfsi00o4h9i6mn0n9mz1
cmgs9sftc00oah9i6wsposxz3	/public/images/medium/1395bb81-7b81-4733-ae20-742f8157e243-1760549620068.webp	800	1116	webp	85	205986	cmgs9sfsi00o4h9i6mn0n9mz1
cmgs9sinf00ohh9i6q5lgz0pq	/public/images/medium/7ec704e2-1d05-4d35-a388-ccd0477f1d78-1760549623948.webp	800	581	webp	85	118506	cmgs9sina00obh9i6jp2myxdp
cmgs9sinf00ofh9i6m511mdsm	/public/images/thumbnails/7ec704e2-1d05-4d35-a388-ccd0477f1d78-1760549623948.webp	150	150	webp	80	8514	cmgs9sina00obh9i6jp2myxdp
cmgs9slcm00ooh9i68ifk1lcp	/public/images/full/26046848-8f40-43ac-9390-cb0a2dd404d3-1760549627616.webp	5169	3588	webp	90	1351062	cmgs9slcj00oih9i60msybon3
cmgs9slcm00onh9i6lxrcqfss	/public/images/thumbnails/26046848-8f40-43ac-9390-cb0a2dd404d3-1760549627616.webp	150	150	webp	80	8960	cmgs9slcj00oih9i60msybon3
cmgs9snzn00ouh9i6l7abif7e	/public/images/medium/f2d97f64-9dab-4c4d-b14e-0c59e414dea7-1760549631109.webp	800	570	webp	85	54670	cmgs9snzi00oph9i6w9mldn85
cmgs9spvo00oyh9i6lfqiyiwa	/public/images/medium/1783091c-a69d-4bb4-a2c9-3ab83303a3af-1760549634532.webp	800	579	webp	85	45808	cmgs9spvj00owh9i6pcbox0j8
cmgsaj5ya02ffh9i6qa4011vy	/public/images/medium/7a259061-1116-4d89-b361-3aec47c3832c-1760550867985.webp	800	1161	webp	85	155536	cmgsaj5y702fbh9i6rufc52fs
cmgsaj79q02flh9i603lcdie8	/public/images/thumbnails/1ccd8ff8-1ff1-4f07-9a2c-7d452b8df544-1760550870868.webp	150	150	webp	80	6788	cmgsaj79k02fih9i642eu08ys
cmgsaj95j02fvh9i6ohhpl62p	/public/images/full/53d723c0-ed12-4cf7-9077-f5cbeb12834e-1760550872578.webp	2904	4258	webp	90	761206	cmgsaj95f02fph9i6j1h4wqh7
cmgsajb0k02fzh9i6r1w2wb44	/public/images/full/9952d0e8-9609-45ac-8743-c44de6fe3c11-1760550875021.webp	4169	2932	webp	90	1188302	cmgsajb0h02fwh9i6mw1b11cn
cmgsajcgh02g9h9i6pu0fgv9s	/public/images/full/ac94f5f9-3f4e-4c7a-b9be-cb02dd1f438d-1760550877435.webp	3650	2514	webp	90	861158	cmgsajcgd02g3h9i67j7c5azu
cmgsajdnv02ggh9i6y9xshv5g	/public/images/thumbnails/ecdfac52-ab1e-43ed-874f-8ecf765c07dc-1760550879297.webp	150	150	webp	80	7202	cmgsajdnq02gah9i6lg2arlch
cmgsajh5b02gnh9i6ujpa2b4k	/public/images/thumbnails/3264663e-314b-48a7-a8a5-d301f6c1d1c3-1760550880867.webp	150	150	webp	80	11348	cmgsajh5802ghh9i6e68mdlnn
cmgsajj8m02gsh9i6uw0sjomj	/public/images/medium/869efe4e-a0f9-4135-bd95-b9a8231bd9ae-1760550885382.webp	800	1051	webp	85	222870	cmgsajj8h02goh9i6wxljji9t
cmgsajkua02h0h9i6ejju1l2g	/public/images/medium/1af0e4e5-91b9-4378-99ee-ed8da8b9e122-1760550888094.webp	800	580	webp	85	135444	cmgsajku702gvh9i6plga5xrk
cmgsajmes02h6h9i64lapjwpz	/public/images/medium/420a1b92-10f6-4fa2-90cf-314b196be508-1760550890169.webp	800	575	webp	85	140422	cmgsajmeo02h2h9i6k0uqsgya
cmgsajnzf02hfh9i6tq6jyvzj	/public/images/full/2d7fed67-a2aa-4236-af11-0564edb85afd-1760550892203.webp	3607	2605	webp	90	1038016	cmgsajnz902h9h9i6vvzf1wpw
cmgsajpq602hkh9i6cl5ftpi6	/public/images/medium/8ff7a3e9-8c18-4354-bbb9-baea6b62e4ec-1760550894234.webp	800	518	webp	85	52448	cmgsajpq302hgh9i6v1z203v0
cmgsar05p031uh9i6v5ue1sdm	/public/images/full/8a769182-2880-4b35-8de9-abcf0d8bbbf5-1760551233056.webp	5153	3432	webp	90	1975192	cmgsar05i031oh9i6y8uwvaoq
cmgsar2rm0320h9i60lby00ad	/public/images/medium/882b35d5-f349-4b8b-aefe-80445e1bf1fe-1760551236612.webp	800	1190	webp	85	194694	cmgsar2rj031vh9i65uqhtyga
cmgsar56s0328h9i6x77abcja	/public/images/thumbnails/11753bfb-9591-4883-9803-5df264b531ef-1760551239987.webp	150	150	webp	80	6698	cmgsar56m0322h9i6vyft5ybr
cmgsar7k3032dh9i69gyu0a6a	/public/images/full/2a704439-37cc-44b7-a1c2-50ac74d1e320-1760551243130.webp	3351	5091	webp	90	1048296	cmgsar7k00329h9i6bsx0p3v8
cmgsara16032kh9i6p8cavidg	/public/images/medium/6c3a59ee-88db-4d78-a320-d10998925240-1760551246198.webp	800	1216	webp	85	133212	cmgsara12032gh9i680ct0oid
cmgsarclo032rh9i6umm8lm22	/public/images/medium/b074c884-2dcf-48bd-93e1-372f32406dcc-1760551249416.webp	800	1175	webp	85	161982	cmgsarclk032nh9i6mx73z8zy
cmgsardrb032yh9i6oehdec1y	/public/images/medium/6bcc390c-2be3-4cff-a0fa-f8fecaab6d5a-1760551252738.webp	800	794	webp	85	118824	cmgsardr9032uh9i6aj3lc9qr
cmgsarew40336h9i6403tfpmu	/public/images/full/0234bf59-84ea-4147-9763-44bd933abac5-1760551254233.webp	2639	2573	webp	90	573516	cmgsarew20331h9i6yxogsojb
cmgsarg19033ch9i6x64u56sx	/public/images/thumbnails/f2d88f86-b7b7-4c4f-af5d-8c47c58f0672-1760551255701.webp	150	150	webp	80	5706	cmgsarg150338h9i6y90ltdsa
cmgsargz4033lh9i6ngx94t0k	/public/images/thumbnails/facd4e72-c8d1-4101-9bd2-9666fb095782-1760551257183.webp	150	150	webp	80	4346	cmgsargyz033fh9i6vmvyf3rw
cmgsaribu033qh9i6b52gt1z2	/public/images/medium/a937a959-56ce-449f-b6ac-d20265d18aa8-1760551258406.webp	800	731	webp	85	74612	cmgsaribq033mh9i6q1ih2g85
cmgsas686033yh9i6c85fge8k	/public/images/full/36f5bf04-fc2a-4fc5-ba1a-6a810e07131a-1760551260174.webp	8127	5908	webp	90	8967844	cmgsas683033th9i60ri2354f
cmgsas89g0345h9i6gksf1a03	/public/images/thumbnails/47068c6e-e25b-43b5-9053-2ea6c953184a-1760551290191.webp	150	150	webp	80	5708	cmgsas89d0340h9i62izt0uwz
cmgsasb4z034ch9i6ry7z9mnl	/public/images/thumbnails/7cf040d1-b35e-4472-8f97-876c15accc2a-1760551293778.webp	150	150	webp	80	5754	cmgsasb4u0347h9i6gcvvdevp
cmgsasdwr034kh9i6rt97gre4	/public/images/medium/f2892191-f363-498b-9398-5800415f8e35-1760551297498.webp	800	527	webp	85	86216	cmgsasdwn034eh9i6r47tf2q0
cmgsasfi1034ph9i631uxygyh	/public/images/thumbnails/2f25fcdd-962d-4cd9-a6f2-446e943e6ee6-1760551301084.webp	150	150	webp	80	7758	cmgsasfhz034lh9i6tbamb39u
cmgsashs5034xh9i6zc3sn22k	/public/images/medium/80fc5692-e905-4c24-8a1c-0382d54cc4a9-1760551303150.webp	800	554	webp	85	91594	cmgsashs2034sh9i6lwb6r4wq
cmgsasj600354h9i6b72yzusn	/public/images/full/8c5417e5-14ee-4950-89df-ed8f425e45c5-1760551306109.webp	2514	3385	webp	90	669484	cmgsasj5x034zh9i62646f70m
cmgsaskfl035ch9i6tumrxw7f	/public/images/full/aaa09157-70c9-46b5-98f8-9dbb91e20938-1760551307892.webp	3170	2496	webp	90	661144	cmgsaskfh0356h9i6drf8g5uq
cmgsaslrg035jh9i668dzdyfe	/public/images/thumbnails/a5c7be90-deab-4c67-94d7-9d32bd1d84e0-1760551309542.webp	150	150	webp	80	8586	cmgsaslre035dh9i67zukssbv
cmgsaso6z035qh9i60a77zfce	/public/images/full/2543163c-a89f-4562-b56b-61458a6cfc75-1760551311264.webp	4981	3432	webp	90	1465300	cmgsaso6v035kh9i6xrm9heg2
cmgsasplf035xh9i6bjckrsrq	/public/images/medium/8b03174f-b891-4785-8ece-b6cd74be5479-1760551314415.webp	800	537	webp	85	77990	cmgsasplb035rh9i6sqnqyry1
cmgsasqsx0361h9i6ll8spuok	/public/images/thumbnails/b8ae5073-1b8e-4382-b97d-0b525cfdceae-1760551316235.webp	150	150	webp	80	10952	cmgsasqst035yh9i6uoz5uy58
cmgsatwvh039fh9i6wx2m60ty	/public/images/full/afd4ac20-d063-4412-84e3-c33691a0c89e-1760551371126.webp	2545	2090	webp	90	393648	cmgsatwvf0399h9i6daxifeeq
cmgsaty3q039ih9i6s6ifuoro	/public/images/medium/c1b4d5e9-85b4-419a-90f8-7b4351d745d1-1760551372315.webp	800	1128	webp	85	150140	cmgsaty3o039gh9i6un9n8ir8
cmgsatzqm039th9i6eabocz0g	/public/images/medium/95376fd4-5aaf-4ccc-aa70-f06e90d0302c-1760551373917.webp	800	1268	webp	85	151452	cmgsatzqj039nh9i6buqs1ho6
cmgsau1u7039yh9i66yr5s98n	/public/images/thumbnails/ad510812-8167-48f7-9033-b3aa1e13225d-1760551376036.webp	150	150	webp	80	7738	cmgsau1u5039uh9i6yno4rw5z
cmgsau3kj03a6h9i6hg3qtf90	/public/images/medium/585e4107-84e3-4fce-8b7d-8a5949430fc2-1760551378752.webp	800	1273	webp	85	289546	cmgsau3kf03a1h9i6m7usw1y7
cmgs9snzn00oth9i6s6fe64kd	/public/images/thumbnails/f2d97f64-9dab-4c4d-b14e-0c59e414dea7-1760549631109.webp	150	150	webp	80	5378	cmgs9snzi00oph9i6w9mldn85
cmgs9spvq00p0h9i6fb4s0npo	/public/images/thumbnails/1783091c-a69d-4bb4-a2c9-3ab83303a3af-1760549634532.webp	150	150	webp	80	6182	cmgs9spvj00owh9i6pcbox0j8
cmgsajrkg02hqh9i62ostxrss	/public/images/thumbnails/ca59bf7b-982e-4d25-9c5f-7aa95521f62f-1760550896495.webp	150	150	webp	80	8878	cmgsajrkc02hnh9i6l97jkkxm
cmgsaju5j02hxh9i6nl8j84wq	/public/images/thumbnails/926130bc-701e-4335-b4e0-e1d0bcb277e3-1760550898901.webp	150	150	webp	80	6700	cmgsaju5g02huh9i63pe2athb
cmgsajvcj02i5h9i6yx4acql0	/public/images/full/58df0916-590d-463b-826a-501b0ea4928c-1760550902233.webp	3154	1996	webp	90	911648	cmgsajvcf02i1h9i6m4kl7uqb
cmgsajwif02ich9i6llwtvhaw	/public/images/thumbnails/b42e0dcd-dafe-4119-bdf6-851eff795894-1760550903782.webp	150	150	webp	80	8600	cmgsajwib02i8h9i6fq2o8tjk
cmgsajz1402ilh9i641wpwktf	/public/images/thumbnails/8f5c216b-0add-4498-bb40-682ed8619042-1760550905296.webp	150	150	webp	80	9706	cmgsajz1002ifh9i6caudywxd
cmgsak1le02iqh9i6sd2fi912	/public/images/medium/b9a85601-c086-46a7-9bae-4853d1906678-1760550908569.webp	800	560	webp	85	97856	cmgsak1l802imh9i6rg56vei9
cmgsak32802ixh9i60bjj2dyv	/public/images/thumbnails/e8a4e3da-384a-47d7-b3c4-4db773465393-1760550911871.webp	150	150	webp	80	8070	cmgsak32602ith9i65ry6b83v
cmgsak4i402j6h9i67ycbzmye	/public/images/full/4f066ca4-2ced-4e0f-a7bc-af2c07a668f7-1760550913779.webp	2639	3184	webp	90	636812	cmgsak4i202j0h9i6ia801t1g
cmgsak5yr02jch9i6ci3a0qny	/public/images/medium/f804a47e-3632-4b3e-9f2c-b2d901af1616-1760550915649.webp	800	594	webp	85	88588	cmgsak5yo02j7h9i6cobx2zxb
cmgsak7f502jkh9i6y3grm3u4	/public/images/medium/0812991a-1453-4dd1-b14b-7655f1eff7fa-1760550917534.webp	800	566	webp	85	111096	cmgsak7f302jeh9i6277g390r
cmgsaka0z02jqh9i69rvj50ap	/public/images/thumbnails/c1e92ef5-fec6-4283-9c97-503cd19fe330-1760550919433.webp	150	150	webp	80	5924	cmgsaka0u02jlh9i65saeyb2u
cmgsakcrg02jxh9i6g3m2us10	/public/images/full/642a74a1-78f5-4b08-ac0f-510f4ff8efa9-1760550922814.webp	3619	5012	webp	90	1626490	cmgsakcrb02jsh9i6bttujrt2
cmgsakfgp02k5h9i6eep4iwbo	/public/images/full/85a3b8c8-549f-4128-8292-0a1aa427c668-1760550926350.webp	3603	5044	webp	90	1467368	cmgsakfgn02jzh9i6vq6brhnc
cmgsaki7602kch9i6p9s9s2kp	/public/images/full/c372b696-6157-4c04-80f0-e3fe10ae281c-1760550929854.webp	5137	3619	webp	90	1730330	cmgsaki7202k6h9i6xtyjn18s
cmgsakjok02kgh9i61xzalqmr	/public/images/full/05e9055b-e71b-43eb-a56f-5615ac032544-1760550933392.webp	2639	3431	webp	90	752338	cmgsakjof02kdh9i6qyxar91x
cmgsaklho02kph9i66sjgaawr	/public/images/thumbnails/f018b53d-ebd2-4e93-b122-751be8febfc4-1760550935321.webp	150	150	webp	80	7026	cmgsaklhm02kkh9i6czz2f3up
cmgsakn3l02kwh9i6ccav6yd6	/public/images/medium/9d1a886e-9e5e-4bda-956b-b32d40a618a7-1760550937665.webp	800	1067	webp	85	158070	cmgsakn3i02krh9i63sh5x9bz
cmgsakok502l2h9i64v2t58k3	/public/images/thumbnails/9ef3c397-f00f-44cc-839e-d361d33e12d0-1760550939748.webp	150	150	webp	80	10182	cmgsakoju02kyh9i6ohvr22xq
cmgsakqoe02l9h9i6dzo9u7vc	/public/images/medium/0445d48f-0b7d-4046-b5b4-be7ecb695602-1760550941636.webp	800	1137	webp	85	164116	cmgsakqob02l5h9i6aqilybwg
cmgsaks7402lih9i6g3xvwv7l	/public/images/thumbnails/d02c4366-8102-45c4-bf90-464711435da0-1760550944385.webp	150	150	webp	80	6670	cmgsaks7002lch9i61pv4lsu4
cmgsaku1a02lnh9i6x1lblz4v	/public/images/medium/850092a2-57a9-48da-a4b6-2e8fd91468c7-1760550946353.webp	800	547	webp	85	77942	cmgsaku1702ljh9i63520q8i3
cmgsakvzi02luh9i65dn13kyb	/public/images/medium/ab336f90-64e3-4c43-bd52-03f534e87a49-1760550948737.webp	800	529	webp	85	96930	cmgsakvzf02lqh9i6gm6cvs83
cmgsakxdf02m3h9i6bfkdnzqm	/public/images/full/0a8dbb46-e15c-4828-95e9-422107a2904a-1760550951265.webp	3310	2620	webp	90	708284	cmgsakxdc02lxh9i6g16vsyms
cmgsakz8602m7h9i6b6lqt19c	/public/images/full/6004e76e-af9d-4328-8c6f-40f93f0671c5-1760550953060.webp	4216	2917	webp	90	1006974	cmgsakz8302m4h9i6hz0wqb9n
cmgsal0o702mfh9i65zxvz45i	/public/images/full/e14f3f3d-b535-4bec-aee6-7691c909cb27-1760550955464.webp	3263	2683	webp	90	824774	cmgsal0o402mbh9i6nhspy5z8
cmgsal26j02moh9i6p87bk8z8	/public/images/full/a962cb3b-6b9a-4701-b66d-2d88db8837e2-1760550957332.webp	3857	2698	webp	90	790908	cmgsal26h02mih9i60ze8qdpq
cmgsal3hh02mth9i655ci87kn	/public/images/medium/ce1b0b1b-fb6f-41da-bba2-1d194e639ba9-1760550959287.webp	800	787	webp	85	64066	cmgsal3he02mph9i6bm757uum
cmgsal52e02n1h9i6i6lh4tmq	/public/images/medium/1ab32894-38ab-4684-af50-35074c577027-1760550960988.webp	800	580	webp	85	77786	cmgsal52a02mwh9i6pk0ewdsj
cmgsal6pr02n9h9i6rrkbe29o	/public/images/full/b96ea969-0323-4034-9f9e-ba706cb0e5e4-1760550963037.webp	2576	3541	webp	90	1070124	cmgsal6pm02n3h9i6a0uqcrpm
cmgsal8qc02neh9i6usuv462c	/public/images/thumbnails/e8822790-8103-458c-9d15-3a86d05853df-1760550965178.webp	150	150	webp	80	6638	cmgsal8q902nah9i6kclptklp
cmgsala2u02nnh9i6opgs7f45	/public/images/medium/6ee36772-b03c-49fe-a2c3-2d74c4e217ac-1760550967779.webp	800	630	webp	85	62808	cmgsala2r02nhh9i6enw1rnvx
cmgsalbn102nuh9i61dx36tzk	/public/images/full/b0017310-a0c0-4a52-a022-62371dc15de7-1760550969529.webp	2701	3978	webp	90	661790	cmgsalbmy02noh9i65qiqvphx
cmgsalcxz02nzh9i6rssp6q92	/public/images/medium/3a03540a-1adc-4d4a-b7b4-809b16be6d82-1760550971547.webp	800	765	webp	85	62756	cmgsalcxv02nvh9i6d4kjtpxt
cmgsale9n02o6h9i68f126yl0	/public/images/full/3c88ea7d-e0ae-4f23-9dc7-4067d00bb2a3-1760550973234.webp	2857	3073	webp	90	423912	cmgsale9i02o2h9i6mqo66z3j
cmgsalgb602oeh9i6z91z3dnp	/public/images/thumbnails/1eaac488-502b-420b-9e3f-28ffdc953522-1760550974963.webp	150	150	webp	80	9046	cmgsalgb102o9h9i6t2pq3lln
cmgsalhvh02okh9i6ubgnt6lr	/public/images/thumbnails/21d496b8-0cf8-4c0f-a83d-19c937fb4108-1760550977609.webp	150	150	webp	80	8436	cmgsalhvd02ogh9i6y5noy38l
cmgsaljj602oth9i6d1of5pvs	/public/images/thumbnails/f7ebded5-c1b0-4cc4-b9ea-96f5466f6b32-1760550979636.webp	150	150	webp	80	8156	cmgsaljj202onh9i61jze4xz6
cmgsalmek02ozh9i68yvms9c3	/public/images/thumbnails/f3fc0d31-14ea-4e47-aff4-7667e226b87e-1760550981793.webp	150	150	webp	80	6204	cmgsalmeh02ouh9i6irtjndrg
cmgsaloc602p7h9i64fkkgplk	/public/images/full/710d09c2-cbde-4963-8565-4ef60c9bfc23-1760550985501.webp	4450	3119	webp	90	858512	cmgsaloc002p1h9i60niz1chf
cmgsalq8f02peh9i6q4ernnsj	/public/images/full/ccda0b6d-2ccf-4001-a391-341a96cc2bd2-1760550988012.webp	4497	3088	webp	90	769722	cmgsalq8d02p8h9i6gevxn6qx
cmgsalt7y02pkh9i6uuvu1qsp	/public/images/medium/cc996586-4d28-457c-9aaa-ee5be8aa8625-1760550990470.webp	800	544	webp	85	64322	cmgsalt7t02pfh9i6f6fnxdvp
cmgs9spvr00p2h9i6fvdmyh1f	/public/images/full/1783091c-a69d-4bb4-a2c9-3ab83303a3af-1760549634532.webp	4294	3104	webp	90	734812	cmgs9spvj00owh9i6pcbox0j8
cmgs9srjh00p7h9i6zhfrsxnx	/public/images/thumbnails/f527042d-bb4d-4236-af91-2cc5ff3ab802-1760549636981.webp	150	150	webp	80	7972	cmgs9srjc00p3h9i6fwfgq58j
cmgs9srjh00p6h9i6o775pt9s	/public/images/medium/f527042d-bb4d-4236-af91-2cc5ff3ab802-1760549636981.webp	800	495	webp	85	68216	cmgs9srjc00p3h9i6fwfgq58j
cmgs9srji00p9h9i6cbnnvxpn	/public/images/full/f527042d-bb4d-4236-af91-2cc5ff3ab802-1760549636981.webp	4357	2698	webp	90	743038	cmgs9srjc00p3h9i6fwfgq58j
cmgs9suiv00pgh9i6ot1zqani	/public/images/full/bbce9e90-9f27-4d71-9ac3-c1eef0bbb525-1760549639139.webp	3875	5384	webp	90	1403890	cmgs9suip00pah9i62p3zbxw7
cmgs9suiu00peh9i6p74o9j98	/public/images/thumbnails/bbce9e90-9f27-4d71-9ac3-c1eef0bbb525-1760549639139.webp	150	150	webp	80	3886	cmgs9suip00pah9i62p3zbxw7
cmgs9suiu00pdh9i6k57zqo0v	/public/images/medium/bbce9e90-9f27-4d71-9ac3-c1eef0bbb525-1760549639139.webp	800	1112	webp	85	98276	cmgs9suip00pah9i62p3zbxw7
cmgs9sxfs00pmh9i64p4yzww5	/public/images/medium/e395ce2f-f6a4-4e76-8e98-3de06b0264f0-1760549643008.webp	800	1109	webp	85	114982	cmgs9sxfn00phh9i6wv82y0ii
cmgs9sxfs00plh9i67w5cw7cr	/public/images/thumbnails/e395ce2f-f6a4-4e76-8e98-3de06b0264f0-1760549643008.webp	150	150	webp	80	6820	cmgs9sxfn00phh9i6wv82y0ii
cmgs9sxfs00pnh9i6qclxukan	/public/images/full/e395ce2f-f6a4-4e76-8e98-3de06b0264f0-1760549643008.webp	3749	5195	webp	90	1460994	cmgs9sxfn00phh9i6wv82y0ii
cmgs9t0bb00psh9i68mveztkm	/public/images/thumbnails/64de734c-a4f9-4209-bf7f-870fc9588e3b-1760549646789.webp	150	150	webp	80	8454	cmgs9t0b900poh9i676wxooak
cmgs9t0bb00puh9i61y8054dn	/public/images/medium/64de734c-a4f9-4209-bf7f-870fc9588e3b-1760549646789.webp	800	1113	webp	85	133394	cmgs9t0b900poh9i676wxooak
cmgs9t0bb00pth9i6q9md06ru	/public/images/full/64de734c-a4f9-4209-bf7f-870fc9588e3b-1760549646789.webp	3749	5216	webp	90	1349062	cmgs9t0b900poh9i676wxooak
cmgs9t1r400pxh9i6my8psk63	/public/images/thumbnails/ad1715ac-c16b-4502-a397-3a2c5859643b-1760549650509.webp	150	150	webp	80	4222	cmgs9t1r200pvh9i6b1edsgv8
cmgs9t1r500q1h9i6i81nnb2d	/public/images/medium/ad1715ac-c16b-4502-a397-3a2c5859643b-1760549650509.webp	800	578	webp	85	38328	cmgs9t1r200pvh9i6b1edsgv8
cmgs9t1r500pzh9i691uik6tp	/public/images/full/ad1715ac-c16b-4502-a397-3a2c5859643b-1760549650509.webp	3779	2730	webp	90	482896	cmgs9t1r200pvh9i6b1edsgv8
cmgs9t4fy00q6h9i6hoxvw8w6	/public/images/thumbnails/e12a1fd5-9646-4ece-9007-0a469ac77653-1760549652372.webp	150	150	webp	80	9080	cmgs9t4fv00q2h9i6cu9y3xmn
cmgs9t4fy00q5h9i6t31bzmi8	/public/images/medium/e12a1fd5-9646-4ece-9007-0a469ac77653-1760549652372.webp	800	571	webp	85	72894	cmgs9t4fv00q2h9i6cu9y3xmn
cmgs9t4fy00q8h9i6td28izz4	/public/images/full/e12a1fd5-9646-4ece-9007-0a469ac77653-1760549652372.webp	5153	3681	webp	90	1354682	cmgs9t4fv00q2h9i6cu9y3xmn
cmgs9t5h500qeh9i6zzln6v0u	/public/images/medium/fd9257d1-9dd3-4a67-8c2b-7ea845afc7b2-1760549655860.webp	800	654	webp	85	97866	cmgs9t5h100q9h9i6emdsx27s
cmgs9t5h500qfh9i6532phg30	/public/images/full/fd9257d1-9dd3-4a67-8c2b-7ea845afc7b2-1760549655860.webp	2592	2121	webp	90	612902	cmgs9t5h100q9h9i6emdsx27s
cmgs9t5h500qdh9i6ikrplxfe	/public/images/thumbnails/fd9257d1-9dd3-4a67-8c2b-7ea845afc7b2-1760549655860.webp	150	150	webp	80	5240	cmgs9t5h100q9h9i6emdsx27s
cmgs9t6ia00qlh9i63nyc83cp	/public/images/medium/ea54af6c-8ef9-4c77-81ed-3c0f8c27734e-1760549657191.webp	800	671	webp	85	108170	cmgs9t6i600qgh9i60wzih96o
cmgs9t6ia00qkh9i6kgmjkv2q	/public/images/full/ea54af6c-8ef9-4c77-81ed-3c0f8c27734e-1760549657191.webp	2623	2199	webp	90	681968	cmgs9t6i600qgh9i60wzih96o
cmgs9t6ia00qmh9i6wsn23n6c	/public/images/thumbnails/ea54af6c-8ef9-4c77-81ed-3c0f8c27734e-1760549657191.webp	150	150	webp	80	7046	cmgs9t6i600qgh9i60wzih96o
cmgs9t9ah00qsh9i6l1081bs8	/public/images/full/90cbdefe-4cdc-4675-a141-1f293d268ea3-1760549658531.webp	3806	5169	webp	90	1469030	cmgs9t9af00qnh9i64ei2l7c0
cmgs9t9ah00qrh9i6wt6k0s53	/public/images/thumbnails/90cbdefe-4cdc-4675-a141-1f293d268ea3-1760549658531.webp	150	150	webp	80	6210	cmgs9t9af00qnh9i64ei2l7c0
cmgs9t9ah00qth9i6o3td64vn	/public/images/medium/90cbdefe-4cdc-4675-a141-1f293d268ea3-1760549658531.webp	800	1086	webp	85	138538	cmgs9t9af00qnh9i64ei2l7c0
cmgs9tazy00qyh9i6ai3rkudd	/public/images/medium/48c5fbf2-6c18-4fb5-949f-c73a31c6758c-1760549662142.webp	800	988	webp	85	144324	cmgs9tazs00quh9i6frwa9qeo
cmgs9tazy00qxh9i6lnueqy52	/public/images/thumbnails/48c5fbf2-6c18-4fb5-949f-c73a31c6758c-1760549662142.webp	150	150	webp	80	9278	cmgs9tazs00quh9i6frwa9qeo
cmgs9tb0f00r0h9i6i2lxzh3s	/public/images/full/48c5fbf2-6c18-4fb5-949f-c73a31c6758c-1760549662142.webp	2953	3645	webp	90	955552	cmgs9tazs00quh9i6frwa9qeo
cmgs9tclm00r5h9i6q03o8yjs	/public/images/full/268edc0a-c531-4cc1-bee9-b9425f907736-1760549664372.webp	3729	2660	webp	90	883248	cmgs9tclg00r1h9i6z16937c4
cmgs9tclm00r7h9i6in780r0h	/public/images/thumbnails/268edc0a-c531-4cc1-bee9-b9425f907736-1760549664372.webp	150	150	webp	80	9256	cmgs9tclg00r1h9i6z16937c4
cmgs9tclm00r6h9i6wy5uxtea	/public/images/medium/268edc0a-c531-4cc1-bee9-b9425f907736-1760549664372.webp	800	571	webp	85	100820	cmgs9tclg00r1h9i6z16937c4
cmgs9ted600reh9i6fft4v5uv	/public/images/medium/8a8bad9f-f049-45c2-b9b6-8f01e536f2eb-1760549666428.webp	800	544	webp	85	50604	cmgs9ted200r8h9i69ixdtir5
cmgs9ted600rdh9i6uyi1na8y	/public/images/thumbnails/8a8bad9f-f049-45c2-b9b6-8f01e536f2eb-1760549666428.webp	150	150	webp	80	6038	cmgs9ted200r8h9i69ixdtir5
cmgs9ted600rch9i6b2ry1ma5	/public/images/full/8a8bad9f-f049-45c2-b9b6-8f01e536f2eb-1760549666428.webp	4247	2885	webp	90	780790	cmgs9ted200r8h9i69ixdtir5
cmgs9tfr100rjh9i6jxczh2i2	/public/images/thumbnails/ff6ae86e-842c-4690-ba51-c173c7a193b4-1760549668712.webp	150	150	webp	80	9474	cmgs9tfqw00rfh9i6rh43360q
cmgs9tfr100rlh9i6du21jsg8	/public/images/medium/ff6ae86e-842c-4690-ba51-c173c7a193b4-1760549668712.webp	800	624	webp	85	96810	cmgs9tfqw00rfh9i6rh43360q
cmgs9tfr100rkh9i6ucbofkpi	/public/images/full/ff6ae86e-842c-4690-ba51-c173c7a193b4-1760549668712.webp	3279	2558	webp	90	755382	cmgs9tfqw00rfh9i6rh43360q
cmgs9tho900roh9i6f1thl1ka	/public/images/thumbnails/152aa4f2-6c55-4f0a-b643-505058d4b2b6-1760549670508.webp	150	150	webp	80	8380	cmgs9tho100rmh9i6h6pv5bw8
cmgs9tho900rqh9i62of5ss47	/public/images/full/152aa4f2-6c55-4f0a-b643-505058d4b2b6-1760549670508.webp	2901	4341	webp	90	1043972	cmgs9tho100rmh9i6h6pv5bw8
cmgs9thoa00rsh9i671e7fuo0	/public/images/medium/152aa4f2-6c55-4f0a-b643-505058d4b2b6-1760549670508.webp	800	1197	webp	85	176560	cmgs9tho100rmh9i6h6pv5bw8
cmgs9tk8p00rwh9i6h7zvwfri	/public/images/thumbnails/e271c359-e864-4603-9bf0-763eb2ef098b-1760549673003.webp	150	150	webp	80	7472	cmgs9tk8l00rth9i674ff62fv
cmgs9tl7l00s5h9i6pyoffvn8	/public/images/medium/6e2b491f-b9fe-4307-be68-5fcaeafd55c6-1760549676328.webp	800	576	webp	85	106308	cmgs9tl7i00s0h9i6pp9tvwmx
cmgs9tml900sdh9i6a81plo5t	/public/images/full/c6937ee2-e673-41a9-9afe-bfdacd4c7547-1760549677591.webp	3263	2605	webp	90	678662	cmgs9tml500s7h9i6ntbgoq7d
cmgs9tot000skh9i6sh6u0soz	/public/images/thumbnails/ede3978b-bbf4-4143-969d-49e627d8096e-1760549679383.webp	150	150	webp	80	7356	cmgs9tosw00seh9i6vwketcuk
cmgs9tpsa00sph9i6pp6n0omm	/public/images/thumbnails/f3a2a3ec-ed54-4562-b3f6-f9f6bfaf08c6-1760549682252.webp	150	150	webp	80	5678	cmgs9tps300slh9i669v3dudh
cmgs9tr8z00swh9i6nfxlksap	/public/images/medium/db190729-aac0-4d8c-a63a-473dadba9a1c-1760549683514.webp	800	1120	webp	85	131714	cmgs9tr8x00ssh9i65nh2afri
cmgs9tsj800t2h9i6nz6hmw8r	/public/images/thumbnails/9ba099c4-51ca-4323-a4a3-9ad96698d84b-1760549685410.webp	150	150	webp	80	7236	cmgs9tsj600szh9i6a94ujl66
cmgs9tv8h00tah9i6hua504g0	/public/images/full/9316dca5-ff74-48a5-b8ed-e6c20595d1cd-1760549687085.webp	3623	5049	webp	90	1373710	cmgs9tv8c00t6h9i6kuzrcbxb
cmgs9tw8o00tjh9i61c7nlmpk	/public/images/full/ac8988b1-d2a3-49d8-b7a1-2b56425d9b00-1760549690585.webp	2280	2371	webp	90	419518	cmgs9tw8k00tdh9i6zqr170oc
cmgs9txpl00tph9i6uuapp0l5	/public/images/medium/56bd93b7-992f-4267-888b-e3054e275a70-1760549691877.webp	800	581	webp	85	102190	cmgs9txpi00tkh9i645nrbl20
cmgs9tysx00txh9i60ra31uy8	/public/images/thumbnails/40c9572d-7a94-461c-a42f-56a16ff26aec-1760549693789.webp	150	150	webp	80	7450	cmgs9tyss00trh9i665yzxhv5
cmgs9u1l100u3h9i6vp8xk82a	/public/images/thumbnails/9e0286f1-159a-45aa-aba1-98e97f06cdf6-1760549695209.webp	150	150	webp	80	7782	cmgs9u1ky00tyh9i6msm1fve7
cmgs9u3kb00uah9i680cunt7g	/public/images/medium/aecab2d8-8941-4596-a26b-6745c2f9ea41-1760549698810.webp	800	576	webp	85	66442	cmgs9u3k900u5h9i6xlgrsnir
cmgs9u6b700uhh9i6ayw7s7hl	/public/images/thumbnails/54e9b6e1-0c51-4461-b704-2e03f26324d5-1760549701391.webp	150	150	webp	80	11328	cmgs9u6b300uch9i6m35rahyp
cmgs9u7tf00unh9i6y2npqiah	/public/images/medium/65bb31cf-2de1-4e54-bb78-2b7b17131646-1760549704928.webp	800	1232	webp	85	135220	cmgs9u7ta00ujh9i6usf8tv6w
cmgs9u9ee00uwh9i6o7jwxftk	/public/images/full/101f982a-fa28-46bb-90b7-a0aa5b2330d5-1760549706880.webp	3888	2605	webp	90	812578	cmgs9u9eb00uqh9i6m7t82iwp
cmgs9uab100v1h9i6bboofyr2	/public/images/full/73098897-7f79-4df9-9012-837a3a46268b-1760549708932.webp	2561	1981	webp	90	404280	cmgs9uaaw00uxh9i6u4ut91m5
cmgs9ubxr00vah9i6btazp8dy	/public/images/full/64e9b221-c779-4850-a321-255724ccc196-1760549710110.webp	3212	3369	webp	90	783526	cmgs9ubxp00v4h9i62srn25lo
cmgs9udvv00vgh9i6evpqe0ff	/public/images/thumbnails/bb0f8c32-18f5-436a-be59-d5a58b17b9f0-1760549712225.webp	150	150	webp	80	4226	cmgs9udvr00vbh9i6n9wicxos
cmgs9uet300vnh9i62pu5575x	/public/images/medium/e7d7a8f9-9b24-4fd7-91ae-a4d450a3b6e2-1760549714746.webp	800	1156	webp	85	135180	cmgs9uesy00vih9i6lshaz4hx
cmgs9uhf400vvh9i6bp5muk87	/public/images/thumbnails/10e792b3-0580-4278-b08b-3dd2d501bcbf-1760549715958.webp	150	150	webp	80	6746	cmgs9uhf000vph9i6iuj9noi3
cmgs9uite00w0h9i6l26qbvms	/public/images/thumbnails/0ac1b21f-fd4f-45cc-bd2f-0b82536ff63c-1760549719330.webp	150	150	webp	80	6776	cmgs9uitc00vwh9i6qc2lxvlv
cmgs9ujrh00w6h9i6mam02p60	/public/images/medium/72958d9d-8aa2-40ee-8deb-4bf04ca9c9bb-1760549721140.webp	800	635	webp	85	94718	cmgs9ujrc00w3h9i6u4qow7e0
cmgs9ukn400wfh9i6rirepp8t	/public/images/full/faa743de-15ce-4774-846a-313380ab8160-1760549722361.webp	2764	1950	webp	90	382326	cmgs9ukn200wah9i6hnq8r9rd
cmgs9unl100wkh9i66ymq4t2l	/public/images/full/e76c717f-7093-4589-a485-c43d929bde46-1760549723510.webp	3435	5070	webp	90	2108590	cmgs9unkv00whh9i6mimjx7k1
cmgs9urpd00wsh9i6yil6joxv	/public/images/thumbnails/55c55a8c-57cd-4fd6-b6b1-c5c0bf8db6b1-1760549727318.webp	150	150	webp	80	5948	cmgs9urpb00woh9i6i9pjtt4w
cmgs9uta200wzh9i6rovflmel	/public/images/thumbnails/877fb10b-0e51-4670-814f-2dd715920cca-1760549732664.webp	150	150	webp	80	8754	cmgs9ut9x00wvh9i6boym8e1d
cmgs9uusv00x6h9i6edgr1531	/public/images/thumbnails/2bcbb968-3b5b-4dc8-aa11-f243f75bbbfb-1760549734710.webp	150	150	webp	80	10470	cmgs9uust00x2h9i69av75sa9
cmgs9uwf700xch9i630gtryok	/public/images/medium/0980498e-f136-413e-bc1b-211fcc6b95ea-1760549736673.webp	800	575	webp	85	108844	cmgs9uwf100x9h9i6n0pctlcg
cmgs9v1c800xmh9i60mkc3s1m	/public/images/full/033f9d09-e221-4acf-a123-57ed69b4a595-1760549738778.webp	7758	5099	webp	90	2144000	cmgs9v1c100xgh9i605s06l15
cmgs9v2fr00xrh9i65v3yec9s	/public/images/thumbnails/ba41c34c-c35b-472c-a86c-ade7267ac3e9-1760549745147.webp	150	150	webp	80	5652	cmgs9v2fm00xnh9i691gofbw6
cmgs9v4xg00xyh9i6l5qo2s8i	/public/images/full/92dea022-9121-4f45-b47c-2266e3382f15-1760549746567.webp	4903	3338	webp	90	1363786	cmgs9v4xb00xuh9i6zwytgxe1
cmgs9v7kq00y7h9i69hqvp2sb	/public/images/medium/4251d996-e487-47e9-af9e-37e8970893df-1760549749800.webp	800	1161	webp	85	200760	cmgs9v7kn00y1h9i6r11ekh7s
cmgs9v9zo00ydh9i6txkxrlbe	/public/images/medium/a04598fa-a3be-464b-83e2-93f3410bd30f-1760549753230.webp	800	538	webp	85	101912	cmgs9v9zm00y8h9i6lhflaso4
cmgsajrkz02hth9i6ot6k9d20	/public/images/medium/ca59bf7b-982e-4d25-9c5f-7aa95521f62f-1760550896495.webp	800	1073	webp	85	214262	cmgsajrkc02hnh9i6l97jkkxm
cmgsaju5j02hyh9i605jb4qbh	/public/images/medium/926130bc-701e-4335-b4e0-e1d0bcb277e3-1760550898901.webp	800	591	webp	85	81102	cmgsaju5g02huh9i63pe2athb
cmgsajvcj02i7h9i67vuf0kza	/public/images/medium/58df0916-590d-463b-826a-501b0ea4928c-1760550902233.webp	800	506	webp	85	115750	cmgsajvcf02i1h9i6m4kl7uqb
cmgsajwif02ieh9i6sf9rhh02	/public/images/medium/b42e0dcd-dafe-4119-bdf6-851eff795894-1760550903782.webp	800	511	webp	85	114880	cmgsajwib02i8h9i6fq2o8tjk
cmgsajz1302iih9i6co9povrn	/public/images/medium/8f5c216b-0add-4498-bb40-682ed8619042-1760550905296.webp	800	560	webp	85	95654	cmgsajz1002ifh9i6caudywxd
cmgsak1le02iph9i6fa23z4zf	/public/images/full/b9a85601-c086-46a7-9bae-4853d1906678-1760550908569.webp	5012	3509	webp	90	1520782	cmgsak1l802imh9i6rg56vei9
cmgsak32802iyh9i6euw19rsg	/public/images/full/e8a4e3da-384a-47d7-b3c4-4db773465393-1760550911871.webp	3560	2558	webp	90	759178	cmgsak32602ith9i65ry6b83v
cmgsak4i402j5h9i6rg9pw9rt	/public/images/thumbnails/4f066ca4-2ced-4e0f-a7bc-af2c07a668f7-1760550913779.webp	150	150	webp	80	4042	cmgsak4i202j0h9i6ia801t1g
cmgsak5yr02jbh9i6ptootqlt	/public/images/thumbnails/f804a47e-3632-4b3e-9f2c-b2d901af1616-1760550915649.webp	150	150	webp	80	9316	cmgsak5yo02j7h9i6cobx2zxb
cmgs9tk8p00ryh9i6wv12p1wt	/public/images/full/e271c359-e864-4603-9bf0-763eb2ef098b-1760549673003.webp	5044	3463	webp	90	1447960	cmgs9tk8l00rth9i674ff62fv
cmgs9tl7l00s6h9i6ao52q7l1	/public/images/full/6e2b491f-b9fe-4307-be68-5fcaeafd55c6-1760549676328.webp	2686	1934	webp	90	525644	cmgs9tl7i00s0h9i6pp9tvwmx
cmgs9tml800s9h9i6xdgqhs26	/public/images/thumbnails/c6937ee2-e673-41a9-9afe-bfdacd4c7547-1760549677591.webp	150	150	webp	80	8210	cmgs9tml500s7h9i6ntbgoq7d
cmgs9tot000sih9i685ebwrnv	/public/images/full/ede3978b-bbf4-4143-969d-49e627d8096e-1760549679383.webp	4841	3088	webp	90	1360192	cmgs9tosw00seh9i6vwketcuk
cmgs9tpsa00srh9i66xaksl82	/public/images/full/f3a2a3ec-ed54-4562-b3f6-f9f6bfaf08c6-1760549682252.webp	2373	2386	webp	90	367134	cmgs9tps300slh9i669v3dudh
cmgs9tr8z00svh9i6g87lhrgc	/public/images/thumbnails/db190729-aac0-4d8c-a63a-473dadba9a1c-1760549683514.webp	150	150	webp	80	8258	cmgs9tr8x00ssh9i65nh2afri
cmgs9tsj800t5h9i6aov9sceu	/public/images/medium/9ba099c4-51ca-4323-a4a3-9ad96698d84b-1760549685410.webp	800	804	webp	85	133712	cmgs9tsj600szh9i6a94ujl66
cmgs9tv8h00tch9i62hsyq69u	/public/images/medium/9316dca5-ff74-48a5-b8ed-e6c20595d1cd-1760549687085.webp	800	1115	webp	85	151790	cmgs9tv8c00t6h9i6kuzrcbxb
cmgs9tw8o00tih9i6a9nvqsxi	/public/images/medium/ac8988b1-d2a3-49d8-b7a1-2b56425d9b00-1760549690585.webp	800	832	webp	85	88750	cmgs9tw8k00tdh9i6zqr170oc
cmgs9txpl00toh9i6vscxd8hp	/public/images/full/56bd93b7-992f-4267-888b-e3054e275a70-1760549691877.webp	3498	2542	webp	90	900064	cmgs9txpi00tkh9i645nrbl20
cmgs9tysx00tvh9i60wq5los6	/public/images/full/40c9572d-7a94-461c-a42f-56a16ff26aec-1760549693789.webp	2123	2589	webp	90	572420	cmgs9tyss00trh9i665yzxhv5
cmgs9u1l100u2h9i647rbt9bz	/public/images/full/9e0286f1-159a-45aa-aba1-98e97f06cdf6-1760549695209.webp	4997	3416	webp	90	2049322	cmgs9u1ky00tyh9i6msm1fve7
cmgs9u3kb00ubh9i6vutaarpf	/public/images/full/aecab2d8-8941-4596-a26b-6745c2f9ea41-1760549698810.webp	4247	3057	webp	90	1063318	cmgs9u3k900u5h9i6xlgrsnir
cmgs9u6b700uih9i6lr7judsf	/public/images/full/54e9b6e1-0c51-4461-b704-2e03f26324d5-1760549701391.webp	5106	3447	webp	90	2033550	cmgs9u6b300uch9i6m35rahyp
cmgs9u7tg00uph9i6fnnzrhi7	/public/images/thumbnails/65bb31cf-2de1-4e54-bb78-2b7b17131646-1760549704928.webp	150	150	webp	80	6692	cmgs9u7ta00ujh9i6usf8tv6w
cmgs9u9ee00uth9i626g87nz9	/public/images/medium/101f982a-fa28-46bb-90b7-a0aa5b2330d5-1760549706880.webp	800	536	webp	85	88536	cmgs9u9eb00uqh9i6m7t82iwp
cmgs9uab100v2h9i6k3zp2glq	/public/images/medium/73098897-7f79-4df9-9012-837a3a46268b-1760549708932.webp	800	619	webp	85	73584	cmgs9uaaw00uxh9i6u4ut91m5
cmgs9ubxq00v7h9i6ffvlmsba	/public/images/medium/64e9b221-c779-4850-a321-255724ccc196-1760549710110.webp	800	839	webp	85	125732	cmgs9ubxp00v4h9i62srn25lo
cmgs9udvv00vfh9i6k4stt4zm	/public/images/full/bb0f8c32-18f5-436a-be59-d5a58b17b9f0-1760549712225.webp	2764	4243	webp	90	1010818	cmgs9udvr00vbh9i6n9wicxos
cmgs9uet300voh9i6uaciqw9x	/public/images/thumbnails/e7d7a8f9-9b24-4fd7-91ae-a4d450a3b6e2-1760549714746.webp	150	150	webp	80	7548	cmgs9uesy00vih9i6lshaz4hx
cmgs9uhf400vth9i6b3qpzwy4	/public/images/medium/10e792b3-0580-4278-b08b-3dd2d501bcbf-1760549715958.webp	800	1195	webp	85	116650	cmgs9uhf000vph9i6iuj9noi3
cmgs9uite00w1h9i689z8ka6z	/public/images/medium/0ac1b21f-fd4f-45cc-bd2f-0b82536ff63c-1760549719330.webp	800	576	webp	85	90032	cmgs9uitc00vwh9i6qc2lxvlv
cmgs9ujrj00w9h9i6ciyeawjd	/public/images/full/72958d9d-8aa2-40ee-8deb-4bf04ca9c9bb-1760549721140.webp	2592	2059	webp	90	499022	cmgs9ujrc00w3h9i6u4qow7e0
cmgs9ukn400weh9i69fmia8mp	/public/images/medium/faa743de-15ce-4774-846a-313380ab8160-1760549722361.webp	800	564	webp	85	68624	cmgs9ukn200wah9i6hnq8r9rd
cmgs9unl100wlh9i6m847kww6	/public/images/thumbnails/e76c717f-7093-4589-a485-c43d929bde46-1760549723510.webp	150	150	webp	80	9608	cmgs9unkv00whh9i6mimjx7k1
cmgs9urpd00wuh9i66k47mbxz	/public/images/full/55c55a8c-57cd-4fd6-b6b1-c5c0bf8db6b1-1760549727318.webp	7578	4819	webp	90	1157476	cmgs9urpb00woh9i6i9pjtt4w
cmgs9uta200x0h9i68x5zm47v	/public/images/full/877fb10b-0e51-4670-814f-2dd715920cca-1760549732664.webp	3623	2667	webp	90	1107724	cmgs9ut9x00wvh9i6boym8e1d
cmgs9uusv00x8h9i6pbi4gg7a	/public/images/full/2bcbb968-3b5b-4dc8-aa11-f243f75bbbfb-1760549734710.webp	3701	2667	webp	90	926248	cmgs9uust00x2h9i69av75sa9
cmgs9uwf700xfh9i6xtgj7t15	/public/images/thumbnails/0980498e-f136-413e-bc1b-211fcc6b95ea-1760549736673.webp	150	150	webp	80	9240	cmgs9uwf100x9h9i6n0pctlcg
cmgs9v1c600xkh9i67evdtdv4	/public/images/medium/033f9d09-e221-4acf-a123-57ed69b4a595-1760549738778.webp	800	526	webp	85	68200	cmgs9v1c100xgh9i605s06l15
cmgs9v2fr00xth9i6hqb3tcfz	/public/images/medium/ba41c34c-c35b-472c-a86c-ade7267ac3e9-1760549745147.webp	800	559	webp	85	60020	cmgs9v2fm00xnh9i691gofbw6
cmgs9v4xg00xzh9i648q9yi40	/public/images/thumbnails/92dea022-9121-4f45-b47c-2266e3382f15-1760549746567.webp	150	150	webp	80	7582	cmgs9v4xb00xuh9i6zwytgxe1
cmgs9v7kq00y6h9i6n9uxpzj5	/public/images/full/4251d996-e487-47e9-af9e-37e8970893df-1760549749800.webp	3432	4981	webp	90	1418774	cmgs9v7kn00y1h9i6r11ekh7s
cmgs9v9zo00ych9i66384d05o	/public/images/thumbnails/a04598fa-a3be-464b-83e2-93f3410bd30f-1760549753230.webp	150	150	webp	80	7800	cmgs9v9zm00y8h9i6lhflaso4
cmgsak7f502jjh9i6y4u4rvt3	/public/images/full/0812991a-1453-4dd1-b14b-7655f1eff7fa-1760550917534.webp	3638	2573	webp	90	932136	cmgsak7f302jeh9i6277g390r
cmgsaka0z02jrh9i6rydzducv	/public/images/medium/c1e92ef5-fec6-4283-9c97-503cd19fe330-1760550919433.webp	800	577	webp	85	69088	cmgsaka0u02jlh9i65saeyb2u
cmgsakcrg02jyh9i6t00t3rmh	/public/images/medium/642a74a1-78f5-4b08-ac0f-510f4ff8efa9-1760550922814.webp	800	1108	webp	85	145180	cmgsakcrb02jsh9i6bttujrt2
cmgsakfgp02k3h9i6medmf5n6	/public/images/thumbnails/85a3b8c8-549f-4128-8292-0a1aa427c668-1760550926350.webp	150	150	webp	80	6476	cmgsakfgn02jzh9i6vq6brhnc
cmgsaki7602kah9i6c3e7zwy0	/public/images/medium/c372b696-6157-4c04-80f0-e3fe10ae281c-1760550929854.webp	800	563	webp	85	73188	cmgsaki7202k6h9i6xtyjn18s
cmgsakjok02khh9i6v02fuxf4	/public/images/medium/05e9055b-e71b-43eb-a56f-5615ac032544-1760550933392.webp	800	1040	webp	85	148762	cmgsakjof02kdh9i6qyxar91x
cmgsaklho02kqh9i6a0xiwyu7	/public/images/full/f018b53d-ebd2-4e93-b122-751be8febfc4-1760550935321.webp	3685	2995	webp	90	1407290	cmgsaklhm02kkh9i6czz2f3up
cmgsakn3l02kvh9i6hkvq2db0	/public/images/thumbnails/9d1a886e-9e5e-4bda-956b-b32d40a618a7-1760550937665.webp	150	150	webp	80	9128	cmgsakn3i02krh9i63sh5x9bz
cmgsakok502l4h9i65xwkgyqi	/public/images/full/9ef3c397-f00f-44cc-839e-d361d33e12d0-1760550939748.webp	3201	2620	webp	90	929212	cmgsakoju02kyh9i6ohvr22xq
cmgs9tk8p00rzh9i67e28b10s	/public/images/medium/e271c359-e864-4603-9bf0-763eb2ef098b-1760549673003.webp	800	549	webp	85	69306	cmgs9tk8l00rth9i674ff62fv
cmgs9tl7l00s4h9i6ywqpyztn	/public/images/thumbnails/6e2b491f-b9fe-4307-be68-5fcaeafd55c6-1760549676328.webp	150	150	webp	80	9082	cmgs9tl7i00s0h9i6pp9tvwmx
cmgs9tml900sch9i6cdwpfbr7	/public/images/medium/c6937ee2-e673-41a9-9afe-bfdacd4c7547-1760549677591.webp	800	639	webp	85	109250	cmgs9tml500s7h9i6ntbgoq7d
cmgs9tot000sjh9i6x6piz9hq	/public/images/medium/ede3978b-bbf4-4143-969d-49e627d8096e-1760549679383.webp	800	510	webp	85	75460	cmgs9tosw00seh9i6vwketcuk
cmgs9tpsa00sqh9i6qxfro9k6	/public/images/medium/f3a2a3ec-ed54-4562-b3f6-f9f6bfaf08c6-1760549682252.webp	800	804	webp	85	79404	cmgs9tps300slh9i669v3dudh
cmgs9tr9000syh9i6ojkq1nyi	/public/images/full/db190729-aac0-4d8c-a63a-473dadba9a1c-1760549683514.webp	2529	3541	webp	90	601304	cmgs9tr8x00ssh9i65nh2afri
cmgs9tsj800t4h9i6fzyczojs	/public/images/full/9ba099c4-51ca-4323-a4a3-9ad96698d84b-1760549685410.webp	2608	2620	webp	90	843124	cmgs9tsj600szh9i6a94ujl66
cmgs9tv8h00t9h9i6gayln91y	/public/images/thumbnails/9316dca5-ff74-48a5-b8ed-e6c20595d1cd-1760549687085.webp	150	150	webp	80	7854	cmgs9tv8c00t6h9i6kuzrcbxb
cmgs9tw8o00thh9i6ujy7lyp1	/public/images/thumbnails/ac8988b1-d2a3-49d8-b7a1-2b56425d9b00-1760549690585.webp	150	150	webp	80	7306	cmgs9tw8k00tdh9i6zqr170oc
cmgs9txpl00tqh9i63p5tukvy	/public/images/thumbnails/56bd93b7-992f-4267-888b-e3054e275a70-1760549691877.webp	150	150	webp	80	8282	cmgs9txpi00tkh9i645nrbl20
cmgs9tysx00tuh9i6wxci94hh	/public/images/medium/40c9572d-7a94-461c-a42f-56a16ff26aec-1760549693789.webp	800	976	webp	85	144394	cmgs9tyss00trh9i665yzxhv5
cmgs9u1l100u4h9i6qfyb2gd4	/public/images/medium/9e0286f1-159a-45aa-aba1-98e97f06cdf6-1760549695209.webp	800	547	webp	85	94906	cmgs9u1ky00tyh9i6msm1fve7
cmgs9u3kb00u9h9i6limrrtp6	/public/images/thumbnails/aecab2d8-8941-4596-a26b-6745c2f9ea41-1760549698810.webp	150	150	webp	80	7680	cmgs9u3k900u5h9i6xlgrsnir
cmgs9u6b700ugh9i6tkrw0sx1	/public/images/medium/54e9b6e1-0c51-4461-b704-2e03f26324d5-1760549701391.webp	800	540	webp	85	134726	cmgs9u6b300uch9i6m35rahyp
cmgs9u7tf00umh9i67rsji4pb	/public/images/full/65bb31cf-2de1-4e54-bb78-2b7b17131646-1760549704928.webp	2451	3775	webp	90	792036	cmgs9u7ta00ujh9i6usf8tv6w
cmgs9u9ee00uvh9i6n3y2lopd	/public/images/thumbnails/101f982a-fa28-46bb-90b7-a0aa5b2330d5-1760549706880.webp	150	150	webp	80	9054	cmgs9u9eb00uqh9i6m7t82iwp
cmgs9uab100v3h9i6r9jq69w3	/public/images/thumbnails/73098897-7f79-4df9-9012-837a3a46268b-1760549708932.webp	150	150	webp	80	7052	cmgs9uaaw00uxh9i6u4ut91m5
cmgs9ubxq00v8h9i6lhfjo5h4	/public/images/thumbnails/64e9b221-c779-4850-a321-255724ccc196-1760549710110.webp	150	150	webp	80	8894	cmgs9ubxp00v4h9i62srn25lo
cmgs9udvv00vhh9i6yhhf2c5j	/public/images/medium/bb0f8c32-18f5-436a-be59-d5a58b17b9f0-1760549712225.webp	800	1228	webp	85	138626	cmgs9udvr00vbh9i6n9wicxos
cmgs9uet300vmh9i6cyxtd70v	/public/images/full/e7d7a8f9-9b24-4fd7-91ae-a4d450a3b6e2-1760549714746.webp	1780	2573	webp	90	397864	cmgs9uesy00vih9i6lshaz4hx
cmgs9uhf400vuh9i6qjta6xbj	/public/images/full/10e792b3-0580-4278-b08b-3dd2d501bcbf-1760549715958.webp	3477	5195	webp	90	1077046	cmgs9uhf000vph9i6iuj9noi3
cmgs9uite00w2h9i6h5iripg7	/public/images/full/0ac1b21f-fd4f-45cc-bd2f-0b82536ff63c-1760549719330.webp	3529	2542	webp	90	890518	cmgs9uitc00vwh9i6qc2lxvlv
cmgs9ujrh00w7h9i6xwcsiu69	/public/images/thumbnails/72958d9d-8aa2-40ee-8deb-4bf04ca9c9bb-1760549721140.webp	150	150	webp	80	8292	cmgs9ujrc00w3h9i6u4qow7e0
cmgs9ukn400wgh9i6ccpqzieq	/public/images/thumbnails/faa743de-15ce-4774-846a-313380ab8160-1760549722361.webp	150	150	webp	80	7786	cmgs9ukn200wah9i6hnq8r9rd
cmgs9unl100wnh9i6nr79xzgz	/public/images/medium/e76c717f-7093-4589-a485-c43d929bde46-1760549723510.webp	800	1181	webp	85	262892	cmgs9unkv00whh9i6mimjx7k1
cmgs9urpd00wth9i6rh96i1vq	/public/images/medium/55c55a8c-57cd-4fd6-b6b1-c5c0bf8db6b1-1760549727318.webp	800	509	webp	85	55878	cmgs9urpb00woh9i6i9pjtt4w
cmgs9uta200x1h9i606qz87xf	/public/images/medium/877fb10b-0e51-4670-814f-2dd715920cca-1760549732664.webp	800	589	webp	85	143652	cmgs9ut9x00wvh9i6boym8e1d
cmgs9uusv00x5h9i6tmopels5	/public/images/medium/2bcbb968-3b5b-4dc8-aa11-f243f75bbbfb-1760549734710.webp	800	576	webp	85	115536	cmgs9uust00x2h9i69av75sa9
cmgs9uwf700xdh9i6bqcq37cs	/public/images/full/0980498e-f136-413e-bc1b-211fcc6b95ea-1760549736673.webp	3669	2636	webp	90	1039276	cmgs9uwf100x9h9i6n0pctlcg
cmgs9v1c600xih9i6k80l4xej	/public/images/thumbnails/033f9d09-e221-4acf-a123-57ed69b4a595-1760549738778.webp	150	150	webp	80	5282	cmgs9v1c100xgh9i605s06l15
cmgs9v2fr00xsh9i6htwpmbsy	/public/images/full/ba41c34c-c35b-472c-a86c-ade7267ac3e9-1760549745147.webp	3279	2293	webp	90	416554	cmgs9v2fm00xnh9i691gofbw6
cmgs9v4xg00y0h9i6o59fg353	/public/images/medium/92dea022-9121-4f45-b47c-2266e3382f15-1760549746567.webp	800	545	webp	85	84220	cmgs9v4xb00xuh9i6zwytgxe1
cmgs9v7kq00y5h9i67g8xeuen	/public/images/thumbnails/4251d996-e487-47e9-af9e-37e8970893df-1760549749800.webp	150	150	webp	80	7548	cmgs9v7kn00y1h9i6r11ekh7s
cmgs9v9zo00yeh9i65oera5gn	/public/images/full/a04598fa-a3be-464b-83e2-93f3410bd30f-1760549753230.webp	5012	3369	webp	90	1427926	cmgs9v9zm00y8h9i6lhflaso4
cmgs9vbe500ylh9i60vdd3gyv	/public/images/medium/38098dcd-58b1-4f7b-9e75-69f7991ee439-1760549756359.webp	800	652	webp	85	92828	cmgs9vbe300yfh9i67h1fiyqf
cmgs9vbe500yjh9i63imfgca7	/public/images/thumbnails/38098dcd-58b1-4f7b-9e75-69f7991ee439-1760549756359.webp	150	150	webp	80	8942	cmgs9vbe300yfh9i67h1fiyqf
cmgs9vbe500ykh9i69odmjnbk	/public/images/full/38098dcd-58b1-4f7b-9e75-69f7991ee439-1760549756359.webp	3232	2636	webp	90	786494	cmgs9vbe300yfh9i67h1fiyqf
cmgs9vcre00yph9i6telvm450	/public/images/thumbnails/416b39c6-cb9e-425e-b334-b43f1754a18c-1760549758177.webp	150	150	webp	80	6142	cmgs9vcra00ymh9i64d0sn95l
cmgs9vcrg00ysh9i6dc493oik	/public/images/medium/416b39c6-cb9e-425e-b334-b43f1754a18c-1760549758177.webp	800	621	webp	85	74758	cmgs9vcra00ymh9i64d0sn95l
cmgs9vcre00yqh9i6ojov054b	/public/images/full/416b39c6-cb9e-425e-b334-b43f1754a18c-1760549758177.webp	3338	2592	webp	90	687178	cmgs9vcra00ymh9i64d0sn95l
cmgs9vdmq00yvh9i6tannxx0z	/public/images/thumbnails/237fea23-a614-419c-93d0-c6b80448dd7a-1760549759955.webp	150	150	webp	80	7348	cmgs9vdmo00yth9i61xo0c2zv
cmgs9vdmr00yxh9i6jqe7rx6d	/public/images/medium/237fea23-a614-419c-93d0-c6b80448dd7a-1760549759955.webp	800	593	webp	85	91318	cmgs9vdmo00yth9i61xo0c2zv
cmgs9vdmr00yzh9i67vwx76rv	/public/images/full/237fea23-a614-419c-93d0-c6b80448dd7a-1760549759955.webp	2545	1887	webp	90	433276	cmgs9vdmo00yth9i61xo0c2zv
cmgs9vesr00z6h9i6rs0a622d	/public/images/medium/628ff4ce-1e80-4078-bd00-38262c77894f-1760549761078.webp	800	600	webp	85	94884	cmgs9vesp00z0h9i6e5xnsgdj
cmgs9vgcf00zdh9i6l7gfd363	/public/images/full/ab368f57-3cf2-4e27-b863-107b45b6fc7c-1760549762584.webp	2698	3669	webp	90	749792	cmgs9vgcb00z7h9i6cpx7jg1m
cmgs9vj1h00zkh9i6ij447lwh	/public/images/full/44892d2d-6181-49fc-ba4f-811602535951-1760549764599.webp	5075	3494	webp	90	1680376	cmgs9vj1a00zeh9i66fzgz4uw
cmgs9vlqn00zph9i62k327yar	/public/images/thumbnails/074ddef5-7a48-47bb-9839-d41f3116f00e-1760549768090.webp	150	150	webp	80	8168	cmgs9vlqi00zlh9i6rbj4jsk1
cmgs9vmz600zxh9i6t7l7wslt	/public/images/medium/4b6223cc-26ca-450c-8a7e-e5490342ce16-1760549771590.webp	800	633	webp	85	69672	cmgs9vmyz00zsh9i6sblzpxkp
cmgs9vnwb0105h9i6q4crfbu2	/public/images/full/19bb38c1-1e6c-4116-8966-95e42e73825b-1760549773189.webp	1780	2698	webp	90	297500	cmgs9vnw700zzh9i66y1t66n0
cmgs9w3nn010ah9i66d6mhgwy	/public/images/medium/47622c69-dd2b-4037-a541-592003c2e28b-1760549774393.webp	800	533	webp	85	66982	cmgs9w3nk0106h9i68rd3dtgi
cmgs9w4sd010ih9i6oioeo9hc	/public/images/medium/f2ad20af-1015-455e-91d5-04f5f84c4576-1760549794801.webp	800	554	webp	85	118062	cmgs9w4sb010dh9i6q1ifkctx
cmgs9w5y1010qh9i6agdk6z81	/public/images/full/ff1069cb-e4fc-465f-9f69-9e867d49e3fe-1760549796274.webp	3014	2230	webp	90	639620	cmgs9w5xy010kh9i6pwpvetvj
cmgs9w7o7010vh9i60gidwezm	/public/images/thumbnails/fba1783a-e55f-4fb3-be49-667f0cc02f36-1760549797772.webp	150	150	webp	80	7828	cmgs9w7o3010rh9i62sqmir4i
cmgs9wams0113h9i6wttu8ys9	/public/images/medium/cdc4deea-4ab8-41d3-8055-7aedf08411c1-1760549800016.webp	800	1199	webp	85	269218	cmgs9wamp010yh9i69sfdhtom
cmgs9wcj2011bh9i6w9bcwdan	/public/images/full/8f1fdde7-1f8f-41f6-9862-43cc7761205b-1760549803858.webp	4310	2683	webp	90	1544870	cmgs9wciv0115h9i6k8mrrb5p
cmgs9wdlb011ih9i6cecxn1nn	/public/images/medium/31637e79-b9b7-4136-8a33-7bbd4d1b2c1e-1760549806307.webp	800	614	webp	85	60964	cmgs9wdl8011ch9i6korvq745
cmgs9wg2m011lh9i62ggytisv	/public/images/thumbnails/20f18591-c754-4837-abfe-e4ff8c0f8978-1760549807683.webp	150	150	webp	80	8328	cmgs9wg2h011jh9i6s7fs6xam
cmgs9wj0x011wh9i66gnwl2c3	/public/images/full/99ce6c6e-20d9-41c8-8b09-0aa22fa57295-1760549810912.webp	5044	3494	webp	90	2844792	cmgs9wj0u011qh9i6rjo3inos
cmgs9wly30123h9i67lj94u3y	/public/images/full/6df83bb6-a198-4115-986f-f92f7cee7448-1760549814732.webp	5419	3588	webp	90	2100474	cmgs9wly0011xh9i6vk63erms
cmgs9wnco0128h9i634gqt6jf	/public/images/full/f96bb672-952e-4be1-921f-b9f2c5992c5d-1760549818514.webp	2686	3151	webp	90	629422	cmgs9wnck0124h9i62v26qsk6
cmgs9wov2012fh9i6ls4mm564	/public/images/thumbnails/1a3e3e9e-bf39-441c-8cee-97e96a0f6e5b-1760549820340.webp	150	150	webp	80	8488	cmgs9wov0012bh9i6cxcqs7do
cmgs9wq28012nh9i61onkdlnu	/public/images/medium/ba8858e6-d173-4c88-8546-435061faeb2d-1760549822284.webp	800	1067	webp	85	192964	cmgs9wq26012ih9i6sjdv9p5i
cmgs9wu7x012rh9i6nzgyz726	/public/images/medium/4abb8afa-a5b9-4596-9e47-467de5d7c9bc-1760549823847.webp	800	509	webp	85	38834	cmgs9wu7u012ph9i6fvednj9q
cmgs9wvqe0131h9i6zmlpaoed	/public/images/full/6de42dfb-5981-4413-b0bd-1978c4e0b940-1760549829226.webp	2573	3498	webp	90	821506	cmgs9wvqb012wh9i6ak3ehmvv
cmgs9wx4j0138h9i6wncyt339	/public/images/medium/d3c09194-a279-4bb3-8fda-f060b85cfb9c-1760549831193.webp	800	600	webp	85	66120	cmgs9wx4f0133h9i6ge5kkxah
cmgs9wynx013fh9i67sjv4gr5	/public/images/medium/2821847a-6dad-433a-8793-56cfa7dbc87a-1760549833003.webp	800	1196	webp	85	130064	cmgs9wynu013ah9i61k92wefw
cmgs9x1hw013lh9i6efybifo0	/public/images/thumbnails/bc60027d-92d6-4dc3-bc7e-ee7e9b80952c-1760549835009.webp	150	150	webp	80	6020	cmgs9x1hs013hh9i6q62cwwsk
cmgs9x3hi013th9i6515ii8po	/public/images/full/8d59c256-00f8-4d1f-a1a8-e31601b9b39f-1760549838665.webp	4310	3010	webp	90	1144038	cmgs9x3hf013oh9i6brebn226
cmgs9x4rx013zh9i6y1mzlnzd	/public/images/full/618c881f-9042-41af-bc54-adb64c9ced67-1760549841239.webp	2534	3184	webp	90	686966	cmgs9x4rt013vh9i63a2l19sm
cmgs9x66f0147h9i6i1l8y3ar	/public/images/medium/dab60e0b-6f90-4213-8ede-ccb19ee51b92-1760549842919.webp	800	1000	webp	85	149954	cmgs9x66b0142h9i6c0xo3vzj
cmgs9xan3014dh9i6ddefvsw5	/public/images/medium/80c73633-5d8c-44ce-939f-f24d1a65922d-1760549844743.webp	800	502	webp	85	54104	cmgs9xamz0149h9i6hlx4bxsd
cmgs9xdbt014kh9i6ft828964	/public/images/medium/0014bb35-eebf-4e61-ad77-9accb8e8ba2e-1760549850523.webp	800	560	webp	85	86056	cmgs9xdbq014gh9i6ok43qacu
cmgs9xi2e014sh9i6bavxvi6r	/public/images/thumbnails/fb72df58-5696-439f-a181-4b254cf95834-1760549854003.webp	150	150	webp	80	6880	cmgs9xi28014nh9i68khsbx9t
cmgs9xyma014wh9i6nmah9uop	/public/images/thumbnails/4ec37201-a429-47da-adde-d975219d492f-1760549860152.webp	150	150	webp	80	7584	cmgs9xym6014uh9i6nc1d627w
cmgs9y6pp0156h9i6a9o0r4ro	/public/images/full/e8126060-8fc8-4014-be29-8b44be3458f4-1760549881594.webp	7818	4819	webp	90	2005616	cmgs9y6pl0151h9i60ibwhh7a
cmgs9ybhe015ch9i6ccmm7g0m	/public/images/medium/7f83b726-edbe-4407-bac2-0db9ff56c418-1760549892078.webp	800	538	webp	85	74100	cmgs9ybhb0158h9i6za9jiul5
cmgs9yr05015hh9i6xea4ye0s	/public/images/thumbnails/bfd48272-1d35-40ab-bdc6-75c556f1b41b-1760549898266.webp	150	150	webp	80	7060	cmgs9yr02015fh9i6jcan8b47
cmgsaklho02koh9i6vdw0ixmx	/public/images/medium/f018b53d-ebd2-4e93-b122-751be8febfc4-1760550935321.webp	800	650	webp	85	122152	cmgsaklhm02kkh9i6czz2f3up
cmgsakn3l02kxh9i6gstmkh8u	/public/images/full/9d1a886e-9e5e-4bda-956b-b32d40a618a7-1760550937665.webp	2748	3665	webp	90	949742	cmgsakn3i02krh9i63sh5x9bz
cmgsakok502l3h9i6p6wu9jcu	/public/images/medium/9ef3c397-f00f-44cc-839e-d361d33e12d0-1760550939748.webp	800	655	webp	85	115110	cmgsakoju02kyh9i6ohvr22xq
cmgsakqoe02lbh9i6ghghhx51	/public/images/full/0445d48f-0b7d-4046-b5b4-be7ecb695602-1760550941636.webp	3010	4279	webp	90	1150708	cmgsakqob02l5h9i6aqilybwg
cmgsaks7402lhh9i62l27bol0	/public/images/full/d02c4366-8102-45c4-bf90-464711435da0-1760550944385.webp	2402	3779	webp	90	776918	cmgsaks7002lch9i61pv4lsu4
cmgsaku1a02lmh9i6gie8r8rv	/public/images/full/850092a2-57a9-48da-a4b6-2e8fd91468c7-1760550946353.webp	4247	2901	webp	90	949264	cmgsaku1702ljh9i63520q8i3
cmgsakvzi02lwh9i68w3vqzqb	/public/images/full/ab336f90-64e3-4c43-bd52-03f534e87a49-1760550948737.webp	4435	2932	webp	90	1055496	cmgsakvzf02lqh9i6gm6cvs83
cmgsakxdf02m1h9i6tq71fybm	/public/images/thumbnails/0a8dbb46-e15c-4828-95e9-422107a2904a-1760550951265.webp	150	150	webp	80	8406	cmgsakxdc02lxh9i6g16vsyms
cmgsakz8602m9h9i6ozadgowi	/public/images/medium/6004e76e-af9d-4328-8c6f-40f93f0671c5-1760550953060.webp	800	553	webp	85	94160	cmgsakz8302m4h9i6hz0wqb9n
cmgs9vesr00z5h9i62sbvqo0y	/public/images/thumbnails/628ff4ce-1e80-4078-bd00-38262c77894f-1760549761078.webp	150	150	webp	80	8830	cmgs9vesp00z0h9i6e5xnsgdj
cmgs9vgcf00zbh9i64rg7mc98	/public/images/thumbnails/ab368f57-3cf2-4e27-b863-107b45b6fc7c-1760549762584.webp	150	150	webp	80	7728	cmgs9vgcb00z7h9i6cpx7jg1m
cmgs9vj1h00zjh9i656v44yqk	/public/images/thumbnails/44892d2d-6181-49fc-ba4f-811602535951-1760549764599.webp	150	150	webp	80	9142	cmgs9vj1a00zeh9i66fzgz4uw
cmgs9vlqn00zoh9i6nvpfcuah	/public/images/full/074ddef5-7a48-47bb-9839-d41f3116f00e-1760549768090.webp	5216	3432	webp	90	1931894	cmgs9vlqi00zlh9i6rbj4jsk1
cmgs9vmz600zyh9i6a0kxzwsn	/public/images/thumbnails/4b6223cc-26ca-450c-8a7e-e5490342ce16-1760549771590.webp	150	150	webp	80	6186	cmgs9vmyz00zsh9i6sblzpxkp
cmgs9vnwb0104h9i6hnfthglk	/public/images/medium/19bb38c1-1e6c-4116-8966-95e42e73825b-1760549773189.webp	800	1213	webp	85	94756	cmgs9vnw700zzh9i66y1t66n0
cmgs9w3nn0108h9i6w899ps9v	/public/images/thumbnails/47622c69-dd2b-4037-a541-592003c2e28b-1760549774393.webp	150	150	webp	80	4358	cmgs9w3nk0106h9i68rd3dtgi
cmgs9w4sd010jh9i6rr9i3c9h	/public/images/full/f2ad20af-1015-455e-91d5-04f5f84c4576-1760549794801.webp	2995	2074	webp	90	784754	cmgs9w4sb010dh9i6q1ifkctx
cmgs9w5y1010oh9i6s3z2or9q	/public/images/thumbnails/ff1069cb-e4fc-465f-9f69-9e867d49e3fe-1760549796274.webp	150	150	webp	80	8100	cmgs9w5xy010kh9i6pwpvetvj
cmgs9w7o7010xh9i62nk1g077	/public/images/full/fba1783a-e55f-4fb3-be49-667f0cc02f36-1760549797772.webp	4044	2683	webp	90	953042	cmgs9w7o3010rh9i62sqmir4i
cmgs9wamt0114h9i6vxhvzyf7	/public/images/full/cdc4deea-4ab8-41d3-8055-7aedf08411c1-1760549800016.webp	3404	5101	webp	90	2741722	cmgs9wamp010yh9i69sfdhtom
cmgs9wcj2011ah9i6a82dqrx7	/public/images/thumbnails/8f1fdde7-1f8f-41f6-9862-43cc7761205b-1760549803858.webp	150	150	webp	80	7526	cmgs9wciv0115h9i6k8mrrb5p
cmgs9wdlb011fh9i6o33cfuba	/public/images/thumbnails/31637e79-b9b7-4136-8a33-7bbd4d1b2c1e-1760549806307.webp	150	150	webp	80	7280	cmgs9wdl8011ch9i6korvq745
cmgs9wg2m011ph9i6cg7qlbgw	/public/images/full/20f18591-c754-4837-abfe-e4ff8c0f8978-1760549807683.webp	3229	5028	webp	90	1288900	cmgs9wg2h011jh9i6s7fs6xam
cmgs9wj0x011uh9i69jk9odo2	/public/images/thumbnails/99ce6c6e-20d9-41c8-8b09-0aa22fa57295-1760549810912.webp	150	150	webp	80	7878	cmgs9wj0u011qh9i6rjo3inos
cmgs9wly30122h9i6ntcyh0j5	/public/images/thumbnails/6df83bb6-a198-4115-986f-f92f7cee7448-1760549814732.webp	150	150	webp	80	10964	cmgs9wly0011xh9i6vk63erms
cmgs9wnco012ah9i6zaksy7by	/public/images/thumbnails/f96bb672-952e-4be1-921f-b9f2c5992c5d-1760549818514.webp	150	150	webp	80	5228	cmgs9wnck0124h9i62v26qsk6
cmgs9wov2012hh9i604igauvv	/public/images/full/1a3e3e9e-bf39-441c-8cee-97e96a0f6e5b-1760549820340.webp	3404	2636	webp	90	962640	cmgs9wov0012bh9i6cxcqs7do
cmgs9wq28012kh9i692yq2pia	/public/images/thumbnails/ba8858e6-d173-4c88-8546-435061faeb2d-1760549822284.webp	150	150	webp	80	9654	cmgs9wq26012ih9i6sjdv9p5i
cmgs9wu7x012vh9i6jggjcqaf	/public/images/thumbnails/4abb8afa-a5b9-4596-9e47-467de5d7c9bc-1760549823847.webp	150	150	webp	80	4392	cmgs9wu7u012ph9i6fvednj9q
cmgs9wvqe0130h9i6i5tl2swg	/public/images/thumbnails/6de42dfb-5981-4413-b0bd-1978c4e0b940-1760549829226.webp	150	150	webp	80	6294	cmgs9wvqb012wh9i6ak3ehmvv
cmgs9wx4j0137h9i6s7rgrssn	/public/images/full/d3c09194-a279-4bb3-8fda-f060b85cfb9c-1760549831193.webp	3451	2589	webp	90	703910	cmgs9wx4f0133h9i6ge5kkxah
cmgs9wynx013eh9i6nxvqwurm	/public/images/full/2821847a-6dad-433a-8793-56cfa7dbc87a-1760549833003.webp	2420	3619	webp	90	739998	cmgs9wynu013ah9i61k92wefw
cmgs9x1hw013mh9i6tsxfspvd	/public/images/medium/bc60027d-92d6-4dc3-bc7e-ee7e9b80952c-1760549835009.webp	800	574	webp	85	87058	cmgs9x1hs013hh9i6q62cwwsk
cmgs9x3hi013rh9i6kvaar0n8	/public/images/thumbnails/8d59c256-00f8-4d1f-a1a8-e31601b9b39f-1760549838665.webp	150	150	webp	80	7796	cmgs9x3hf013oh9i6brebn226
cmgs9x4rx0140h9i69y8dvzih	/public/images/medium/618c881f-9042-41af-bc54-adb64c9ced67-1760549841239.webp	800	1005	webp	85	119276	cmgs9x4rt013vh9i63a2l19sm
cmgs9x66f0144h9i6y3zho75r	/public/images/thumbnails/dab60e0b-6f90-4213-8ede-ccb19ee51b92-1760549842919.webp	150	150	webp	80	8034	cmgs9x66b0142h9i6c0xo3vzj
cmgs9xan3014eh9i608vx7ql1	/public/images/full/80c73633-5d8c-44ce-939f-f24d1a65922d-1760549844743.webp	7678	4819	webp	90	1505944	cmgs9xamz0149h9i6hlx4bxsd
cmgs9xdbt014jh9i6zbbi9csi	/public/images/thumbnails/0014bb35-eebf-4e61-ad77-9accb8e8ba2e-1760549850523.webp	150	150	webp	80	8634	cmgs9xdbq014gh9i6ok43qacu
cmgs9xi2d014ph9i6mdvx1at6	/public/images/medium/fb72df58-5696-439f-a181-4b254cf95834-1760549854003.webp	800	544	webp	85	81182	cmgs9xi28014nh9i68khsbx9t
cmgs9xyma014zh9i65jcql88m	/public/images/full/4ec37201-a429-47da-adde-d975219d492f-1760549860152.webp	7798	5099	webp	90	3396298	cmgs9xym6014uh9i6nc1d627w
cmgs9y6pp0157h9i68dssdr8t	/public/images/medium/e8126060-8fc8-4014-be29-8b44be3458f4-1760549881594.webp	800	493	webp	85	91102	cmgs9y6pl0151h9i60ibwhh7a
cmgs9ybhd015ah9i66qtyxvt6	/public/images/thumbnails/7f83b726-edbe-4407-bac2-0db9ff56c418-1760549892078.webp	150	150	webp	80	6300	cmgs9ybhb0158h9i6za9jiul5
cmgs9yr05015lh9i6nd9cc52i	/public/images/full/bfd48272-1d35-40ab-bdc6-75c556f1b41b-1760549898266.webp	7798	4819	webp	90	2627028	cmgs9yr02015fh9i6jcan8b47
cmgsakqoe02lah9i6eyegxrze	/public/images/thumbnails/0445d48f-0b7d-4046-b5b4-be7ecb695602-1760550941636.webp	150	150	webp	80	10030	cmgsakqob02l5h9i6aqilybwg
cmgsaks7402lgh9i6w8rs2mp2	/public/images/medium/d02c4366-8102-45c4-bf90-464711435da0-1760550944385.webp	800	1258	webp	85	125750	cmgsaks7002lch9i61pv4lsu4
cmgsaku1c02lph9i6m6xknnfz	/public/images/thumbnails/850092a2-57a9-48da-a4b6-2e8fd91468c7-1760550946353.webp	150	150	webp	80	9044	cmgsaku1702ljh9i63520q8i3
cmgsakvzi02lvh9i6tmsmg2wq	/public/images/thumbnails/ab336f90-64e3-4c43-bd52-03f534e87a49-1760550948737.webp	150	150	webp	80	9578	cmgsakvzf02lqh9i6gm6cvs83
cmgsakxdf02m2h9i6ayao8oiz	/public/images/medium/0a8dbb46-e15c-4828-95e9-422107a2904a-1760550951265.webp	800	633	webp	85	91786	cmgsakxdc02lxh9i6g16vsyms
cmgsakz8602mah9i669twuxn7	/public/images/thumbnails/6004e76e-af9d-4328-8c6f-40f93f0671c5-1760550953060.webp	150	150	webp	80	10022	cmgsakz8302m4h9i6hz0wqb9n
cmgsal0o702mhh9i6mqrbxw8j	/public/images/medium/e14f3f3d-b535-4bec-aee6-7691c909cb27-1760550955464.webp	800	658	webp	85	104214	cmgsal0o402mbh9i6nhspy5z8
cmgsal26j02mmh9i61vh5b78c	/public/images/thumbnails/a962cb3b-6b9a-4701-b66d-2d88db8837e2-1760550957332.webp	150	150	webp	80	6602	cmgsal26h02mih9i60ze8qdpq
cmgsal3hh02muh9i6v3hneoj2	/public/images/full/ce1b0b1b-fb6f-41da-bba2-1d194e639ba9-1760550959287.webp	2982	2932	webp	90	585914	cmgsal3he02mph9i6bm757uum
cmgsa1lsk018gh9i6fd8nd93f	/public/images/medium/966f9ace-4497-49e8-8680-d34576ef1675-1760550048094.webp	800	576	webp	85	122380	cmgsa1lsi018ch9i6cgj56kwm
cmgsa1lsl018ih9i6lrvl3sof	/public/images/full/966f9ace-4497-49e8-8680-d34576ef1675-1760550048094.webp	5137	3697	webp	90	1552786	cmgsa1lsi018ch9i6cgj56kwm
cmgsa1ndj018ph9i6rsdiaph9	/public/images/full/f73c133d-c362-4bd4-bc3d-fbb65c40942b-1760550051591.webp	3607	2761	webp	90	808678	cmgsa1nde018jh9i6qbkzpdwm
cmgsa1ndj018oh9i66wz7dhvi	/public/images/medium/f73c133d-c362-4bd4-bc3d-fbb65c40942b-1760550051591.webp	800	612	webp	85	113418	cmgsa1nde018jh9i6qbkzpdwm
cmgsa1ndj018nh9i6oxte12no	/public/images/thumbnails/f73c133d-c362-4bd4-bc3d-fbb65c40942b-1760550051591.webp	150	150	webp	80	8866	cmgsa1nde018jh9i6qbkzpdwm
cmgsa1oz1018wh9i6eiobfeg8	/public/images/full/3f198895-db81-4265-8882-f8ac9292571b-1760550053643.webp	3732	2667	webp	90	898058	cmgsa1oyx018qh9i69dz9vwpb
cmgsa1oz1018vh9i6npgz0ci9	/public/images/medium/3f198895-db81-4265-8882-f8ac9292571b-1760550053643.webp	800	571	webp	85	109912	cmgsa1oyx018qh9i69dz9vwpb
cmgsa1oz1018uh9i6tytrwx9l	/public/images/thumbnails/3f198895-db81-4265-8882-f8ac9292571b-1760550053643.webp	150	150	webp	80	8976	cmgsa1oyx018qh9i69dz9vwpb
cmgsa1rva0191h9i6aqss5v6a	/public/images/thumbnails/3edff27b-f671-407e-961d-aadc60e8247d-1760550055721.webp	150	150	webp	80	9518	cmgsa1rv8018xh9i630j99jul
cmgsa1rva0192h9i6beifysxe	/public/images/medium/3edff27b-f671-407e-961d-aadc60e8247d-1760550055721.webp	800	583	webp	85	117392	cmgsa1rv8018xh9i630j99jul
cmgsa1rva0193h9i651gwxol9	/public/images/full/3edff27b-f671-407e-961d-aadc60e8247d-1760550055721.webp	5262	3837	webp	90	1642074	cmgsa1rv8018xh9i630j99jul
cmgsa1uhj0198h9i65ftsrjhl	/public/images/thumbnails/9c28056d-3c16-42e6-9854-7641e3ce4e21-1760550059475.webp	150	150	webp	80	4132	cmgsa1uhh0194h9i6zbtcf73o
cmgsa1uhj0199h9i6qmim0ujj	/public/images/full/9c28056d-3c16-42e6-9854-7641e3ce4e21-1760550059475.webp	5091	3775	webp	90	1124914	cmgsa1uhh0194h9i6zbtcf73o
cmgsa1uhj019ah9i6cs5sgort	/public/images/medium/9c28056d-3c16-42e6-9854-7641e3ce4e21-1760550059475.webp	800	593	webp	85	48942	cmgsa1uhh0194h9i6zbtcf73o
cmgsa1x8l019dh9i6eaj1nz3c	/public/images/thumbnails/8a790cca-919d-4346-9181-0fe76f234e7b-1760550062861.webp	150	150	webp	80	10198	cmgsa1x8j019bh9i6v946qr44
cmgsa1x8l019gh9i6tptlcvbk	/public/images/full/8a790cca-919d-4346-9181-0fe76f234e7b-1760550062861.webp	5122	3712	webp	90	1565630	cmgsa1x8j019bh9i6v946qr44
cmgsa1x8l019hh9i6xb0bs858	/public/images/medium/8a790cca-919d-4346-9181-0fe76f234e7b-1760550062861.webp	800	580	webp	85	107678	cmgsa1x8j019bh9i6v946qr44
cmgsa1z89019nh9i63o4nra7c	/public/images/full/5466934d-0534-4128-afcd-dd6bd1008ddf-1760550066431.webp	4200	3135	webp	90	1180564	cmgsa1z84019ih9i6ht4l2nfh
cmgsa1z89019mh9i6j8l1mrpo	/public/images/thumbnails/5466934d-0534-4128-afcd-dd6bd1008ddf-1760550066431.webp	150	150	webp	80	9868	cmgsa1z84019ih9i6ht4l2nfh
cmgsa1z89019oh9i69sjjwmoa	/public/images/medium/5466934d-0534-4128-afcd-dd6bd1008ddf-1760550066431.webp	800	597	webp	85	112144	cmgsa1z84019ih9i6ht4l2nfh
cmgsa217t019vh9i636hhry99	/public/images/full/dfbe940d-a1b4-4674-b175-ad8944fe0a68-1760550068998.webp	4310	3166	webp	90	1089596	cmgsa217r019ph9i6e5yruq7j
cmgsa217t019th9i60aynuvvg	/public/images/medium/dfbe940d-a1b4-4674-b175-ad8944fe0a68-1760550068998.webp	800	588	webp	85	114180	cmgsa217r019ph9i6e5yruq7j
cmgsa217t019uh9i6um8t33ej	/public/images/thumbnails/dfbe940d-a1b4-4674-b175-ad8944fe0a68-1760550068998.webp	150	150	webp	80	10634	cmgsa217r019ph9i6e5yruq7j
cmgsa242001a2h9i6vvcbxwa4	/public/images/thumbnails/e13c1862-6253-45e8-b243-8ea669b66bc9-1760550071581.webp	150	150	webp	80	6268	cmgsa241x019wh9i6djgf4ngf
cmgsa242001a0h9i6zkay1jox	/public/images/full/e13c1862-6253-45e8-b243-8ea669b66bc9-1760550071581.webp	5169	3946	webp	90	1259320	cmgsa241x019wh9i6djgf4ngf
cmgsa242001a1h9i6kg8ouwc2	/public/images/medium/e13c1862-6253-45e8-b243-8ea669b66bc9-1760550071581.webp	800	611	webp	85	56308	cmgsa241x019wh9i6djgf4ngf
cmgsa26rv01a9h9i61u11ksrz	/public/images/full/c847cf07-0bf1-46e8-9767-e0c876fc6160-1760550075261.webp	5200	3650	webp	90	1593144	cmgsa26rs01a3h9i6d49clqg5
cmgsa26rv01a7h9i636gplcuy	/public/images/thumbnails/c847cf07-0bf1-46e8-9767-e0c876fc6160-1760550075261.webp	150	150	webp	80	8846	cmgsa26rs01a3h9i6d49clqg5
cmgsa26rv01a8h9i6pmve0xq8	/public/images/medium/c847cf07-0bf1-46e8-9767-e0c876fc6160-1760550075261.webp	800	561	webp	85	91684	cmgsa26rs01a3h9i6d49clqg5
cmgsa29cb01ach9i647ui0tw9	/public/images/thumbnails/dae3ba3a-b615-4c9c-ad6f-bcc9817c0710-1760550078791.webp	150	150	webp	80	7228	cmgsa29c901aah9i6qgegh2ox
cmgsa29cb01afh9i6ikf1htx6	/public/images/full/dae3ba3a-b615-4c9c-ad6f-bcc9817c0710-1760550078791.webp	5216	3744	webp	90	1146592	cmgsa29c901aah9i6qgegh2ox
cmgsa29cb01agh9i6809f4zcw	/public/images/medium/dae3ba3a-b615-4c9c-ad6f-bcc9817c0710-1760550078791.webp	800	574	webp	85	65172	cmgsa29c901aah9i6qgegh2ox
cmgsa2c2n01amh9i6shorrxfq	/public/images/full/eb215082-c046-43ac-9848-81789aae1ec9-1760550082111.webp	5262	3821	webp	90	1360000	cmgsa2c2j01ahh9i69j8i6q3n
cmgsa2c2n01anh9i68fhg9fu8	/public/images/thumbnails/eb215082-c046-43ac-9848-81789aae1ec9-1760550082111.webp	150	150	webp	80	6484	cmgsa2c2j01ahh9i69j8i6q3n
cmgsa2c2n01alh9i6mhh4tjkt	/public/images/medium/eb215082-c046-43ac-9848-81789aae1ec9-1760550082111.webp	800	581	webp	85	83228	cmgsa2c2j01ahh9i69j8i6q3n
cmgsa2ets01arh9i64jeh6am5	/public/images/medium/17417537-0a44-480e-9ea9-f62921e8ee3a-1760550085656.webp	800	581	webp	85	63202	cmgsa2eto01aoh9i6asiad19e
cmgsa2ets01ash9i6knlts6hq	/public/images/thumbnails/17417537-0a44-480e-9ea9-f62921e8ee3a-1760550085656.webp	150	150	webp	80	5382	cmgsa2eto01aoh9i6asiad19e
cmgsa2ett01auh9i6bggmhil2	/public/images/full/17417537-0a44-480e-9ea9-f62921e8ee3a-1760550085656.webp	5262	3822	webp	90	1436374	cmgsa2eto01aoh9i6asiad19e
cmgsa2hrd01b1h9i6mgyezatd	/public/images/full/9dd637a9-34d5-47bb-896a-0663b9a0e080-1760550089215.webp	5258	3875	webp	90	1708418	cmgsa2hr901avh9i61rcesh88
cmgsa2hrd01azh9i6h2o7pg53	/public/images/thumbnails/9dd637a9-34d5-47bb-896a-0663b9a0e080-1760550089215.webp	150	150	webp	80	6154	cmgsa2hr901avh9i61rcesh88
cmgsa2hrd01b0h9i66uu1tejj	/public/images/medium/9dd637a9-34d5-47bb-896a-0663b9a0e080-1760550089215.webp	800	589	webp	85	94842	cmgsa2hr901avh9i61rcesh88
cmgsa2kh601b7h9i6bticguxj	/public/images/thumbnails/a4ebd817-5be8-4971-9acb-f4f805ad0833-1760550093015.webp	150	150	webp	80	11304	cmgsa2kh201b2h9i6tw6w1gui
cmgsa2kh601b8h9i69ve1ttxq	/public/images/full/a4ebd817-5be8-4971-9acb-f4f805ad0833-1760550093015.webp	5044	3775	webp	90	1784730	cmgsa2kh201b2h9i6tw6w1gui
cmgs9vesr00z4h9i616al5mhh	/public/images/full/628ff4ce-1e80-4078-bd00-38262c77894f-1760549761078.webp	3076	2308	webp	90	579546	cmgs9vesp00z0h9i6e5xnsgdj
cmgs9vgcf00zch9i65n7x5zpc	/public/images/medium/ab368f57-3cf2-4e27-b863-107b45b6fc7c-1760549762584.webp	800	1088	webp	85	133864	cmgs9vgcb00z7h9i6cpx7jg1m
cmgs9vj1h00zih9i6p74zc15t	/public/images/medium/44892d2d-6181-49fc-ba4f-811602535951-1760549764599.webp	800	551	webp	85	90468	cmgs9vj1a00zeh9i66fzgz4uw
cmgs9vlqo00zrh9i677f6uccm	/public/images/medium/074ddef5-7a48-47bb-9839-d41f3116f00e-1760549768090.webp	800	526	webp	85	90098	cmgs9vlqi00zlh9i6rbj4jsk1
cmgs9vmz600zwh9i6u16tk9ak	/public/images/full/4b6223cc-26ca-450c-8a7e-e5490342ce16-1760549771590.webp	3170	2511	webp	90	531144	cmgs9vmyz00zsh9i6sblzpxkp
cmgs9vnwb0102h9i6wx6e9htj	/public/images/thumbnails/19bb38c1-1e6c-4116-8966-95e42e73825b-1760549773189.webp	150	150	webp	80	5554	cmgs9vnw700zzh9i66y1t66n0
cmgs9w3nn010ch9i69gxniclu	/public/images/full/47622c69-dd2b-4037-a541-592003c2e28b-1760549774393.webp	7678	5119	webp	90	2342300	cmgs9w3nk0106h9i68rd3dtgi
cmgs9w4sd010hh9i6fefwuonv	/public/images/thumbnails/f2ad20af-1015-455e-91d5-04f5f84c4576-1760549794801.webp	150	150	webp	80	7742	cmgs9w4sb010dh9i6q1ifkctx
cmgs9w5y1010nh9i6m095ie1x	/public/images/medium/ff1069cb-e4fc-465f-9f69-9e867d49e3fe-1760549796274.webp	800	592	webp	85	94600	cmgs9w5xy010kh9i6pwpvetvj
cmgs9w7o7010wh9i62za67bd3	/public/images/medium/fba1783a-e55f-4fb3-be49-667f0cc02f36-1760549797772.webp	800	530	webp	85	86336	cmgs9w7o3010rh9i62sqmir4i
cmgs9wams0112h9i65l27z4iu	/public/images/thumbnails/cdc4deea-4ab8-41d3-8055-7aedf08411c1-1760549800016.webp	150	150	webp	80	6974	cmgs9wamp010yh9i69sfdhtom
cmgs9wcj20119h9i66jujz9m0	/public/images/medium/8f1fdde7-1f8f-41f6-9862-43cc7761205b-1760549803858.webp	800	498	webp	85	85786	cmgs9wciv0115h9i6k8mrrb5p
cmgs9wdlb011gh9i68mbcqiyh	/public/images/full/31637e79-b9b7-4136-8a33-7bbd4d1b2c1e-1760549806307.webp	2967	2277	webp	90	377320	cmgs9wdl8011ch9i6korvq745
cmgs9wg2m011oh9i60ityr763	/public/images/medium/20f18591-c754-4837-abfe-e4ff8c0f8978-1760549807683.webp	800	1246	webp	85	184576	cmgs9wg2h011jh9i6s7fs6xam
cmgs9wj0x011vh9i6fdkh6xcl	/public/images/medium/99ce6c6e-20d9-41c8-8b09-0aa22fa57295-1760549810912.webp	800	554	webp	85	102792	cmgs9wj0u011qh9i6rjo3inos
cmgs9wly30121h9i6606gn96p	/public/images/medium/6df83bb6-a198-4115-986f-f92f7cee7448-1760549814732.webp	800	530	webp	85	113986	cmgs9wly0011xh9i6vk63erms
cmgs9wnco0129h9i6jgkgyft8	/public/images/medium/f96bb672-952e-4be1-921f-b9f2c5992c5d-1760549818514.webp	800	938	webp	85	83658	cmgs9wnck0124h9i62v26qsk6
cmgs9wov2012gh9i6li4k41p5	/public/images/medium/1a3e3e9e-bf39-441c-8cee-97e96a0f6e5b-1760549820340.webp	800	620	webp	85	122142	cmgs9wov0012bh9i6cxcqs7do
cmgs9wq28012oh9i6ug63zarb	/public/images/full/ba8858e6-d173-4c88-8546-435061faeb2d-1760549822284.webp	2233	2979	webp	90	707510	cmgs9wq26012ih9i6sjdv9p5i
cmgs9wu7x012uh9i6acd33wq0	/public/images/full/4abb8afa-a5b9-4596-9e47-467de5d7c9bc-1760549823847.webp	7578	4819	webp	90	992186	cmgs9wu7u012ph9i6fvednj9q
cmgs9wvqe0132h9i6t96dnhp3	/public/images/medium/6de42dfb-5981-4413-b0bd-1978c4e0b940-1760549829226.webp	800	1088	webp	85	156914	cmgs9wvqb012wh9i6ak3ehmvv
cmgs9wx4j0139h9i6llgii52m	/public/images/thumbnails/d3c09194-a279-4bb3-8fda-f060b85cfb9c-1760549831193.webp	150	150	webp	80	4896	cmgs9wx4f0133h9i6ge5kkxah
cmgs9wyny013gh9i6x3k1idlg	/public/images/thumbnails/2821847a-6dad-433a-8793-56cfa7dbc87a-1760549833003.webp	150	150	webp	80	4748	cmgs9wynu013ah9i61k92wefw
cmgs9x1hw013nh9i6ry02a1xa	/public/images/full/bc60027d-92d6-4dc3-bc7e-ee7e9b80952c-1760549835009.webp	5200	3728	webp	90	1730788	cmgs9x1hs013hh9i6q62cwwsk
cmgs9x3hi013uh9i6lbdp7jrb	/public/images/medium/8d59c256-00f8-4d1f-a1a8-e31601b9b39f-1760549838665.webp	800	559	webp	85	103296	cmgs9x3hf013oh9i6brebn226
cmgs9x4rx0141h9i6p5i2lx2q	/public/images/thumbnails/618c881f-9042-41af-bc54-adb64c9ced67-1760549841239.webp	150	150	webp	80	6872	cmgs9x4rt013vh9i63a2l19sm
cmgs9x66f0148h9i63ael599a	/public/images/full/dab60e0b-6f90-4213-8ede-ccb19ee51b92-1760549842919.webp	2597	3247	webp	90	791548	cmgs9x66b0142h9i6c0xo3vzj
cmgs9xan3014fh9i63narqcs5	/public/images/thumbnails/80c73633-5d8c-44ce-939f-f24d1a65922d-1760549844743.webp	150	150	webp	80	5374	cmgs9xamz0149h9i6hlx4bxsd
cmgs9xdbt014mh9i66yfbc4kp	/public/images/full/0014bb35-eebf-4e61-ad77-9accb8e8ba2e-1760549850523.webp	5122	3587	webp	90	1780304	cmgs9xdbq014gh9i6ok43qacu
cmgs9xi2e014th9i6ohmzlnf6	/public/images/full/fb72df58-5696-439f-a181-4b254cf95834-1760549854003.webp	7578	5159	webp	90	1753298	cmgs9xi28014nh9i68khsbx9t
cmgs9xyma0150h9i6tltnf4s9	/public/images/medium/4ec37201-a429-47da-adde-d975219d492f-1760549860152.webp	800	523	webp	85	103176	cmgs9xym6014uh9i6nc1d627w
cmgs9y6pp0155h9i60691peh9	/public/images/thumbnails/e8126060-8fc8-4014-be29-8b44be3458f4-1760549881594.webp	150	150	webp	80	7720	cmgs9y6pl0151h9i60ibwhh7a
cmgs9ybhe015eh9i6bju54g5p	/public/images/full/7f83b726-edbe-4407-bac2-0db9ff56c418-1760549892078.webp	7578	5099	webp	90	1986878	cmgs9ybhb0158h9i6za9jiul5
cmgs9yr05015kh9i6wb7fzjai	/public/images/medium/bfd48272-1d35-40ab-bdc6-75c556f1b41b-1760549898266.webp	800	494	webp	85	75832	cmgs9yr02015fh9i6jcan8b47
cmgsal0o702mgh9i6mdcnlqrz	/public/images/thumbnails/e14f3f3d-b535-4bec-aee6-7691c909cb27-1760550955464.webp	150	150	webp	80	6678	cmgsal0o402mbh9i6nhspy5z8
cmgsal26j02mnh9i637rcewot	/public/images/medium/a962cb3b-6b9a-4701-b66d-2d88db8837e2-1760550957332.webp	800	560	webp	85	65800	cmgsal26h02mih9i60ze8qdpq
cmgsal3hh02mvh9i6k6qebqjz	/public/images/thumbnails/ce1b0b1b-fb6f-41da-bba2-1d194e639ba9-1760550959287.webp	150	150	webp	80	4860	cmgsal3he02mph9i6bm757uum
cmgsal52e02n0h9i6r8w957jv	/public/images/thumbnails/1ab32894-38ab-4684-af50-35074c577027-1760550960988.webp	150	150	webp	80	7316	cmgsal52a02mwh9i6pk0ewdsj
cmgsal6pq02n7h9i60u66kfnh	/public/images/thumbnails/b96ea969-0323-4034-9f9e-ba706cb0e5e4-1760550963037.webp	150	150	webp	80	9472	cmgsal6pm02n3h9i6a0uqcrpm
cmgsal8qc02nfh9i62psl9oqc	/public/images/medium/e8822790-8103-458c-9d15-3a86d05853df-1760550965178.webp	800	1134	webp	85	162082	cmgsal8q902nah9i6kclptklp
cmgsala2u02nlh9i6dbap19l0	/public/images/thumbnails/6ee36772-b03c-49fe-a2c3-2d74c4e217ac-1760550967779.webp	150	150	webp	80	6512	cmgsala2r02nhh9i6enw1rnvx
cmgsalbn102nsh9i6xmezlmk5	/public/images/thumbnails/b0017310-a0c0-4a52-a022-62371dc15de7-1760550969529.webp	150	150	webp	80	5226	cmgsalbmy02noh9i65qiqvphx
cmgsalcxz02o1h9i6lcdic5vj	/public/images/full/3a03540a-1adc-4d4a-b7b4-809b16be6d82-1760550971547.webp	3014	2885	webp	90	463496	cmgsalcxv02nvh9i6d4kjtpxt
cmgs9z7tn015sh9i6u86uyh6w	/public/images/full/013843ea-3057-4be5-b34c-3f8a62f300be-1760549918401.webp	7898	5199	webp	90	2684368	cmgs9z7tj015mh9i632acse7o
cmgs9z7tn015rh9i68id82xl4	/public/images/medium/013843ea-3057-4be5-b34c-3f8a62f300be-1760549918401.webp	800	526	webp	85	81016	cmgs9z7tj015mh9i632acse7o
cmgs9z7tn015oh9i62zjgmrgy	/public/images/thumbnails/013843ea-3057-4be5-b34c-3f8a62f300be-1760549918401.webp	150	150	webp	80	7832	cmgs9z7tj015mh9i632acse7o
cmgs9znh1015vh9i6el6mm799	/public/images/thumbnails/55777d02-e9c0-46c4-b07d-5baecd8ed5aa-1760549940182.webp	150	150	webp	80	6924	cmgs9zngx015th9i6ne38yxxx
cmgs9znh1015zh9i6foc04h59	/public/images/medium/55777d02-e9c0-46c4-b07d-5baecd8ed5aa-1760549940182.webp	800	509	webp	85	101176	cmgs9zngx015th9i6ne38yxxx
cmgs9znh1015yh9i663qfh2ps	/public/images/full/55777d02-e9c0-46c4-b07d-5baecd8ed5aa-1760549940182.webp	7578	4819	webp	90	3301672	cmgs9zngx015th9i6ne38yxxx
cmgsa071s0164h9i6hkuq5eo2	/public/images/full/b171761d-08d1-42dd-a29e-1e9250a24ee3-1760549960463.webp	8174	5934	webp	90	3026448	cmgsa071n0160h9i6u7z70x7i
cmgsa071r0162h9i6x0tccp1t	/public/images/medium/b171761d-08d1-42dd-a29e-1e9250a24ee3-1760549960463.webp	800	581	webp	85	105660	cmgsa071n0160h9i6u7z70x7i
cmgsa072a0166h9i6dvpku7xe	/public/images/thumbnails/b171761d-08d1-42dd-a29e-1e9250a24ee3-1760549960463.webp	150	150	webp	80	9978	cmgsa071n0160h9i6u7z70x7i
cmgsa0rco0169h9i6tcwohqii	/public/images/thumbnails/4bf06b71-3666-4a6f-8a8e-e8fdd199587f-1760549985862.webp	150	150	webp	80	4736	cmgsa0rch0167h9i6gkuq1633
cmgsa0rcp016bh9i69bskuqdc	/public/images/medium/4bf06b71-3666-4a6f-8a8e-e8fdd199587f-1760549985862.webp	800	1102	webp	85	104874	cmgsa0rch0167h9i6gkuq1633
cmgsa0rcq016dh9i610mk9qxe	/public/images/full/4bf06b71-3666-4a6f-8a8e-e8fdd199587f-1760549985862.webp	5934	8174	webp	90	3822426	cmgsa0rch0167h9i6gkuq1633
cmgsa0u4r016hh9i6d6cow5qk	/public/images/thumbnails/2ff56b1a-a9fa-4177-87c5-ac0e38cc0dd3-1760550012153.webp	150	150	webp	80	10056	cmgsa0u4o016eh9i61595wl94
cmgsa0u4r016kh9i6slf1hn4n	/public/images/full/2ff56b1a-a9fa-4177-87c5-ac0e38cc0dd3-1760550012153.webp	5106	3744	webp	90	1493438	cmgsa0u4o016eh9i61595wl94
cmgsa0u4r016jh9i6n94g8trd	/public/images/medium/2ff56b1a-a9fa-4177-87c5-ac0e38cc0dd3-1760550012153.webp	800	587	webp	85	103612	cmgsa0u4o016eh9i61595wl94
cmgsa0wxu016qh9i6xgri6sw3	/public/images/medium/4fb0e435-c879-4cef-99c7-96aa944831b6-1760550015744.webp	800	582	webp	85	146602	cmgsa0wxp016lh9i66nxtsp2q
cmgsa0wxu016ph9i67mtsmpta	/public/images/full/4fb0e435-c879-4cef-99c7-96aa944831b6-1760550015744.webp	5106	3712	webp	90	1792832	cmgsa0wxp016lh9i66nxtsp2q
cmgsa0wxu016rh9i6omk9ezih	/public/images/thumbnails/4fb0e435-c879-4cef-99c7-96aa944831b6-1760550015744.webp	150	150	webp	80	9814	cmgsa0wxp016lh9i66nxtsp2q
cmgsa0zts016yh9i60e4xahcg	/public/images/medium/36707aeb-58d9-4f83-ae8c-e46949b0f9c4-1760550019383.webp	800	1117	webp	85	148220	cmgsa0ztq016sh9i6u3ziltkw
cmgsa0zts016wh9i6oossd4fk	/public/images/thumbnails/36707aeb-58d9-4f83-ae8c-e46949b0f9c4-1760550019383.webp	150	150	webp	80	7610	cmgsa0ztq016sh9i6u3ziltkw
cmgsa0zts016xh9i6b0w8prds	/public/images/full/36707aeb-58d9-4f83-ae8c-e46949b0f9c4-1760550019383.webp	3759	5247	webp	90	1363044	cmgsa0ztq016sh9i6u3ziltkw
cmgsa12ji0174h9i6kmfzo1cg	/public/images/full/fcbb353b-1bb5-4a11-8c8f-13fd39dbc13a-1760550023120.webp	5309	3744	webp	90	1315278	cmgsa12jf016zh9i622kimfio
cmgsa12ji0173h9i6ztim1onr	/public/images/thumbnails/fcbb353b-1bb5-4a11-8c8f-13fd39dbc13a-1760550023120.webp	150	150	webp	80	9308	cmgsa12jf016zh9i622kimfio
cmgsa12ji0175h9i64brqfxf5	/public/images/medium/fcbb353b-1bb5-4a11-8c8f-13fd39dbc13a-1760550023120.webp	800	564	webp	85	76864	cmgsa12jf016zh9i622kimfio
cmgsa15960178h9i6obay6jm5	/public/images/thumbnails/504ab6dd-cfc8-4ae8-8939-495708acfc5f-1760550026643.webp	150	150	webp	80	11056	cmgsa15950176h9i67o91o864
cmgsa1597017bh9i6346q5x83	/public/images/full/504ab6dd-cfc8-4ae8-8939-495708acfc5f-1760550026643.webp	5372	3650	webp	90	1495034	cmgsa15950176h9i67o91o864
cmgsa1597017ch9i68v2vgc7p	/public/images/medium/504ab6dd-cfc8-4ae8-8939-495708acfc5f-1760550026643.webp	800	543	webp	85	112996	cmgsa15950176h9i67o91o864
cmgsa182b017hh9i6i05wrrxn	/public/images/medium/d7863145-c1cf-479e-a15f-e2b812bab279-1760550030171.webp	800	573	webp	85	101040	cmgsa1827017dh9i6bd6dyvuy
cmgsa182b017ih9i6gt2gnn9v	/public/images/thumbnails/d7863145-c1cf-479e-a15f-e2b812bab279-1760550030171.webp	150	150	webp	80	10258	cmgsa1827017dh9i6bd6dyvuy
cmgsa182b017jh9i6z28nuvnf	/public/images/full/d7863145-c1cf-479e-a15f-e2b812bab279-1760550030171.webp	5247	3759	webp	90	1419128	cmgsa1827017dh9i6bd6dyvuy
cmgsa1ayh017oh9i6tyc3nyss	/public/images/full/cf353794-793b-480e-9f07-be7bf71a5173-1760550033800.webp	5247	3681	webp	90	1931316	cmgsa1ayc017kh9i64a5c79uv
cmgsa1ayh017qh9i62s84wfng	/public/images/thumbnails/cf353794-793b-480e-9f07-be7bf71a5173-1760550033800.webp	150	150	webp	80	11268	cmgsa1ayc017kh9i64a5c79uv
cmgsa1ayh017ph9i6e1xab7v6	/public/images/medium/cf353794-793b-480e-9f07-be7bf71a5173-1760550033800.webp	800	561	webp	85	145572	cmgsa1ayc017kh9i64a5c79uv
cmgsa1do6017vh9i6d45sju56	/public/images/thumbnails/b50c4981-3aa2-4148-9573-607d89f51e74-1760550037551.webp	150	150	webp	80	9658	cmgsa1do1017rh9i6sf9ykm9j
cmgsa1do6017wh9i6n0qfd29h	/public/images/full/b50c4981-3aa2-4148-9573-607d89f51e74-1760550037551.webp	5106	3744	webp	90	1562904	cmgsa1do1017rh9i6sf9ykm9j
cmgsa1do6017xh9i6proycelw	/public/images/medium/b50c4981-3aa2-4148-9573-607d89f51e74-1760550037551.webp	800	587	webp	85	123168	cmgsa1do1017rh9i6sf9ykm9j
cmgsa1gen0181h9i6b0p0a4ku	/public/images/thumbnails/003e9f61-947c-4700-8c20-69ba5f7141dc-1760550041077.webp	150	150	webp	80	10892	cmgsa1gel017yh9i6tp2a4rpe
cmgsa1gen0182h9i65p87fezp	/public/images/medium/003e9f61-947c-4700-8c20-69ba5f7141dc-1760550041077.webp	800	582	webp	85	137702	cmgsa1gel017yh9i6tp2a4rpe
cmgsa1gen0184h9i6o7h2ayvh	/public/images/full/003e9f61-947c-4700-8c20-69ba5f7141dc-1760550041077.webp	5106	3712	webp	90	1626466	cmgsa1gel017yh9i6tp2a4rpe
cmgsa1j3a0187h9i6w99by2u8	/public/images/medium/9a255f46-e529-452f-b5c4-e529eebb08eb-1760550044614.webp	800	587	webp	85	111370	cmgsa1j350185h9i6a308feed
cmgsa1j3a018bh9i6thzbotn6	/public/images/full/9a255f46-e529-452f-b5c4-e529eebb08eb-1760550044614.webp	5122	3759	webp	90	1420564	cmgsa1j350185h9i6a308feed
cmgsa1j3a018ah9i65tlj2hnc	/public/images/thumbnails/9a255f46-e529-452f-b5c4-e529eebb08eb-1760550044614.webp	150	150	webp	80	9278	cmgsa1j350185h9i6a308feed
cmgsa1lsk018eh9i63krls6s8	/public/images/thumbnails/966f9ace-4497-49e8-8680-d34576ef1675-1760550048094.webp	150	150	webp	80	10022	cmgsa1lsi018ch9i6cgj56kwm
cmgsa2kh601b6h9i6a9wgt0nl	/public/images/medium/a4ebd817-5be8-4971-9acb-f4f805ad0833-1760550093015.webp	800	598	webp	85	135230	cmgsa2kh201b2h9i6tw6w1gui
cmgsa2n6201bdh9i6t6sumgca	/public/images/thumbnails/ede86ae4-ded2-4fda-a7c9-aa995c9cdbb8-1760550096550.webp	150	150	webp	80	9098	cmgsa2n5y01b9h9i6lget8u7b
cmgsa2py501blh9i65g1bjg8g	/public/images/medium/de179319-39bd-4526-b315-dcf531431b2c-1760550100040.webp	800	584	webp	85	86848	cmgsa2py101bgh9i6niap5nee
cmgsa35ew01bsh9i64d4t5vf7	/public/images/full/0eddeb7c-2540-4a58-876b-a4e3797d6d9c-1760550103640.webp	6996	5321	webp	90	2806146	cmgsa35et01bnh9i6nd5adf39
cmgsa387801bzh9i695302zv9	/public/images/thumbnails/f77b69ab-8155-4ab6-a92e-37f1fc4db410-1760550123676.webp	150	150	webp	80	8712	cmgsa387301buh9i6vat7u1mv
cmgsa3b7301c6h9i6hjdtcoif	/public/images/medium/75335af8-1f0c-48eb-ad89-e5da448e486e-1760550127302.webp	800	555	webp	85	54470	cmgsa3b6z01c1h9i6eq0u34om
cmgsa3eco01ceh9i6qsyg4jt9	/public/images/full/44885dc0-3333-4f58-83f1-e5ef3851bc56-1760550131174.webp	3854	5405	webp	90	1805330	cmgsa3ecm01c8h9i6ib5l2jcd
cmgsa3huo01clh9i65aiffw5o	/public/images/medium/6e349cc8-c693-4d86-8579-c1dd93f665f6-1760550135260.webp	800	1094	webp	85	147012	cmgsa3hul01cfh9i6lpl7j260
cmgsa3kkw01csh9i678ovdwfl	/public/images/medium/96641819-e7d7-445d-bf21-964a2ad66c90-1760550139799.webp	800	566	webp	85	72058	cmgsa3kks01cmh9i6u9da9rxm
cmgsa3nll01cyh9i6tjxoa0ho	/public/images/thumbnails/56a224ad-dabe-4ca6-bc1c-8e955c867ec0-1760550143344.webp	150	150	webp	80	8036	cmgsa3nlj01cth9i6qg8tcc4x
cmgsa3ool01d6h9i6fgdffxpg	/public/images/full/bf11b415-0ed9-4e5a-a794-37cfe1183bae-1760550147246.webp	2889	2012	webp	90	798878	cmgsa3ooi01d0h9i6xkaw9sk6
cmgsa46tz01ddh9i6qbe6gi17	/public/images/medium/3a411284-87d5-4fc8-8bc7-41311587fa94-1760550148660.webp	800	622	webp	85	115652	cmgsa46tu01d7h9i6yyzb8rgp
cmgsa49eo01dkh9i6f2l2duhr	/public/images/medium/9cad594d-6053-4337-aa6e-42303a56ff3f-1760550172172.webp	800	551	webp	85	73014	cmgsa49em01deh9i6wftbd1gr
cmgsa4b1f01dqh9i6faa3h6yy	/public/images/medium/c4c221f7-7c67-47c6-98a0-13553bc05510-1760550175514.webp	800	547	webp	85	69286	cmgsa4b1901dlh9i6deyshhs9
cmgsal52e02n2h9i6vjbhxhm8	/public/images/full/1ab32894-38ab-4684-af50-35074c577027-1760550960988.webp	3701	2683	webp	90	873072	cmgsal52a02mwh9i6pk0ewdsj
cmgsal6pq02n6h9i66llo5nlj	/public/images/medium/b96ea969-0323-4034-9f9e-ba706cb0e5e4-1760550963037.webp	800	1099	webp	85	180372	cmgsal6pm02n3h9i6a0uqcrpm
cmgsal8qc02ngh9i62ou7hjri	/public/images/full/e8822790-8103-458c-9d15-3a86d05853df-1760550965178.webp	2982	4227	webp	90	1238074	cmgsal8q902nah9i6kclptklp
cmgsala2u02nmh9i6qh8arfq9	/public/images/full/6ee36772-b03c-49fe-a2c3-2d74c4e217ac-1760550967779.webp	3326	2620	webp	90	692664	cmgsala2r02nhh9i6enw1rnvx
cmgsalbn102nth9i6gl088jbz	/public/images/medium/b0017310-a0c0-4a52-a022-62371dc15de7-1760550969529.webp	800	1179	webp	85	78160	cmgsalbmy02noh9i65qiqvphx
cmgsalcxz02o0h9i6lhkui71k	/public/images/thumbnails/3a03540a-1adc-4d4a-b7b4-809b16be6d82-1760550971547.webp	150	150	webp	80	5476	cmgsalcxv02nvh9i6d4kjtpxt
cmgsale9n02o5h9i6ph8h11ii	/public/images/thumbnails/3c88ea7d-e0ae-4f23-9dc7-4067d00bb2a3-1760550973234.webp	150	150	webp	80	5134	cmgsale9i02o2h9i6mqo66z3j
cmgsalgb602ofh9i69ha0dd7l	/public/images/full/1eaac488-502b-420b-9e3f-28ffdc953522-1760550974963.webp	2995	4372	webp	90	1112194	cmgsalgb102o9h9i6t2pq3lln
cmgsalhvh02olh9i6nangi3j8	/public/images/full/21d496b8-0cf8-4c0f-a83d-19c937fb4108-1760550977609.webp	2683	3576	webp	90	834398	cmgsalhvd02ogh9i6y5noy38l
cmgsaljj502orh9i6crmwjxsr	/public/images/full/f7ebded5-c1b0-4cc4-b9ea-96f5466f6b32-1760550979636.webp	3792	2827	webp	90	896788	cmgsaljj202onh9i61jze4xz6
cmgsalmek02oyh9i6s1lcxmem	/public/images/full/f3fc0d31-14ea-4e47-aff4-7667e226b87e-1760550981793.webp	5231	3665	webp	90	1724874	cmgsalmeh02ouh9i6irtjndrg
cmgsaloc602p5h9i63e00pwbv	/public/images/medium/710d09c2-cbde-4963-8565-4ef60c9bfc23-1760550985501.webp	800	560	webp	85	52414	cmgsaloc002p1h9i60niz1chf
cmgsalq8f02pbh9i67m5vsmht	/public/images/thumbnails/ccda0b6d-2ccf-4001-a391-341a96cc2bd2-1760550988012.webp	150	150	webp	80	5452	cmgsalq8d02p8h9i6gevxn6qx
cmgsalt7y02pjh9i6u49jigoy	/public/images/full/cc996586-4d28-457c-9aaa-ee5be8aa8625-1760550990470.webp	5294	3603	webp	90	2217562	cmgsalt7t02pfh9i6f6fnxdvp
cmgsalw4l02poh9i6t5fimwvs	/public/images/medium/f7c4c5c1-c4fa-4db6-a7a8-117b70f8c54f-1760550994348.webp	800	1192	webp	85	167320	cmgsalw4h02pmh9i61inht8tz
cmgsalydv02pyh9i6qvfod3c4	/public/images/thumbnails/e08b2a0f-2475-4930-a4fb-dbf94561c0c5-1760550998112.webp	150	150	webp	80	8194	cmgsalydm02pth9i6l7oj974g
cmgsam0bf02q4h9i6d8qjjk5o	/public/images/thumbnails/0a970dd6-2f7c-45fb-a342-8c5ddbdfadb1-1760551001030.webp	150	150	webp	80	7976	cmgsam0bc02q0h9i6kgqp2k8r
cmgsam1so02qch9i62p03qwtg	/public/images/thumbnails/0764776c-1eec-4315-9b1c-7ddbf1aef9a1-1760551003530.webp	150	150	webp	80	6138	cmgsam1sl02q7h9i6t9hmkj6z
cmgsam38e02qih9i6k6ai166y	/public/images/full/41924c0e-8ac9-4d8d-8e8b-7a1b1fa92602-1760551005452.webp	2608	3603	webp	90	642280	cmgsam38b02qeh9i6wsyd8oqo
cmgsam4mw02qrh9i6bbxcngwo	/public/images/full/294f46d2-7026-4d71-be8e-9af22032b2b4-1760551007314.webp	3623	2589	webp	90	772848	cmgsam4mt02qlh9i6lrqeeslg
cmgsam7fd02qxh9i6jsttvax1	/public/images/full/aa9cffc2-fa3a-49d6-a9a8-6e2f94b7e44e-1760551009146.webp	3518	5091	webp	90	1945300	cmgsam7fa02qsh9i6ynnoqy0g
cmgsama9502r1h9i6an1v0wdr	/public/images/thumbnails/795be836-29d0-4287-8a9e-8411b1d7ba22-1760551012757.webp	150	150	webp	80	8432	cmgsama9302qzh9i65h7ar8vj
cmgsashs5034yh9i67rg2mlvw	/public/images/full/80fc5692-e905-4c24-8a1c-0382d54cc4a9-1760551303150.webp	4794	3322	webp	90	1123164	cmgsashs2034sh9i6lwb6r4wq
cmgsasj5z0351h9i6jcre0z73	/public/images/medium/8c5417e5-14ee-4950-89df-ed8f425e45c5-1760551306109.webp	800	1077	webp	85	119476	cmgsasj5x034zh9i62646f70m
cmgsaskfl035ah9i6pprjex5q	/public/images/medium/aaa09157-70c9-46b5-98f8-9dbb91e20938-1760551307892.webp	800	630	webp	85	93248	cmgsaskfh0356h9i6drf8g5uq
cmgsaslrg035ih9i671mqbd76	/public/images/medium/a5c7be90-deab-4c67-94d7-9d32bd1d84e0-1760551309542.webp	800	625	webp	85	93532	cmgsaslre035dh9i67zukssbv
cmgsaso6z035oh9i6bzv21a2o	/public/images/medium/2543163c-a89f-4562-b56b-61458a6cfc75-1760551311264.webp	800	551	webp	85	80164	cmgsaso6v035kh9i6xrm9heg2
cmgsasple035vh9i6aiafw6ea	/public/images/full/8b03174f-b891-4785-8ece-b6cd74be5479-1760551314415.webp	3697	2483	webp	90	781022	cmgsasplb035rh9i6sqnqyry1
cmgsasqsx0364h9i6pz3qtv3t	/public/images/full/b8ae5073-1b8e-4382-b97d-0b525cfdceae-1760551316235.webp	2389	2636	webp	90	669400	cmgsasqst035yh9i6uoz5uy58
cmgsa2n6101bbh9i66hme3t4u	/public/images/medium/ede86ae4-ded2-4fda-a7c9-aa995c9cdbb8-1760550096550.webp	800	563	webp	85	112856	cmgsa2n5y01b9h9i6lget8u7b
cmgsa2py501bmh9i6muk67yb9	/public/images/full/de179319-39bd-4526-b315-dcf531431b2c-1760550100040.webp	5106	3728	webp	90	1444336	cmgsa2py101bgh9i6niap5nee
cmgsa35ew01brh9i6z729deb0	/public/images/medium/0eddeb7c-2540-4a58-876b-a4e3797d6d9c-1760550103640.webp	800	608	webp	85	74342	cmgsa35et01bnh9i6nd5adf39
cmgsa387801c0h9i6935drnil	/public/images/full/f77b69ab-8155-4ab6-a92e-37f1fc4db410-1760550123676.webp	5122	3509	webp	90	1973778	cmgsa387301buh9i6vat7u1mv
cmgsa3b7301c5h9i6zl1c1blf	/public/images/full/75335af8-1f0c-48eb-ad89-e5da448e486e-1760550127302.webp	5258	3644	webp	90	2373458	cmgsa3b6z01c1h9i6eq0u34om
cmgsa3eco01cch9i652fb93wr	/public/images/medium/44885dc0-3333-4f58-83f1-e5ef3851bc56-1760550131174.webp	800	1122	webp	85	131106	cmgsa3ecm01c8h9i6ib5l2jcd
cmgsa3hun01chh9i68pkiq9xt	/public/images/thumbnails/6e349cc8-c693-4d86-8579-c1dd93f665f6-1760550135260.webp	150	150	webp	80	4724	cmgsa3hul01cfh9i6lpl7j260
cmgsa3kkw01crh9i6x46h35q5	/public/images/full/96641819-e7d7-445d-bf21-964a2ad66c90-1760550139799.webp	5075	3588	webp	90	1606620	cmgsa3kks01cmh9i6u9da9rxm
cmgsa3nll01cxh9i66nxud90y	/public/images/medium/56a224ad-dabe-4ca6-bc1c-8e955c867ec0-1760550143344.webp	800	547	webp	85	105334	cmgsa3nlj01cth9i6qg8tcc4x
cmgsa3ool01d3h9i64x91x6pw	/public/images/thumbnails/bf11b415-0ed9-4e5a-a794-37cfe1183bae-1760550147246.webp	150	150	webp	80	8392	cmgsa3ooi01d0h9i6xkaw9sk6
cmgsa46tz01dch9i6gsqmh27t	/public/images/full/3a411284-87d5-4fc8-8bc7-41311587fa94-1760550148660.webp	7331	5698	webp	90	4038452	cmgsa46tu01d7h9i6yyzb8rgp
cmgsa49eo01djh9i6y28rdd3k	/public/images/thumbnails/9cad594d-6053-4337-aa6e-42303a56ff3f-1760550172172.webp	150	150	webp	80	7848	cmgsa49em01deh9i6wftbd1gr
cmgsa4b1f01drh9i6v2oa7byv	/public/images/thumbnails/c4c221f7-7c67-47c6-98a0-13553bc05510-1760550175514.webp	150	150	webp	80	6162	cmgsa4b1901dlh9i6deyshhs9
cmgsale9n02o8h9i6sjnotnhh	/public/images/medium/3c88ea7d-e0ae-4f23-9dc7-4067d00bb2a3-1760550973234.webp	800	861	webp	85	58454	cmgsale9i02o2h9i6mqo66z3j
cmgsalgb602odh9i6vkqt5cmd	/public/images/medium/1eaac488-502b-420b-9e3f-28ffdc953522-1760550974963.webp	800	1168	webp	85	150626	cmgsalgb102o9h9i6t2pq3lln
cmgsalhvh02omh9i69qyhziky	/public/images/medium/21d496b8-0cf8-4c0f-a83d-19c937fb4108-1760550977609.webp	800	1067	webp	85	165508	cmgsalhvd02ogh9i6y5noy38l
cmgsaljj502oqh9i6elxs483w	/public/images/medium/f7ebded5-c1b0-4cc4-b9ea-96f5466f6b32-1760550979636.webp	800	596	webp	85	85038	cmgsaljj202onh9i61jze4xz6
cmgsalmek02p0h9i60p5tgvm8	/public/images/medium/f3fc0d31-14ea-4e47-aff4-7667e226b87e-1760550981793.webp	800	561	webp	85	61760	cmgsalmeh02ouh9i6irtjndrg
cmgsaloc602p6h9i6yov909qs	/public/images/thumbnails/710d09c2-cbde-4963-8565-4ef60c9bfc23-1760550985501.webp	150	150	webp	80	6180	cmgsaloc002p1h9i60niz1chf
cmgsalq8f02pch9i698zzcizf	/public/images/medium/ccda0b6d-2ccf-4001-a391-341a96cc2bd2-1760550988012.webp	800	549	webp	85	43256	cmgsalq8d02p8h9i6gevxn6qx
cmgsalt7y02plh9i6zni44nzr	/public/images/thumbnails/cc996586-4d28-457c-9aaa-ee5be8aa8625-1760550990470.webp	150	150	webp	80	5318	cmgsalt7t02pfh9i6f6fnxdvp
cmgsalw4m02prh9i6u6be5pc7	/public/images/thumbnails/f7c4c5c1-c4fa-4db6-a7a8-117b70f8c54f-1760550994348.webp	150	150	webp	80	5904	cmgsalw4h02pmh9i61inht8tz
cmgsalydv02pxh9i64pbuwmor	/public/images/full/e08b2a0f-2475-4930-a4fb-dbf94561c0c5-1760550998112.webp	2856	4192	webp	90	2240472	cmgsalydm02pth9i6l7oj974g
cmgsam0bf02q5h9i6pdqmgzu8	/public/images/full/0a970dd6-2f7c-45fb-a342-8c5ddbdfadb1-1760551001030.webp	2732	4024	webp	90	1192088	cmgsam0bc02q0h9i6kgqp2k8r
cmgsam1so02qdh9i6n39gxjhj	/public/images/full/0764776c-1eec-4315-9b1c-7ddbf1aef9a1-1760551003530.webp	3685	2636	webp	90	755144	cmgsam1sl02q7h9i6t9hmkj6z
cmgsam38e02qkh9i6mvw1pn1f	/public/images/medium/41924c0e-8ac9-4d8d-8e8b-7a1b1fa92602-1760551005452.webp	800	1105	webp	85	85692	cmgsam38b02qeh9i6wsyd8oqo
cmgsam4mw02qqh9i6rnpu11d9	/public/images/medium/294f46d2-7026-4d71-be8e-9af22032b2b4-1760551007314.webp	800	572	webp	85	67730	cmgsam4mt02qlh9i6lrqeeslg
cmgsam7fd02qwh9i6veu2e17k	/public/images/thumbnails/aa9cffc2-fa3a-49d6-a9a8-6e2f94b7e44e-1760551009146.webp	150	150	webp	80	6920	cmgsam7fa02qsh9i6ynnoqy0g
cmgsama9602r4h9i6m1b5jf3a	/public/images/medium/795be836-29d0-4287-8a9e-8411b1d7ba22-1760551012757.webp	800	552	webp	85	111366	cmgsama9302qzh9i65h7ar8vj
cmgsasqsx0363h9i6jc9gj7i2	/public/images/medium/b8ae5073-1b8e-4382-b97d-0b525cfdceae-1760551316235.webp	800	883	webp	85	166472	cmgsasqst035yh9i6uoz5uy58
cmgsau1u7039zh9i6iediwvmb	/public/images/medium/ad510812-8167-48f7-9033-b3aa1e13225d-1760551376036.webp	800	1388	webp	85	312934	cmgsau1u5039uh9i6yno4rw5z
cmgsau3kj03a4h9i6z0rrkpzq	/public/images/thumbnails/585e4107-84e3-4fce-8b7d-8a5949430fc2-1760551378752.webp	150	150	webp	80	9460	cmgsau3kf03a1h9i6m7usw1y7
cmgsau6gf03aeh9i60w17ecri	/public/images/full/c6d51f66-08ba-40af-9d1c-d5007135ad2a-1760551381006.webp	3267	4923	webp	90	2516896	cmgsau6gc03a8h9i6n3rqvuzp
cmgsau91b03akh9i6ljbu3dev	/public/images/medium/7132dce5-22cc-439b-996c-f9e4db99f767-1760551384747.webp	800	552	webp	85	83942	cmgsau91903afh9i64z6jnsk2
cmgsaubmz03aoh9i6k7jhh4pn	/public/images/thumbnails/810d52b3-810d-4588-abff-969aaec1cc23-1760551388087.webp	150	150	webp	80	5820	cmgsaubmx03amh9i6syczlhwk
cmgsauetp03azh9i6qbpew3qf	/public/images/full/ca527866-3652-4a01-bc2b-317b306e7a90-1760551391466.webp	3539	5007	webp	90	2515208	cmgsauetl03ath9i6wydul3ot
cmgsaugqp03b6h9i6vabx46oa	/public/images/thumbnails/8d0d8373-8c15-446a-a889-c3aa78c89e40-1760551395580.webp	150	150	webp	80	8284	cmgsaugqn03b0h9i6zh3t7e39
cmgsauiuv03bdh9i6j4645yvo	/public/images/full/7bd76a34-4ca6-4562-8c95-9c97143a6896-1760551398066.webp	2896	4669	webp	90	1131116	cmgsauiuo03b7h9i6la3nmwed
cmgsaul5r03bjh9i6iyb5bg3n	/public/images/medium/56b11222-3de8-46ea-9ffa-59367bac4f1d-1760551400810.webp	800	554	webp	85	63144	cmgsaul5o03beh9i6oiug2ekc
cmgsaumg103bqh9i65bbb3raa	/public/images/thumbnails/f7f2435b-1217-4404-b369-67e8260148d6-1760551403796.webp	150	150	webp	80	4240	cmgsaumfv03blh9i6s3btu3zc
cmgsaumg103bph9i6h20q0gtb	/public/images/full/f7f2435b-1217-4404-b369-67e8260148d6-1760551403796.webp	2592	3166	webp	90	726882	cmgsaumfv03blh9i6s3btu3zc
cmgsaumg103brh9i6o1x4gzt6	/public/images/medium/f7f2435b-1217-4404-b369-67e8260148d6-1760551403796.webp	800	977	webp	85	88552	cmgsaumfv03blh9i6s3btu3zc
cmgsaup8i03buh9i629yxau0h	/public/images/thumbnails/e9b3f370-0c08-4102-81ba-e2845a329c01-1760551405464.webp	150	150	webp	80	6846	cmgsaup8a03bsh9i6tsk4uetm
cmgsa2n6301bfh9i6p2h10ctz	/public/images/full/ede86ae4-ded2-4fda-a7c9-aa995c9cdbb8-1760550096550.webp	5184	3650	webp	90	1430202	cmgsa2n5y01b9h9i6lget8u7b
cmgsa2py501bkh9i6sb7omrie	/public/images/thumbnails/de179319-39bd-4526-b315-dcf531431b2c-1760550100040.webp	150	150	webp	80	5974	cmgsa2py101bgh9i6niap5nee
cmgsa35ew01bth9i6opgt8nor	/public/images/thumbnails/0eddeb7c-2540-4a58-876b-a4e3797d6d9c-1760550103640.webp	150	150	webp	80	7040	cmgsa35et01bnh9i6nd5adf39
cmgsa387801byh9i63cn71jwe	/public/images/medium/f77b69ab-8155-4ab6-a92e-37f1fc4db410-1760550123676.webp	800	548	webp	85	80330	cmgsa387301buh9i6vat7u1mv
cmgsa3b7301c7h9i6va0j7c7z	/public/images/thumbnails/75335af8-1f0c-48eb-ad89-e5da448e486e-1760550127302.webp	150	150	webp	80	4248	cmgsa3b6z01c1h9i6eq0u34om
cmgsa3eco01cah9i6dwt1if9m	/public/images/thumbnails/44885dc0-3333-4f58-83f1-e5ef3851bc56-1760550131174.webp	150	150	webp	80	4914	cmgsa3ecm01c8h9i6ib5l2jcd
cmgsa3huo01ckh9i6057l8yjp	/public/images/full/6e349cc8-c693-4d86-8579-c1dd93f665f6-1760550135260.webp	3937	5384	webp	90	2262318	cmgsa3hul01cfh9i6lpl7j260
cmgsa3kkw01cqh9i6ivkyifdt	/public/images/thumbnails/96641819-e7d7-445d-bf21-964a2ad66c90-1760550139799.webp	150	150	webp	80	7056	cmgsa3kks01cmh9i6u9da9rxm
cmgsa3nll01czh9i6x1ql0d2f	/public/images/full/56a224ad-dabe-4ca6-bc1c-8e955c867ec0-1760550143344.webp	5247	3588	webp	90	2354490	cmgsa3nlj01cth9i6qg8tcc4x
cmgsa3ool01d5h9i6w60tw507	/public/images/medium/bf11b415-0ed9-4e5a-a794-37cfe1183bae-1760550147246.webp	800	557	webp	85	120144	cmgsa3ooi01d0h9i6xkaw9sk6
cmgsa46tx01d9h9i6wtqcia6t	/public/images/thumbnails/3a411284-87d5-4fc8-8bc7-41311587fa94-1760550148660.webp	150	150	webp	80	8482	cmgsa46tu01d7h9i6yyzb8rgp
cmgsa49eo01dih9i67vzk4wtz	/public/images/full/9cad594d-6053-4337-aa6e-42303a56ff3f-1760550172172.webp	5137	3541	webp	90	1226308	cmgsa49em01deh9i6wftbd1gr
cmgsa4b1f01dph9i6qucolg88	/public/images/full/c4c221f7-7c67-47c6-98a0-13553bc05510-1760550175514.webp	4013	2745	webp	90	897324	cmgsa4b1901dlh9i6deyshhs9
cmgsa4cht01dxh9i6nqv2g8rw	/public/images/full/b857679d-fa83-4f91-94fa-ed602a605a02-1760550177627.webp	3732	2745	webp	90	583566	cmgsa4chq01dsh9i6b9ka3h7k
cmgsa4cht01dyh9i6y1ax0j8m	/public/images/thumbnails/b857679d-fa83-4f91-94fa-ed602a605a02-1760550177627.webp	150	150	webp	80	5780	cmgsa4chq01dsh9i6b9ka3h7k
cmgsa4chs01dwh9i6b42q4wda	/public/images/medium/b857679d-fa83-4f91-94fa-ed602a605a02-1760550177627.webp	800	588	webp	85	56134	cmgsa4chq01dsh9i6b9ka3h7k
cmgsa4e3i01e3h9i6b9lrudra	/public/images/thumbnails/b9f4a232-666e-414d-b036-951682eb9480-1760550179510.webp	150	150	webp	80	6596	cmgsa4e3f01dzh9i6twywnvsy
cmgsa4e3i01e5h9i67rfzquce	/public/images/medium/b9f4a232-666e-414d-b036-951682eb9480-1760550179510.webp	800	594	webp	85	59928	cmgsa4e3f01dzh9i6twywnvsy
cmgsa4e3i01e4h9i6e81nmm8w	/public/images/full/b9f4a232-666e-414d-b036-951682eb9480-1760550179510.webp	3654	2714	webp	90	701656	cmgsa4e3f01dzh9i6twywnvsy
cmgsa4flj01ech9i63w242fy6	/public/images/medium/e30f1daf-b352-4e19-97b4-f8c6d77f2b84-1760550181586.webp	800	1084	webp	85	124178	cmgsa4fle01e6h9i6lpg35ocy
cmgsa4flj01ebh9i6z8bmgs17	/public/images/thumbnails/e30f1daf-b352-4e19-97b4-f8c6d77f2b84-1760550181586.webp	150	150	webp	80	7564	cmgsa4fle01e6h9i6lpg35ocy
cmgsa4flj01eah9i6ooa69l48	/public/images/full/e30f1daf-b352-4e19-97b4-f8c6d77f2b84-1760550181586.webp	2597	3519	webp	90	671332	cmgsa4fle01e6h9i6lpg35ocy
cmgsa4hcl01ejh9i6peb4kbtw	/public/images/medium/7fcd6ae4-8b28-4629-b1bc-d26fda0caab3-1760550183533.webp	800	569	webp	85	120314	cmgsa4hch01edh9i64yxzd3rq
cmgsa4hcl01ehh9i687etdyko	/public/images/full/7fcd6ae4-8b28-4629-b1bc-d26fda0caab3-1760550183533.webp	3857	2745	webp	90	1081400	cmgsa4hch01edh9i64yxzd3rq
cmgsa4hcl01eih9i6duxgiv5n	/public/images/thumbnails/7fcd6ae4-8b28-4629-b1bc-d26fda0caab3-1760550183533.webp	150	150	webp	80	10064	cmgsa4hch01edh9i64yxzd3rq
cmgsa4j6201emh9i6xw89quvv	/public/images/thumbnails/ddce8ca2-fb97-4b1f-8ae0-657ddedec37f-1760550185808.webp	150	150	webp	80	7964	cmgsa4j6001ekh9i6v6cikq4x
cmgsa4j6201eoh9i61tmixn6i	/public/images/medium/ddce8ca2-fb97-4b1f-8ae0-657ddedec37f-1760550185808.webp	800	632	webp	85	93662	cmgsa4j6001ekh9i6v6cikq4x
cmgsa4j6301eqh9i6zxhousvd	/public/images/full/ddce8ca2-fb97-4b1f-8ae0-657ddedec37f-1760550185808.webp	3888	3073	webp	90	961928	cmgsa4j6001ekh9i6v6cikq4x
cmgsa4l3a01euh9i6ju71q3tg	/public/images/thumbnails/1ff0ebfc-345f-4117-ad40-490a74f9a0de-1760550188156.webp	150	150	webp	80	5822	cmgsa4l3801erh9i66mngaxrt
cmgsa4l3a01ewh9i6ak115cbk	/public/images/medium/1ff0ebfc-345f-4117-ad40-490a74f9a0de-1760550188156.webp	800	635	webp	85	70716	cmgsa4l3801erh9i66mngaxrt
cmgsa4l3a01exh9i6xhikj36e	/public/images/full/1ff0ebfc-345f-4117-ad40-490a74f9a0de-1760550188156.webp	4107	3260	webp	90	1029956	cmgsa4l3801erh9i66mngaxrt
cmgsa4mkt01f2h9i6bfcsn8s8	/public/images/full/be04da0f-da88-400b-837c-69c1677b4b56-1760550190648.webp	3779	2683	webp	90	631138	cmgsa4mkq01eyh9i6k4kvjbuo
cmgsa4mkt01f4h9i6czt2ssrz	/public/images/thumbnails/be04da0f-da88-400b-837c-69c1677b4b56-1760550190648.webp	150	150	webp	80	7436	cmgsa4mkq01eyh9i6k4kvjbuo
cmgsa4mkt01f3h9i64v8q4lju	/public/images/medium/be04da0f-da88-400b-837c-69c1677b4b56-1760550190648.webp	800	568	webp	85	63274	cmgsa4mkq01eyh9i6k4kvjbuo
cmgsa4phr01fbh9i62mgvbtpl	/public/images/thumbnails/5dbe8196-4a3c-48bf-b289-3fc782d3ff64-1760550192582.webp	150	150	webp	80	7660	cmgsa4phm01f5h9i67k29ea4z
cmgsa4phr01fah9i6gu7j5pxp	/public/images/full/5dbe8196-4a3c-48bf-b289-3fc782d3ff64-1760550192582.webp	5122	3385	webp	90	2037530	cmgsa4phm01f5h9i67k29ea4z
cmgsa4phr01f9h9i6yb654ky4	/public/images/medium/5dbe8196-4a3c-48bf-b289-3fc782d3ff64-1760550192582.webp	800	529	webp	85	82934	cmgsa4phm01f5h9i67k29ea4z
cmgsa4s7v01fgh9i61qzr3ut7	/public/images/medium/beb57cb5-7309-4d0a-bcbd-77a3e72f4c98-1760550196363.webp	800	530	webp	85	71352	cmgsa4s7q01fch9i601v8uqcx
cmgsa4s7v01fih9i6vj1w0kwd	/public/images/full/beb57cb5-7309-4d0a-bcbd-77a3e72f4c98-1760550196363.webp	5247	3478	webp	90	1862946	cmgsa4s7q01fch9i601v8uqcx
cmgsa4s7v01ffh9i65iwl6u4i	/public/images/thumbnails/beb57cb5-7309-4d0a-bcbd-77a3e72f4c98-1760550196363.webp	150	150	webp	80	6950	cmgsa4s7q01fch9i601v8uqcx
cmgsa4uxt01flh9i665beftlx	/public/images/thumbnails/c879cf49-5420-4773-9e39-6033f27f01cc-1760550199892.webp	150	150	webp	80	7356	cmgsa4uxr01fjh9i6ydtsarea
cmgsa4uxu01foh9i6r8rbkq6q	/public/images/full/c879cf49-5420-4773-9e39-6033f27f01cc-1760550199892.webp	5247	3478	webp	90	2025966	cmgsa4uxr01fjh9i6ydtsarea
cmgsa4uxu01fph9i675x1jo7r	/public/images/medium/c879cf49-5420-4773-9e39-6033f27f01cc-1760550199892.webp	800	530	webp	85	83270	cmgsa4uxr01fjh9i6ydtsarea
cmgsa4xn301fuh9i6z0n42yyd	/public/images/thumbnails/bf64fbfc-1152-4bb2-92a8-87c3d0b698bc-1760550203421.webp	150	150	webp	80	8442	cmgsa4xmz01fqh9i6we2gpyhk
cmgsa50im01g1h9i6f3so97ig	/public/images/full/efc3cc4b-9864-43e5-aed8-c5f397939afa-1760550206915.webp	5419	3494	webp	90	1788494	cmgsa50ij01fxh9i6g5uzct1g
cmgsa5hcj01g9h9i67m3tx38q	/public/images/full/f6aae720-1d7d-4afa-a71a-35216ad74f96-1760550210663.webp	6954	5258	webp	90	4039886	cmgsa5hcf01g4h9i66idyj2ea
cmgsa5k8t01ggh9i6jsqpt754	/public/images/thumbnails/91361daa-67f8-4031-9479-baf7b7a35def-1760550232463.webp	150	150	webp	80	7934	cmgsa5k8r01gbh9i62o3a2p1f
cmgsa5n2w01goh9i6n94blp5s	/public/images/medium/590a99a0-1cc4-47f0-af14-9d654d5e402e-1760550236216.webp	800	595	webp	85	90408	cmgsa5n2r01gih9i6gl32ay6u
cmgsa5oxw01gsh9i6xfhj5vhx	/public/images/medium/ba5b331c-65f5-4d9e-a6e1-cb7d1f09dab5-1760550239881.webp	800	1076	webp	85	135798	cmgsa5oxu01gph9i60i84y5rr
cmgsa5qjf01h2h9i6l3ewde29	/public/images/full/bff276e7-13e8-4f8a-9df7-e97c0c9d4edf-1760550242312.webp	3435	2792	webp	90	996570	cmgsa5qjb01gwh9i6l6yof2zb
cmgsa5s9201h9h9i6uhpgleq0	/public/images/medium/67c0397b-da5b-4263-9d63-c7812a6a61d9-1760550244375.webp	800	536	webp	85	83882	cmgsa5s8x01h3h9i6aphaegsc
cmgsa5tx501heh9i6k2bnhfen	/public/images/medium/9599e4c2-04af-47ff-b6dd-32a0a42dd82d-1760550246588.webp	800	1075	webp	85	127466	cmgsa5tx301hah9i6v07radlo
cmgsa5vqb01hmh9i6b371o5ba	/public/images/medium/dea58f40-f670-4b6f-8e2a-17a730f76863-1760550248744.webp	800	1027	webp	85	122538	cmgsa5vq801hhh9i6pgjqqm05
cmgsa5x8h01hsh9i6nltui0az	/public/images/thumbnails/0ef66108-7b28-43b4-beb4-530551a5e044-1760550251107.webp	150	150	webp	80	6802	cmgsa5x8e01hoh9i6jkou2zux
cmgsa5z4e01hzh9i6nxuxyogm	/public/images/thumbnails/7b7299d9-e1c5-4e88-a0f7-b609acd5c731-1760550253051.webp	150	150	webp	80	8422	cmgsa5z4601hvh9i6xgnbkxy6
cmgsa60qj01i8h9i6b6bl2tv7	/public/images/thumbnails/8785e4e5-f9cb-411a-817a-c7888e1d41b8-1760550255492.webp	150	150	webp	80	8276	cmgsa60qg01i2h9i610tmlyis
cmgsa62q601ifh9i6znuqzufk	/public/images/medium/d63f43c8-1236-483b-b1a9-7dfaf11e514d-1760550257582.webp	800	1200	webp	85	135590	cmgsa62q301i9h9i6oishdz1n
cmgsa654d01ilh9i6whqez1w8	/public/images/full/f27b13e8-a75e-482c-b706-5e2fc9e83e7f-1760550260160.webp	4462	2974	webp	90	1157976	cmgsa654401igh9i6m7vzwr4u
cmgsa67i001iqh9i6fpivuq81	/public/images/thumbnails/28f098a7-7d60-44ab-bbf9-53fd953bdc86-1760550263287.webp	150	150	webp	80	5998	cmgsa67hw01inh9i67jwfjfv8
cmgsa69fl01j0h9i62hvc09ip	/public/images/medium/96aa85b0-225e-477d-a2ed-a170d0bdc7dc-1760550266353.webp	800	1175	webp	85	113282	cmgsa69fh01iuh9i63p1yrm7t
cmgsa6bhc01j4h9i6uysy4mod	/public/images/thumbnails/712cf770-e983-4194-8623-16210a440a3a-1760550268857.webp	150	150	webp	80	9324	cmgsa6bh701j1h9i6m5ldajgs
cmgsa6eyt01jbh9i6pfmyzda2	/public/images/thumbnails/c778129e-a3f8-4013-b84c-4480465ab9e9-1760550271524.webp	150	150	webp	80	9660	cmgsa6eyq01j8h9i6w42l624f
cmgsa6gum01jlh9i61wvyjydu	/public/images/medium/90cacbc0-8777-49b5-8e26-2ea05b918dd1-1760550276024.webp	800	541	webp	85	91654	cmgsa6gui01jfh9i6bh7rlh6r
cmgsa6jhr01jqh9i698lverqt	/public/images/medium/3730f698-6180-4467-93dc-904c1b094f33-1760550278468.webp	800	1161	webp	85	179230	cmgsa6jhp01jmh9i6sgkpxlcx
cmgsalw4m02psh9i69qqbs29h	/public/images/full/f7c4c5c1-c4fa-4db6-a7a8-117b70f8c54f-1760550994348.webp	3572	5325	webp	90	1854028	cmgsalw4h02pmh9i61inht8tz
cmgsalydv02pzh9i6qf3800iw	/public/images/medium/e08b2a0f-2475-4930-a4fb-dbf94561c0c5-1760550998112.webp	800	1174	webp	85	230514	cmgsalydm02pth9i6l7oj974g
cmgsam0bf02q6h9i6hf26itcx	/public/images/medium/0a970dd6-2f7c-45fb-a342-8c5ddbdfadb1-1760551001030.webp	800	1178	webp	85	201404	cmgsam0bc02q0h9i6kgqp2k8r
cmgsam1so02qbh9i6i6rskrzn	/public/images/medium/0764776c-1eec-4315-9b1c-7ddbf1aef9a1-1760551003530.webp	800	572	webp	85	61218	cmgsam1sl02q7h9i6t9hmkj6z
cmgsam38e02qjh9i6qk7l8uhf	/public/images/thumbnails/41924c0e-8ac9-4d8d-8e8b-7a1b1fa92602-1760551005452.webp	150	150	webp	80	6104	cmgsam38b02qeh9i6wsyd8oqo
cmgsam4mw02qph9i6rli86e6f	/public/images/thumbnails/294f46d2-7026-4d71-be8e-9af22032b2b4-1760551007314.webp	150	150	webp	80	6792	cmgsam4mt02qlh9i6lrqeeslg
cmgsam7fd02qyh9i6v8wdjcz8	/public/images/medium/aa9cffc2-fa3a-49d6-a9a8-6e2f94b7e44e-1760551009146.webp	800	1157	webp	85	204728	cmgsam7fa02qsh9i6ynnoqy0g
cmgsama9602r5h9i6meudx51o	/public/images/full/795be836-29d0-4287-8a9e-8411b1d7ba22-1760551012757.webp	5106	3525	webp	90	1996882	cmgsama9302qzh9i65h7ar8vj
cmgsasslc036bh9i6fyaip32d	/public/images/full/0b5025d7-5973-4455-98e2-bff1d3c6c944-1760551317795.webp	2732	3899	webp	90	1021392	cmgsassla0365h9i6e0zmnfyn
cmgsasslc036ah9i6tvq7cj7f	/public/images/medium/0b5025d7-5973-4455-98e2-bff1d3c6c944-1760551317795.webp	800	1141	webp	85	163566	cmgsassla0365h9i6e0zmnfyn
cmgsasu6b036hh9i6rtc34y4f	/public/images/full/6c005847-6d27-4f32-b6ee-a9ca01e5f6d6-1760551320112.webp	2636	3654	webp	90	884580	cmgsasu68036ch9i6g9bws37r
cmgsasu6b036gh9i68xhk8s57	/public/images/thumbnails/6c005847-6d27-4f32-b6ee-a9ca01e5f6d6-1760551320112.webp	150	150	webp	80	8622	cmgsasu68036ch9i6g9bws37r
cmgsasx7l036lh9i6911l34oc	/public/images/thumbnails/9002b47c-5d81-439e-b117-d078f0432501-1760551322173.webp	150	150	webp	80	6500	cmgsasx7i036jh9i6y31tg6cb
cmgsasx7l036ph9i6d86h1noo	/public/images/full/9002b47c-5d81-439e-b117-d078f0432501-1760551322173.webp	3686	5258	webp	90	1991502	cmgsasx7i036jh9i6y31tg6cb
cmgsat0a4036uh9i6gw1v3clr	/public/images/medium/fbaf3092-bbdd-4133-bd50-3213a4a0e474-1760551326096.webp	800	1154	webp	85	171278	cmgsat0a1036qh9i6hydq8x2a
cmgsat0a5036wh9i60q0o48tr	/public/images/full/fbaf3092-bbdd-4133-bd50-3213a4a0e474-1760551326096.webp	3644	5258	webp	90	1843754	cmgsat0a1036qh9i6hydq8x2a
cmgsat3540373h9i6y258jbei	/public/images/full/7235a477-ee86-469a-a3b5-90bbbc1c0953-1760551330082.webp	5258	3686	webp	90	1861064	cmgsat352036xh9i6hjiuclrd
cmgsat3540371h9i6oovr9fpi	/public/images/medium/7235a477-ee86-469a-a3b5-90bbbc1c0953-1760551330082.webp	800	561	webp	85	71120	cmgsat352036xh9i6hjiuclrd
cmgsat62o0378h9i6m0tqxwm9	/public/images/full/de1e2b59-3d3a-4ced-9691-635f10c89d2d-1760551333789.webp	5262	3759	webp	90	1761466	cmgsat62k0374h9i608h91mix
cmgsat62o0379h9i6d5i9ktl9	/public/images/thumbnails/de1e2b59-3d3a-4ced-9691-635f10c89d2d-1760551333789.webp	150	150	webp	80	7038	cmgsat62k0374h9i608h91mix
cmgsat968037dh9i6pta2tzvz	/public/images/medium/1fe3966c-8137-473c-aead-9044c6a7204e-1760551337595.webp	800	1122	webp	85	137952	cmgsat964037bh9i676te9j9n
cmgsat969037hh9i6maqy7r4n	/public/images/full/1fe3966c-8137-473c-aead-9044c6a7204e-1760551337595.webp	3854	5405	webp	90	1884448	cmgsat964037bh9i676te9j9n
cmgsa4xn401fwh9i6dccnxzxe	/public/images/full/bf64fbfc-1152-4bb2-92a8-87c3d0b698bc-1760550203421.webp	5294	3603	webp	90	1711224	cmgsa4xmz01fqh9i6we2gpyhk
cmgsa50im01g2h9i63n6q4en2	/public/images/thumbnails/efc3cc4b-9864-43e5-aed8-c5f397939afa-1760550206915.webp	150	150	webp	80	5120	cmgsa50ij01fxh9i6g5uzct1g
cmgsa5hcj01g6h9i6u36r2n99	/public/images/thumbnails/f6aae720-1d7d-4afa-a71a-35216ad74f96-1760550210663.webp	150	150	webp	80	7670	cmgsa5hcf01g4h9i66idyj2ea
cmgsa5k8t01ghh9i6ioyj82rm	/public/images/full/91361daa-67f8-4031-9479-baf7b7a35def-1760550232463.webp	5309	3821	webp	90	1421584	cmgsa5k8r01gbh9i62o3a2p1f
cmgsa5n2w01gnh9i6058t3k07	/public/images/thumbnails/590a99a0-1cc4-47f0-af14-9d654d5e402e-1760550236216.webp	150	150	webp	80	7930	cmgsa5n2r01gih9i6gl32ay6u
cmgsa5oxw01gth9i6xx3g67l2	/public/images/thumbnails/ba5b331c-65f5-4d9e-a6e1-cb7d1f09dab5-1760550239881.webp	150	150	webp	80	5934	cmgsa5oxu01gph9i60i84y5rr
cmgsa5qjf01gzh9i6gtnyp2ad	/public/images/medium/bff276e7-13e8-4f8a-9df7-e97c0c9d4edf-1760550242312.webp	800	650	webp	85	123958	cmgsa5qjb01gwh9i6l6yof2zb
cmgsa5s9201h7h9i64qsn983h	/public/images/thumbnails/67c0397b-da5b-4263-9d63-c7812a6a61d9-1760550244375.webp	150	150	webp	80	8496	cmgsa5s8x01h3h9i6aphaegsc
cmgsa5tx601hgh9i6qfx3bil2	/public/images/full/9599e4c2-04af-47ff-b6dd-32a0a42dd82d-1760550246588.webp	2869	3854	webp	90	762964	cmgsa5tx301hah9i6v07radlo
cmgsa5vqb01hlh9i6z1ql5zkx	/public/images/thumbnails/dea58f40-f670-4b6f-8e2a-17a730f76863-1760550248744.webp	150	150	webp	80	6662	cmgsa5vq801hhh9i6pgjqqm05
cmgsa5x8h01huh9i6otoh8dnm	/public/images/medium/0ef66108-7b28-43b4-beb4-530551a5e044-1760550251107.webp	800	629	webp	85	80202	cmgsa5x8e01hoh9i6jkou2zux
cmgsa5z4e01i1h9i6lcdwo86v	/public/images/full/7b7299d9-e1c5-4e88-a0f7-b609acd5c731-1760550253051.webp	3951	3010	webp	90	1030722	cmgsa5z4601hvh9i6xgnbkxy6
cmgsa60qj01i6h9i6ziir7hrz	/public/images/medium/8785e4e5-f9cb-411a-817a-c7888e1d41b8-1760550255492.webp	800	622	webp	85	88580	cmgsa60qg01i2h9i610tmlyis
cmgsa62q601idh9i6blg5woss	/public/images/thumbnails/d63f43c8-1236-483b-b1a9-7dfaf11e514d-1760550257582.webp	150	150	webp	80	8522	cmgsa62q301i9h9i6oishdz1n
cmgsa654d01imh9i6exm14nq1	/public/images/thumbnails/f27b13e8-a75e-482c-b706-5e2fc9e83e7f-1760550260160.webp	150	150	webp	80	9496	cmgsa654401igh9i6m7vzwr4u
cmgsa67i101ith9i6qdi0h04f	/public/images/medium/28f098a7-7d60-44ab-bbf9-53fd953bdc86-1760550263287.webp	800	1170	webp	85	204146	cmgsa67hw01inh9i67jwfjfv8
cmgsa69fl01iyh9i6ctmpa17b	/public/images/full/96aa85b0-225e-477d-a2ed-a170d0bdc7dc-1760550266353.webp	2995	4399	webp	90	860638	cmgsa69fh01iuh9i63p1yrm7t
cmgsa6bhc01j7h9i6kmih2ubn	/public/images/full/712cf770-e983-4194-8623-16210a440a3a-1760550268857.webp	2979	4357	webp	90	978758	cmgsa6bh701j1h9i6m5ldajgs
cmgsa6eyt01jch9i6mh599dk4	/public/images/medium/c778129e-a3f8-4013-b84c-4480465ab9e9-1760550271524.webp	800	562	webp	85	94856	cmgsa6eyq01j8h9i6w42l624f
cmgsa6gum01jkh9i6pq41xf8k	/public/images/full/90cacbc0-8777-49b5-8e26-2ea05b918dd1-1760550276024.webp	4357	2948	webp	90	1016106	cmgsa6gui01jfh9i6bh7rlh6r
cmgsa6jhr01jsh9i6qu1cdlm7	/public/images/thumbnails/3730f698-6180-4467-93dc-904c1b094f33-1760550278468.webp	150	150	webp	80	7144	cmgsa6jhp01jmh9i6sgkpxlcx
cmgsamcv102rbh9i69nickuyj	/public/images/medium/dc08c2ea-8804-4fe3-a788-a6933016d693-1760551016413.webp	800	519	webp	85	94058	cmgsamcuv02r6h9i6fu846d5j
cmgsamcv102rch9i612f718pe	/public/images/full/dc08c2ea-8804-4fe3-a788-a6933016d693-1760551016413.webp	5075	3291	webp	90	1700658	cmgsamcuv02r6h9i6fu846d5j
cmgsamcv102rah9i6zmavpoq1	/public/images/thumbnails/dc08c2ea-8804-4fe3-a788-a6933016d693-1760551016413.webp	150	150	webp	80	8992	cmgsamcuv02r6h9i6fu846d5j
cmgsamfrt02rgh9i6ayugxdwt	/public/images/thumbnails/df09b705-5ee8-4852-8fad-1e740570b89c-1760551019793.webp	150	150	webp	80	8200	cmgsamfrq02rdh9i637n8anup
cmgsamfrt02rih9i6rhp07xma	/public/images/full/df09b705-5ee8-4852-8fad-1e740570b89c-1760551019793.webp	5200	3478	webp	90	2383206	cmgsamfrq02rdh9i637n8anup
cmgsamfrt02rjh9i6ayeddmg8	/public/images/medium/df09b705-5ee8-4852-8fad-1e740570b89c-1760551019793.webp	800	535	webp	85	77002	cmgsamfrq02rdh9i637n8anup
cmgsamgmq02rqh9i6qgd0y0jw	/public/images/full/5b441c75-1111-4dbb-b2b5-f3f3c5781ed6-1760551023562.webp	1811	2573	webp	90	240502	cmgsamgmk02rkh9i6jw2kreiz
cmgsamgmq02rph9i6824wbefs	/public/images/thumbnails/5b441c75-1111-4dbb-b2b5-f3f3c5781ed6-1760551023562.webp	150	150	webp	80	3602	cmgsamgmk02rkh9i6jw2kreiz
cmgsamgmq02roh9i6fleady3a	/public/images/medium/5b441c75-1111-4dbb-b2b5-f3f3c5781ed6-1760551023562.webp	800	1137	webp	85	69344	cmgsamgmk02rkh9i6jw2kreiz
cmgsamjfs02rwh9i6p635bq6j	/public/images/thumbnails/78146fd2-289d-49df-a3a0-e9902c6cb59f-1760551024680.webp	150	150	webp	80	7502	cmgsamjfo02rrh9i6c6gd4zsn
cmgsamjfs02rxh9i69znz6gqt	/public/images/medium/78146fd2-289d-49df-a3a0-e9902c6cb59f-1760551024680.webp	800	1210	webp	85	218664	cmgsamjfo02rrh9i6c6gd4zsn
cmgsamjfs02rvh9i6btoa6k6k	/public/images/full/78146fd2-289d-49df-a3a0-e9902c6cb59f-1760551024680.webp	3373	5101	webp	90	2144782	cmgsamjfo02rrh9i6c6gd4zsn
cmgsamke602s2h9i60jq64lor	/public/images/thumbnails/1f036044-f56f-4c5f-9b03-1fe55353370d-1760551028315.webp	150	150	webp	80	8400	cmgsamke302ryh9i6pgy0t7nr
cmgsamke602s4h9i6b0f2w0h0	/public/images/full/1f036044-f56f-4c5f-9b03-1fe55353370d-1760551028315.webp	2717	1747	webp	90	696640	cmgsamke302ryh9i6pgy0t7nr
cmgsamke602s3h9i6jr9n3e3e	/public/images/medium/1f036044-f56f-4c5f-9b03-1fe55353370d-1760551028315.webp	800	514	webp	85	104720	cmgsamke302ryh9i6pgy0t7nr
cmgsamlx402s7h9i6xbaq69be	/public/images/thumbnails/a8c60b5b-d093-45cc-b161-570f5362d92b-1760551029559.webp	150	150	webp	80	8112	cmgsamlx202s5h9i6ogoqajhr
cmgsamlx402sah9i6z11f3ddd	/public/images/medium/a8c60b5b-d093-45cc-b161-570f5362d92b-1760551029559.webp	800	506	webp	85	81496	cmgsamlx202s5h9i6ogoqajhr
cmgsamlx402sbh9i6sjiomav0	/public/images/full/a8c60b5b-d093-45cc-b161-570f5362d92b-1760551029559.webp	3966	2511	webp	90	809064	cmgsamlx202s5h9i6ogoqajhr
cmgsamn4t02sgh9i62axgk0lh	/public/images/full/24f1cb13-2ed7-4833-9c47-821ed5c05c6b-1760551031533.webp	3201	2199	webp	90	819172	cmgsamn4p02sch9i65tof9oq2
cmgsamn4t02shh9i6tdx3dwsh	/public/images/medium/24f1cb13-2ed7-4833-9c47-821ed5c05c6b-1760551031533.webp	800	550	webp	85	96696	cmgsamn4p02sch9i65tof9oq2
cmgsamn4t02sih9i6t3mw6xw0	/public/images/thumbnails/24f1cb13-2ed7-4833-9c47-821ed5c05c6b-1760551031533.webp	150	150	webp	80	6398	cmgsamn4p02sch9i65tof9oq2
cmgsamoom02snh9i63y8kc21i	/public/images/medium/1e3ed21b-c53f-49d8-807f-c628e907edb1-1760551033105.webp	800	557	webp	85	98120	cmgsamook02sjh9i6fomkxj47
cmgsa4xn301fvh9i6vi8xp283	/public/images/medium/bf64fbfc-1152-4bb2-92a8-87c3d0b698bc-1760550203421.webp	800	544	webp	85	94266	cmgsa4xmz01fqh9i6we2gpyhk
cmgsa50im01g3h9i6nvhpfwan	/public/images/medium/efc3cc4b-9864-43e5-aed8-c5f397939afa-1760550206915.webp	800	516	webp	85	47938	cmgsa50ij01fxh9i6g5uzct1g
cmgsa5hcj01gah9i6mr3ulgdr	/public/images/medium/f6aae720-1d7d-4afa-a71a-35216ad74f96-1760550210663.webp	800	605	webp	85	79132	cmgsa5hcf01g4h9i66idyj2ea
cmgsa5k8t01gfh9i6o08m7zvr	/public/images/medium/91361daa-67f8-4031-9479-baf7b7a35def-1760550232463.webp	800	576	webp	85	81482	cmgsa5k8r01gbh9i62o3a2p1f
cmgsa5n2w01gmh9i6yeill8dt	/public/images/full/590a99a0-1cc4-47f0-af14-9d654d5e402e-1760550236216.webp	5200	3868	webp	90	1621834	cmgsa5n2r01gih9i6gl32ay6u
cmgsamoom02soh9i69mtn5sua	/public/images/thumbnails/1e3ed21b-c53f-49d8-807f-c628e907edb1-1760551033105.webp	150	150	webp	80	8428	cmgsamook02sjh9i6fomkxj47
cmgsamq5402svh9i6fzifd51u	/public/images/full/27715c80-8764-4c7c-b987-58d1dacb109f-1760551035113.webp	3263	2511	webp	90	1045260	cmgsamq5002sqh9i6licnoiey
cmgsamrjb02t1h9i6i6ve207p	/public/images/thumbnails/093089af-28bf-496f-a133-80245bb9c1ff-1760551037006.webp	150	150	webp	80	8936	cmgsamrj802sxh9i673i059ai
cmgsamszl02tah9i615dwe4g4	/public/images/medium/85c6b418-3b7c-4b43-903b-4aaa3bd68447-1760551038808.webp	800	1013	webp	85	181978	cmgsamsze02t4h9i6jxqlicwz
cmgsamudq02tgh9i6uxc7uswg	/public/images/thumbnails/1fec16e4-705f-45ca-b0d5-50ec9e86747c-1760551040687.webp	150	150	webp	80	8402	cmgsamudn02tbh9i637z78py2
cmgsamvto02tmh9i6i90pmxo0	/public/images/full/84ce802a-cda1-4494-90b9-97d0fce28a8a-1760551042496.webp	3248	2589	webp	90	886224	cmgsamvtk02tih9i6zyagrkkc
cmgsamx8j02tvh9i6ybydn63x	/public/images/medium/84ded9c2-0740-4a3d-878c-0db62a6f384f-1760551044364.webp	800	1012	webp	85	101918	cmgsamx8g02tph9i6dclutool
cmgsamywg02u1h9i6s07p6ev6	/public/images/medium/2483c744-3ba5-4cf0-ad9d-7c6d571c102e-1760551046203.webp	800	1118	webp	85	281422	cmgsamywa02twh9i6def223yy
cmgsanj3502u5h9i6ewbkh51x	/public/images/thumbnails/3bf46c16-b7ca-4a1d-bec8-c004415938a5-1760551048370.webp	150	150	webp	80	8926	cmgsanj3202u3h9i6sirt3mbj
cmgsankkf02ugh9i6lbt5z0p6	/public/images/medium/e0932283-0e74-43bb-9b77-d98617183f85-1760551074513.webp	800	581	webp	85	113338	cmgsankkb02uah9i62amepee0
cmgsanmhf02umh9i6vb7224a5	/public/images/medium/63ee5e56-27e9-4465-81b3-43447e4c59e5-1760551076430.webp	800	790	webp	85	100326	cmgsanmhc02uhh9i6qh9x0afl
cmgsannz702uth9i6o9pq9x0l	/public/images/full/bdd65757-2230-4701-819b-02fa3d21aca4-1760551078921.webp	3654	2573	webp	90	937266	cmgsannz402uoh9i6bg198r08
cmgsanpvj02v0h9i6asjc2yv9	/public/images/thumbnails/bf8e6dc6-2031-484d-aa10-8708bcb0f6b4-1760551080858.webp	150	150	webp	80	6752	cmgsanpvf02uvh9i6o9jrq6tb
cmgsansl902v6h9i68px5306o	/public/images/full/56180721-490f-4a33-bb52-bea77c58ed4e-1760551083321.webp	5200	3556	webp	90	1489134	cmgsansl502v2h9i6l9u8f2u2
cmgsantoq02veh9i6k1ub8zdm	/public/images/full/8cbfae35-3333-491c-ad12-48002faefe93-1760551086833.webp	2779	2106	webp	90	670278	cmgsanton02v9h9i6upnpoy0p
cmgsanun702vkh9i6ildrg42f	/public/images/medium/2bcf4553-696e-47bb-9186-b5de1588448c-1760551088248.webp	800	511	webp	85	126820	cmgsanun302vgh9i6ji5pmb47
cmgsanvkt02vrh9i6yjfiw4e0	/public/images/full/4b911ad4-39c3-43cf-ac3f-6e0410f97ee1-1760551089494.webp	2592	1747	webp	90	840930	cmgsanvkq02vnh9i60fqkpfmq
cmgsao0bs02vyh9i6kxcjhkli	/public/images/thumbnails/6d2bf0a5-efaf-4818-9944-3f92ae2a103e-1760551090711.webp	150	150	webp	80	3712	cmgsao0bm02vuh9i6eo1nynr6
cmgsao1zl02w5h9i6nchb90df	/public/images/medium/4da92417-c11f-4194-9900-8ab15e22deee-1760551096864.webp	800	1269	webp	85	187246	cmgsao1zf02w1h9i63n1pp3k9
cmgsao3ni02wdh9i6x65sktdc	/public/images/full/c385c31f-cfb0-4bfc-bf78-b6da1a7032b8-1760551099014.webp	2467	3712	webp	90	1080176	cmgsao3ne02w8h9i6jvpjg055
cmgsao5bn02wjh9i6ljrexkhl	/public/images/full/59cdc6be-ad8b-43f9-9983-dc7bc9e64cad-1760551101177.webp	2576	3650	webp	90	1122840	cmgsao5bi02wfh9i6t1fd7uv4
cmgsao7zf02wqh9i65rym7m4j	/public/images/thumbnails/0a4b54b4-edf8-4810-a046-cd3311a6051c-1760551103348.webp	150	150	webp	80	6624	cmgsao7zb02wmh9i6tt2u9huz
cmgsaoalz02wxh9i6z5d2qr95	/public/images/full/05344b1e-59b7-45b2-bea0-b409c8e91452-1760551106788.webp	4919	3338	webp	90	1980890	cmgsaoalv02wth9i6vukatwgf
cmgsaodg102x6h9i6rzcve7g9	/public/images/medium/b98e3e8a-1c08-414a-a7ed-c8956735139c-1760551110199.webp	800	1198	webp	85	214806	cmgsaodfw02x0h9i6bdmyn00t
cmgsaofnx02xch9i6l3hx7uze	/public/images/thumbnails/12a5f1eb-cd6c-4002-babd-e8f43361feb8-1760551113863.webp	150	150	webp	80	6538	cmgsaofnv02x7h9i6tjbznx8i
cmgsaohzt02xih9i62g6rdw35	/public/images/full/98c460ff-99fd-4a04-aeac-0b6d8e45e6ab-1760551116735.webp	4981	3385	webp	90	1199714	cmgsaohzp02xeh9i6esxa25zc
cmgsaoker02xrh9i6ndmskbz9	/public/images/thumbnails/06962ce0-c41e-424e-99dd-d8849edb9d41-1760551119765.webp	150	150	webp	80	8632	cmgsaokem02xlh9i66uq7a8j3
cmgsaonas02xvh9i6yexdxz9h	/public/images/thumbnails/0eaf3505-d383-418c-86ec-27daa4a298ae-1760551122895.webp	150	150	webp	80	7544	cmgsaonaq02xsh9i64wmlau61
cmgsaovrk02y5h9i6zvy7dglk	/public/images/full/881ab602-39d4-4795-860c-ec8bfb776d07-1760551126647.webp	5091	6879	webp	90	3114880	cmgsaovrh02xzh9i6gmljov5z
cmgsapaz202yah9i6hp8r6tzp	/public/images/medium/e17a5dc6-f69a-4b32-a685-16ee7959e723-1760551137616.webp	800	1036	webp	85	117420	cmgsapayz02y6h9i64hdfegvs
cmgsappjc02yhh9i6fnm1nqew	/public/images/full/89c17e17-9cf4-4051-a0c4-ec75e6f6faa6-1760551157322.webp	6754	5216	webp	90	2562274	cmgsappj902ydh9i6wkhtumwe
cmgsapsdn02yoh9i6qt1jk669	/public/images/medium/9eade249-b00b-419c-b56b-d0e569c681fb-1760551176195.webp	800	1206	webp	85	194830	cmgsapsdj02ykh9i67102gsm7
cmgsapx9c02yxh9i6icupdxbp	/public/images/thumbnails/9bf043ff-3309-4a8f-a49d-4eb7018ba222-1760551179885.webp	150	150	webp	80	6474	cmgsapx9902yrh9i6xnrochap
cmgsapygs02z4h9i6m48g0r5g	/public/images/full/b2fceceb-5476-4497-ab41-1d096335c70b-1760551186192.webp	2136	2597	webp	90	785938	cmgsapygm02yyh9i6lsrvomvd
cmgsapzpt02zbh9i6drqdmisg	/public/images/medium/bdf1d566-602d-4217-9f47-ae5871eb318e-1760551187765.webp	800	981	webp	85	222894	cmgsapzpq02z5h9i6qsg3v8nh
cmgsaq17302zih9i63ik3rocu	/public/images/full/a2978841-fc5a-45ec-bd85-2b5512c9611b-1760551189378.webp	2123	3307	webp	90	1119116	cmgsaq17002zch9i6uvf5djce
cmgsaq22y02zmh9i6py4rnj5m	/public/images/thumbnails/0579dce0-cf57-48ac-971e-c2d2a6d12460-1760551191297.webp	150	150	webp	80	6850	cmgsaq22v02zjh9i6aw88r1fw
cmgsaq34g02zvh9i6zdybadm4	/public/images/thumbnails/2065cdf0-17c0-48f0-9b05-f609c3ddae1a-1760551192448.webp	150	150	webp	80	6670	cmgsaq34c02zqh9i6pnysdtqc
cmgsa5oye01gvh9i6s6zuz12v	/public/images/full/ba5b331c-65f5-4d9e-a6e1-cb7d1f09dab5-1760550239881.webp	2807	3774	webp	90	1202426	cmgsa5oxu01gph9i60i84y5rr
cmgsa5qjf01h0h9i68inqiufr	/public/images/thumbnails/bff276e7-13e8-4f8a-9df7-e97c0c9d4edf-1760550242312.webp	150	150	webp	80	10246	cmgsa5qjb01gwh9i6l6yof2zb
cmgsa5s9201h8h9i68qwb4uxm	/public/images/full/67c0397b-da5b-4263-9d63-c7812a6a61d9-1760550244375.webp	4169	2792	webp	90	813328	cmgsa5s8x01h3h9i6aphaegsc
cmgsa5tx501hdh9i6k85lubiz	/public/images/thumbnails/9599e4c2-04af-47ff-b6dd-32a0a42dd82d-1760550246588.webp	150	150	webp	80	7692	cmgsa5tx301hah9i6v07radlo
cmgsa5vqb01hnh9i6022k29f2	/public/images/full/dea58f40-f670-4b6f-8e2a-17a730f76863-1760550248744.webp	3014	3868	webp	90	982698	cmgsa5vq801hhh9i6pgjqqm05
cmgsa5x8h01hrh9i6lrwtyr5z	/public/images/full/0ef66108-7b28-43b4-beb4-530551a5e044-1760550251107.webp	3451	2714	webp	90	781384	cmgsa5x8e01hoh9i6jkou2zux
cmgsa5z4e01i0h9i618zl0l0u	/public/images/medium/7b7299d9-e1c5-4e88-a0f7-b609acd5c731-1760550253051.webp	800	610	webp	85	85194	cmgsa5z4601hvh9i6xgnbkxy6
cmgsa60qj01i7h9i6am3awgqw	/public/images/full/8785e4e5-f9cb-411a-817a-c7888e1d41b8-1760550255492.webp	3591	2792	webp	90	1021138	cmgsa60qg01i2h9i610tmlyis
cmgsa62q601ieh9i668cpc5yv	/public/images/full/d63f43c8-1236-483b-b1a9-7dfaf11e514d-1760550257582.webp	2974	4462	webp	90	943708	cmgsa62q301i9h9i6oishdz1n
cmgsa654d01ikh9i6d82m59gi	/public/images/medium/f27b13e8-a75e-482c-b706-5e2fc9e83e7f-1760550260160.webp	800	533	webp	85	111214	cmgsa654401igh9i6m7vzwr4u
cmgsa67i001irh9i6zrlt6olt	/public/images/full/28f098a7-7d60-44ab-bbf9-53fd953bdc86-1760550263287.webp	2979	4357	webp	90	1277178	cmgsa67hw01inh9i67jwfjfv8
cmgsa69fl01izh9i6fwue51hx	/public/images/thumbnails/96aa85b0-225e-477d-a2ed-a170d0bdc7dc-1760550266353.webp	150	150	webp	80	8082	cmgsa69fh01iuh9i63p1yrm7t
cmgsa6bhc01j5h9i6g7quvjrq	/public/images/medium/712cf770-e983-4194-8623-16210a440a3a-1760550268857.webp	800	1170	webp	85	151834	cmgsa6bh701j1h9i6m5ldajgs
cmgsa6eyt01jeh9i6kg399tdh	/public/images/full/c778129e-a3f8-4013-b84c-4480465ab9e9-1760550271524.webp	5023	3529	webp	90	4234986	cmgsa6eyq01j8h9i6w42l624f
cmgsa6gum01jih9i6shuk9j24	/public/images/thumbnails/90cacbc0-8777-49b5-8e26-2ea05b918dd1-1760550276024.webp	150	150	webp	80	9376	cmgsa6gui01jfh9i6bh7rlh6r
cmgsa6jhr01jph9i60rgenqib	/public/images/full/3730f698-6180-4467-93dc-904c1b094f33-1760550278468.webp	3521	5108	webp	90	1310704	cmgsa6jhp01jmh9i6sgkpxlcx
cmgsa6mld01jxh9i6frbhnsll	/public/images/full/237af8e4-72a9-419a-adb6-68ec044081f8-1760550281892.webp	3830	5866	webp	90	1238342	cmgsa6mla01jth9i6ryh1es3y
cmgsa6mld01jwh9i6spprjazy	/public/images/thumbnails/237af8e4-72a9-419a-adb6-68ec044081f8-1760550281892.webp	150	150	webp	80	7974	cmgsa6mla01jth9i6ryh1es3y
cmgsa6mlz01jzh9i6crm6nmj5	/public/images/medium/237af8e4-72a9-419a-adb6-68ec044081f8-1760550281892.webp	800	1225	webp	85	130640	cmgsa6mla01jth9i6ryh1es3y
cmgsa6pwz01k6h9i6n9htlh79	/public/images/full/608f682f-8839-4fe1-b577-b158fa025b3f-1760550285944.webp	3949	5896	webp	90	1465176	cmgsa6pwu01k0h9i6njetq68x
cmgsa6pwz01k4h9i60usl81ym	/public/images/medium/608f682f-8839-4fe1-b577-b158fa025b3f-1760550285944.webp	800	1195	webp	85	125552	cmgsa6pwu01k0h9i6njetq68x
cmgsa6pwz01k5h9i6q0l2mmow	/public/images/thumbnails/608f682f-8839-4fe1-b577-b158fa025b3f-1760550285944.webp	150	150	webp	80	6356	cmgsa6pwu01k0h9i6njetq68x
cmgsa6sgb01kbh9i6gvlxo8h0	/public/images/medium/db952d75-0681-4841-bd6c-d0f441fba303-1760550290213.webp	800	556	webp	85	99556	cmgsa6sg701k7h9i61hkha4pm
cmgsa6sgb01kah9i6wu181u35	/public/images/thumbnails/db952d75-0681-4841-bd6c-d0f441fba303-1760550290213.webp	150	150	webp	80	9562	cmgsa6sg701k7h9i61hkha4pm
cmgsa6sgd01kdh9i61qz87ifg	/public/images/full/db952d75-0681-4841-bd6c-d0f441fba303-1760550290213.webp	5028	3494	webp	90	1645186	cmgsa6sg701k7h9i61hkha4pm
cmgsa6u3c01kjh9i6syuzdaav	/public/images/medium/fdbc6311-39b5-4c9c-91b3-2a918ba67965-1760550293506.webp	800	513	webp	85	91734	cmgsa6u3901keh9i60o76650h
cmgsa6u3c01kkh9i69np0volo	/public/images/full/fdbc6311-39b5-4c9c-91b3-2a918ba67965-1760550293506.webp	4013	2573	webp	90	1048040	cmgsa6u3901keh9i60o76650h
cmgsa6u3c01kih9i60z93maw2	/public/images/thumbnails/fdbc6311-39b5-4c9c-91b3-2a918ba67965-1760550293506.webp	150	150	webp	80	10130	cmgsa6u3901keh9i60o76650h
cmgsa6v3s01kph9i6g8ebob9t	/public/images/full/e8ebcba9-b6fc-47b6-801a-7c6d5ec50d84-1760550295628.webp	2795	2137	webp	90	404094	cmgsa6v3m01klh9i64d9odqw0
cmgsa6v3s01krh9i60jumpudm	/public/images/thumbnails/e8ebcba9-b6fc-47b6-801a-7c6d5ec50d84-1760550295628.webp	150	150	webp	80	6422	cmgsa6v3m01klh9i64d9odqw0
cmgsa6v3s01kqh9i6yq4b4u0a	/public/images/medium/e8ebcba9-b6fc-47b6-801a-7c6d5ec50d84-1760550295628.webp	800	612	webp	85	70172	cmgsa6v3m01klh9i64d9odqw0
cmgsa6x0c01kyh9i6w5a29x83	/public/images/full/78721322-3844-43a6-9c22-b6773b90afe0-1760550296939.webp	3658	3788	webp	90	844868	cmgsa6x0a01ksh9i6ingawbgm
cmgsa6x0c01kwh9i6cwot6dyp	/public/images/thumbnails/78721322-3844-43a6-9c22-b6773b90afe0-1760550296939.webp	150	150	webp	80	5978	cmgsa6x0a01ksh9i6ingawbgm
cmgsa6x0c01kvh9i63aodf256	/public/images/medium/78721322-3844-43a6-9c22-b6773b90afe0-1760550296939.webp	800	828	webp	85	97066	cmgsa6x0a01ksh9i6ingawbgm
cmgsa6yxh01l3h9i66pkda6g4	/public/images/full/b1b842f7-2acc-4679-9b83-422580bf4351-1760550299404.webp	3681	3632	webp	90	960466	cmgsa6yxe01kzh9i66kuio2bo
cmgsa6yxh01l2h9i6yolnt1vc	/public/images/medium/b1b842f7-2acc-4679-9b83-422580bf4351-1760550299404.webp	800	790	webp	85	112444	cmgsa6yxe01kzh9i66kuio2bo
cmgsa6yxh01l5h9i6porgpcdw	/public/images/thumbnails/b1b842f7-2acc-4679-9b83-422580bf4351-1760550299404.webp	150	150	webp	80	8064	cmgsa6yxe01kzh9i66kuio2bo
cmgsa70r301lah9i6c4glahkd	/public/images/medium/9008a2fd-2df6-43ae-a901-5f84296ffebc-1760550301899.webp	800	790	webp	85	97044	cmgsa70qy01l6h9i6qpy0ga4c
cmgsa70r301lch9i6rmh50ytm	/public/images/full/9008a2fd-2df6-43ae-a901-5f84296ffebc-1760550301899.webp	3725	3677	webp	90	827624	cmgsa70qy01l6h9i6qpy0ga4c
cmgsa70r301lbh9i6hec9pq0u	/public/images/thumbnails/9008a2fd-2df6-43ae-a901-5f84296ffebc-1760550301899.webp	150	150	webp	80	6312	cmgsa70qy01l6h9i6qpy0ga4c
cmgsa728s01ljh9i60r5ze39f	/public/images/full/1843ee56-3d98-4df1-a7f5-591f8e3e44fc-1760550304254.webp	3685	2558	webp	90	713674	cmgsa728o01ldh9i6wypymbtm
cmgsa728s01lih9i6jsr431vv	/public/images/medium/1843ee56-3d98-4df1-a7f5-591f8e3e44fc-1760550304254.webp	800	555	webp	85	72352	cmgsa728o01ldh9i6wypymbtm
cmgsa728s01lhh9i6w1eey8oq	/public/images/thumbnails/1843ee56-3d98-4df1-a7f5-591f8e3e44fc-1760550304254.webp	150	150	webp	80	8440	cmgsa728o01ldh9i6wypymbtm
cmgsa750c01lnh9i68hp32fsg	/public/images/medium/50ffe865-e906-48a7-868e-f239c011cf52-1760550306190.webp	800	1206	webp	85	263110	cmgsa750a01lkh9i686ei4k9w
cmgsa77pl01lxh9i6tr0bznyr	/public/images/medium/e9a0c73a-49bb-42eb-8d17-effe41d41779-1760550309787.webp	800	536	webp	85	88284	cmgsa77pi01lrh9i6ldppnqzz
cmgsa7afp01m2h9i66sx3phk7	/public/images/medium/b52e28f1-503b-4680-82c9-2f6708456d41-1760550313290.webp	800	531	webp	85	68774	cmgsa7afn01lyh9i6toh4w3a8
cmgsa7ctt01m8h9i6th822cai	/public/images/thumbnails/73f52a0a-f0de-4255-a90d-f66a09d76c18-1760550316810.webp	150	150	webp	80	5348	cmgsa7ctr01m5h9i6ntz35a1s
cmgsa7fjz01mhh9i6jzf6hwml	/public/images/full/902d49bf-0b4d-4764-9375-d22e775a179d-1760550319919.webp	4934	3322	webp	90	2289910	cmgsa7fjx01mch9i6dukyl4ev
cmgsa7i1k01mmh9i6uriyptju	/public/images/thumbnails/cd8fb692-bcd9-4976-b7f1-a0c6b691bed9-1760550323452.webp	150	150	webp	80	5362	cmgsa7i1h01mjh9i6wcox4bf0
cmgsa7jax01muh9i6w5a33k0g	/public/images/medium/829fff66-62cb-4030-b20f-e0a81dcd2abd-1760550326674.webp	800	649	webp	85	85058	cmgsa7jat01mqh9i6niuzroek
cmgsa7lmw01n1h9i6vp9ec2k3	/public/images/full/7dd43815-ef3f-4858-9b05-4c5d9fe6dce6-1760550328309.webp	5075	3447	webp	90	1059224	cmgsa7lmu01mxh9i6oruq7qwo
cmgsa7mqb01nah9i6wv6qny52	/public/images/full/44b9ae8f-4d0d-4927-93e5-eafe0c167e8f-1760550331324.webp	2529	3041	webp	90	507748	cmgsa7mq901n4h9i6sfc94ryl
cmgsa7nls01nhh9i6dpk9j5nh	/public/images/full/55eb238b-1c0c-4fe0-b0da-b0d0e726c085-1760550332740.webp	2248	2246	webp	90	353866	cmgsa7nlq01nbh9i65ybar6fo
cmgsa7p6601nlh9i6vvly1rmo	/public/images/medium/10157ffd-e23c-4e54-9e69-516bdee111e3-1760550333875.webp	800	571	webp	85	107268	cmgsa7p6101nih9i6whpdzpz7
cmgsa7qbh01nth9i6cfhtadud	/public/images/full/fcf5801e-638a-4fc9-804c-4266c8544c96-1760550335905.webp	2681	2430	webp	90	725524	cmgsa7qbf01nph9i6cbl9w8gf
cmgsa7sxe01o0h9i62n4nebtu	/public/images/medium/0e92de7b-c1e2-4241-adbd-1f16e5f56b78-1760550337399.webp	800	507	webp	85	84906	cmgsa7sxb01nwh9i6wyr1n0j5
cmgsa7urp01o7h9i6tgfdjmqm	/public/images/full/dfa48fb0-d2fe-4fe2-92ee-b632db558c9a-1760550340800.webp	3413	3387	webp	90	990822	cmgsa7urm01o3h9i6p8f5z749
cmgsa7w0401ogh9i62mm4sc1k	/public/images/full/b0a0384b-c945-42d0-8666-17c31ad4294c-1760550343157.webp	2576	3135	webp	90	595882	cmgsa7w0201oah9i6n4nft6yj
cmgsa7xsj01olh9i62fpqddt0	/public/images/medium/cc1d720d-4158-4d6f-bb90-6283f8aece40-1760550344757.webp	800	1134	webp	85	128730	cmgsa7xsf01ohh9i61s7yqxcb
cmgsa80l501ouh9i6jymsuall	/public/images/medium/f1e701d3-0cec-4064-8912-fb776add3fe7-1760550347080.webp	800	580	webp	85	127908	cmgsa80l101ooh9i6uk4hu5ne
cmgsa821i01p1h9i613gjl4hm	/public/images/full/d3c4a495-2b69-4539-9b44-f211c480f1cf-1760550350698.webp	3607	2495	webp	90	916326	cmgsa821d01ovh9i6jneqbnnu
cmgsa83ec01p7h9i6z1zy8svh	/public/images/medium/fd056db4-3562-4858-9921-1abe840ffb9d-1760550352587.webp	800	625	webp	85	77786	cmgsa83ea01p2h9i6myp4vapt
cmgsa84s801pdh9i6tkjatw83	/public/images/thumbnails/2b6b4b3e-7703-4891-8217-63c5ddfa9089-1760550354340.webp	150	150	webp	80	10090	cmgsa84s301p9h9i6obhio0bb
cmgsa86ac01pjh9i6fuu8x2aw	/public/images/full/a85ae036-a0e0-448c-8cec-c66b4b2b3b15-1760550356146.webp	3263	2542	webp	90	1080870	cmgsa86a701pgh9i6ohul24lj
cmgsamoom02sph9i6vloe5i27	/public/images/full/1e3ed21b-c53f-49d8-807f-c628e907edb1-1760551033105.webp	3560	2480	webp	90	877546	cmgsamook02sjh9i6fomkxj47
cmgsamq5402suh9i6ampdr3py	/public/images/thumbnails/27715c80-8764-4c7c-b987-58d1dacb109f-1760551035113.webp	150	150	webp	80	9228	cmgsamq5002sqh9i6licnoiey
cmgsamrjb02t2h9i6ssz9z4q0	/public/images/full/093089af-28bf-496f-a133-80245bb9c1ff-1760551037006.webp	3232	2558	webp	90	750756	cmgsamrj802sxh9i673i059ai
cmgsamszl02t8h9i6o485dnip	/public/images/full/85c6b418-3b7c-4b43-903b-4aaa3bd68447-1760551038808.webp	2514	3182	webp	90	994904	cmgsamsze02t4h9i6jxqlicwz
cmgsamudq02tfh9i6pkrb1y3l	/public/images/full/1fec16e4-705f-45ca-b0d5-50ec9e86747c-1760551040687.webp	2592	3244	webp	90	759114	cmgsamudn02tbh9i637z78py2
cmgsamvto02toh9i6pbtyvwqo	/public/images/thumbnails/84ce802a-cda1-4494-90b9-97d0fce28a8a-1760551042496.webp	150	150	webp	80	10228	cmgsamvtk02tih9i6zyagrkkc
cmgsamx8j02tuh9i6p14mc8og	/public/images/full/84ded9c2-0740-4a3d-878c-0db62a6f384f-1760551044364.webp	2639	3338	webp	90	640172	cmgsamx8g02tph9i6dclutool
cmgsamywe02tyh9i6qenbnqjr	/public/images/thumbnails/2483c744-3ba5-4cf0-ad9d-7c6d571c102e-1760551046203.webp	150	150	webp	80	12348	cmgsamywa02twh9i6def223yy
cmgsanj3602u9h9i6ev07dg6g	/public/images/full/3bf46c16-b7ca-4a1d-bec8-c004415938a5-1760551048370.webp	7896	5908	webp	90	4983660	cmgsanj3202u3h9i6sirt3mbj
cmgsankke02udh9i6r8j0zm8u	/public/images/thumbnails/e0932283-0e74-43bb-9b77-d98617183f85-1760551074513.webp	150	150	webp	80	8220	cmgsankkb02uah9i62amepee0
cmgsanmhf02unh9i6jlijynzm	/public/images/thumbnails/63ee5e56-27e9-4465-81b3-43447e4c59e5-1760551076430.webp	150	150	webp	80	6108	cmgsanmhc02uhh9i6qh9x0afl
cmgsannz702uuh9i6xn30d7l2	/public/images/thumbnails/bdd65757-2230-4701-819b-02fa3d21aca4-1760551078921.webp	150	150	webp	80	8138	cmgsannz402uoh9i6bg198r08
cmgsanpvj02v1h9i6qmk4frvn	/public/images/full/bf8e6dc6-2031-484d-aa10-8708bcb0f6b4-1760551080858.webp	4310	2917	webp	90	1315238	cmgsanpvf02uvh9i6o9jrq6tb
cmgsansl902v7h9i64afuiaao	/public/images/medium/56180721-490f-4a33-bb52-bea77c58ed4e-1760551083321.webp	800	547	webp	85	62662	cmgsansl502v2h9i6l9u8f2u2
cmgsantoq02vdh9i6vjht1c38	/public/images/medium/8cbfae35-3333-491c-ad12-48002faefe93-1760551086833.webp	800	606	webp	85	86826	cmgsanton02v9h9i6upnpoy0p
cmgsanun702vmh9i6m5uj0w6z	/public/images/thumbnails/2bcf4553-696e-47bb-9186-b5de1588448c-1760551088248.webp	150	150	webp	80	9064	cmgsanun302vgh9i6ji5pmb47
cmgsanvkt02vth9i6rhrufu1l	/public/images/medium/4b911ad4-39c3-43cf-ac3f-6e0410f97ee1-1760551089494.webp	800	539	webp	85	143220	cmgsanvkq02vnh9i60fqkpfmq
cmgsao0bs02vzh9i6wjfnqqhr	/public/images/medium/6d2bf0a5-efaf-4818-9944-3f92ae2a103e-1760551090711.webp	800	1103	webp	85	124012	cmgsao0bm02vuh9i6eo1nynr6
cmgsao1zl02w4h9i69lwlx4tl	/public/images/thumbnails/4da92417-c11f-4194-9900-8ab15e22deee-1760551096864.webp	150	150	webp	80	4228	cmgsao1zf02w1h9i63n1pp3k9
cmgsao3ni02weh9i68g00j6dd	/public/images/thumbnails/c385c31f-cfb0-4bfc-bf78-b6da1a7032b8-1760551099014.webp	150	150	webp	80	4844	cmgsao3ne02w8h9i6jvpjg055
cmgsao5bn02wlh9i62tzkibzj	/public/images/thumbnails/59cdc6be-ad8b-43f9-9983-dc7bc9e64cad-1760551101177.webp	150	150	webp	80	4656	cmgsao5bi02wfh9i6t1fd7uv4
cmgsao7zg02wsh9i647rxp4gv	/public/images/full/0a4b54b4-edf8-4810-a046-cd3311a6051c-1760551103348.webp	5044	3400	webp	90	1794180	cmgsao7zb02wmh9i6tt2u9huz
cmgsa750c01loh9i6kjoc0mdf	/public/images/thumbnails/50ffe865-e906-48a7-868e-f239c011cf52-1760550306190.webp	150	150	webp	80	8226	cmgsa750a01lkh9i686ei4k9w
cmgsa77pl01lwh9i6pb4f1tcn	/public/images/full/e9a0c73a-49bb-42eb-8d17-effe41d41779-1760550309787.webp	5137	3447	webp	90	1833666	cmgsa77pi01lrh9i6ldppnqzz
cmgsa7afp01m3h9i6fouh7bjh	/public/images/thumbnails/b52e28f1-503b-4680-82c9-2f6708456d41-1760550313290.webp	150	150	webp	80	6666	cmgsa7afn01lyh9i6toh4w3a8
cmgsa7ctt01mbh9i6hplym5lz	/public/images/medium/73f52a0a-f0de-4255-a90d-f66a09d76c18-1760550316810.webp	800	527	webp	85	48706	cmgsa7ctr01m5h9i6ntz35a1s
cmgsa7fjz01mgh9i6mzyb6k5v	/public/images/thumbnails/902d49bf-0b4d-4764-9375-d22e775a179d-1760550319919.webp	150	150	webp	80	9226	cmgsa7fjx01mch9i6dukyl4ev
cmgsa7i1k01mnh9i6bvspfnb9	/public/images/medium/cd8fb692-bcd9-4976-b7f1-a0c6b691bed9-1760550323452.webp	800	543	webp	85	63632	cmgsa7i1h01mjh9i6wcox4bf0
cmgsa7jax01mth9i6g1b5ta77	/public/images/thumbnails/829fff66-62cb-4030-b20f-e0a81dcd2abd-1760550326674.webp	150	150	webp	80	7338	cmgsa7jat01mqh9i6niuzroek
cmgsa7lmw01n2h9i6mzw9w0tu	/public/images/medium/7dd43815-ef3f-4858-9b05-4c5d9fe6dce6-1760550328309.webp	800	543	webp	85	73194	cmgsa7lmu01mxh9i6oruq7qwo
cmgsa7mqb01n9h9i6qd78jjfw	/public/images/medium/44b9ae8f-4d0d-4927-93e5-eafe0c167e8f-1760550331324.webp	800	962	webp	85	91984	cmgsa7mq901n4h9i6sfc94ryl
cmgsa7nls01nfh9i6ktkhkxvt	/public/images/medium/55eb238b-1c0c-4fe0-b0da-b0d0e726c085-1760550332740.webp	800	799	webp	85	81750	cmgsa7nlq01nbh9i65ybar6fo
cmgsa7p6701noh9i6nlfrgkoq	/public/images/thumbnails/10157ffd-e23c-4e54-9e69-516bdee111e3-1760550333875.webp	150	150	webp	80	8070	cmgsa7p6101nih9i6whpdzpz7
cmgsa7qbh01nvh9i6qd4xgsjw	/public/images/thumbnails/fcf5801e-638a-4fc9-804c-4266c8544c96-1760550335905.webp	150	150	webp	80	7752	cmgsa7qbf01nph9i6cbl9w8gf
cmgsa7sxe01o1h9i6bgmv67w8	/public/images/thumbnails/0e92de7b-c1e2-4241-adbd-1f16e5f56b78-1760550337399.webp	150	150	webp	80	9098	cmgsa7sxb01nwh9i6wyr1n0j5
cmgsa7urp01o6h9i6vnltay3b	/public/images/medium/dfa48fb0-d2fe-4fe2-92ee-b632db558c9a-1760550340800.webp	800	794	webp	85	112246	cmgsa7urm01o3h9i6p8f5z749
cmgsa7w0401odh9i6teqgk6qe	/public/images/thumbnails/b0a0384b-c945-42d0-8666-17c31ad4294c-1760550343157.webp	150	150	webp	80	10144	cmgsa7w0201oah9i6n4nft6yj
cmgsa7xsj01omh9i6uf1fofj7	/public/images/thumbnails/cc1d720d-4158-4d6f-bb90-6283f8aece40-1760550344757.webp	150	150	webp	80	7872	cmgsa7xsf01ohh9i61s7yqxcb
cmgsa80l501oth9i6nkmgz14n	/public/images/thumbnails/f1e701d3-0cec-4064-8912-fb776add3fe7-1760550347080.webp	150	150	webp	80	10344	cmgsa80l101ooh9i6uk4hu5ne
cmgsa821h01oyh9i6ymtq4992	/public/images/thumbnails/d3c4a495-2b69-4539-9b44-f211c480f1cf-1760550350698.webp	150	150	webp	80	7522	cmgsa821d01ovh9i6jneqbnnu
cmgsa83ec01p6h9i6xziuw0qk	/public/images/thumbnails/fd056db4-3562-4858-9921-1abe840ffb9d-1760550352587.webp	150	150	webp	80	6952	cmgsa83ea01p2h9i6myp4vapt
cmgsa84s801pfh9i6kkafj9nn	/public/images/medium/2b6b4b3e-7703-4891-8217-63c5ddfa9089-1760550354340.webp	800	633	webp	85	125468	cmgsa84s301p9h9i6obhio0bb
cmgsa86ac01pmh9i66zyqxze8	/public/images/medium/a85ae036-a0e0-448c-8cec-c66b4b2b3b15-1760550356146.webp	800	623	webp	85	128918	cmgsa86a701pgh9i6ohul24lj
cmgsamq5402swh9i6ttbtrc0w	/public/images/medium/27715c80-8764-4c7c-b987-58d1dacb109f-1760551035113.webp	800	616	webp	85	126944	cmgsamq5002sqh9i6licnoiey
cmgsamrjb02t3h9i623dv5erq	/public/images/medium/093089af-28bf-496f-a133-80245bb9c1ff-1760551037006.webp	800	633	webp	85	100012	cmgsamrj802sxh9i673i059ai
cmgsamszl02t9h9i67pdm2qx2	/public/images/thumbnails/85c6b418-3b7c-4b43-903b-4aaa3bd68447-1760551038808.webp	150	150	webp	80	8884	cmgsamsze02t4h9i6jxqlicwz
cmgsamudq02thh9i6vnfb6pwi	/public/images/medium/1fec16e4-705f-45ca-b0d5-50ec9e86747c-1760551040687.webp	800	1001	webp	85	138676	cmgsamudn02tbh9i637z78py2
cmgsamvto02tnh9i6o8wlj9eb	/public/images/medium/84ce802a-cda1-4494-90b9-97d0fce28a8a-1760551042496.webp	800	637	webp	85	109202	cmgsamvtk02tih9i6zyagrkkc
cmgsamx8j02tth9i6f2y4qxlx	/public/images/thumbnails/84ded9c2-0740-4a3d-878c-0db62a6f384f-1760551044364.webp	150	150	webp	80	6204	cmgsamx8g02tph9i6dclutool
cmgsamywg02u2h9i6227h3er8	/public/images/full/2483c744-3ba5-4cf0-ad9d-7c6d571c102e-1760551046203.webp	2545	3556	webp	90	1297368	cmgsamywa02twh9i6def223yy
cmgsanj3502u7h9i6esktiavf	/public/images/medium/3bf46c16-b7ca-4a1d-bec8-c004415938a5-1760551048370.webp	800	598	webp	85	111462	cmgsanj3202u3h9i6sirt3mbj
cmgsankke02ueh9i67oxu5gfc	/public/images/full/e0932283-0e74-43bb-9b77-d98617183f85-1760551074513.webp	3545	2573	webp	90	942060	cmgsankkb02uah9i62amepee0
cmgsanmhf02ulh9i66z7mxo8g	/public/images/full/63ee5e56-27e9-4465-81b3-43447e4c59e5-1760551076430.webp	3658	3610	webp	90	974972	cmgsanmhc02uhh9i6qh9x0afl
cmgsannz702ush9i6f6p563d7	/public/images/medium/bdd65757-2230-4701-819b-02fa3d21aca4-1760551078921.webp	800	563	webp	85	76826	cmgsannz402uoh9i6bg198r08
cmgsanpvj02uzh9i6z60rymj2	/public/images/medium/bf8e6dc6-2031-484d-aa10-8708bcb0f6b4-1760551080858.webp	800	542	webp	85	78454	cmgsanpvf02uvh9i6o9jrq6tb
cmgsansl902v8h9i6w6krw3p0	/public/images/thumbnails/56180721-490f-4a33-bb52-bea77c58ed4e-1760551083321.webp	150	150	webp	80	5104	cmgsansl502v2h9i6l9u8f2u2
cmgsantoq02vfh9i6xd4slbrb	/public/images/thumbnails/8cbfae35-3333-491c-ad12-48002faefe93-1760551086833.webp	150	150	webp	80	7348	cmgsanton02v9h9i6upnpoy0p
cmgsanun702vlh9i684b56zyx	/public/images/full/2bcf4553-696e-47bb-9186-b5de1588448c-1760551088248.webp	2732	1747	webp	90	781188	cmgsanun302vgh9i6ji5pmb47
cmgsanvks02vph9i6akniifg9	/public/images/thumbnails/4b911ad4-39c3-43cf-ac3f-6e0410f97ee1-1760551089494.webp	150	150	webp	80	9134	cmgsanvkq02vnh9i60fqkpfmq
cmgsao0bs02w0h9i64sddlymg	/public/images/full/6d2bf0a5-efaf-4818-9944-3f92ae2a103e-1760551090711.webp	5059	6973	webp	90	2181420	cmgsao0bm02vuh9i6eo1nynr6
cmgsao1zl02w7h9i6klezgzke	/public/images/full/4da92417-c11f-4194-9900-8ab15e22deee-1760551096864.webp	2480	3935	webp	90	1051006	cmgsao1zf02w1h9i63n1pp3k9
cmgsao3ni02wch9i6xcng5l2t	/public/images/medium/c385c31f-cfb0-4bfc-bf78-b6da1a7032b8-1760551099014.webp	800	1204	webp	85	186310	cmgsao3ne02w8h9i6jvpjg055
cmgsao5bn02wkh9i6vdgyowf0	/public/images/medium/59cdc6be-ad8b-43f9-9983-dc7bc9e64cad-1760551101177.webp	800	1134	webp	85	182706	cmgsao5bi02wfh9i6t1fd7uv4
cmgsao7ze02woh9i6p7c14h0l	/public/images/medium/0a4b54b4-edf8-4810-a046-cd3311a6051c-1760551103348.webp	800	539	webp	85	72794	cmgsao7zb02wmh9i6tt2u9huz
cmgsaoalz02wzh9i62rt5leah	/public/images/medium/05344b1e-59b7-45b2-bea0-b409c8e91452-1760551106788.webp	800	543	webp	85	70584	cmgsaoalv02wth9i6vukatwgf
cmgsa750d01lqh9i6pkbfwmqi	/public/images/full/50ffe865-e906-48a7-868e-f239c011cf52-1760550306190.webp	3309	4986	webp	90	2149012	cmgsa750a01lkh9i686ei4k9w
cmgsa77pl01lvh9i6la4b15od	/public/images/thumbnails/e9a0c73a-49bb-42eb-8d17-effe41d41779-1760550309787.webp	150	150	webp	80	7274	cmgsa77pi01lrh9i6ldppnqzz
cmgsa7afq01m4h9i6oqz1ajnu	/public/images/full/b52e28f1-503b-4680-82c9-2f6708456d41-1760550313290.webp	5122	3400	webp	90	1940376	cmgsa7afn01lyh9i6toh4w3a8
cmgsa7ctt01m9h9i6iwcw0iu1	/public/images/full/73f52a0a-f0de-4255-a90d-f66a09d76c18-1760550316810.webp	5184	3416	webp	90	1524532	cmgsa7ctr01m5h9i6ntz35a1s
cmgsa7fjz01mih9i638kjuugt	/public/images/medium/902d49bf-0b4d-4764-9375-d22e775a179d-1760550319919.webp	800	539	webp	85	114028	cmgsa7fjx01mch9i6dukyl4ev
cmgsa7i1k01mph9i6fa98sgyc	/public/images/full/cd8fb692-bcd9-4976-b7f1-a0c6b691bed9-1760550323452.webp	4841	3291	webp	90	1720990	cmgsa7i1h01mjh9i6wcox4bf0
cmgsa7jax01mwh9i6p3fmgbrn	/public/images/full/829fff66-62cb-4030-b20f-e0a81dcd2abd-1760550326674.webp	3154	2558	webp	90	644254	cmgsa7jat01mqh9i6niuzroek
cmgsa7lmw01n3h9i6hdc0bnpu	/public/images/thumbnails/7dd43815-ef3f-4858-9b05-4c5d9fe6dce6-1760550328309.webp	150	150	webp	80	7902	cmgsa7lmu01mxh9i6oruq7qwo
cmgsa7mqb01n8h9i6v9vipda9	/public/images/thumbnails/44b9ae8f-4d0d-4927-93e5-eafe0c167e8f-1760550331324.webp	150	150	webp	80	7608	cmgsa7mq901n4h9i6sfc94ryl
cmgsa7nls01neh9i6699zq2h4	/public/images/thumbnails/55eb238b-1c0c-4fe0-b0da-b0d0e726c085-1760550332740.webp	150	150	webp	80	6218	cmgsa7nlq01nbh9i65ybar6fo
cmgsa7p6601nmh9i638ud52ai	/public/images/full/10157ffd-e23c-4e54-9e69-516bdee111e3-1760550333875.webp	3607	2573	webp	90	1133682	cmgsa7p6101nih9i6whpdzpz7
cmgsa7qbh01nuh9i6h2f0168f	/public/images/medium/fcf5801e-638a-4fc9-804c-4266c8544c96-1760550335905.webp	800	725	webp	85	130874	cmgsa7qbf01nph9i6cbl9w8gf
cmgsa7sxe01o2h9i649qt8phs	/public/images/full/0e92de7b-c1e2-4241-adbd-1f16e5f56b78-1760550337399.webp	5656	3590	webp	90	1210260	cmgsa7sxb01nwh9i6wyr1n0j5
cmgsa7urp01o9h9i6rt7a7jqg	/public/images/thumbnails/dfa48fb0-d2fe-4fe2-92ee-b632db558c9a-1760550340800.webp	150	150	webp	80	6124	cmgsa7urm01o3h9i6p8f5z749
cmgsa7w0401oeh9i68w6qrodr	/public/images/medium/b0a0384b-c945-42d0-8666-17c31ad4294c-1760550343157.webp	800	973	webp	85	135052	cmgsa7w0201oah9i6n4nft6yj
cmgsa7xsj01onh9i64sdxgroo	/public/images/full/cc1d720d-4158-4d6f-bb90-6283f8aece40-1760550344757.webp	2951	4180	webp	90	892278	cmgsa7xsf01ohh9i61s7yqxcb
cmgsa80l501osh9i6hyyxatef	/public/images/full/f1e701d3-0cec-4064-8912-fb776add3fe7-1760550347080.webp	5059	3665	webp	90	2216358	cmgsa80l101ooh9i6uk4hu5ne
cmgsa821h01ozh9i66f8arjaj	/public/images/medium/d3c4a495-2b69-4539-9b44-f211c480f1cf-1760550350698.webp	800	553	webp	85	86054	cmgsa821d01ovh9i6jneqbnnu
cmgsa83ec01p8h9i65gcriywo	/public/images/full/fd056db4-3562-4858-9921-1abe840ffb9d-1760550352587.webp	3310	2589	webp	90	693296	cmgsa83ea01p2h9i6myp4vapt
cmgsa84s801peh9i676eeopvk	/public/images/full/2b6b4b3e-7703-4891-8217-63c5ddfa9089-1760550354340.webp	3232	2558	webp	90	1065000	cmgsa84s301p9h9i6obhio0bb
cmgsa86ac01pkh9i6mvy5iat9	/public/images/thumbnails/a85ae036-a0e0-448c-8cec-c66b4b2b3b15-1760550356146.webp	150	150	webp	80	9478	cmgsa86a701pgh9i6ohul24lj
cmgsa87ii01pqh9i6c1iqdcgl	/public/images/thumbnails/623264d7-87f5-42f0-a61c-92ea02fccdc0-1760550358091.webp	150	150	webp	80	6132	cmgsa87if01pnh9i6ejtp82lq
cmgsa87ii01prh9i6rj9omo5j	/public/images/full/623264d7-87f5-42f0-a61c-92ea02fccdc0-1760550358091.webp	3232	2558	webp	90	887688	cmgsa87if01pnh9i6ejtp82lq
cmgsa87ii01pth9i6juo63ij8	/public/images/medium/623264d7-87f5-42f0-a61c-92ea02fccdc0-1760550358091.webp	800	633	webp	85	113502	cmgsa87if01pnh9i6ejtp82lq
cmgsa88x601pyh9i6jlf4j4c2	/public/images/medium/ecd322c5-5cec-404e-a264-1490319a5835-1760550359675.webp	800	623	webp	85	133288	cmgsa88x201puh9i692wzc31g
cmgsa88x601q0h9i6yd7mhgg8	/public/images/full/ecd322c5-5cec-404e-a264-1490319a5835-1760550359675.webp	3263	2542	webp	90	991464	cmgsa88x201puh9i692wzc31g
cmgsa88x601pzh9i6g87w24zc	/public/images/thumbnails/ecd322c5-5cec-404e-a264-1490319a5835-1760550359675.webp	150	150	webp	80	10212	cmgsa88x201puh9i692wzc31g
cmgsa8acd01q4h9i67o3mcf20	/public/images/medium/4cfb28bf-87d8-4bda-be07-95d85f9fc8d2-1760550361503.webp	800	633	webp	85	149940	cmgsa8aca01q1h9i68o9p3vo1
cmgsa8acd01q5h9i6zkpgnu9d	/public/images/thumbnails/4cfb28bf-87d8-4bda-be07-95d85f9fc8d2-1760550361503.webp	150	150	webp	80	11040	cmgsa8aca01q1h9i68o9p3vo1
cmgsa8acd01q7h9i6oadkp01v	/public/images/full/4cfb28bf-87d8-4bda-be07-95d85f9fc8d2-1760550361503.webp	3232	2558	webp	90	1094186	cmgsa8aca01q1h9i68o9p3vo1
cmgsa8bnx01qch9i6s79vaoke	/public/images/thumbnails/95fe8cba-fdbd-42bf-8cf7-b5406fa83e9d-1760550363342.webp	150	150	webp	80	10434	cmgsa8bns01q8h9i6ydn2inbr
cmgsa8bnx01qdh9i669akm5ei	/public/images/full/95fe8cba-fdbd-42bf-8cf7-b5406fa83e9d-1760550363342.webp	3154	2542	webp	90	1030784	cmgsa8bns01q8h9i6ydn2inbr
cmgsa8bnx01qeh9i60n0jp6ek	/public/images/medium/95fe8cba-fdbd-42bf-8cf7-b5406fa83e9d-1760550363342.webp	800	645	webp	85	146242	cmgsa8bns01q8h9i6ydn2inbr
cmgsa8cxk01qkh9i6iufd1ia3	/public/images/full/38638bc4-0e78-4b5f-a640-ad4e61ad759d-1760550365052.webp	3232	2542	webp	90	654386	cmgsa8cxg01qfh9i6vomq34jr
cmgsa8cxk01qlh9i6wf4m2a1f	/public/images/medium/38638bc4-0e78-4b5f-a640-ad4e61ad759d-1760550365052.webp	800	629	webp	85	81464	cmgsa8cxg01qfh9i6vomq34jr
cmgsa8cxk01qjh9i6gf0mvabu	/public/images/thumbnails/38638bc4-0e78-4b5f-a640-ad4e61ad759d-1760550365052.webp	150	150	webp	80	9332	cmgsa8cxg01qfh9i6vomq34jr
cmgsa8e9501qqh9i606hxoqfc	/public/images/medium/d93e05eb-9509-45d1-b98d-11cf755ce16b-1760550366697.webp	800	649	webp	85	96006	cmgsa8e9201qmh9i6auuoitw4
cmgsa8e9501qph9i6dpyxvsvu	/public/images/full/d93e05eb-9509-45d1-b98d-11cf755ce16b-1760550366697.webp	3232	2620	webp	90	745874	cmgsa8e9201qmh9i6auuoitw4
cmgsa8e9601qsh9i6lk1hffkl	/public/images/thumbnails/d93e05eb-9509-45d1-b98d-11cf755ce16b-1760550366697.webp	150	150	webp	80	8098	cmgsa8e9201qmh9i6auuoitw4
cmgsa8fxh01qzh9i65q5ouvri	/public/images/medium/a7e691ef-d469-4ff4-83aa-fee0375cf19b-1760550368410.webp	800	1225	webp	85	158388	cmgsa8fxd01qth9i6470ydcah
cmgsa8fxg01qxh9i6yt5rie3c	/public/images/thumbnails/a7e691ef-d469-4ff4-83aa-fee0375cf19b-1760550368410.webp	150	150	webp	80	8760	cmgsa8fxd01qth9i6470ydcah
cmgsa8fxg01qyh9i6pf42q2ez	/public/images/full/a7e691ef-d469-4ff4-83aa-fee0375cf19b-1760550368410.webp	2639	4040	webp	90	800866	cmgsa8fxd01qth9i6470ydcah
cmgsa8han01r4h9i65w74bxun	/public/images/thumbnails/e6351afb-d2c5-44a6-9f66-15f6a357eb88-1760550370592.webp	150	150	webp	80	9542	cmgsa8haj01r0h9i6he065ru4
cmgsa8han01r6h9i63uz41dso	/public/images/medium/e6351afb-d2c5-44a6-9f66-15f6a357eb88-1760550370592.webp	800	649	webp	85	111420	cmgsa8haj01r0h9i6he065ru4
cmgsa8iql01rah9i654hik8ta	/public/images/full/93679dab-10b1-4b6d-b945-8aa28c0dcaa8-1760550372356.webp	3357	2573	webp	90	832152	cmgsa8iqg01r7h9i64so8a81g
cmgsa8lgw01rih9i6ccey53h9	/public/images/thumbnails/a49f5831-3b03-44f8-b6d7-06120947878e-1760550374226.webp	150	150	webp	80	8426	cmgsa8lgt01reh9i6tevp4vgr
cmgsa8o3o01rrh9i6a0ujw5cr	/public/images/full/e3f58bcf-87f9-4905-a291-e60745398c0e-1760550377765.webp	5012	3681	webp	90	1687248	cmgsa8o3m01rlh9i6nmtmz85h
cmgsa8r2301rxh9i6yxr9zdtu	/public/images/medium/6a86d36c-404e-40d4-90fa-4a14fe3c1b33-1760550381191.webp	800	570	webp	85	179168	cmgsa8r1x01rsh9i6wiat7o9z
cmgsa8tsc01s3h9i6l0xuajow	/public/images/thumbnails/53287919-c493-41ab-9373-7fbff894b954-1760550385012.webp	150	150	webp	80	8920	cmgsa8ts901rzh9i6pn9efta8
cmgsa8wfd01sbh9i6zl31b8n6	/public/images/full/e0090530-4cdd-4e5c-b876-3712ab8f43ca-1760550388544.webp	5012	3400	webp	90	2096510	cmgsa8wf901s6h9i63rymvwgr
cmgsa8z8901sgh9i6lnpv17s1	/public/images/medium/c7aecab9-44fb-4272-82c8-c5e04080faea-1760550391971.webp	800	586	webp	85	138616	cmgsa8z8601sdh9i67xb1h266
cmgsa922i01sqh9i6f2aojesy	/public/images/thumbnails/97728739-2323-4d49-b11f-cecf624882d7-1760550395608.webp	150	150	webp	80	8490	cmgsa922e01skh9i611ewlvkf
cmgsa94mx01sxh9i6qqk2lord	/public/images/full/e5e77c88-7025-43d7-b6d4-0d5f335174e8-1760550399286.webp	4934	3369	webp	90	1938830	cmgsa94mr01srh9i6y3o4bbzm
cmgsa96q801t3h9i6j5gxm3kt	/public/images/thumbnails/24d58138-369c-4de3-ae58-73c3767caf61-1760550402603.webp	150	150	webp	80	6192	cmgsa96q401syh9i6jm7mutjr
cmgsa98n201tbh9i6tvk7uqa6	/public/images/medium/b35fbda8-163e-4487-a0ba-fac0a5005763-1760550405319.webp	800	516	webp	85	74062	cmgsa98mz01t5h9i652grndt1
cmgsa9adk01thh9i6m9f49hrn	/public/images/medium/241df6f8-1377-4c49-bc07-2a1e8af5d3e8-1760550407795.webp	800	599	webp	85	142706	cmgsa9adi01tch9i672porsc1
cmgsa9caz01tmh9i6x1icfuuv	/public/images/medium/2588c59f-bce8-4526-bd77-49050a142439-1760550410049.webp	800	1251	webp	85	144946	cmgsa9cax01tjh9i64681p3d2
cmgsa9e8101twh9i6rkg9nqm6	/public/images/full/eb182c97-b4eb-4104-8f3b-fda675768b0f-1760550412549.webp	3112	4477	webp	90	909154	cmgsa9e7y01tqh9i6mr6b5m7s
cmgsa9f8101u3h9i6ifgnqxjo	/public/images/thumbnails/1e4aa39c-f24a-4ef1-8100-a7e7157ce27b-1760550415025.webp	150	150	webp	80	5956	cmgsa9f7y01txh9i6r3tul2xu
cmgsa9gs101u7h9i6jx1b27dt	/public/images/medium/f44624d6-4a50-445a-91a8-3fa06bf61ddd-1760550416325.webp	800	1070	webp	85	175080	cmgsa9grz01u4h9i64inc5r5s
cmgsa9isd01ufh9i6gobdc67c	/public/images/full/057203cc-a2db-402e-98d1-3524e323e54e-1760550418337.webp	4328	3075	webp	90	1151854	cmgsa9isa01ubh9i64h9x4ycs
cmgsa9k6h01unh9i6asfjefzq	/public/images/medium/86b1e201-775b-4603-b7cf-cba9543dcf9f-1760550420947.webp	800	543	webp	85	83044	cmgsa9k6d01uih9i68g4neqyc
cmgsa9lhh01uth9i6lsg3w84m	/public/images/thumbnails/84c0ccca-8123-4c8e-8de9-425a11faeb17-1760550422751.webp	150	150	webp	80	7246	cmgsa9lhe01uph9i6y8f1845i
cmgsa9n0l01v0h9i6lgtfpvf3	/public/images/thumbnails/bece637f-f2d3-41d4-8341-89a93bca594e-1760550424436.webp	150	150	webp	80	6654	cmgsa9n0f01uwh9i676bbo80b
cmgsa9oj601v7h9i60bphwj42	/public/images/full/0b5b447e-7643-4274-967b-28e24dbc6d79-1760550426424.webp	2632	3743	webp	90	734240	cmgsa9oj201v3h9i6r0hjsusk
cmgsa9put01veh9i67veykdc0	/public/images/full/3a46e810-0048-4aef-ac65-34deabae2ade-1760550428387.webp	2498	3498	webp	90	466020	cmgsa9pup01vah9i6cm33eyla
cmgsa9qv001vnh9i60j598vz9	/public/images/full/cafd0fcd-3c17-43de-a404-17065a575ab6-1760550430101.webp	2052	2652	webp	90	444336	cmgsa9quw01vhh9i6icx47kn1
cmgsa9sab01vth9i6umythbmm	/public/images/full/3bc7402b-5006-47a7-90bd-6ae5a127c9eb-1760550431404.webp	3716	2496	webp	90	872460	cmgsa9sa801voh9i6gcc9ox72
cmgsa9tvu01vzh9i64vm3hufv	/public/images/thumbnails/90d81d75-4ac6-4f03-9270-c77e32920724-1760550433260.webp	150	150	webp	80	8550	cmgsa9tvr01vvh9i6kif51dsy
cmgsa9v7s01w7h9i64ekr7uy4	/public/images/full/c197766d-eeae-451c-92ae-e528572ab0ea-1760550435321.webp	3435	2605	webp	90	746732	cmgsa9v7q01w2h9i6qyullo2f
cmgsa9wmt01wdh9i6k2jc79ds	/public/images/full/62110178-597d-4087-b917-b82aa80e886e-1760550437054.webp	3170	2449	webp	90	1408770	cmgsa9wmo01w9h9i6wvro5w9d
cmgsa9yec01wkh9i6qd5xvfp8	/public/images/thumbnails/b1d0bab1-2d42-48a6-ad3f-85d5b0542894-1760550438885.webp	150	150	webp	80	6146	cmgsa9ye801wgh9i6x0mvqq09
cmgsa9zxk01wsh9i67eu5lxu2	/public/images/thumbnails/b96849f8-9b23-4170-b848-7be19c8b4007-1760550441170.webp	150	150	webp	80	5280	cmgsa9zxh01wnh9i693jukhqs
cmgsaa1li01wxh9i6qesfg2t6	/public/images/medium/e98871ed-97a8-46f0-b46a-637e17150a91-1760550443159.webp	800	501	webp	85	89632	cmgsaa1ld01wuh9i681egnlmb
cmgsaa2us01x4h9i67bfju080	/public/images/medium/7cf096dc-1088-4bf9-83b6-588caa89284b-1760550445319.webp	800	960	webp	85	104996	cmgsaa2up01x1h9i66x862mro
cmgsaa4ca01xeh9i6x5i7m2k7	/public/images/full/a3487a51-8f4e-4f12-974b-a2a4c7adc663-1760550446950.webp	3623	2573	webp	90	974156	cmgsaa4c801x8h9i6yfddbtxz
cmgsaa68x01xih9i61c18c4sq	/public/images/thumbnails/1b9f242d-240a-480d-924b-1e68513fe02f-1760550448878.webp	150	150	webp	80	10840	cmgsaa68u01xfh9i68mercpgj
cmgsaa86401xrh9i6zqtqdpjh	/public/images/full/342db764-30d3-46fa-b46b-8cb56257b62b-1760550451352.webp	4388	2948	webp	90	1085836	cmgsaa85z01xmh9i64lz4m1al
cmgsaaavh01xzh9i6q82vxj2t	/public/images/thumbnails/c9ede70d-1c82-4617-8ba1-454210c831a3-1760550453851.webp	150	150	webp	80	6818	cmgsaaave01xth9i6tkcbmj5n
cmgsaabzy01y6h9i69isjnq93	/public/images/thumbnails/2b3b426b-f61e-47b4-b7aa-94575df6c6d4-1760550457348.webp	150	150	webp	80	10488	cmgsaabzu01y0h9i68t85mbty
cmgsaadqe01ydh9i6sc4fpymh	/public/images/medium/885e6d90-9981-4a99-a040-291a624518ad-1760550458800.webp	800	1274	webp	85	184170	cmgsaadq901y7h9i6i7r0e3ca
cmgsaafjb01yih9i6781xgpnd	/public/images/medium/19c7fc3f-ff94-43b8-a594-268c197f4075-1760550461045.webp	800	1191	webp	85	134502	cmgsaafj601yeh9i6gvt9migz
cmgsaah2p01yph9i67i5hatp5	/public/images/thumbnails/aed53e47-9286-450d-a97f-f182464ca773-1760550463382.webp	150	150	webp	80	7130	cmgsaah2m01ylh9i6yp1u08fr
cmgsaaijz01ywh9i6bds35qhf	/public/images/medium/040d1fe0-96a0-4c07-b9d7-8fec9b0f7c36-1760550465383.webp	800	529	webp	85	58498	cmgsaaijv01ysh9i62xtt611s
cmgsaak2k01z4h9i6bw1vu58c	/public/images/full/93f174e3-44f7-4b03-90d3-965a51f53172-1760550467303.webp	3938	2618	webp	90	765020	cmgsaak2h01yzh9i6x63ftq4r
cmgsaamjn01zbh9i63zh7sy5n	/public/images/thumbnails/0c6dd52e-e914-4bd4-957d-63b8d98b8c30-1760550469276.webp	150	150	webp	80	6182	cmgsaamjk01z6h9i64c5k0v1a
cmgsa8han01r5h9i6hl5ij36b	/public/images/full/e6351afb-d2c5-44a6-9f66-15f6a357eb88-1760550370592.webp	3232	2620	webp	90	815526	cmgsa8haj01r0h9i6he065ru4
cmgsa8iql01rbh9i65ge173ek	/public/images/medium/93679dab-10b1-4b6d-b945-8aa28c0dcaa8-1760550372356.webp	800	613	webp	85	85720	cmgsa8iqg01r7h9i64so8a81g
cmgsa8lgx01rkh9i6zbwzbq5r	/public/images/full/a49f5831-3b03-44f8-b6d7-06120947878e-1760550374226.webp	5091	3541	webp	90	1872830	cmgsa8lgt01reh9i6tevp4vgr
cmgsa8o3o01rqh9i6p1km16xj	/public/images/medium/e3f58bcf-87f9-4905-a291-e60745398c0e-1760550377765.webp	800	587	webp	85	111544	cmgsa8o3m01rlh9i6nmtmz85h
cmgsa8r2201ruh9i6e9pi2vdz	/public/images/thumbnails/6a86d36c-404e-40d4-90fa-4a14fe3c1b33-1760550381191.webp	150	150	webp	80	13190	cmgsa8r1x01rsh9i6wiat7o9z
cmgsa8tsc01s5h9i6hrw1cg2k	/public/images/full/53287919-c493-41ab-9373-7fbff894b954-1760550385012.webp	3619	5106	webp	90	1708264	cmgsa8ts901rzh9i6pn9efta8
cmgsa8wfd01sah9i6fh3y155r	/public/images/medium/e0090530-4cdd-4e5c-b876-3712ab8f43ca-1760550388544.webp	800	543	webp	85	103146	cmgsa8wf901s6h9i63rymvwgr
cmgsa8z8901sih9i6iy0hswu6	/public/images/thumbnails/c7aecab9-44fb-4272-82c8-c5e04080faea-1760550391971.webp	150	150	webp	80	9844	cmgsa8z8601sdh9i67xb1h266
cmgsa922i01soh9i6n3guku5g	/public/images/full/97728739-2323-4d49-b11f-cecf624882d7-1760550395608.webp	3681	5028	webp	90	1812084	cmgsa922e01skh9i611ewlvkf
cmgsa94mv01sth9i6j02uo20q	/public/images/medium/e5e77c88-7025-43d7-b6d4-0d5f335174e8-1760550399286.webp	800	546	webp	85	93794	cmgsa94mr01srh9i6y3o4bbzm
cmgsa96q801t4h9i6or5vgkrw	/public/images/full/24d58138-369c-4de3-ae58-73c3767caf61-1760550402603.webp	2709	4551	webp	90	1508950	cmgsa96q401syh9i6jm7mutjr
cmgsa98n201t9h9i6j1c9y82q	/public/images/thumbnails/b35fbda8-163e-4487-a0ba-fac0a5005763-1760550405319.webp	150	150	webp	80	7872	cmgsa98mz01t5h9i652grndt1
cmgsa9adk01tgh9i6q6d3rsa0	/public/images/thumbnails/241df6f8-1377-4c49-bc07-2a1e8af5d3e8-1760550407795.webp	150	150	webp	80	8600	cmgsa9adi01tch9i672porsc1
cmgsa9cb001tph9i6wg9rhg6h	/public/images/full/2588c59f-bce8-4526-bd77-49050a142439-1760550410049.webp	2923	4569	webp	90	948510	cmgsa9cax01tjh9i64681p3d2
cmgsa9e8101tuh9i6wkzuv35y	/public/images/medium/eb182c97-b4eb-4104-8f3b-fda675768b0f-1760550412549.webp	800	1151	webp	85	131418	cmgsa9e7y01tqh9i6mr6b5m7s
cmgsa9f8101u1h9i6mszzkpez	/public/images/full/1e4aa39c-f24a-4ef1-8100-a7e7157ce27b-1760550415025.webp	2855	2273	webp	90	448192	cmgsa9f7y01txh9i6r3tul2xu
cmgsa9gs101u8h9i6bz7l8011	/public/images/thumbnails/f44624d6-4a50-445a-91a8-3fa06bf61ddd-1760550416325.webp	150	150	webp	80	9466	cmgsa9grz01u4h9i64inc5r5s
cmgsa9isd01uhh9i6lhshli8i	/public/images/thumbnails/057203cc-a2db-402e-98d1-3524e323e54e-1760550418337.webp	150	150	webp	80	8986	cmgsa9isa01ubh9i64h9x4ycs
cmgsa9k6h01uoh9i690naejlc	/public/images/full/86b1e201-775b-4603-b7cf-cba9543dcf9f-1760550420947.webp	3547	2406	webp	90	739522	cmgsa9k6d01uih9i68g4neqyc
cmgsa9lhh01uvh9i6esre2t35	/public/images/medium/84c0ccca-8123-4c8e-8de9-425a11faeb17-1760550422751.webp	800	544	webp	85	67904	cmgsa9lhe01uph9i6y8f1845i
cmgsa9n0l01v1h9i6m8typ2w5	/public/images/medium/bece637f-f2d3-41d4-8341-89a93bca594e-1760550424436.webp	800	598	webp	85	92176	cmgsa9n0f01uwh9i676bbo80b
cmgsa9oj601v9h9i6psr8ilg2	/public/images/medium/0b5b447e-7643-4274-967b-28e24dbc6d79-1760550426424.webp	800	1137	webp	85	123960	cmgsa9oj201v3h9i6r0hjsusk
cmgsa9put01vfh9i63r0l99bo	/public/images/medium/3a46e810-0048-4aef-ac65-34deabae2ade-1760550428387.webp	800	1120	webp	85	73818	cmgsa9pup01vah9i6cm33eyla
cmgsa9qv001vlh9i6id3wdxnk	/public/images/thumbnails/cafd0fcd-3c17-43de-a404-17065a575ab6-1760550430101.webp	150	150	webp	80	5388	cmgsa9quw01vhh9i6icx47kn1
cmgsa9sab01vuh9i6c7xqiyp5	/public/images/medium/3bc7402b-5006-47a7-90bd-6ae5a127c9eb-1760550431404.webp	800	537	webp	85	81304	cmgsa9sa801voh9i6gcc9ox72
cmgsa9tvu01vyh9i64kjjyj80	/public/images/medium/90d81d75-4ac6-4f03-9270-c77e32920724-1760550433260.webp	800	545	webp	85	91588	cmgsa9tvr01vvh9i6kif51dsy
cmgsa9v7s01w6h9i690glfzj2	/public/images/medium/c197766d-eeae-451c-92ae-e528572ab0ea-1760550435321.webp	800	607	webp	85	87504	cmgsa9v7q01w2h9i6qyullo2f
cmgsa9wmt01wfh9i69a6j7ads	/public/images/thumbnails/62110178-597d-4087-b917-b82aa80e886e-1760550437054.webp	150	150	webp	80	7890	cmgsa9wmo01w9h9i6wvro5w9d
cmgsa9yec01wmh9i6pb8oom1c	/public/images/full/b1d0bab1-2d42-48a6-ad3f-85d5b0542894-1760550438885.webp	4200	2683	webp	90	1222916	cmgsa9ye801wgh9i6x0mvqq09
cmgsa9zxk01wth9i6epifohd0	/public/images/full/b96849f8-9b23-4170-b848-7be19c8b4007-1760550441170.webp	2514	3946	webp	90	755546	cmgsa9zxh01wnh9i693jukhqs
cmgsaa1lj01x0h9i6ehh3lt01	/public/images/full/e98871ed-97a8-46f0-b46a-637e17150a91-1760550443159.webp	4107	2573	webp	90	1197452	cmgsaa1ld01wuh9i681egnlmb
cmgsaa2us01x5h9i6qtk3hnha	/public/images/thumbnails/7cf096dc-1088-4bf9-83b6-588caa89284b-1760550445319.webp	150	150	webp	80	6782	cmgsaa2up01x1h9i66x862mro
cmgsaa4ca01xdh9i6x0n7xabu	/public/images/medium/a3487a51-8f4e-4f12-974b-a2a4c7adc663-1760550446950.webp	800	568	webp	85	100988	cmgsaa4c801x8h9i6yfddbtxz
cmgsaa68x01xjh9i6ysd8l7vr	/public/images/medium/1b9f242d-240a-480d-924b-1e68513fe02f-1760550448878.webp	800	556	webp	85	119862	cmgsaa68u01xfh9i68mercpgj
cmgsaa86401xqh9i6wgttervh	/public/images/medium/342db764-30d3-46fa-b46b-8cb56257b62b-1760550451352.webp	800	537	webp	85	98914	cmgsaa85z01xmh9i64lz4m1al
cmgsaaavh01xyh9i6kkc94z9y	/public/images/full/c9ede70d-1c82-4617-8ba1-454210c831a3-1760550453851.webp	5184	3369	webp	90	1796786	cmgsaaave01xth9i6tkcbmj5n
cmgsaabzy01y5h9i6fmc828mo	/public/images/medium/2b3b426b-f61e-47b4-b7aa-94575df6c6d4-1760550457348.webp	800	1080	webp	85	178276	cmgsaabzu01y0h9i68t85mbty
cmgsaadqd01yah9i6xmaq7e2j	/public/images/thumbnails/885e6d90-9981-4a99-a040-291a624518ad-1760550458800.webp	150	150	webp	80	7338	cmgsaadq901y7h9i6i7r0e3ca
cmgsaafjb01ykh9i6ujha1tos	/public/images/full/19c7fc3f-ff94-43b8-a594-268c197f4075-1760550461045.webp	2729	4060	webp	90	1055526	cmgsaafj601yeh9i6gvt9migz
cmgsaah2p01yoh9i6k885hjz5	/public/images/full/aed53e47-9286-450d-a97f-f182464ca773-1760550463382.webp	3977	2576	webp	90	787152	cmgsaah2m01ylh9i6yp1u08fr
cmgsaaijz01yvh9i6icf9lwvx	/public/images/thumbnails/040d1fe0-96a0-4c07-b9d7-8fec9b0f7c36-1760550465383.webp	150	150	webp	80	6188	cmgsaaijv01ysh9i62xtt611s
cmgsaak2k01z5h9i65dsafjut	/public/images/thumbnails/93f174e3-44f7-4b03-90d3-965a51f53172-1760550467303.webp	150	150	webp	80	7450	cmgsaak2h01yzh9i6x63ftq4r
cmgsaamjn01zch9i6ii61wym7	/public/images/full/0c6dd52e-e914-4bd4-957d-63b8d98b8c30-1760550469276.webp	4997	3494	webp	90	1576290	cmgsaamjk01z6h9i64c5k0v1a
cmgsa8iql01rdh9i6hczh0m5e	/public/images/thumbnails/93679dab-10b1-4b6d-b945-8aa28c0dcaa8-1760550372356.webp	150	150	webp	80	6946	cmgsa8iqg01r7h9i64so8a81g
cmgsa8lgw01rhh9i6a2oxzcsd	/public/images/medium/a49f5831-3b03-44f8-b6d7-06120947878e-1760550374226.webp	800	557	webp	85	107314	cmgsa8lgt01reh9i6tevp4vgr
cmgsa8o3o01rph9i6lhgi0u96	/public/images/thumbnails/e3f58bcf-87f9-4905-a291-e60745398c0e-1760550377765.webp	150	150	webp	80	8750	cmgsa8o3m01rlh9i6nmtmz85h
cmgsa8r2301ryh9i6e9yqi9n2	/public/images/full/6a86d36c-404e-40d4-90fa-4a14fe3c1b33-1760550381191.webp	5028	3581	webp	90	2362414	cmgsa8r1x01rsh9i6wiat7o9z
cmgsa8tsc01s2h9i685sv10ef	/public/images/medium/53287919-c493-41ab-9373-7fbff894b954-1760550385012.webp	800	1129	webp	85	161262	cmgsa8ts901rzh9i6pn9efta8
cmgsa8wfd01sch9i6uelzgwvf	/public/images/thumbnails/e0090530-4cdd-4e5c-b876-3712ab8f43ca-1760550388544.webp	150	150	webp	80	9518	cmgsa8wf901s6h9i63rymvwgr
cmgsa8z8901sjh9i61n5tlwys	/public/images/full/c7aecab9-44fb-4272-82c8-c5e04080faea-1760550391971.webp	5028	3681	webp	90	2039342	cmgsa8z8601sdh9i67xb1h266
cmgsa922i01sph9i6sddi1i54	/public/images/medium/97728739-2323-4d49-b11f-cecf624882d7-1760550395608.webp	800	1093	webp	85	148086	cmgsa922e01skh9i611ewlvkf
cmgsa94mx01swh9i6i4clr8lp	/public/images/thumbnails/e5e77c88-7025-43d7-b6d4-0d5f335174e8-1760550399286.webp	150	150	webp	80	8190	cmgsa94mr01srh9i6y3o4bbzm
cmgsa96q801t2h9i65r93ykil	/public/images/medium/24d58138-369c-4de3-ae58-73c3767caf61-1760550402603.webp	800	1344	webp	85	197532	cmgsa96q401syh9i6jm7mutjr
cmgsa98n201tah9i6tyg93rp7	/public/images/full/b35fbda8-163e-4487-a0ba-fac0a5005763-1760550405319.webp	4426	2852	webp	90	1226166	cmgsa98mz01t5h9i652grndt1
cmgsa9adl01tih9i6cwxpt7u1	/public/images/full/241df6f8-1377-4c49-bc07-2a1e8af5d3e8-1760550407795.webp	3765	2816	webp	90	1499150	cmgsa9adi01tch9i672porsc1
cmgsa9caz01tnh9i6qsea4wa7	/public/images/thumbnails/2588c59f-bce8-4526-bd77-49050a142439-1760550410049.webp	150	150	webp	80	7618	cmgsa9cax01tjh9i64681p3d2
cmgsa9e8101tvh9i6vwu4z1ea	/public/images/thumbnails/eb182c97-b4eb-4104-8f3b-fda675768b0f-1760550412549.webp	150	150	webp	80	7656	cmgsa9e7y01tqh9i6mr6b5m7s
cmgsa9f8101u2h9i69djn8eds	/public/images/medium/1e4aa39c-f24a-4ef1-8100-a7e7157ce27b-1760550415025.webp	800	637	webp	85	72500	cmgsa9f7y01txh9i6r3tul2xu
cmgsa9gs201uah9i63xpohj7j	/public/images/full/f44624d6-4a50-445a-91a8-3fa06bf61ddd-1760550416325.webp	2699	3610	webp	90	871140	cmgsa9grz01u4h9i64inc5r5s
cmgsa9isd01ugh9i6gnto3h8d	/public/images/medium/057203cc-a2db-402e-98d1-3524e323e54e-1760550418337.webp	800	568	webp	85	97138	cmgsa9isa01ubh9i64h9x4ycs
cmgsa9k6h01umh9i645ro26ha	/public/images/thumbnails/86b1e201-775b-4603-b7cf-cba9543dcf9f-1760550420947.webp	150	150	webp	80	6768	cmgsa9k6d01uih9i68g4neqyc
cmgsa9lhh01uuh9i6e0x09lka	/public/images/full/84c0ccca-8123-4c8e-8de9-425a11faeb17-1760550422751.webp	3703	2518	webp	90	601440	cmgsa9lhe01uph9i6y8f1845i
cmgsa9n0l01v2h9i6gpxj3o1j	/public/images/full/bece637f-f2d3-41d4-8341-89a93bca594e-1760550424436.webp	3636	2718	webp	90	894432	cmgsa9n0f01uwh9i676bbo80b
cmgsa9oj601v6h9i6sdl9aeza	/public/images/thumbnails/0b5b447e-7643-4274-967b-28e24dbc6d79-1760550426424.webp	150	150	webp	80	5974	cmgsa9oj201v3h9i6r0hjsusk
cmgsa9put01vgh9i6c8tlwrvp	/public/images/thumbnails/3a46e810-0048-4aef-ac65-34deabae2ade-1760550428387.webp	150	150	webp	80	3716	cmgsa9pup01vah9i6cm33eyla
cmgsa9qv001vmh9i6hlg0esvk	/public/images/medium/cafd0fcd-3c17-43de-a404-17065a575ab6-1760550430101.webp	800	1034	webp	85	124542	cmgsa9quw01vhh9i6icx47kn1
cmgsa9sab01vsh9i6trplhbrj	/public/images/thumbnails/3bc7402b-5006-47a7-90bd-6ae5a127c9eb-1760550431404.webp	150	150	webp	80	7928	cmgsa9sa801voh9i6gcc9ox72
cmgsa9tvu01w1h9i6vl0yceue	/public/images/full/90d81d75-4ac6-4f03-9270-c77e32920724-1760550433260.webp	3732	2542	webp	90	986976	cmgsa9tvr01vvh9i6kif51dsy
cmgsa9v7s01w8h9i6s2sp3ikl	/public/images/thumbnails/c197766d-eeae-451c-92ae-e528572ab0ea-1760550435321.webp	150	150	webp	80	7194	cmgsa9v7q01w2h9i6qyullo2f
cmgsa9wmt01weh9i66w4kfmes	/public/images/medium/62110178-597d-4087-b917-b82aa80e886e-1760550437054.webp	800	618	webp	85	142248	cmgsa9wmo01w9h9i6wvro5w9d
cmgsa9yec01wlh9i64x0y6w3q	/public/images/medium/b1d0bab1-2d42-48a6-ad3f-85d5b0542894-1760550438885.webp	800	510	webp	85	75540	cmgsa9ye801wgh9i6x0mvqq09
cmgsa9zxk01wrh9i6tsgz4ocs	/public/images/medium/b96849f8-9b23-4170-b848-7be19c8b4007-1760550441170.webp	800	1256	webp	85	119680	cmgsa9zxh01wnh9i693jukhqs
cmgsaa1li01wyh9i6psjsqw11	/public/images/thumbnails/e98871ed-97a8-46f0-b46a-637e17150a91-1760550443159.webp	150	150	webp	80	9018	cmgsaa1ld01wuh9i681egnlmb
cmgsaa2us01x7h9i60yz6wk0h	/public/images/full/7cf096dc-1088-4bf9-83b6-588caa89284b-1760550445319.webp	2639	3166	webp	90	695518	cmgsaa2up01x1h9i66x862mro
cmgsaa4ca01xch9i6mnxkl0cq	/public/images/thumbnails/a3487a51-8f4e-4f12-974b-a2a4c7adc663-1760550446950.webp	150	150	webp	80	8674	cmgsaa4c801x8h9i6yfddbtxz
cmgsaa68y01xlh9i6caqntu7m	/public/images/full/1b9f242d-240a-480d-924b-1e68513fe02f-1760550448878.webp	4263	2963	webp	90	1336716	cmgsaa68u01xfh9i68mercpgj
cmgsaa86401xsh9i6fq4wi5sv	/public/images/thumbnails/342db764-30d3-46fa-b46b-8cb56257b62b-1760550451352.webp	150	150	webp	80	11748	cmgsaa85z01xmh9i64lz4m1al
cmgsaaavh01xxh9i6d1nwpo0g	/public/images/medium/c9ede70d-1c82-4617-8ba1-454210c831a3-1760550453851.webp	800	520	webp	85	64616	cmgsaaave01xth9i6tkcbmj5n
cmgsaabzy01y4h9i6k0lnhuk6	/public/images/full/2b3b426b-f61e-47b4-b7aa-94575df6c6d4-1760550457348.webp	2092	2823	webp	90	574496	cmgsaabzu01y0h9i68t85mbty
cmgsaadqd01ybh9i6snzhws11	/public/images/full/885e6d90-9981-4a99-a040-291a624518ad-1760550458800.webp	2558	4075	webp	90	1175906	cmgsaadq901y7h9i6i7r0e3ca
cmgsaafjb01yjh9i6otbwtdeq	/public/images/thumbnails/19c7fc3f-ff94-43b8-a594-268c197f4075-1760550461045.webp	150	150	webp	80	6068	cmgsaafj601yeh9i6gvt9migz
cmgsaah2p01yrh9i6qme2mdb9	/public/images/medium/aed53e47-9286-450d-a97f-f182464ca773-1760550463382.webp	800	518	webp	85	68176	cmgsaah2m01ylh9i6yp1u08fr
cmgsaaik101yyh9i68tbqr71h	/public/images/full/040d1fe0-96a0-4c07-b9d7-8fec9b0f7c36-1760550465383.webp	3959	2618	webp	90	624982	cmgsaaijv01ysh9i62xtt611s
cmgsaak2k01z3h9i631qarlod	/public/images/medium/93f174e3-44f7-4b03-90d3-965a51f53172-1760550467303.webp	800	532	webp	85	69508	cmgsaak2h01yzh9i6x63ftq4r
cmgsaamjn01zah9i688iw5hp8	/public/images/medium/0c6dd52e-e914-4bd4-957d-63b8d98b8c30-1760550469276.webp	800	559	webp	85	64274	cmgsaamjk01z6h9i64c5k0v1a
cmgsaap2401zih9i6089nza1m	/public/images/full/3e9dee25-79ff-4be9-a68a-fc0819ac777e-1760550472476.webp	4934	3307	webp	90	1809408	cmgsaap2101zdh9i6789lysd6
cmgsaap2401zjh9i6n34gt04l	/public/images/thumbnails/3e9dee25-79ff-4be9-a68a-fc0819ac777e-1760550472476.webp	150	150	webp	80	9958	cmgsaap2101zdh9i6789lysd6
cmgsaoalz02wyh9i61d416s57	/public/images/thumbnails/05344b1e-59b7-45b2-bea0-b409c8e91452-1760551106788.webp	150	150	webp	80	6674	cmgsaoalv02wth9i6vukatwgf
cmgsaodg102x4h9i68v7w6013	/public/images/full/b98e3e8a-1c08-414a-a7ed-c8956735139c-1760551110199.webp	3307	4950	webp	90	2391510	cmgsaodfw02x0h9i6bdmyn00t
cmgsaofnx02xdh9i6nsdtaoii	/public/images/full/12a5f1eb-cd6c-4002-babd-e8f43361feb8-1760551113863.webp	4716	3307	webp	90	1105594	cmgsaofnv02x7h9i6tjbznx8i
cmgsaohzt02xjh9i6qncirwie	/public/images/thumbnails/98c460ff-99fd-4a04-aeac-0b6d8e45e6ab-1760551116735.webp	150	150	webp	80	8788	cmgsaohzp02xeh9i6esxa25zc
cmgsaokeq02xnh9i6z4j2mbak	/public/images/full/06962ce0-c41e-424e-99dd-d8849edb9d41-1760551119765.webp	5028	3432	webp	90	1289706	cmgsaokem02xlh9i66uq7a8j3
cmgsaonas02xyh9i6nj9ypvvc	/public/images/full/0eaf3505-d383-418c-86ec-27daa4a298ae-1760551122895.webp	5012	3728	webp	90	1894532	cmgsaonaq02xsh9i64wmlau61
cmgsaovrk02y3h9i6t33pli6s	/public/images/thumbnails/881ab602-39d4-4795-860c-ec8bfb776d07-1760551126647.webp	150	150	webp	80	6148	cmgsaovrh02xzh9i6gmljov5z
cmgsasslc0369h9i6wz0rg60l	/public/images/thumbnails/0b5025d7-5973-4455-98e2-bff1d3c6c944-1760551317795.webp	150	150	webp	80	7124	cmgsassla0365h9i6e0zmnfyn
cmgsasu6b036ih9i6qwpy8tyl	/public/images/medium/6c005847-6d27-4f32-b6ee-a9ca01e5f6d6-1760551320112.webp	800	1109	webp	85	174636	cmgsasu68036ch9i6g9bws37r
cmgsasx7l036nh9i6amw2pydo	/public/images/medium/9002b47c-5d81-439e-b117-d078f0432501-1760551322173.webp	800	1141	webp	85	177030	cmgsasx7i036jh9i6y31tg6cb
cmgsat0a4036th9i6rbfrlmlt	/public/images/thumbnails/fbaf3092-bbdd-4133-bd50-3213a4a0e474-1760551326096.webp	150	150	webp	80	7394	cmgsat0a1036qh9i6hydq8x2a
cmgsat3540372h9i6gc1rbctn	/public/images/thumbnails/7235a477-ee86-469a-a3b5-90bbbc1c0953-1760551330082.webp	150	150	webp	80	7180	cmgsat352036xh9i6hjiuclrd
cmgsat62o037ah9i633sj7q20	/public/images/medium/de1e2b59-3d3a-4ced-9691-635f10c89d2d-1760551333789.webp	800	571	webp	85	67142	cmgsat62k0374h9i608h91mix
cmgsat969037fh9i6tm2dxnua	/public/images/thumbnails/1fe3966c-8137-473c-aead-9044c6a7204e-1760551337595.webp	150	150	webp	80	6008	cmgsat964037bh9i676te9j9n
cmgsatbvm037oh9i6yl4kk9ut	/public/images/medium/246497bc-1ee3-43fa-a627-f658dfe0ca9c-1760551341618.webp	800	515	webp	85	86002	cmgsatbvi037ih9i619trnk2k
cmgsateww037vh9i6ap4rku5t	/public/images/thumbnails/741ab899-2a58-43c4-aa41-274327f70d8e-1760551345116.webp	150	150	webp	80	5638	cmgsatewp037ph9i6mq4oehwf
cmgsathun0380h9i6g91eo7ky	/public/images/medium/0aba3cdb-9b69-4205-bff5-f358abd79fe4-1760551349043.webp	800	546	webp	85	79022	cmgsathuk037wh9i67edoh6bp
cmgsatjg60387h9i69es7jwi8	/public/images/full/13925ca9-3527-4463-99bf-abf06933b6ee-1760551352863.webp	3529	2573	webp	90	984992	cmgsatjg10383h9i6rn4wcmxz
cmgsatlb1038gh9i6z2n4afmj	/public/images/thumbnails/00c60884-d1c0-48ed-8a0e-d6d6ae3b28d6-1760551354931.webp	150	150	webp	80	7322	cmgsatlau038ah9i6udhv7fmi
cmgsato83038lh9i6t8ksivdp	/public/images/thumbnails/f2acf61d-883c-444e-8d5a-0b04fe7db83a-1760551357338.webp	150	150	webp	80	6408	cmgsato7x038hh9i65mmsxwvd
cmgsatqqx038uh9i6zr2fqsag	/public/images/medium/683f403f-b92c-4bd3-bc8e-e22d487351cc-1760551361115.webp	800	1213	webp	85	175934	cmgsatqqv038oh9i62a6zac6z
cmgsatt99038zh9i6arafeuag	/public/images/medium/116a5bbf-f005-485b-aaba-41581b8c027e-1760551364381.webp	800	524	webp	85	86326	cmgsatt96038vh9i6vpo6y534
cmgsatvyc0395h9i6q2a5422f	/public/images/medium/ad81f1b2-8c81-4b98-9cdc-620c1a26d101-1760551367634.webp	800	1163	webp	85	225394	cmgsatvy90392h9i6fc2f83pv
cmgsatwvh039eh9i6m70ajc5b	/public/images/medium/afd4ac20-d063-4412-84e3-c33691a0c89e-1760551371126.webp	800	657	webp	85	67890	cmgsatwvf0399h9i6daxifeeq
cmgsaty3r039kh9i64i6nbwd0	/public/images/thumbnails/c1b4d5e9-85b4-419a-90f8-7b4351d745d1-1760551372315.webp	150	150	webp	80	8438	cmgsaty3o039gh9i6un9n8ir8
cmgsatzqm039sh9i62rchmhq3	/public/images/full/95376fd4-5aaf-4ccc-aa70-f06e90d0302c-1760551373917.webp	2513	3980	webp	90	810630	cmgsatzqj039nh9i6buqs1ho6
cmgsau1u703a0h9i6wslrlvcp	/public/images/full/ad510812-8167-48f7-9033-b3aa1e13225d-1760551376036.webp	2534	4399	webp	90	1618152	cmgsau1u5039uh9i6yno4rw5z
cmgsau3kj03a7h9i6prn8oa3q	/public/images/full/585e4107-84e3-4fce-8b7d-8a5949430fc2-1760551378752.webp	2408	3833	webp	90	1316992	cmgsau3kf03a1h9i6m7usw1y7
cmgsau6gf03adh9i6dytwsf6s	/public/images/thumbnails/c6d51f66-08ba-40af-9d1c-d5007135ad2a-1760551381006.webp	150	150	webp	80	6164	cmgsau6gc03a8h9i6n3rqvuzp
cmgsau6gf03ach9i6wd2avsaj	/public/images/medium/c6d51f66-08ba-40af-9d1c-d5007135ad2a-1760551381006.webp	800	1206	webp	85	225256	cmgsau6gc03a8h9i6n3rqvuzp
cmgsau91b03ajh9i6e5ngqalr	/public/images/thumbnails/7132dce5-22cc-439b-996c-f9e4db99f767-1760551384747.webp	150	150	webp	80	8140	cmgsau91903afh9i64z6jnsk2
cmgsau91b03alh9i62fkxuey9	/public/images/full/7132dce5-22cc-439b-996c-f9e4db99f767-1760551384747.webp	4923	3393	webp	90	1938750	cmgsau91903afh9i64z6jnsk2
cmgsaubn003arh9i6h90foiob	/public/images/full/810d52b3-810d-4588-abff-969aaec1cc23-1760551388087.webp	3267	4923	webp	90	1350584	cmgsaubmx03amh9i6syczlhwk
cmgsaubn003ash9i6l90ndga3	/public/images/medium/810d52b3-810d-4588-abff-969aaec1cc23-1760551388087.webp	800	1206	webp	85	166144	cmgsaubmx03amh9i6syczlhwk
cmgsaueto03axh9i67g3ativ0	/public/images/thumbnails/ca527866-3652-4a01-bc2b-317b306e7a90-1760551391466.webp	150	150	webp	80	5852	cmgsauetl03ath9i6wydul3ot
cmgsaueto03awh9i65xuxzjvp	/public/images/medium/ca527866-3652-4a01-bc2b-317b306e7a90-1760551391466.webp	800	1132	webp	85	219192	cmgsauetl03ath9i6wydul3ot
cmgsaugqp03b5h9i6mlpoufua	/public/images/full/8d0d8373-8c15-446a-a889-c3aa78c89e40-1760551395580.webp	3676	2727	webp	90	1462552	cmgsaugqn03b0h9i6zh3t7e39
cmgsaugqp03b4h9i6orrno1wb	/public/images/medium/8d0d8373-8c15-446a-a889-c3aa78c89e40-1760551395580.webp	800	593	webp	85	128236	cmgsaugqn03b0h9i6zh3t7e39
cmgsauiuv03bch9i6pdnneow1	/public/images/medium/7bd76a34-4ca6-4562-8c95-9c97143a6896-1760551398066.webp	800	1290	webp	85	126176	cmgsauiuo03b7h9i6la3nmwed
cmgsauiuv03bbh9i6cwev8ndq	/public/images/thumbnails/7bd76a34-4ca6-4562-8c95-9c97143a6896-1760551398066.webp	150	150	webp	80	5364	cmgsauiuo03b7h9i6la3nmwed
cmgsaul5r03bkh9i6v2w1ovju	/public/images/full/56b11222-3de8-46ea-9ffa-59367bac4f1d-1760551400810.webp	5044	3494	webp	90	1046918	cmgsaul5o03beh9i6oiug2ekc
cmgsaul5r03bih9i60skya5yv	/public/images/thumbnails/56b11222-3de8-46ea-9ffa-59367bac4f1d-1760551400810.webp	150	150	webp	80	5970	cmgsaul5o03beh9i6oiug2ekc
cmgsaap2401zhh9i6qotfn6kf	/public/images/medium/3e9dee25-79ff-4be9-a68a-fc0819ac777e-1760550472476.webp	800	536	webp	85	118042	cmgsaap2101zdh9i6789lysd6
cmgsaasrq01zoh9i6iws5l7pp	/public/images/medium/32360a0e-e242-43dc-9da4-5dfde3648203-1760550475743.webp	800	1074	webp	85	164620	cmgsaasri01zkh9i6guujvvtz
cmgsaasrq01znh9i6yv7zf3kx	/public/images/thumbnails/32360a0e-e242-43dc-9da4-5dfde3648203-1760550475743.webp	150	150	webp	80	7318	cmgsaasri01zkh9i6guujvvtz
cmgsaasrr01zqh9i6fgtlftkm	/public/images/full/32360a0e-e242-43dc-9da4-5dfde3648203-1760550475743.webp	4258	5715	webp	90	2656404	cmgsaasri01zkh9i6guujvvtz
cmgsaav9x01zth9i6gcte57uv	/public/images/medium/7130435d-7ee9-4828-851b-f28aef7b31ae-1760550480557.webp	800	560	webp	85	112224	cmgsaav9t01zrh9i6o2gh3578
cmgsaav9x01zwh9i6jav3b0rg	/public/images/full/7130435d-7ee9-4828-851b-f28aef7b31ae-1760550480557.webp	5012	3509	webp	90	1645400	cmgsaav9t01zrh9i6o2gh3578
cmgsaav9x01zxh9i6vdmbunzk	/public/images/thumbnails/7130435d-7ee9-4828-851b-f28aef7b31ae-1760550480557.webp	150	150	webp	80	9564	cmgsaav9t01zrh9i6o2gh3578
cmgsaaxkz0202h9i6bggdmm44	/public/images/thumbnails/ffa6521c-7d77-41f2-a5a7-43585876259e-1760550483791.webp	150	150	webp	80	8540	cmgsaaxkw01zyh9i6zjnwn2j7
cmgsaaxkz0203h9i62wd7au75	/public/images/full/ffa6521c-7d77-41f2-a5a7-43585876259e-1760550483791.webp	5012	3541	webp	90	1324522	cmgsaaxkw01zyh9i6zjnwn2j7
cmgsaaxkz0204h9i6hougffan	/public/images/medium/ffa6521c-7d77-41f2-a5a7-43585876259e-1760550483791.webp	800	565	webp	85	83652	cmgsaaxkw01zyh9i6zjnwn2j7
cmgsabe0v0207h9i6aoz7h7dl	/public/images/medium/c3000103-d962-4511-9a2e-4b12e0e4ed88-1760550486786.webp	800	596	webp	85	96178	cmgsabe0r0205h9i6bd0rnq35
cmgsabe0w020bh9i6i0o770a4	/public/images/full/c3000103-d962-4511-9a2e-4b12e0e4ed88-1760550486786.webp	6744	5028	webp	90	5174638	cmgsabe0r0205h9i6bd0rnq35
cmgsabe0w020ah9i60galqenx	/public/images/thumbnails/c3000103-d962-4511-9a2e-4b12e0e4ed88-1760550486786.webp	150	150	webp	80	8066	cmgsabe0r0205h9i6bd0rnq35
cmgsabes9020hh9i6hlvv75lm	/public/images/medium/2e717eb4-87b5-4d51-a062-42f85bf3c1f9-1760550508078.webp	800	965	webp	85	145552	cmgsabes6020ch9i6hxpb15b0
cmgsabes9020gh9i6q172bav5	/public/images/thumbnails/2e717eb4-87b5-4d51-a062-42f85bf3c1f9-1760550508078.webp	150	150	webp	80	8676	cmgsabes6020ch9i6hxpb15b0
cmgsabes9020ih9i6r828uwtc	/public/images/full/2e717eb4-87b5-4d51-a062-42f85bf3c1f9-1760550508078.webp	1655	1996	webp	90	394586	cmgsabes6020ch9i6hxpb15b0
cmgsabfwp020ph9i61jtm3ve4	/public/images/thumbnails/40bface7-4e19-404d-b3e3-987ded82ca0c-1760550509068.webp	150	150	webp	80	8254	cmgsabfwk020jh9i623an3xqi
cmgsabfwp020nh9i6u3ityisq	/public/images/medium/40bface7-4e19-404d-b3e3-987ded82ca0c-1760550509068.webp	800	1038	webp	85	151860	cmgsabfwk020jh9i623an3xqi
cmgsabfwp020oh9i6qt1czdmm	/public/images/full/40bface7-4e19-404d-b3e3-987ded82ca0c-1760550509068.webp	2092	2714	webp	90	524994	cmgsabfwk020jh9i623an3xqi
cmgsabgya020uh9i6rc8k8stf	/public/images/medium/7fc39805-aef0-4394-9896-5f3a9db5d638-1760550510521.webp	800	692	webp	85	101610	cmgsabgy7020qh9i67u42xtw1
cmgsabgya020wh9i6yqmkuqwv	/public/images/full/7fc39805-aef0-4394-9896-5f3a9db5d638-1760550510521.webp	2561	2215	webp	90	462596	cmgsabgy7020qh9i67u42xtw1
cmgsabgya020vh9i6k1xevkhq	/public/images/thumbnails/7fc39805-aef0-4394-9896-5f3a9db5d638-1760550510521.webp	150	150	webp	80	7756	cmgsabgy7020qh9i67u42xtw1
cmgsabhvr0211h9i6yopxwrsc	/public/images/thumbnails/1c1c1721-a0b5-474a-a9d6-824b42fe55cb-1760550511883.webp	150	150	webp	80	7530	cmgsabhvn020xh9i6cpy9wxgb
cmgsabhvr0212h9i684wl2h2c	/public/images/medium/1c1c1721-a0b5-474a-a9d6-824b42fe55cb-1760550511883.webp	800	678	webp	85	90446	cmgsabhvn020xh9i6cpy9wxgb
cmgsabhvr0213h9i6k1pfwy44	/public/images/full/1c1c1721-a0b5-474a-a9d6-824b42fe55cb-1760550511883.webp	2561	2168	webp	90	435516	cmgsabhvn020xh9i6cpy9wxgb
cmgsabic80217h9i6ruvd5sp7	/public/images/thumbnails/d4e91bf8-7390-4808-a2ad-2ac1b73fa9e0-1760550513082.webp	150	150	webp	80	4994	cmgsabic50214h9i6neliboyy
cmgsabic8021ah9i6r07ysmq3	/public/images/full/d4e91bf8-7390-4808-a2ad-2ac1b73fa9e0-1760550513082.webp	1015	1341	webp	90	90838	cmgsabic50214h9i6neliboyy
cmgsabic80219h9i6orsz4pa6	/public/images/medium/d4e91bf8-7390-4808-a2ad-2ac1b73fa9e0-1760550513082.webp	800	1057	webp	85	64356	cmgsabic50214h9i6neliboyy
cmgsabjbi021gh9i67ck29us7	/public/images/medium/b00c740e-b559-477e-bc8c-0afd305a8d53-1760550513675.webp	800	859	webp	85	100168	cmgsabjbf021bh9i6v645esqe
cmgsabjbi021hh9i6oe0e52ic	/public/images/full/b00c740e-b559-477e-bc8c-0afd305a8d53-1760550513675.webp	2311	2480	webp	90	398808	cmgsabjbf021bh9i6v645esqe
cmgsabjbi021eh9i6ty6vn22t	/public/images/thumbnails/b00c740e-b559-477e-bc8c-0afd305a8d53-1760550513675.webp	150	150	webp	80	7944	cmgsabjbf021bh9i6v645esqe
cmgsabkc9021mh9i61wwfjm3t	/public/images/medium/4e64cbcd-0530-4f94-abab-3acb6d90b44f-1760550514947.webp	800	831	webp	85	83962	cmgsabkc5021ih9i68ogh8k58
cmgsabkc9021nh9i6jod8ad7i	/public/images/thumbnails/4e64cbcd-0530-4f94-abab-3acb6d90b44f-1760550514947.webp	150	150	webp	80	6732	cmgsabkc5021ih9i68ogh8k58
cmgsabkc9021oh9i6ddplw769	/public/images/full/4e64cbcd-0530-4f94-abab-3acb6d90b44f-1760550514947.webp	2358	2449	webp	90	420864	cmgsabkc5021ih9i68ogh8k58
cmgsablc6021vh9i6dw7cs6l2	/public/images/thumbnails/67d93f47-026b-4650-ad4e-54174a38450f-1760550516271.webp	150	150	webp	80	6174	cmgsablc3021ph9i632t7dqhz
cmgsablc6021th9i6hyrzpb38	/public/images/full/67d93f47-026b-4650-ad4e-54174a38450f-1760550516271.webp	2373	2386	webp	90	412490	cmgsablc3021ph9i632t7dqhz
cmgsablc6021uh9i6q7igh2t9	/public/images/medium/67d93f47-026b-4650-ad4e-54174a38450f-1760550516271.webp	800	804	webp	85	83412	cmgsablc3021ph9i632t7dqhz
cmgsabmae0221h9i60erat9ss	/public/images/medium/ccd0f625-427e-45d3-a227-f46b6dc26a68-1760550517564.webp	800	851	webp	85	88514	cmgsabmac021wh9i6q4b8o8rd
cmgsabmae0220h9i669unx3or	/public/images/thumbnails/ccd0f625-427e-45d3-a227-f46b6dc26a68-1760550517564.webp	150	150	webp	80	6800	cmgsabmac021wh9i6q4b8o8rd
cmgsabmae0222h9i63fie6yi2	/public/images/full/ccd0f625-427e-45d3-a227-f46b6dc26a68-1760550517564.webp	2186	2324	webp	90	363126	cmgsabmac021wh9i6q4b8o8rd
cmgsabn8q0228h9i6s265rw0l	/public/images/full/e77a86ab-0bd3-498d-bd67-1691538f700b-1760550518790.webp	2342	2339	webp	90	434578	cmgsabn8m0223h9i6jrjbamj4
cmgsabn8q0227h9i6t8yaubqu	/public/images/medium/e77a86ab-0bd3-498d-bd67-1691538f700b-1760550518790.webp	800	799	webp	85	101658	cmgsabn8m0223h9i6jrjbamj4
cmgsabn8q0229h9i6x1n8czg7	/public/images/thumbnails/e77a86ab-0bd3-498d-bd67-1691538f700b-1760550518790.webp	150	150	webp	80	7986	cmgsabn8m0223h9i6jrjbamj4
cmgsabo6g022fh9i6img1wzzd	/public/images/thumbnails/83a47ac3-62b1-4b29-a765-bb08529e2774-1760550520030.webp	150	150	webp	80	9266	cmgsabo6d022ah9i6wffm47dx
cmgsabp47022lh9i6x2guhipe	/public/images/full/27179c86-c0e0-4555-b275-de905f25d1b2-1760550521247.webp	1887	2529	webp	90	432924	cmgsabp44022hh9i6ixk6dogg
cmgsabq15022th9i6abqycc3r	/public/images/full/af944772-e29e-494d-8eab-c33d0053f095-1760550522455.webp	1918	2654	webp	90	353784	cmgsabq13022oh9i6yu58f0t0
cmgsabqyw022yh9i6mqvdv96i	/public/images/thumbnails/cb313bb2-0971-4f4a-9543-cc1692d28d25-1760550523646.webp	150	150	webp	80	7892	cmgsabqyt022vh9i6ejtyrq0q
cmgsabru60238h9i65j9bki5o	/public/images/medium/dcf17860-3914-471b-a7de-35511de15ca1-1760550524859.webp	800	1145	webp	85	108864	cmgsabru20232h9i6wq5ur1nd
cmgsabu5h023fh9i6mz9uown1	/public/images/full/71f1fbf8-1035-4eb1-8cf0-51c82f5896aa-1760550525989.webp	5012	3541	webp	90	946532	cmgsabu5c0239h9i6k5wopiwf
cmgsabww7023kh9i6mxppv3m6	/public/images/medium/b0b3236a-e8c4-48e8-a557-62da2bf3c29b-1760550528987.webp	800	550	webp	85	105148	cmgsabww2023gh9i6f9wuem1e
cmgsabzqp023rh9i6w6lid897	/public/images/thumbnails/3330473f-9d90-49ca-9b20-6120f763b193-1760550532537.webp	150	150	webp	80	7924	cmgsabzqm023nh9i6sr97x435
cmgsac2hl023zh9i6mnch9um4	/public/images/medium/43ad7425-f3d6-4dad-a268-04a02c114051-1760550536239.webp	800	550	webp	85	112748	cmgsac2hf023uh9i684wos3d6
cmgsac5fg0244h9i6lxg79tj6	/public/images/medium/edbd37b7-d3d2-4026-b631-61655e058f91-1760550539789.webp	800	550	webp	85	126890	cmgsac5fc0241h9i6msplfpzu
cmgsac6zt024dh9i6napfqml8	/public/images/medium/6e259151-5a55-4416-9d3f-9cff4145a5ce-1760550543625.webp	800	1309	webp	85	115086	cmgsac6zq0248h9i6p5d580fo
cmgsac966024jh9i6p8q5iqyr	/public/images/full/205b5bab-02ab-410d-85fd-f3017cd9b4e2-1760550545634.webp	3338	4856	webp	90	792704	cmgsac961024fh9i6obflp06c
cmgsacaht024sh9i6d5n3tjwv	/public/images/thumbnails/906a6d5b-1697-4654-bfa0-f1c5c904fc63-1760550548452.webp	150	150	webp	80	8762	cmgsacahp024mh9i69ahvdwo9
cmgsaccz2024yh9i6wqo5iazs	/public/images/thumbnails/a147e787-2dce-4440-ae91-64014d366984-1760550550169.webp	150	150	webp	80	6092	cmgsaccz0024th9i6irqa3zpe
cmgsacfli0256h9i69qjml4kx	/public/images/full/44763d3b-7d83-4541-9220-bfc93aa43b0c-1760550553384.webp	5012	3400	webp	90	1477562	cmgsacfle0250h9i6phnkoave
cmgsacvcd025ch9i6k8ofovmz	/public/images/thumbnails/efeeb7d5-04ec-4b10-a3a6-5118ef1af775-1760550556799.webp	150	150	webp	80	10856	cmgsacvc80257h9i695v0ykgs
cmgsaodg102x5h9i68qm0wovh	/public/images/thumbnails/b98e3e8a-1c08-414a-a7ed-c8956735139c-1760551110199.webp	150	150	webp	80	6630	cmgsaodfw02x0h9i6bdmyn00t
cmgsaofnx02xbh9i69u8i23d8	/public/images/medium/12a5f1eb-cd6c-4002-babd-e8f43361feb8-1760551113863.webp	800	560	webp	85	53654	cmgsaofnv02x7h9i6tjbznx8i
cmgsaohzu02xkh9i69pt72o3x	/public/images/medium/98c460ff-99fd-4a04-aeac-0b6d8e45e6ab-1760551116735.webp	800	544	webp	85	95708	cmgsaohzp02xeh9i6esxa25zc
cmgsaoker02xph9i6cndbudn5	/public/images/medium/06962ce0-c41e-424e-99dd-d8849edb9d41-1760551119765.webp	800	546	webp	85	94000	cmgsaokem02xlh9i66uq7a8j3
cmgsaonas02xxh9i6av7m5vmk	/public/images/medium/0eaf3505-d383-418c-86ec-27daa4a298ae-1760551122895.webp	800	595	webp	85	85298	cmgsaonaq02xsh9i64wmlau61
cmgsaovrk02y4h9i6twjy6kqx	/public/images/medium/881ab602-39d4-4795-860c-ec8bfb776d07-1760551126647.webp	800	1081	webp	85	121272	cmgsaovrh02xzh9i6gmljov5z
cmgsapaz202ych9i6jaeqceu3	/public/images/full/e17a5dc6-f69a-4b32-a685-16ee7959e723-1760551137616.webp	5216	6754	webp	90	3036214	cmgsapayz02y6h9i64hdfegvs
cmgsappjc02yjh9i6cr92firz	/public/images/medium/89c17e17-9cf4-4051-a0c4-ec75e6f6faa6-1760551157322.webp	800	618	webp	85	90492	cmgsappj902ydh9i6wkhtumwe
cmgsapsdn02yph9i621s1r586	/public/images/thumbnails/9eade249-b00b-419c-b56b-d0e569c681fb-1760551176195.webp	150	150	webp	80	4786	cmgsapsdj02ykh9i67102gsm7
cmgsapx9c02ywh9i607kk1zjy	/public/images/full/9bf043ff-3309-4a8f-a49d-4eb7018ba222-1760551179885.webp	6744	4839	webp	90	3257250	cmgsapx9902yrh9i6xnrochap
cmgsapygs02z2h9i6csyz6jb6	/public/images/thumbnails/b2fceceb-5476-4497-ab41-1d096335c70b-1760551186192.webp	150	150	webp	80	4814	cmgsapygm02yyh9i6lsrvomvd
cmgsapzpt02z9h9i61o2jjdan	/public/images/full/bdf1d566-602d-4217-9f47-ae5871eb318e-1760551187765.webp	2220	2723	webp	90	879954	cmgsapzpq02z5h9i6qsg3v8nh
cmgsaq17202zeh9i6xbrn6yxz	/public/images/medium/a2978841-fc5a-45ec-bd85-2b5512c9611b-1760551189378.webp	800	1246	webp	85	276818	cmgsaq17002zch9i6uvf5djce
cmgsaq22y02zph9i64q2xsgst	/public/images/full/0579dce0-cf57-48ac-971e-c2d2a6d12460-1760551191297.webp	2170	2277	webp	90	368820	cmgsaq22v02zjh9i6aw88r1fw
cmgsaq34g02zwh9i679erwvps	/public/images/full/2065cdf0-17c0-48f0-9b05-f609c3ddae1a-1760551192448.webp	2123	2620	webp	90	530388	cmgsaq34c02zqh9i6pnysdtqc
cmgsaq4jd0303h9i6opa1d6d0	/public/images/full/d91ec5ba-912a-4c62-8b3b-c7604febe00b-1760551193795.webp	2670	3666	webp	90	462620	cmgsaq4j602zxh9i6hkia6i2h
cmgsaq5mz030ah9i6z3s0996u	/public/images/thumbnails/9471f552-8556-448e-ac73-62ce563fdba1-1760551195621.webp	150	150	webp	80	4794	cmgsaq5mt0304h9i6pe1fjg4q
cmgsaq6nf030fh9i6bgnseb6j	/public/images/thumbnails/9d523ce5-ecb7-422e-ab90-a0a0c23803d6-1760551197049.webp	150	150	webp	80	5178	cmgsaq6nc030bh9i6rg8v1inz
cmgsatbvm037mh9i65oqhnq2h	/public/images/full/246497bc-1ee3-43fa-a627-f658dfe0ca9c-1760551341618.webp	5309	3416	webp	90	1892850	cmgsatbvi037ih9i619trnk2k
cmgsateww037th9i6q7ik4tsv	/public/images/medium/741ab899-2a58-43c4-aa41-274327f70d8e-1760551345116.webp	800	580	webp	85	57268	cmgsatewp037ph9i6mq4oehwf
cmgsathun0381h9i63v3ooz6b	/public/images/full/0aba3cdb-9b69-4205-bff5-f358abd79fe4-1760551349043.webp	5169	3525	webp	90	2488190	cmgsathuk037wh9i67edoh6bp
cmgsatjg60389h9i6fqo9s0kz	/public/images/thumbnails/13925ca9-3527-4463-99bf-abf06933b6ee-1760551352863.webp	150	150	webp	80	7498	cmgsatjg10383h9i6rn4wcmxz
cmgsatlb1038fh9i6tjtrh88w	/public/images/full/00c60884-d1c0-48ed-8a0e-d6d6ae3b28d6-1760551354931.webp	4278	2542	webp	90	1611270	cmgsatlau038ah9i6udhv7fmi
cmgsato83038mh9i6smbvuh4t	/public/images/medium/f2acf61d-883c-444e-8d5a-0b04fe7db83a-1760551357338.webp	800	1067	webp	85	200296	cmgsato7x038hh9i65mmsxwvd
cmgsatqqx038sh9i6robkaorm	/public/images/thumbnails/683f403f-b92c-4bd3-bc8e-e22d487351cc-1760551361115.webp	150	150	webp	80	5484	cmgsatqqv038oh9i62a6zac6z
cmgsatt990391h9i6tkpt8ric	/public/images/full/116a5bbf-f005-485b-aaba-41581b8c027e-1760551364381.webp	4981	3260	webp	90	1570922	cmgsatt96038vh9i6vpo6y534
cmgsatvyc0398h9i63rco4qu3	/public/images/full/ad81f1b2-8c81-4b98-9cdc-620c1a26d101-1760551367634.webp	3372	4902	webp	90	1662562	cmgsatvy90392h9i6fc2f83pv
cmgsabo6g022eh9i6e16m1nez	/public/images/medium/83a47ac3-62b1-4b29-a765-bb08529e2774-1760550520030.webp	800	629	webp	85	115512	cmgsabo6d022ah9i6wffm47dx
cmgsabp47022nh9i6pqu427al	/public/images/medium/27179c86-c0e0-4555-b275-de905f25d1b2-1760550521247.webp	800	1072	webp	85	142712	cmgsabp44022hh9i6ixk6dogg
cmgsabq15022qh9i61gpaprr5	/public/images/thumbnails/af944772-e29e-494d-8eab-c33d0053f095-1760550522455.webp	150	150	webp	80	6894	cmgsabq13022oh9i6yu58f0t0
cmgsabqyw0231h9i64z5is4ml	/public/images/full/cb313bb2-0971-4f4a-9543-cc1692d28d25-1760550523646.webp	1887	2561	webp	90	470086	cmgsabqyt022vh9i6ejtyrq0q
cmgsabru60237h9i6pijjjknp	/public/images/full/dcf17860-3914-471b-a7de-35511de15ca1-1760550524859.webp	1778	2545	webp	90	311528	cmgsabru20232h9i6wq5ur1nd
cmgsabu5h023dh9i6btft5kst	/public/images/medium/71f1fbf8-1035-4eb1-8cf0-51c82f5896aa-1760550525989.webp	800	565	webp	85	63458	cmgsabu5c0239h9i6k5wopiwf
cmgsabww7023mh9i69dnrhc9m	/public/images/full/b0b3236a-e8c4-48e8-a557-62da2bf3c29b-1760550528987.webp	4950	3400	webp	90	2284264	cmgsabww2023gh9i6f9wuem1e
cmgsabzqp023th9i6df0iewjr	/public/images/medium/3330473f-9d90-49ca-9b20-6120f763b193-1760550532537.webp	800	1174	webp	85	238298	cmgsabzqm023nh9i6sr97x435
cmgsac2hj023wh9i6ijiomps3	/public/images/full/43ad7425-f3d6-4dad-a268-04a02c114051-1760550536239.webp	4950	3400	webp	90	2562902	cmgsac2hf023uh9i684wos3d6
cmgsapaz202y8h9i6soiujkn2	/public/images/thumbnails/e17a5dc6-f69a-4b32-a685-16ee7959e723-1760551137616.webp	150	150	webp	80	5974	cmgsapayz02y6h9i64hdfegvs
cmgsappjc02yfh9i6ipspgysd	/public/images/thumbnails/89c17e17-9cf4-4051-a0c4-ec75e6f6faa6-1760551157322.webp	150	150	webp	80	6850	cmgsappj902ydh9i6wkhtumwe
cmgsapsdn02yqh9i6pbg78vbm	/public/images/full/9eade249-b00b-419c-b56b-d0e569c681fb-1760551176195.webp	3435	5179	webp	90	2007990	cmgsapsdj02ykh9i67102gsm7
cmgsapx9c02yvh9i6jc0y3w97	/public/images/medium/9bf043ff-3309-4a8f-a49d-4eb7018ba222-1760551179885.webp	800	574	webp	85	80976	cmgsapx9902yrh9i6xnrochap
cmgsapygs02z3h9i6rtrx9k24	/public/images/medium/b2fceceb-5476-4497-ab41-1d096335c70b-1760551186192.webp	800	973	webp	85	182118	cmgsapygm02yyh9i6lsrvomvd
cmgsapzpt02zah9i69ipff9v3	/public/images/thumbnails/bdf1d566-602d-4217-9f47-ae5871eb318e-1760551187765.webp	150	150	webp	80	8942	cmgsapzpq02z5h9i6qsg3v8nh
cmgsaq17302zgh9i6unr0alf6	/public/images/thumbnails/a2978841-fc5a-45ec-bd85-2b5512c9611b-1760551189378.webp	150	150	webp	80	7864	cmgsaq17002zch9i6uvf5djce
cmgsaq22y02znh9i6tchkbs6j	/public/images/medium/0579dce0-cf57-48ac-971e-c2d2a6d12460-1760551191297.webp	800	839	webp	85	85604	cmgsaq22v02zjh9i6aw88r1fw
cmgsaq34g02zuh9i6wz926asp	/public/images/medium/2065cdf0-17c0-48f0-9b05-f609c3ddae1a-1760551192448.webp	800	987	webp	85	127608	cmgsaq34c02zqh9i6pnysdtqc
cmgsaq4jd0301h9i6trw7q92o	/public/images/medium/d91ec5ba-912a-4c62-8b3b-c7604febe00b-1760551193795.webp	800	1098	webp	85	58632	cmgsaq4j602zxh9i6hkia6i2h
cmgsaq5mz0307h9i6ebzgucf4	/public/images/medium/9471f552-8556-448e-ac73-62ce563fdba1-1760551195621.webp	800	906	webp	85	130522	cmgsaq5mt0304h9i6pe1fjg4q
cmgsaq6nf030hh9i6wubpluli	/public/images/full/9d523ce5-ecb7-422e-ab90-a0a0c23803d6-1760551197049.webp	2555	2053	webp	90	713992	cmgsaq6nc030bh9i6rg8v1inz
cmgsaq7m0030kh9i6ik1lakmn	/public/images/thumbnails/7bc0318a-506d-45d4-a2fa-428375b8e34c-1760551198366.webp	150	150	webp	80	5178	cmgsaq7lv030ih9i6ricnfu5v
cmgsaq904030th9i6pok4v257	/public/images/full/378d27af-f4f8-40a1-bd14-be23fa32f4ae-1760551199646.webp	3466	2511	webp	90	703558	cmgsaq900030ph9i6kee946d0
cmgsaqblb030zh9i6rh3tf0ib	/public/images/medium/bc799cce-d8ff-4212-8d80-c3821143809b-1760551201423.webp	800	549	webp	85	75130	cmgsaqbl6030wh9i6efxbmud8
cmgsaqdv90319h9i6lzb3two0	/public/images/full/a0a880ec-1cca-4757-80ae-ea3b104d69fe-1760551204779.webp	4185	3385	webp	90	1283744	cmgsaqdv60313h9i6f2ic4owx
cmgsaqgif031dh9i60aczwuzn	/public/images/full/f33421a9-081c-4ce2-804b-4b50b92aa4d3-1760551207728.webp	3619	4981	webp	90	1452452	cmgsaqgid031ah9i62vkqbx3k
cmgsaqxez031nh9i6pmne95by	/public/images/full/15f310c4-1c4e-4af7-8ab3-b77aac74dd63-1760551211181.webp	6817	5122	webp	90	5062422	cmgsaqxew031hh9i6q37c51ag
cmgsar05o031sh9i67tpwah1l	/public/images/thumbnails/8a769182-2880-4b35-8de9-abcf0d8bbbf5-1760551233056.webp	150	150	webp	80	5528	cmgsar05i031oh9i6y8uwvaoq
cmgsar2rm031zh9i6a366smkp	/public/images/thumbnails/882b35d5-f349-4b8b-aefe-80445e1bf1fe-1760551236612.webp	150	150	webp	80	5878	cmgsar2rj031vh9i65uqhtyga
cmgsar56s0327h9i6o9ewp3gi	/public/images/medium/11753bfb-9591-4883-9803-5df264b531ef-1760551239987.webp	800	1165	webp	85	104536	cmgsar56m0322h9i6vyft5ybr
cmgsar7k3032eh9i6cenyag6b	/public/images/thumbnails/2a704439-37cc-44b7-a1c2-50ac74d1e320-1760551243130.webp	150	150	webp	80	8210	cmgsar7k00329h9i6bsx0p3v8
cmgsara16032mh9i6w91cbahs	/public/images/full/6c3a59ee-88db-4d78-a320-d10998925240-1760551246198.webp	3351	5091	webp	90	1087172	cmgsara12032gh9i680ct0oid
cmgsarclo032sh9i6ou2825c4	/public/images/thumbnails/b074c884-2dcf-48bd-93e1-372f32406dcc-1760551249416.webp	150	150	webp	80	6172	cmgsarclk032nh9i6mx73z8zy
cmgsardrb032zh9i69wcdaomp	/public/images/thumbnails/6bcc390c-2be3-4cff-a0fa-f8fecaab6d5a-1760551252738.webp	150	150	webp	80	7920	cmgsardr9032uh9i6aj3lc9qr
cmgsarew40337h9i63vsfqkce	/public/images/medium/0234bf59-84ea-4147-9763-44bd933abac5-1760551254233.webp	800	780	webp	85	90914	cmgsarew20331h9i6yxogsojb
cmgsarg19033bh9i6iov2zkxt	/public/images/medium/f2d88f86-b7b7-4c4f-af5d-8c47c58f0672-1760551255701.webp	800	809	webp	85	72982	cmgsarg150338h9i6y90ltdsa
cmgsargz4033jh9i6xy4zwlkz	/public/images/full/facd4e72-c8d1-4101-9bd2-9666fb095782-1760551257183.webp	2358	2246	webp	90	332950	cmgsargyz033fh9i6vmvyf3rw
cmgsaribu033rh9i6vi07pyd8	/public/images/full/a937a959-56ce-449f-b6ac-d20265d18aa8-1760551258406.webp	3123	2854	webp	90	564578	cmgsaribq033mh9i6q1ih2g85
cmgsas685033vh9i6p02y1u7k	/public/images/thumbnails/36f5bf04-fc2a-4fc5-ba1a-6a810e07131a-1760551260174.webp	150	150	webp	80	8496	cmgsas683033th9i60ri2354f
cmgsas89g0346h9i6jdrosm0c	/public/images/full/47068c6e-e25b-43b5-9053-2ea6c953184a-1760551290191.webp	3400	4981	webp	90	2114512	cmgsas89d0340h9i62izt0uwz
cmgsasb4z034bh9i6u9ornewc	/public/images/medium/7cf040d1-b35e-4472-8f97-876c15accc2a-1760551293778.webp	800	1235	webp	85	169212	cmgsasb4u0347h9i6gcvvdevp
cmgsasdwr034ih9i6hhcjmk5b	/public/images/full/f2892191-f363-498b-9398-5800415f8e35-1760551297498.webp	5012	3307	webp	90	2289352	cmgsasdwn034eh9i6r47tf2q0
cmgsasfi1034rh9i6gyaklr2t	/public/images/full/2f25fcdd-962d-4cd9-a6f2-446e943e6ee6-1760551301084.webp	3763	2636	webp	90	793210	cmgsasfhz034lh9i6tbamb39u
cmgsafcbf026qh9i65kcei1pc	/public/images/full/3b5339dd-c081-42b7-8df9-89f300cfd98c-1760550667108.webp	8033	5934	webp	90	4250842	cmgsafcbc026kh9i6bz3r00c8
cmgsafekw026vh9i6b7oll56m	/public/images/medium/28289ed5-56ba-4578-8656-de3db1e31a8a-1760550692491.webp	800	407	webp	85	78570	cmgsafeku026rh9i6hy8f8dm4
cmgsafekw026xh9i6jinzg9mp	/public/images/full/28289ed5-56ba-4578-8656-de3db1e31a8a-1760550692491.webp	5762	2932	webp	90	1156680	cmgsafeku026rh9i6hy8f8dm4
cmgsafekw026uh9i6asjej4s6	/public/images/thumbnails/28289ed5-56ba-4578-8656-de3db1e31a8a-1760550692491.webp	150	150	webp	80	9410	cmgsafeku026rh9i6hy8f8dm4
cmgsaffns0274h9i6uc8eaaxv	/public/images/thumbnails/1d9a0a98-dbbd-4404-b8f2-98f76e16c6f0-1760550695424.webp	150	150	webp	80	7452	cmgsaffnq026yh9i6t8lb92dx
cmgsaffns0273h9i6zyi68zpv	/public/images/full/1d9a0a98-dbbd-4404-b8f2-98f76e16c6f0-1760550695424.webp	2545	2121	webp	90	775080	cmgsaffnq026yh9i6t8lb92dx
cmgsaffns0272h9i6iinuhvwj	/public/images/medium/1d9a0a98-dbbd-4404-b8f2-98f76e16c6f0-1760550695424.webp	800	667	webp	85	131842	cmgsaffnq026yh9i6t8lb92dx
cmgsafgp7027ah9i6yne9dr1p	/public/images/full/a732289f-3430-4d12-bfa3-677be2131c6d-1760550696828.webp	2935	2106	webp	90	416990	cmgsafgp10275h9i6yu5t43fd
cmgsafgp7027bh9i67m2r5y4i	/public/images/medium/a732289f-3430-4d12-bfa3-677be2131c6d-1760550696828.webp	800	574	webp	85	56640	cmgsafgp10275h9i6yu5t43fd
cmgsafgp70279h9i6kwzeuln1	/public/images/thumbnails/a732289f-3430-4d12-bfa3-677be2131c6d-1760550696828.webp	150	150	webp	80	5020	cmgsafgp10275h9i6yu5t43fd
cmgsafjyx027ih9i65jdsgw0o	/public/images/medium/477bb6de-952a-4147-a8d8-7409c4994e74-1760550698197.webp	800	881	webp	85	263380	cmgsafjyu027ch9i6x3btkax2
cmgsafjyx027hh9i6zja3n1jz	/public/images/thumbnails/477bb6de-952a-4147-a8d8-7409c4994e74-1760550698197.webp	150	150	webp	80	10114	cmgsafjyu027ch9i6x3btkax2
cmgsafjyx027gh9i68j0ett99	/public/images/full/477bb6de-952a-4147-a8d8-7409c4994e74-1760550698197.webp	3482	3837	webp	90	5926098	cmgsafjyu027ch9i6x3btkax2
cmgsafkvo027ph9i6uwmk47zu	/public/images/thumbnails/9824e4d7-a10f-439b-9c7e-e975b815ba00-1760550702414.webp	150	150	webp	80	8304	cmgsafkvj027jh9i6jpahe9km
cmgsafkvo027oh9i6mquyhrcc	/public/images/medium/9824e4d7-a10f-439b-9c7e-e975b815ba00-1760550702414.webp	800	1080	webp	85	127132	cmgsafkvj027jh9i6jpahe9km
cmgsafkvo027nh9i6fkue4fha	/public/images/full/9824e4d7-a10f-439b-9c7e-e975b815ba00-1760550702414.webp	1998	2698	webp	90	411400	cmgsafkvj027jh9i6jpahe9km
cmgsafnlk027uh9i6m7dp5n4t	/public/images/medium/8256f92e-3f2d-4fcf-9f4b-e0ef159f03ee-1760550703591.webp	800	1156	webp	85	110422	cmgsafnlg027qh9i6nwa3cjsd
cmgsafnlk027th9i6bglggt1y	/public/images/full/8256f92e-3f2d-4fcf-9f4b-e0ef159f03ee-1760550703591.webp	3697	5340	webp	90	1228584	cmgsafnlg027qh9i6nwa3cjsd
cmgsafnlk027wh9i6qmwxy65b	/public/images/thumbnails/8256f92e-3f2d-4fcf-9f4b-e0ef159f03ee-1760550703591.webp	150	150	webp	80	5530	cmgsafnlg027qh9i6nwa3cjsd
cmgsafqb4027zh9i6g45l4hxu	/public/images/thumbnails/71277d76-0da9-49c2-a0f4-6c779a9801c3-1760550707118.webp	150	150	webp	80	6900	cmgsafqb2027xh9i6lpjc12sa
cmgsafqb50283h9i69tw1f35n	/public/images/full/71277d76-0da9-49c2-a0f4-6c779a9801c3-1760550707118.webp	5247	3759	webp	90	1226006	cmgsafqb2027xh9i6lpjc12sa
cmgsafqb50281h9i6hmduvo63	/public/images/medium/71277d76-0da9-49c2-a0f4-6c779a9801c3-1760550707118.webp	800	573	webp	85	59354	cmgsafqb2027xh9i6lpjc12sa
cmgsafrpa028ah9i68abd19pb	/public/images/thumbnails/204fc825-49d4-4dad-84bd-1fd5aa33dce0-1760550710624.webp	150	150	webp	80	7084	cmgsafrp60284h9i6g5tcxhy1
cmgsafrpa0288h9i68zrsegsj	/public/images/full/204fc825-49d4-4dad-84bd-1fd5aa33dce0-1760550710624.webp	3248	2620	webp	90	616140	cmgsafrp60284h9i6g5tcxhy1
cmgsafrpa0289h9i6b1jx42ve	/public/images/medium/204fc825-49d4-4dad-84bd-1fd5aa33dce0-1760550710624.webp	800	645	webp	85	74640	cmgsafrp60284h9i6g5tcxhy1
cmgsaft51028gh9i6z1wxuai7	/public/images/thumbnails/f255d84b-0f23-400e-b6bb-dee04c309228-1760550712436.webp	150	150	webp	80	7476	cmgsaft4y028bh9i6ipgq4n4u
cmgsaft51028fh9i6j86s1m0c	/public/images/medium/f255d84b-0f23-400e-b6bb-dee04c309228-1760550712436.webp	800	1186	webp	85	127268	cmgsaft4y028bh9i6ipgq4n4u
cmgsaft51028hh9i6104ae34d	/public/images/full/f255d84b-0f23-400e-b6bb-dee04c309228-1760550712436.webp	2420	3588	webp	90	721698	cmgsaft4y028bh9i6ipgq4n4u
cmgsaq4jd0302h9i6aah4kfmf	/public/images/thumbnails/d91ec5ba-912a-4c62-8b3b-c7604febe00b-1760551193795.webp	150	150	webp	80	2478	cmgsaq4j602zxh9i6hkia6i2h
cmgsaq5mz0308h9i6embpdvvk	/public/images/full/9471f552-8556-448e-ac73-62ce563fdba1-1760551195621.webp	2262	2561	webp	90	559462	cmgsaq5mt0304h9i6pe1fjg4q
cmgsaq6nf030gh9i6bpaqydig	/public/images/medium/9d523ce5-ecb7-422e-ab90-a0a0c23803d6-1760551197049.webp	800	643	webp	85	86330	cmgsaq6nc030bh9i6rg8v1inz
cmgsatbvm037nh9i6l01skwd6	/public/images/thumbnails/246497bc-1ee3-43fa-a627-f658dfe0ca9c-1760551341618.webp	150	150	webp	80	8736	cmgsatbvi037ih9i619trnk2k
cmgsateww037uh9i6rr4g1y39	/public/images/full/741ab899-2a58-43c4-aa41-274327f70d8e-1760551345116.webp	5169	3744	webp	90	2423332	cmgsatewp037ph9i6mq4oehwf
cmgsathun0382h9i6nhm3rx8k	/public/images/thumbnails/0aba3cdb-9b69-4205-bff5-f358abd79fe4-1760551349043.webp	150	150	webp	80	7808	cmgsathuk037wh9i67edoh6bp
cmgsatjg60388h9i6i0sgnpil	/public/images/medium/13925ca9-3527-4463-99bf-abf06933b6ee-1760551352863.webp	800	583	webp	85	96726	cmgsatjg10383h9i6rn4wcmxz
cmgsatlb0038ch9i6vbzgam1g	/public/images/medium/00c60884-d1c0-48ed-8a0e-d6d6ae3b28d6-1760551354931.webp	800	475	webp	85	94814	cmgsatlau038ah9i6udhv7fmi
cmgsato83038nh9i67nscixr6	/public/images/full/f2acf61d-883c-444e-8d5a-0b04fe7db83a-1760551357338.webp	3770	5028	webp	90	1842064	cmgsato7x038hh9i65mmsxwvd
cmgsatqqx038th9i68ycp0r12	/public/images/full/683f403f-b92c-4bd3-bc8e-e22d487351cc-1760551361115.webp	3330	5049	webp	90	1649650	cmgsatqqv038oh9i62a6zac6z
cmgsatt990390h9i6w3lfm0jp	/public/images/thumbnails/116a5bbf-f005-485b-aaba-41581b8c027e-1760551364381.webp	150	150	webp	80	7530	cmgsatt96038vh9i6vpo6y534
cmgsatvyc0397h9i69t56aitt	/public/images/thumbnails/ad81f1b2-8c81-4b98-9cdc-620c1a26d101-1760551367634.webp	150	150	webp	80	9488	cmgsatvy90392h9i6fc2f83pv
cmgsatwvh039ch9i69vr4axdo	/public/images/thumbnails/afd4ac20-d063-4412-84e3-c33691a0c89e-1760551371126.webp	150	150	webp	80	6796	cmgsatwvf0399h9i6daxifeeq
cmgsaty3r039mh9i69f2i8k1q	/public/images/full/c1b4d5e9-85b4-419a-90f8-7b4351d745d1-1760551372315.webp	2215	3123	webp	90	591320	cmgsaty3o039gh9i6un9n8ir8
cmgsatzql039rh9i6hnm02otb	/public/images/thumbnails/95376fd4-5aaf-4ccc-aa70-f06e90d0302c-1760551373917.webp	150	150	webp	80	7692	cmgsatzqj039nh9i6buqs1ho6
cmgsabo6g022gh9i6rtgn98ka	/public/images/full/83a47ac3-62b1-4b29-a765-bb08529e2774-1760550520030.webp	2576	2027	webp	90	563094	cmgsabo6d022ah9i6wffm47dx
cmgsabp47022mh9i67s8qoyjs	/public/images/thumbnails/27179c86-c0e0-4555-b275-de905f25d1b2-1760550521247.webp	150	150	webp	80	7444	cmgsabp44022hh9i6ixk6dogg
cmgsabq15022uh9i6ti4k60b6	/public/images/medium/af944772-e29e-494d-8eab-c33d0053f095-1760550522455.webp	800	1107	webp	85	104322	cmgsabq13022oh9i6yu58f0t0
cmgsabqyw0230h9i6iwlqoum9	/public/images/medium/cb313bb2-0971-4f4a-9543-cc1692d28d25-1760550523646.webp	800	1086	webp	85	151288	cmgsabqyt022vh9i6ejtyrq0q
cmgsabru60236h9i61jsrqmiw	/public/images/thumbnails/dcf17860-3914-471b-a7de-35511de15ca1-1760550524859.webp	150	150	webp	80	6258	cmgsabru20232h9i6wq5ur1nd
cmgsabu5h023eh9i6scippwrm	/public/images/thumbnails/71f1fbf8-1035-4eb1-8cf0-51c82f5896aa-1760550525989.webp	150	150	webp	80	7604	cmgsabu5c0239h9i6k5wopiwf
cmgsabww7023lh9i6ot49axhn	/public/images/thumbnails/b0b3236a-e8c4-48e8-a557-62da2bf3c29b-1760550528987.webp	150	150	webp	80	9730	cmgsabww2023gh9i6f9wuem1e
cmgsabzqp023sh9i6mlg83zec	/public/images/full/3330473f-9d90-49ca-9b20-6120f763b193-1760550532537.webp	3416	5012	webp	90	2149362	cmgsabzqm023nh9i6sr97x435
cmgsac2hl0240h9i6rlne51s0	/public/images/thumbnails/43ad7425-f3d6-4dad-a268-04a02c114051-1760550536239.webp	150	150	webp	80	9730	cmgsac2hf023uh9i684wos3d6
cmgsac5fg0245h9i6mq69296l	/public/images/thumbnails/edbd37b7-d3d2-4026-b631-61655e058f91-1760550539789.webp	150	150	webp	80	9674	cmgsac5fc0241h9i6msplfpzu
cmgsac5g10247h9i67j7q6eox	/public/images/full/edbd37b7-d3d2-4026-b631-61655e058f91-1760550539789.webp	4950	3400	webp	90	2675762	cmgsac5fc0241h9i6msplfpzu
cmgsac6zt024eh9i65v0arpu5	/public/images/full/6e259151-5a55-4416-9d3f-9cff4145a5ce-1760550543625.webp	2498	4087	webp	90	708918	cmgsac6zq0248h9i6p5d580fo
cmgsac6zt024ch9i6omolqkja	/public/images/thumbnails/6e259151-5a55-4416-9d3f-9cff4145a5ce-1760550543625.webp	150	150	webp	80	6324	cmgsac6zq0248h9i6p5d580fo
cmgsac966024lh9i61fcuus85	/public/images/medium/205b5bab-02ab-410d-85fd-f3017cd9b4e2-1760550545634.webp	800	1164	webp	85	79348	cmgsac961024fh9i6obflp06c
cmgsac966024kh9i6asp06w1l	/public/images/thumbnails/205b5bab-02ab-410d-85fd-f3017cd9b4e2-1760550545634.webp	150	150	webp	80	4244	cmgsac961024fh9i6obflp06c
cmgsacaht024qh9i6x0cjfy3j	/public/images/full/906a6d5b-1697-4654-bfa0-f1c5c904fc63-1760550548452.webp	3154	2589	webp	90	812664	cmgsacahp024mh9i69ahvdwo9
cmgsacaht024rh9i6rct7tujg	/public/images/medium/906a6d5b-1697-4654-bfa0-f1c5c904fc63-1760550548452.webp	800	656	webp	85	141450	cmgsacahp024mh9i69ahvdwo9
cmgsaccz2024xh9i6njlbfo69	/public/images/full/a147e787-2dce-4440-ae91-64014d366984-1760550550169.webp	5091	3509	webp	90	1341864	cmgsaccz0024th9i6irqa3zpe
cmgsaccz2024zh9i6krws5683	/public/images/medium/a147e787-2dce-4440-ae91-64014d366984-1760550550169.webp	800	552	webp	85	71022	cmgsaccz0024th9i6irqa3zpe
cmgsacflh0254h9i6yjtqneuh	/public/images/thumbnails/44763d3b-7d83-4541-9220-bfc93aa43b0c-1760550553384.webp	150	150	webp	80	8548	cmgsacfle0250h9i6phnkoave
cmgsacflh0253h9i6q3htw0ns	/public/images/medium/44763d3b-7d83-4541-9220-bfc93aa43b0c-1760550553384.webp	800	543	webp	85	104878	cmgsacfle0250h9i6phnkoave
cmgsacvcd0259h9i67saepc55	/public/images/medium/efeeb7d5-04ec-4b10-a3a6-5118ef1af775-1760550556799.webp	800	614	webp	85	172702	cmgsacvc80257h9i695v0ykgs
cmgsacvcd025dh9i6hceom8il	/public/images/full/efeeb7d5-04ec-4b10-a3a6-5118ef1af775-1760550556799.webp	6754	5184	webp	90	4382516	cmgsacvc80257h9i695v0ykgs
cmgsadbee025ih9i6438gyp7r	/public/images/thumbnails/0887fc20-30eb-41a6-8e42-7f4034a462bc-1760550577204.webp	150	150	webp	80	9814	cmgsadbe8025eh9i6p0edmmcm
cmgsadbed025gh9i6papk85fs	/public/images/medium/0887fc20-30eb-41a6-8e42-7f4034a462bc-1760550577204.webp	800	585	webp	85	149084	cmgsadbe8025eh9i6p0edmmcm
cmgsadbez025kh9i6go5a0kzq	/public/images/full/0887fc20-30eb-41a6-8e42-7f4034a462bc-1760550577204.webp	6849	5007	webp	90	4748666	cmgsadbe8025eh9i6p0edmmcm
cmgsadqpq025nh9i68cnnl4qr	/public/images/thumbnails/c61d2d47-dc3f-4a9a-ba01-a830c66cd088-1760550598027.webp	150	150	webp	80	6580	cmgsadqpl025lh9i6rtqldxac
cmgsadqpr025ph9i6rjbh87ip	/public/images/medium/c61d2d47-dc3f-4a9a-ba01-a830c66cd088-1760550598027.webp	800	575	webp	85	93426	cmgsadqpl025lh9i6rtqldxac
cmgsadqpr025rh9i6ry6mx17m	/public/images/full/c61d2d47-dc3f-4a9a-ba01-a830c66cd088-1760550598027.webp	7079	5091	webp	90	3183502	cmgsadqpl025lh9i6rtqldxac
cmgsae6an025uh9i6go2bjwyb	/public/images/thumbnails/7165eee7-7ccf-44c3-b4bb-8e224a87d109-1760550617861.webp	150	150	webp	80	6800	cmgsae6ai025sh9i6v0qhmxvr
cmgsae6an025yh9i6wrc25v34	/public/images/medium/7165eee7-7ccf-44c3-b4bb-8e224a87d109-1760550617861.webp	800	1047	webp	85	167986	cmgsae6ai025sh9i6v0qhmxvr
cmgsae6an025xh9i6yowgpb0h	/public/images/full/7165eee7-7ccf-44c3-b4bb-8e224a87d109-1760550617861.webp	5247	6863	webp	90	3814386	cmgsae6ai025sh9i6v0qhmxvr
cmgsaepsr0261h9i627h3a5cw	/public/images/thumbnails/9f59f53c-60f6-4793-9bf7-bf3780bd108c-1760550638047.webp	150	150	webp	80	11538	cmgsaepso025zh9i6mvf5wbt4
cmgsaepss0263h9i6sa6thtei	/public/images/medium/9f59f53c-60f6-4793-9bf7-bf3780bd108c-1760550638047.webp	800	552	webp	85	124304	cmgsaepso025zh9i6mvf5wbt4
cmgsaepss0265h9i6uw5j9510	/public/images/full/9f59f53c-60f6-4793-9bf7-bf3780bd108c-1760550638047.webp	8169	5635	webp	90	4587172	cmgsaepso025zh9i6mvf5wbt4
cmgsaer6s0269h9i6zpi0maxv	/public/images/thumbnails/3c09d542-ec56-4b6f-b71b-06e3011488e2-1760550663314.webp	150	150	webp	80	6058	cmgsaer6q0266h9i65buhk3k7
cmgsaer6s026ch9i6akz25791	/public/images/medium/3c09d542-ec56-4b6f-b71b-06e3011488e2-1760550663314.webp	800	586	webp	85	75100	cmgsaer6q0266h9i65buhk3k7
cmgsaer6s026bh9i68mgpt2q8	/public/images/full/3c09d542-ec56-4b6f-b71b-06e3011488e2-1760550663314.webp	3576	2620	webp	90	587032	cmgsaer6q0266h9i65buhk3k7
cmgsaespw026ih9i6awnngdag	/public/images/full/1e797b49-84b4-4cf0-bcf4-531b3ddaa0ce-1760550665113.webp	2620	3576	webp	90	818674	cmgsaespt026dh9i6yq0t3omc
cmgsaespw026jh9i640kekaz8	/public/images/medium/1e797b49-84b4-4cf0-bcf4-531b3ddaa0ce-1760550665113.webp	800	1092	webp	85	161712	cmgsaespt026dh9i6yq0t3omc
cmgsaespw026hh9i6wx404m9d	/public/images/thumbnails/1e797b49-84b4-4cf0-bcf4-531b3ddaa0ce-1760550665113.webp	150	150	webp	80	10502	cmgsaespt026dh9i6yq0t3omc
cmgsafcbe026mh9i63yrvl7q0	/public/images/medium/3b5339dd-c081-42b7-8df9-89f300cfd98c-1760550667108.webp	800	590	webp	85	113246	cmgsafcbc026kh9i6bz3r00c8
cmgsafcbf026ph9i6xbh2nsn4	/public/images/thumbnails/3b5339dd-c081-42b7-8df9-89f300cfd98c-1760550667108.webp	150	150	webp	80	7134	cmgsafcbc026kh9i6bz3r00c8
cmgsaup8k03bwh9i649eeor7x	/public/images/medium/e9b3f370-0c08-4102-81ba-e2845a329c01-1760551405464.webp	800	556	webp	85	88684	cmgsaup8a03bsh9i6tsk4uetm
cmgsauruq03c4h9i6frdyg8xv	/public/images/thumbnails/74dc0b7d-16a0-4f84-94d8-67295bd163b8-1760551409089.webp	150	150	webp	80	7886	cmgsaurum03bzh9i691un8wcj
cmgsauult03cch9i609aksmtr	/public/images/full/e0bb6b44-6f03-480f-bd27-6b45ff4b3674-1760551412471.webp	5106	3400	webp	90	2218592	cmgsauulr03c6h9i67wq09w1m
cmgsauvmq03chh9i61ex11uui	/public/images/medium/3cb0dfac-5faa-489c-a807-2e54aff3bf40-1760551416038.webp	800	523	webp	85	52810	cmgsauvmo03cdh9i6qwws1r6q
cmgsauwrg03coh9i69gcatppr	/public/images/full/b02b06a0-8264-48f2-8093-caf869b7f4aa-1760551417364.webp	3295	2215	webp	90	401652	cmgsauwre03ckh9i67ox2qzmi
cmgsauz4503cxh9i6xri9ggbr	/public/images/medium/d6f40aaa-fff6-4bf8-804e-679e9d9bc58c-1760551418839.webp	800	1002	webp	85	106142	cmgsauz3z03crh9i6i8psjyt9
cmgsav1xq03d0h9i6r7nbpkrd	/public/images/thumbnails/59dfed65-2ad5-486b-b2bf-057f9f032852-1760551421882.webp	150	150	webp	80	7554	cmgsav1xm03cyh9i66hvauf9t
cmgsav4gv03dah9i6jjptwoit	/public/images/thumbnails/cedff5d0-18ea-4da4-a92a-7ab09663e1ce-1760551425546.webp	150	150	webp	80	6496	cmgsav4gr03d5h9i6huj0cn4f
cmgsav6hd03dgh9i6emnhquc4	/public/images/thumbnails/0fc23778-6611-47da-b685-760b98a871f0-1760551428816.webp	150	150	webp	80	7834	cmgsav6h703dch9i6prsb4865
cmgsav90o03doh9i6rbxe0zqs	/public/images/full/85a3a17f-73bc-403e-aa31-98205454e3d1-1760551431438.webp	4997	3307	webp	90	1889678	cmgsav90m03djh9i6lomt148d
cmgsavbmj03duh9i61ryrwqrk	/public/images/thumbnails/f6c5e26a-4f56-4051-886e-5f4f905af831-1760551434715.webp	150	150	webp	80	6482	cmgsavbmd03dqh9i6yi164qg3
cmgsave6n03e3h9i6xfarek1j	/public/images/medium/bb86969f-2318-493e-a446-7ad32b6c5a8c-1760551438102.webp	800	539	webp	85	60538	cmgsave6h03dxh9i6dna13frq
cmgsavgsc03e7h9i69pe1g4qb	/public/images/thumbnails/300518c6-e5ae-4b32-8733-3d26eec8f197-1760551441404.webp	150	150	webp	80	7108	cmgsavgsa03e4h9i6pwjnz9ek
cmgsavx2d03efh9i6zkqcs6kc	/public/images/full/ed448aef-f0f3-4427-9233-fc22d0ea2974-1760551444797.webp	5216	6754	webp	90	4008636	cmgsavx2903ebh9i6w2q8skej
cmgsavxzb03enh9i61mfo3wxq	/public/images/full/f5d20193-6a5a-4d23-a063-a7f4fa602d54-1760551465875.webp	1889	2542	webp	90	385816	cmgsavxz803eih9i6rc4c2dog
cmgsavzem03evh9i65w5wwlei	/public/images/full/0e0c9b61-6ed1-4be9-b284-2fc3b5020918-1760551467064.webp	2561	3681	webp	90	604576	cmgsavzej03eph9i6nmkjzcui
cmgsaw0yb03f0h9i6buggp7f7	/public/images/full/d479e772-deb6-4290-b800-a4bbfcc4df70-1760551468910.webp	2592	3634	webp	90	732748	cmgsaw0y703ewh9i6a7971j7s
cmgsawi4q03f9h9i6kw0vnte5	/public/images/full/caaa7cdf-af14-4916-8733-4f2625ec3215-1760551470938.webp	7079	5237	webp	90	4944330	cmgsawi4l03f3h9i6bl5mfrmi
cmgsawkgm03feh9i6m2jko4x4	/public/images/thumbnails/dcf76dfd-a654-4085-98f7-3045f1902d1a-1760551493187.webp	150	150	webp	80	7510	cmgsawkgi03fah9i63s494y0v
cmgsawln903fmh9i6a71a3wfn	/public/images/thumbnails/67c3f136-6e3b-4c48-83bb-b924410e42ff-1760551496199.webp	150	150	webp	80	8704	cmgsawln403fhh9i64olu1nd8
cmgsbjtqi053qh9i6dwhddvax	/public/images/full/05da1ad3-a287-447a-ab61-74c783c36faa-1760552579483.webp	1733	2589	webp	90	223680	cmgsbjtqb053kh9i64knt52r7
cmgsbjtqi053oh9i6jd96fc0i	/public/images/thumbnails/05da1ad3-a287-447a-ab61-74c783c36faa-1760552579483.webp	150	150	webp	80	5512	cmgsbjtqb053kh9i64knt52r7
cmgsbjvgy053vh9i65omz5ek8	/public/images/full/a0faaa7e-5562-4fa5-b3a9-84ad02782ab2-1760552581313.webp	2592	1903	webp	90	434880	cmgsbjvgn053rh9i68xkg6ghq
cmgsbjvh0053xh9i628np376q	/public/images/thumbnails/a0faaa7e-5562-4fa5-b3a9-84ad02782ab2-1760552581313.webp	150	150	webp	80	5504	cmgsbjvgn053rh9i68xkg6ghq
cmgsbjwmp0544h9i6i4j46354	/public/images/full/af7ed86a-94d2-4ddb-b2b1-843fb73f3f60-1760552583590.webp	1903	2639	webp	90	353316	cmgsbjwmm053yh9i6bp6utbj8
cmgsbjwmp0542h9i6ck11csl8	/public/images/thumbnails/af7ed86a-94d2-4ddb-b2b1-843fb73f3f60-1760552583590.webp	150	150	webp	80	4924	cmgsbjwmm053yh9i6bp6utbj8
cmgsbjxpv0547h9i6t5g31aim	/public/images/thumbnails/d5971b58-cd19-4047-a1a9-f03e6ef0fd45-1760552585058.webp	150	150	webp	80	7938	cmgsbjxpt0545h9i6t6iucnun
cmgsbjxpw054bh9i6pwe2rrbv	/public/images/full/d5971b58-cd19-4047-a1a9-f03e6ef0fd45-1760552585058.webp	1887	2561	webp	90	457884	cmgsbjxpt0545h9i6t6iucnun
cmgsbjyxr054ih9i62nsce3b3	/public/images/full/779afb93-116e-4329-8f54-0721eea900f1-1760552586469.webp	1762	2545	webp	90	354158	cmgsbjyxp054ch9i64hgpu5po
cmgsbjyxr054fh9i60ey56m5n	/public/images/thumbnails/779afb93-116e-4329-8f54-0721eea900f1-1760552586469.webp	150	150	webp	80	7478	cmgsbjyxp054ch9i64hgpu5po
cmgsbk013054ph9i69tiab0tp	/public/images/medium/7769c004-64f7-44c4-8536-ea8c42651a3d-1760552588050.webp	800	1110	webp	85	115722	cmgsbk011054jh9i6ymugp5rr
cmgsbk013054nh9i68a86xert	/public/images/full/7769c004-64f7-44c4-8536-ea8c42651a3d-1760552588050.webp	1856	2576	webp	90	344216	cmgsbk011054jh9i6ymugp5rr
cmgsbk0rh054uh9i6n2lhv8xj	/public/images/thumbnails/b147772f-d5ef-412b-aad3-8bbb535e5eff-1760552589457.webp	150	150	webp	80	6528	cmgsbk0re054qh9i6wnqyxuun
cmgsbk0rh054wh9i6l7i9okrf	/public/images/medium/b147772f-d5ef-412b-aad3-8bbb535e5eff-1760552589457.webp	800	589	webp	85	58508	cmgsbk0re054qh9i6wnqyxuun
cmgsbk1n90552h9i6iq9wdxmq	/public/images/medium/08980076-11a0-4f15-abd8-ebd806176045-1760552590407.webp	800	580	webp	85	52498	cmgsbk1n7054xh9i6pf1dioqe
cmgsbk1n90551h9i6x2qlbsjj	/public/images/thumbnails/08980076-11a0-4f15-abd8-ebd806176045-1760552590407.webp	150	150	webp	80	6100	cmgsbk1n7054xh9i6pf1dioqe
cmgsbk2b90556h9i6d32lhflg	/public/images/thumbnails/b5aa5a90-407b-4f9a-83a9-a6c2d938ca7b-1760552591553.webp	150	150	webp	80	5172	cmgsbk2b70554h9i67ork0qvk
cmgsbk2ba055ah9i613z3n8n2	/public/images/full/b5aa5a90-407b-4f9a-83a9-a6c2d938ca7b-1760552591553.webp	2717	1887	webp	90	369446	cmgsbk2b70554h9i67ork0qvk
cmgsbk2yv055fh9i61ouo7flc	/public/images/full/feaac4f7-7aae-4262-b149-3ab32f3be44b-1760552592420.webp	2592	1903	webp	90	365192	cmgsbk2yt055bh9i6rh158kdz
cmgsbk2yv055gh9i6kmzvhq1o	/public/images/thumbnails/feaac4f7-7aae-4262-b149-3ab32f3be44b-1760552592420.webp	150	150	webp	80	7516	cmgsbk2yt055bh9i6rh158kdz
cmgsbk3la055mh9i6kljdd1wk	/public/images/medium/ae70e335-a112-41ba-8ec7-f2f2525c60f2-1760552593270.webp	800	591	webp	85	68476	cmgsbk3l7055ih9i6hc6hqo7x
cmgsbk3la055oh9i6hj1bzms7	/public/images/full/ae70e335-a112-41ba-8ec7-f2f2525c60f2-1760552593270.webp	2514	1856	webp	90	351834	cmgsbk3l7055ih9i6hc6hqo7x
cmgsbk49k055th9i6o67qec1g	/public/images/medium/506404b2-bf02-4155-9a41-9c108988edd4-1760552594073.webp	800	1156	webp	85	108888	cmgsbk49h055ph9i6vwb6l71i
cmgsaup8k03byh9i6x1dxduhi	/public/images/full/e9b3f370-0c08-4102-81ba-e2845a329c01-1760551405464.webp	5075	3525	webp	90	1817318	cmgsaup8a03bsh9i6tsk4uetm
cmgsauruq03c5h9i6zuw39ymn	/public/images/medium/74dc0b7d-16a0-4f84-94d8-67295bd163b8-1760551409089.webp	800	531	webp	85	91008	cmgsaurum03bzh9i691un8wcj
cmgsauult03cbh9i6l3m1ue5k	/public/images/medium/e0bb6b44-6f03-480f-bd27-6b45ff4b3674-1760551412471.webp	800	533	webp	85	85526	cmgsauulr03c6h9i67wq09w1m
cmgsauvmq03cjh9i6ffkanlv3	/public/images/full/3cb0dfac-5faa-489c-a807-2e54aff3bf40-1760551416038.webp	3201	2090	webp	90	478590	cmgsauvmo03cdh9i6qwws1r6q
cmgsauwrg03cqh9i6s8kzbtwb	/public/images/thumbnails/b02b06a0-8264-48f2-8093-caf869b7f4aa-1760551417364.webp	150	150	webp	80	3626	cmgsauwre03ckh9i67ox2qzmi
cmgsauz4503cwh9i605gdas24	/public/images/thumbnails/d6f40aaa-fff6-4bf8-804e-679e9d9bc58c-1760551418839.webp	150	150	webp	80	5996	cmgsauz3z03crh9i6i8psjyt9
cmgsav1xr03d4h9i6tqdujk0j	/public/images/medium/59dfed65-2ad5-486b-b2bf-057f9f032852-1760551421882.webp	800	551	webp	85	99862	cmgsav1xm03cyh9i66hvauf9t
cmgsav4gv03dbh9i6r537rka4	/public/images/medium/cedff5d0-18ea-4da4-a92a-7ab09663e1ce-1760551425546.webp	800	543	webp	85	67106	cmgsav4gr03d5h9i6huj0cn4f
cmgsav6hd03dhh9i63o756ouq	/public/images/full/0fc23778-6611-47da-b685-760b98a871f0-1760551428816.webp	2776	4200	webp	90	1384968	cmgsav6h703dch9i6prsb4865
cmgsav90o03dph9i6x2ns8428	/public/images/thumbnails/85a3a17f-73bc-403e-aa31-98205454e3d1-1760551431438.webp	150	150	webp	80	8138	cmgsav90m03djh9i6lomt148d
cmgsavbmj03dwh9i6ci7t9ff5	/public/images/medium/f6c5e26a-4f56-4051-886e-5f4f905af831-1760551434715.webp	800	549	webp	85	66258	cmgsavbmd03dqh9i6yi164qg3
cmgsave6m03e1h9i6hmlvd93s	/public/images/full/bb86969f-2318-493e-a446-7ad32b6c5a8c-1760551438102.webp	4903	3307	webp	90	1692324	cmgsave6h03dxh9i6dna13frq
cmgsavgsc03e9h9i6g02z1sgy	/public/images/medium/300518c6-e5ae-4b32-8733-3d26eec8f197-1760551441404.webp	800	561	webp	85	80640	cmgsavgsa03e4h9i6pwjnz9ek
cmgsbjtqi053ph9i61b1pxq74	/public/images/medium/05da1ad3-a287-447a-ab61-74c783c36faa-1760552579483.webp	800	1195	webp	85	68894	cmgsbjtqb053kh9i64knt52r7
cmgsbjvgy053th9i6xkon76yt	/public/images/medium/a0faaa7e-5562-4fa5-b3a9-84ad02782ab2-1760552581313.webp	800	587	webp	85	71242	cmgsbjvgn053rh9i68xkg6ghq
cmgsbjwmp0543h9i63af04z6r	/public/images/medium/af7ed86a-94d2-4ddb-b2b1-843fb73f3f60-1760552583590.webp	800	1109	webp	85	100896	cmgsbjwmm053yh9i6bp6utbj8
cmgsbjxpv0549h9i6de7hhjgz	/public/images/medium/d5971b58-cd19-4047-a1a9-f03e6ef0fd45-1760552585058.webp	800	1086	webp	85	142468	cmgsbjxpt0545h9i6t6iucnun
cmgsbjyxr054gh9i6wm5xg3yt	/public/images/medium/779afb93-116e-4329-8f54-0721eea900f1-1760552586469.webp	800	1156	webp	85	122962	cmgsbjyxp054ch9i64hgpu5po
cmgsbk013054oh9i6rb2zk03p	/public/images/thumbnails/7769c004-64f7-44c4-8536-ea8c42651a3d-1760552588050.webp	150	150	webp	80	6882	cmgsbk011054jh9i6ymugp5rr
cmgsbk0rh054vh9i6glytwbnb	/public/images/full/b147772f-d5ef-412b-aad3-8bbb535e5eff-1760552589457.webp	2436	1794	webp	90	289142	cmgsbk0re054qh9i6wnqyxuun
cmgsbk1n90553h9i6lme91dxw	/public/images/full/08980076-11a0-4f15-abd8-ebd806176045-1760552590407.webp	2514	1825	webp	90	274990	cmgsbk1n7054xh9i6pf1dioqe
cmgsbk2ba0558h9i6vbx4800e	/public/images/medium/b5aa5a90-407b-4f9a-83a9-a6c2d938ca7b-1760552591553.webp	800	556	webp	85	51942	cmgsbk2b70554h9i67ork0qvk
cmgsbk2yv055hh9i6ldk6yik1	/public/images/medium/feaac4f7-7aae-4262-b149-3ab32f3be44b-1760552592420.webp	800	587	webp	85	69266	cmgsbk2yt055bh9i6rh158kdz
cmgsbk3la055nh9i6hhffy7b2	/public/images/thumbnails/ae70e335-a112-41ba-8ec7-f2f2525c60f2-1760552593270.webp	150	150	webp	80	6198	cmgsbk3l7055ih9i6hc6hqo7x
cmgsbk49k055vh9i6b5tbkfie	/public/images/full/506404b2-bf02-4155-9a41-9c108988edd4-1760552594073.webp	1762	2545	webp	90	333322	cmgsbk49h055ph9i6vwb6l71i
cmgsbk51d0561h9i68a5ejr0z	/public/images/full/12f3e97d-69ed-498d-b9b8-2aabae8f05f8-1760552594953.webp	1762	2608	webp	90	398192	cmgsbk51a055wh9i6sxsvjd2q
cmgsbk5ox0569h9i6se970jul	/public/images/thumbnails/6df8a89d-45bd-4d03-b51e-49444311b22f-1760552595954.webp	150	150	webp	80	4614	cmgsbk5ov0563h9i6t9w1newi
cmgsbk720056gh9i6h17ezbcl	/public/images/medium/9d0edb20-0f95-4cc3-9ea3-7ce296d6dc44-1760552596803.webp	800	535	webp	85	123258	cmgsbk71y056ah9i6r1aoj787
cmgsbk94f056kh9i62x6tewoa	/public/images/medium/fd9bbe5d-c90f-4ad2-8f20-ed4c6da3ad20-1760552598572.webp	800	543	webp	85	81728	cmgsbk94d056hh9i6zw2m1o24
cmgsbkbe3056qh9i6647lftqr	/public/images/thumbnails/8d250367-43d9-4db1-a8b3-8e86cdaac4f6-1760552601257.webp	150	150	webp	80	5430	cmgsbkbe1056oh9i6ktbndgq6
cmgsbkdhx0571h9i6quy057z6	/public/images/full/fc259ed6-6a75-43ad-b49d-47b4430a4b4e-1760552604190.webp	3369	4966	webp	90	2021624	cmgsbkdhv056vh9i6uixqyi47
cmgsbkfq50578h9i62vubebb5	/public/images/medium/5e22b9c2-3438-49a4-b568-f873297ea9e1-1760552606923.webp	800	1190	webp	85	161714	cmgsbkfq30572h9i6nhzgcu6y
cmgsbki36057dh9i6sl1px93a	/public/images/thumbnails/bc3be51c-2f02-4967-9c3f-fc5d09c08afe-1760552609806.webp	150	150	webp	80	7936	cmgsbki340579h9i6hww1ugma
cmgsbkjyu057mh9i6q7q463wk	/public/images/full/7e999edf-b37f-4e46-8f56-45bebaf828c0-1760552612866.webp	3307	4919	webp	90	1652574	cmgsbkjys057gh9i6q11s656m
cmgsbklym057sh9i6cqr1i8bw	/public/images/thumbnails/21cae695-e79b-494a-807d-8fe49ae0d333-1760552615307.webp	150	150	webp	80	6194	cmgsbklyk057nh9i6ro3iloaq
cmgsbko4c0580h9i60x85p2fj	/public/images/full/c28dddf3-426a-43c3-b0e1-5ecb0f2a5a86-1760552617887.webp	3416	5012	webp	90	2263850	cmgsbko49057uh9i6k21ji8h0
cmgsbkqbv0587h9i6iorlod6z	/public/images/medium/8aee3593-837c-413d-bb44-4ca7fe9fc225-1760552620690.webp	800	1165	webp	85	229794	cmgsbkqbt0581h9i69kemod14
cmgsbl19f058ah9i6dxriv8tk	/public/images/thumbnails/bd40b1be-6a70-4c5c-a39d-ac440025449e-1760552623559.webp	150	150	webp	80	6752	cmgsbl19d0588h9i6zy3610cy
cmgsbl3ie058kh9i6e4rdhg8a	/public/images/full/6935bdb9-df1d-4368-98e1-9c1de1a8f39b-1760552637726.webp	5044	3603	webp	90	2840508	cmgsbl3ic058fh9i68a881haw
cmgsblequ058sh9i6pfkigyyo	/public/images/thumbnails/9bc69745-c752-44f6-ab5f-29a487834739-1760552640645.webp	150	150	webp	80	7518	cmgsbleqr058mh9i6p10m9ay8
cmgsblgpl058xh9i64kvcgdr4	/public/images/medium/4ec5a6b3-2553-4030-bf1b-a5690b1e84b0-1760552655197.webp	800	536	webp	85	99314	cmgsblgpj058th9i6xa52m107
cmgsblhia0595h9i6c5ourtz1	/public/images/thumbnails/d0b873ff-f8ad-4e5a-ae8c-4551bac7c6d0-1760552657738.webp	150	150	webp	80	4444	cmgsblhi80590h9i6qkxzzgg1
cmgsbljfn059ch9i6nov1r8vh	/public/images/thumbnails/09aade64-3ece-424a-b500-de8bc2d72d74-1760552658773.webp	150	150	webp	80	10848	cmgsbljfk0597h9i661d6ejop
cmgsauruq03c3h9i6w26rev4g	/public/images/full/74dc0b7d-16a0-4f84-94d8-67295bd163b8-1760551409089.webp	5075	3369	webp	90	1593458	cmgsaurum03bzh9i691un8wcj
cmgsauult03cah9i6ye000pdy	/public/images/thumbnails/e0bb6b44-6f03-480f-bd27-6b45ff4b3674-1760551412471.webp	150	150	webp	80	7566	cmgsauulr03c6h9i67wq09w1m
cmgsauvmq03cgh9i687zhllyl	/public/images/thumbnails/3cb0dfac-5faa-489c-a807-2e54aff3bf40-1760551416038.webp	150	150	webp	80	4984	cmgsauvmo03cdh9i6qwws1r6q
cmgsauwrg03cph9i6bqonybpk	/public/images/medium/b02b06a0-8264-48f2-8093-caf869b7f4aa-1760551417364.webp	800	538	webp	85	36634	cmgsauwre03ckh9i67ox2qzmi
cmgsauz4503cvh9i6x9nue6vh	/public/images/full/d6f40aaa-fff6-4bf8-804e-679e9d9bc58c-1760551418839.webp	3560	4461	webp	90	1257876	cmgsauz3z03crh9i6i8psjyt9
cmgsav1xq03d2h9i6oeto95n5	/public/images/full/59dfed65-2ad5-486b-b2bf-057f9f032852-1760551421882.webp	5075	3494	webp	90	2230496	cmgsav1xm03cyh9i66hvauf9t
cmgsav4gv03d9h9i60zh8d7ao	/public/images/full/cedff5d0-18ea-4da4-a92a-7ab09663e1ce-1760551425546.webp	5122	3478	webp	90	1447872	cmgsav4gr03d5h9i6huj0cn4f
cmgsav6hd03dih9i6hova8j5l	/public/images/medium/0fc23778-6611-47da-b685-760b98a871f0-1760551428816.webp	800	1210	webp	85	215754	cmgsav6h703dch9i6prsb4865
cmgsav90o03dnh9i6wqw6rmoo	/public/images/medium/85a3a17f-73bc-403e-aa31-98205454e3d1-1760551431438.webp	800	529	webp	85	78404	cmgsav90m03djh9i6lomt148d
cmgsavbmj03dvh9i6rxn5g2xp	/public/images/full/f6c5e26a-4f56-4051-886e-5f4f905af831-1760551434715.webp	4981	3416	webp	90	1797470	cmgsavbmd03dqh9i6yi164qg3
cmgsave6l03dzh9i6n1iba2bx	/public/images/thumbnails/bb86969f-2318-493e-a446-7ad32b6c5a8c-1760551438102.webp	150	150	webp	80	6030	cmgsave6h03dxh9i6dna13frq
cmgsavgsc03eah9i6js96rj4j	/public/images/full/300518c6-e5ae-4b32-8733-3d26eec8f197-1760551441404.webp	4872	3416	webp	90	2002266	cmgsavgsa03e4h9i6pwjnz9ek
cmgsavx2d03ehh9i6g1e3ajyz	/public/images/medium/ed448aef-f0f3-4427-9233-fc22d0ea2974-1760551444797.webp	800	1036	webp	85	180210	cmgsavx2903ebh9i6w2q8skej
cmgsavx2d03edh9i6gp0grm61	/public/images/thumbnails/ed448aef-f0f3-4427-9233-fc22d0ea2974-1760551444797.webp	150	150	webp	80	6742	cmgsavx2903ebh9i6w2q8skej
cmgsavxzb03eoh9i67twck8jg	/public/images/medium/f5d20193-6a5a-4d23-a063-a7f4fa602d54-1760551465875.webp	800	1077	webp	85	122322	cmgsavxz803eih9i6rc4c2dog
cmgsavxzb03emh9i6paq25p17	/public/images/thumbnails/f5d20193-6a5a-4d23-a063-a7f4fa602d54-1760551465875.webp	150	150	webp	80	8336	cmgsavxz803eih9i6rc4c2dog
cmgsavzem03euh9i6omyi01vh	/public/images/medium/0e0c9b61-6ed1-4be9-b284-2fc3b5020918-1760551467064.webp	800	1150	webp	85	122334	cmgsavzej03eph9i6nmkjzcui
cmgsavzem03eth9i6rm33k3ol	/public/images/thumbnails/0e0c9b61-6ed1-4be9-b284-2fc3b5020918-1760551467064.webp	150	150	webp	80	8052	cmgsavzej03eph9i6nmkjzcui
cmgsaw0yc03f2h9i6r4n3gino	/public/images/medium/d479e772-deb6-4290-b800-a4bbfcc4df70-1760551468910.webp	800	1122	webp	85	144940	cmgsaw0y703ewh9i6a7971j7s
cmgsaw0yb03f1h9i6ik60pm8u	/public/images/thumbnails/d479e772-deb6-4290-b800-a4bbfcc4df70-1760551468910.webp	150	150	webp	80	9084	cmgsaw0y703ewh9i6a7971j7s
cmgsawi4p03f5h9i6usxgep4f	/public/images/medium/caaa7cdf-af14-4916-8733-4f2625ec3215-1760551470938.webp	800	592	webp	85	122458	cmgsawi4l03f3h9i6bl5mfrmi
cmgsawi4q03f7h9i6v3sbd3an	/public/images/thumbnails/caaa7cdf-af14-4916-8733-4f2625ec3215-1760551470938.webp	150	150	webp	80	7134	cmgsawi4l03f3h9i6bl5mfrmi
cmgsawkgm03fgh9i6t66vyjza	/public/images/full/dcf76dfd-a654-4085-98f7-3045f1902d1a-1760551493187.webp	3385	5028	webp	90	827206	cmgsawkgi03fah9i63s494y0v
cmgsawkgm03ffh9i6yd5511he	/public/images/medium/dcf76dfd-a654-4085-98f7-3045f1902d1a-1760551493187.webp	800	1189	webp	85	90936	cmgsawkgi03fah9i63s494y0v
cmgsawln903fnh9i68t1jih5l	/public/images/medium/67c3f136-6e3b-4c48-83bb-b924410e42ff-1760551496199.webp	800	1063	webp	85	195750	cmgsawln403fhh9i64olu1nd8
cmgsawln903flh9i6uihwcnlf	/public/images/full/67c3f136-6e3b-4c48-83bb-b924410e42ff-1760551496199.webp	2077	2761	webp	90	723996	cmgsawln403fhh9i64olu1nd8
cmgsawn6x03fqh9i6r89gk09r	/public/images/medium/d8358b53-e971-4a3b-b777-f2c8cd2dd6d7-1760551497748.webp	800	570	webp	85	127590	cmgsawn6s03foh9i60jjd04vo
cmgsawn7t03fsh9i6anrovxfw	/public/images/full/d8358b53-e971-4a3b-b777-f2c8cd2dd6d7-1760551497748.webp	3619	2576	webp	90	862816	cmgsawn6s03foh9i60jjd04vo
cmgsawn7y03fuh9i687x3w2r7	/public/images/thumbnails/d8358b53-e971-4a3b-b777-f2c8cd2dd6d7-1760551497748.webp	150	150	webp	80	10460	cmgsawn6s03foh9i60jjd04vo
cmgsawotf03g1h9i6sms819x4	/public/images/full/9ff77b8e-9164-4705-ae2d-b8d8f7775b0d-1760551499772.webp	3794	2558	webp	90	923484	cmgsawotd03fvh9i6zzosl6oa
cmgsawotf03g0h9i65nm413om	/public/images/medium/9ff77b8e-9164-4705-ae2d-b8d8f7775b0d-1760551499772.webp	800	539	webp	85	86098	cmgsawotd03fvh9i6zzosl6oa
cmgsawotf03fzh9i645rgj5sr	/public/images/thumbnails/9ff77b8e-9164-4705-ae2d-b8d8f7775b0d-1760551499772.webp	150	150	webp	80	8634	cmgsawotd03fvh9i6zzosl6oa
cmgsawqb303g8h9i65besleva	/public/images/full/c4e91db1-e52d-4e60-b837-22c3201c3b2d-1760551501848.webp	2576	3477	webp	90	820874	cmgsawqay03g2h9i67bf54sej
cmgsawqb303g7h9i6uwd0c6w4	/public/images/thumbnails/c4e91db1-e52d-4e60-b837-22c3201c3b2d-1760551501848.webp	150	150	webp	80	6824	cmgsawqay03g2h9i67bf54sej
cmgsawqb303g6h9i6a49mcelw	/public/images/medium/c4e91db1-e52d-4e60-b837-22c3201c3b2d-1760551501848.webp	800	1080	webp	85	142234	cmgsawqay03g2h9i67bf54sej
cmgsawrf003geh9i6zd94r8ju	/public/images/full/4d272320-2508-4f43-8b9a-ea7ab7a6fe3d-1760551503779.webp	2136	2933	webp	90	442226	cmgsawrex03g9h9i6n7qh79ry
cmgsawrez03gch9i6w3k91knc	/public/images/thumbnails/4d272320-2508-4f43-8b9a-ea7ab7a6fe3d-1760551503779.webp	150	150	webp	80	6318	cmgsawrex03g9h9i6n7qh79ry
cmgsawrf003gfh9i6i1rrqs6b	/public/images/medium/4d272320-2508-4f43-8b9a-ea7ab7a6fe3d-1760551503779.webp	800	1099	webp	85	107792	cmgsawrex03g9h9i6n7qh79ry
cmgsawso903gkh9i6fpx1lj7e	/public/images/full/9dca4296-8cd0-4ae1-a36f-ae362c00d368-1760551505216.webp	3217	2417	webp	90	636554	cmgsawso403ggh9i6ainrra8i
cmgsawso903glh9i6ja0x5mlx	/public/images/medium/9dca4296-8cd0-4ae1-a36f-ae362c00d368-1760551505216.webp	800	601	webp	85	98542	cmgsawso403ggh9i6ainrra8i
cmgsawso903gmh9i699equmrd	/public/images/thumbnails/9dca4296-8cd0-4ae1-a36f-ae362c00d368-1760551505216.webp	150	150	webp	80	9586	cmgsawso403ggh9i6ainrra8i
cmgsawvrm03gqh9i68pxsmss2	/public/images/thumbnails/86ca1a4d-bf63-4105-a817-b748ac5aeeee-1760551506849.webp	150	150	webp	80	6760	cmgsawvrj03gnh9i6pzurkart
cmgsawvrm03grh9i6hsz90z75	/public/images/medium/86ca1a4d-bf63-4105-a817-b748ac5aeeee-1760551506849.webp	800	533	webp	85	105052	cmgsawvrj03gnh9i6pzurkart
cmgsawvrn03gth9i6snodbvce	/public/images/full/86ca1a4d-bf63-4105-a817-b748ac5aeeee-1760551506849.webp	5169	3447	webp	90	2972142	cmgsawvrj03gnh9i6pzurkart
cmgsawxd103h0h9i6qgg45emk	/public/images/thumbnails/b0997a7a-5f88-4df6-a4b3-3fac63417043-1760551510850.webp	150	150	webp	80	7162	cmgsawxcw03guh9i6orf70hek
cmgsawz5n03h5h9i6fyqdsnd9	/public/images/full/a8735dec-25f8-415e-bfa0-32abc20872d1-1760551512919.webp	2743	3771	webp	90	1175332	cmgsawz5h03h1h9i6654252rh
cmgsax0dn03heh9i6h2rn8eas	/public/images/full/9cef2c38-7f40-4537-ade6-078ae67bca44-1760551515239.webp	2139	2729	webp	90	604728	cmgsax0dl03h8h9i6h33jwbes
cmgsax3be03hlh9i6ooo0yyjq	/public/images/thumbnails/35616797-5e2d-4fee-b1e9-034942d59d00-1760551516836.webp	150	150	webp	80	8780	cmgsax3ba03hfh9i6xnhnpom6
cmgsax48003hsh9i6jt9x2skw	/public/images/full/123b8c8c-c69f-45a4-ae39-dd1042841b78-1760551520634.webp	2636	1811	webp	90	580952	cmgsax47v03hmh9i6tpkdbovv
cmgsax56g03hzh9i6x53ek1ye	/public/images/full/74e9b41b-26a8-4c82-87bb-7b355d597797-1760551521806.webp	1874	2605	webp	90	473102	cmgsax56d03hth9i6z1y6w81l
cmgsax6ps03i5h9i60fj5t8wl	/public/images/full/bd40d4ea-565d-48ee-ac99-9046ebd0f867-1760551523048.webp	3644	2681	webp	90	902414	cmgsax6pn03i0h9i6ldqyl8c3
cmgsax87003idh9i6h1ejc0bh	/public/images/full/48812d0b-83e1-4220-bd47-6e494422be06-1760551525037.webp	3812	2681	webp	90	556470	cmgsax86s03i7h9i67hnkke9d
cmgsax95n03ihh9i63v2if8fi	/public/images/thumbnails/968a9875-805c-4ba3-a558-2907d7b9e6d5-1760551526960.webp	150	150	webp	80	6168	cmgsax95k03ieh9i6n27n7nwa
cmgsaxafe03iph9i6uq6m44ha	/public/images/full/01e605ab-dc0e-47b2-8a65-c4064e468db9-1760551528205.webp	2326	2995	webp	90	596572	cmgsaxafa03ilh9i6khle3fgi
cmgsaxbft03ivh9i6z7kirzmm	/public/images/medium/d5cf0a2a-1315-4003-b4a5-d6a7eecf2b1b-1760551529859.webp	800	804	webp	85	77714	cmgsaxbfr03ish9i6p26bnvvi
cmgsaxchm03j3h9i6vaispyjg	/public/images/medium/1582964d-f60e-40ad-82c8-5a879b9c3a68-1760551531160.webp	800	587	webp	85	92356	cmgsaxchi03izh9i6dd2j5eir
cmgsaxe5103jah9i63pv1tjzm	/public/images/thumbnails/17ddc3b3-6ae0-4e24-b6ac-9a22e3ad47af-1760551532525.webp	150	150	webp	80	8660	cmgsaxe4z03j6h9i69wef6w7f
cmgsaxftv03jhh9i6fq4szmmj	/public/images/thumbnails/89968773-e572-415b-acad-2ce6af9dba63-1760551534666.webp	150	150	webp	80	8482	cmgsaxftq03jdh9i675ug5p46
cmgsaxgpi03jnh9i6dah4x19n	/public/images/full/3d24839a-8363-40d2-b431-3c7361ac5e4f-1760551536857.webp	2717	1856	webp	90	402292	cmgsaxgpe03jkh9i606y1pej0
cmgsaxi7b03jwh9i66a9xs92h	/public/images/thumbnails/cec26e0c-ba95-4576-952f-2863ef3ebd8d-1760551537986.webp	150	150	webp	80	8456	cmgsaxi7803jrh9i66exizyi4
cmgsaxj4u03k3h9i6d98o1jbg	/public/images/medium/3c4d5bed-87d1-47f5-8241-115e066b19e8-1760551539923.webp	800	1185	webp	85	117178	cmgsaxj4p03jyh9i6e0sjbze1
cmgsaxlvh03kbh9i66mtcn8c6	/public/images/thumbnails/11159d71-1bbb-42e6-a8d8-5cda3c6d79bb-1760551541151.webp	150	150	webp	80	7720	cmgsaxlve03k5h9i6vc97ytyg
cmgsaxoja03keh9i6crrgo9pm	/public/images/medium/e295fd8d-34e6-4c6b-8e59-08682aae64fd-1760551544696.webp	800	1215	webp	85	226412	cmgsaxoj603kch9i6w7r5so66
cmgsaxq5n03knh9i6epq0uxjl	/public/images/full/8b23abc2-89c1-488c-a9a5-e535dd655227-1760551548135.webp	2686	3525	webp	90	911392	cmgsaxq5i03kjh9i67ko7xu91
cmgsaxs4x03kwh9i67k0mm3li	/public/images/full/b3cb6feb-9ec5-48b2-910e-c7654120eda8-1760551550239.webp	2576	4212	webp	90	1335874	cmgsaxs4u03kqh9i69olenjov
cmgsaxt4k03l2h9i6waqi8knv	/public/images/thumbnails/93d0e987-0db1-4903-ac30-089e9a096338-1760551552798.webp	150	150	webp	80	5108	cmgsaxt4g03kxh9i6y74n78q6
cmgsaxvtu03lah9i6ktwo8cf3	/public/images/thumbnails/a0863bc8-ad7a-4e86-87a6-c984f358c420-1760551554096.webp	150	150	webp	80	9484	cmgsaxvtp03l4h9i6bbvadevz
cmgsaxxaz03lgh9i6wed8qggq	/public/images/full/eeb72861-3add-40f9-9e28-9d6c143072e3-1760551557596.webp	2483	3229	webp	90	990212	cmgsaxxav03lbh9i63tru1ojg
cmgsbk49k055uh9i6u785iqzn	/public/images/thumbnails/506404b2-bf02-4155-9a41-9c108988edd4-1760552594073.webp	150	150	webp	80	7114	cmgsbk49h055ph9i6vwb6l71i
cmgsbk51d055zh9i6ykj73us0	/public/images/medium/12f3e97d-69ed-498d-b9b8-2aabae8f05f8-1760552594953.webp	800	1184	webp	85	143858	cmgsbk51a055wh9i6sxsvjd2q
cmgsbk5ox0567h9i63nk71ocl	/public/images/medium/6df8a89d-45bd-4d03-b51e-49444311b22f-1760552595954.webp	800	571	webp	85	61776	cmgsbk5ov0563h9i6t9w1newi
cmgsbk720056eh9i67m1spo3b	/public/images/full/9d0edb20-0f95-4cc3-9ea3-7ce296d6dc44-1760552596803.webp	3779	2527	webp	90	1217450	cmgsbk71y056ah9i6r1aoj787
cmgsbk94f056nh9i6g1rd9gyd	/public/images/full/fd9bbe5d-c90f-4ad2-8f20-ed4c6da3ad20-1760552598572.webp	4966	3369	webp	90	2010590	cmgsbk94d056hh9i6zw2m1o24
cmgsbkbe3056th9i6gpdzcirz	/public/images/full/8d250367-43d9-4db1-a8b3-8e86cdaac4f6-1760552601257.webp	3494	5044	webp	90	2387690	cmgsbkbe1056oh9i6ktbndgq6
cmgsbkdhx056zh9i6ndor8xsg	/public/images/thumbnails/fc259ed6-6a75-43ad-b49d-47b4430a4b4e-1760552604190.webp	150	150	webp	80	7238	cmgsbkdhv056vh9i6uixqyi47
cmgsbkfq50577h9i6hoh6envr	/public/images/full/5e22b9c2-3438-49a4-b568-f873297ea9e1-1760552606923.webp	3307	4919	webp	90	1366440	cmgsbkfq30572h9i6nhzgcu6y
cmgsbki36057fh9i6kn6uwrtm	/public/images/full/bc3be51c-2f02-4967-9c3f-fc5d09c08afe-1760552609806.webp	3435	5007	webp	90	3498290	cmgsbki340579h9i6hww1ugma
cmgsbkjyu057jh9i6gws5cedb	/public/images/thumbnails/7e999edf-b37f-4e46-8f56-45bebaf828c0-1760552612866.webp	150	150	webp	80	6346	cmgsbkjys057gh9i6q11s656m
cmgsbklym057th9i6q6kk2d25	/public/images/medium/21cae695-e79b-494a-807d-8fe49ae0d333-1760552615307.webp	800	550	webp	85	90974	cmgsbklyk057nh9i6ro3iloaq
cmgsbko4b057wh9i6eesrqoln	/public/images/thumbnails/c28dddf3-426a-43c3-b0e1-5ecb0f2a5a86-1760552617887.webp	150	150	webp	80	9454	cmgsbko49057uh9i6k21ji8h0
cmgsbkqbv0585h9i6nex965w5	/public/images/full/8aee3593-837c-413d-bb44-4ca7fe9fc225-1760552620690.webp	3400	4950	webp	90	2167420	cmgsbkqbt0581h9i69kemod14
cmgsbl19f058ch9i6we7fj01p	/public/images/medium/bd40b1be-6a70-4c5c-a39d-ac440025449e-1760552623559.webp	800	599	webp	85	74328	cmgsbl19d0588h9i6zy3610cy
cmgsbl3ie058lh9i69rhqk0lf	/public/images/medium/6935bdb9-df1d-4368-98e1-9c1de1a8f39b-1760552637726.webp	800	571	webp	85	104866	cmgsbl3ic058fh9i68a881haw
cmgsblequ058rh9i61ygc3yth	/public/images/full/9bc69745-c752-44f6-ab5f-29a487834739-1760552640645.webp	6676	4966	webp	90	3874514	cmgsbleqr058mh9i6p10m9ay8
cmgsblgpl058wh9i6mv0d6vgq	/public/images/thumbnails/4ec5a6b3-2553-4030-bf1b-a5690b1e84b0-1760552655197.webp	150	150	webp	80	9688	cmgsblgpj058th9i6xa52m107
cmgsblhia0596h9i6m6qts8ow	/public/images/full/d0b873ff-f8ad-4e5a-ae8c-4551bac7c6d0-1760552657738.webp	1920	2683	webp	90	573290	cmgsblhi80590h9i6qkxzzgg1
cmgsawxd103gyh9i6o1008c2b	/public/images/full/b0997a7a-5f88-4df6-a4b3-3fac63417043-1760551510850.webp	2623	4009	webp	90	661634	cmgsawxcw03guh9i6orf70hek
cmgsawz5n03h7h9i6yvnnothl	/public/images/medium/a8735dec-25f8-415e-bfa0-32abc20872d1-1760551512919.webp	800	1100	webp	85	149820	cmgsawz5h03h1h9i6654252rh
cmgsax0dn03hah9i6s2bx63xe	/public/images/thumbnails/9cef2c38-7f40-4537-ade6-078ae67bca44-1760551515239.webp	150	150	webp	80	9308	cmgsax0dl03h8h9i6h33jwbes
cmgsax3be03hjh9i6lfdcw3pp	/public/images/full/35616797-5e2d-4fee-b1e9-034942d59d00-1760551516836.webp	3447	5028	webp	90	2122912	cmgsax3ba03hfh9i6xnhnpom6
cmgsax48003hqh9i6yf7dgl7o	/public/images/thumbnails/123b8c8c-c69f-45a4-ae39-dd1042841b78-1760551520634.webp	150	150	webp	80	4394	cmgsax47v03hmh9i6tpkdbovv
cmgsax56g03hxh9i6r5xwm9fb	/public/images/medium/74e9b41b-26a8-4c82-87bb-7b355d597797-1760551521806.webp	800	1112	webp	85	143604	cmgsax56d03hth9i6z1y6w81l
cmgsax6ps03i4h9i6o2wvf533	/public/images/medium/bd40d4ea-565d-48ee-ac99-9046ebd0f867-1760551523048.webp	800	588	webp	85	112796	cmgsax6pn03i0h9i6ldqyl8c3
cmgsax86x03ibh9i62qnapyvr	/public/images/thumbnails/48812d0b-83e1-4220-bd47-6e494422be06-1760551525037.webp	150	150	webp	80	5296	cmgsax86s03i7h9i67hnkke9d
cmgsax95n03ijh9i6he3d5bt9	/public/images/medium/968a9875-805c-4ba3-a558-2907d7b9e6d5-1760551526960.webp	800	832	webp	85	79568	cmgsax95k03ieh9i6n27n7nwa
cmgsaxafe03iqh9i64cdtmwk3	/public/images/thumbnails/01e605ab-dc0e-47b2-8a65-c4064e468db9-1760551528205.webp	150	150	webp	80	8756	cmgsaxafa03ilh9i6khle3fgi
cmgsaxbfu03iyh9i6m3farzbp	/public/images/thumbnails/d5cf0a2a-1315-4003-b4a5-d6a7eecf2b1b-1760551529859.webp	150	150	webp	80	6944	cmgsaxbfr03ish9i6p26bnvvi
cmgsaxchm03j5h9i6x0jfmvpk	/public/images/thumbnails/1582964d-f60e-40ad-82c8-5a879b9c3a68-1760551531160.webp	150	150	webp	80	7898	cmgsaxchi03izh9i6dd2j5eir
cmgsaxe5103jch9i6j418glk3	/public/images/medium/17ddc3b3-6ae0-4e24-b6ac-9a22e3ad47af-1760551532525.webp	800	612	webp	85	127210	cmgsaxe4z03j6h9i69wef6w7f
cmgsaxftv03jjh9i6sfkfm6eu	/public/images/full/89968773-e572-415b-acad-2ce6af9dba63-1760551534666.webp	4154	2464	webp	90	1163908	cmgsaxftq03jdh9i675ug5p46
cmgsaxgpi03jqh9i6m97myeay	/public/images/thumbnails/3d24839a-8363-40d2-b431-3c7361ac5e4f-1760551536857.webp	150	150	webp	80	7462	cmgsaxgpe03jkh9i606y1pej0
cmgsaxi7b03jvh9i6chqyj6uy	/public/images/medium/cec26e0c-ba95-4576-952f-2863ef3ebd8d-1760551537986.webp	800	493	webp	85	97664	cmgsaxi7803jrh9i66exizyi4
cmgsaxj4u03k2h9i6f936i6gk	/public/images/full/3c4d5bed-87d1-47f5-8241-115e066b19e8-1760551539923.webp	1780	2636	webp	90	376900	cmgsaxj4p03jyh9i6e0sjbze1
cmgsaxlvh03k8h9i62jouivk5	/public/images/full/11159d71-1bbb-42e6-a8d8-5cda3c6d79bb-1760551541151.webp	4981	3385	webp	90	2234502	cmgsaxlve03k5h9i6vc97ytyg
cmgsaxojb03kih9i6h6maqfss	/public/images/full/e295fd8d-34e6-4c6b-8e59-08682aae64fd-1760551544696.webp	3260	4950	webp	90	1863734	cmgsaxoj603kch9i6w7r5so66
cmgsaxq5n03koh9i6t3zqq4ot	/public/images/thumbnails/8b23abc2-89c1-488c-a9a5-e535dd655227-1760551548135.webp	150	150	webp	80	7004	cmgsaxq5i03kjh9i67ko7xu91
cmgsaxs4w03kvh9i676wlkxxt	/public/images/medium/b3cb6feb-9ec5-48b2-910e-c7654120eda8-1760551550239.webp	800	1308	webp	85	270472	cmgsaxs4u03kqh9i69olenjov
cmgsaxt4k03l3h9i6f78w5dth	/public/images/full/93d0e987-0db1-4903-ac30-089e9a096338-1760551552798.webp	2935	2199	webp	90	396486	cmgsaxt4g03kxh9i6y74n78q6
cmgsaxvtu03l8h9i6xekfsd8q	/public/images/medium/a0863bc8-ad7a-4e86-87a6-c984f358c420-1760551554096.webp	800	551	webp	85	116128	cmgsaxvtp03l4h9i6bbvadevz
cmgsaxxaz03lhh9i6um0h6hc6	/public/images/thumbnails/eeb72861-3add-40f9-9e28-9d6c143072e3-1760551557596.webp	150	150	webp	80	8424	cmgsaxxav03lbh9i63tru1ojg
cmgsbk51d0562h9i6laykuhkl	/public/images/thumbnails/12f3e97d-69ed-498d-b9b8-2aabae8f05f8-1760552594953.webp	150	150	webp	80	8006	cmgsbk51a055wh9i6sxsvjd2q
cmgsbk5ox0568h9i63poznu2g	/public/images/full/6df8a89d-45bd-4d03-b51e-49444311b22f-1760552595954.webp	2576	1840	webp	90	378912	cmgsbk5ov0563h9i6t9w1newi
cmgsbk720056fh9i61wbbkxkb	/public/images/thumbnails/9d0edb20-0f95-4cc3-9ea3-7ce296d6dc44-1760552596803.webp	150	150	webp	80	7498	cmgsbk71y056ah9i6r1aoj787
cmgsbk94f056mh9i6wvxktur5	/public/images/thumbnails/fd9bbe5d-c90f-4ad2-8f20-ed4c6da3ad20-1760552598572.webp	150	150	webp	80	7644	cmgsbk94d056hh9i6zw2m1o24
cmgsbkbe3056uh9i6p9ghylri	/public/images/medium/8d250367-43d9-4db1-a8b3-8e86cdaac4f6-1760552601257.webp	800	1155	webp	85	225390	cmgsbkbe1056oh9i6ktbndgq6
cmgsbkdhx0570h9i6ccub2uls	/public/images/medium/fc259ed6-6a75-43ad-b49d-47b4430a4b4e-1760552604190.webp	800	1180	webp	85	218082	cmgsbkdhv056vh9i6uixqyi47
cmgsbkfq50576h9i6xcwy6v8v	/public/images/thumbnails/5e22b9c2-3438-49a4-b568-f873297ea9e1-1760552606923.webp	150	150	webp	80	5862	cmgsbkfq30572h9i6nhzgcu6y
cmgsbki36057eh9i6xj80np3x	/public/images/medium/bc3be51c-2f02-4967-9c3f-fc5d09c08afe-1760552609806.webp	800	1166	webp	85	320950	cmgsbki340579h9i6hww1ugma
cmgsbkjyu057kh9i6nedmg9y4	/public/images/medium/7e999edf-b37f-4e46-8f56-45bebaf828c0-1760552612866.webp	800	1190	webp	85	182070	cmgsbkjys057gh9i6q11s656m
cmgsbklym057rh9i65dlk06m7	/public/images/full/21cae695-e79b-494a-807d-8fe49ae0d333-1760552615307.webp	4950	3400	webp	90	1733012	cmgsbklyk057nh9i6ro3iloaq
cmgsbko4c057zh9i6lmpkl8ys	/public/images/medium/c28dddf3-426a-43c3-b0e1-5ecb0f2a5a86-1760552617887.webp	800	1174	webp	85	274506	cmgsbko49057uh9i6k21ji8h0
cmgsbkqbv0586h9i6jm0bx8hx	/public/images/thumbnails/8aee3593-837c-413d-bb44-4ca7fe9fc225-1760552620690.webp	150	150	webp	80	8876	cmgsbkqbt0581h9i69kemod14
cmgsbl19f058eh9i60ysh2p8z	/public/images/full/bd40b1be-6a70-4c5c-a39d-ac440025449e-1760552623559.webp	6817	5106	webp	90	2989092	cmgsbl19d0588h9i6zy3610cy
cmgsbl3ie058jh9i6844c4q86	/public/images/thumbnails/6935bdb9-df1d-4368-98e1-9c1de1a8f39b-1760552637726.webp	150	150	webp	80	7050	cmgsbl3ic058fh9i68a881haw
cmgsbleqt058oh9i6n16f4aqj	/public/images/medium/9bc69745-c752-44f6-ab5f-29a487834739-1760552640645.webp	800	595	webp	85	91914	cmgsbleqr058mh9i6p10m9ay8
cmgsblgpl058zh9i6aquyv0ir	/public/images/full/4ec5a6b3-2553-4030-bf1b-a5690b1e84b0-1760552655197.webp	5028	3369	webp	90	2128450	cmgsblgpj058th9i6xa52m107
cmgsblhia0594h9i6f2lzu5bt	/public/images/medium/d0b873ff-f8ad-4e5a-ae8c-4551bac7c6d0-1760552657738.webp	800	1118	webp	85	172628	cmgsblhi80590h9i6qkxzzgg1
cmgsbljfn059bh9i6vpp1mzev	/public/images/full/09aade64-3ece-424a-b500-de8bc2d72d74-1760552658773.webp	3309	5091	webp	90	1306354	cmgsbljfk0597h9i661d6ejop
cmgsblkgz059kh9i6b5kgnoad	/public/images/medium/0326e275-ca83-4c11-8ce6-b504a5cc9cbe-1760552661267.webp	800	609	webp	85	100656	cmgsblkgv059eh9i61ako5ai7
cmgsawxd103gzh9i6ubiaj4vi	/public/images/medium/b0997a7a-5f88-4df6-a4b3-3fac63417043-1760551510850.webp	800	1223	webp	85	117382	cmgsawxcw03guh9i6orf70hek
cmgsawz5n03h4h9i6kgngc9jt	/public/images/thumbnails/a8735dec-25f8-415e-bfa0-32abc20872d1-1760551512919.webp	150	150	webp	80	5566	cmgsawz5h03h1h9i6654252rh
cmgsax0dn03hdh9i6ms8i5xud	/public/images/medium/9cef2c38-7f40-4537-ade6-078ae67bca44-1760551515239.webp	800	1021	webp	85	171024	cmgsax0dl03h8h9i6h33jwbes
cmgsax3be03hkh9i68boxy4s3	/public/images/medium/35616797-5e2d-4fee-b1e9-034942d59d00-1760551516836.webp	800	1167	webp	85	210872	cmgsax3ba03hfh9i6xnhnpom6
cmgsax48003hrh9i670x1wi2p	/public/images/medium/123b8c8c-c69f-45a4-ae39-dd1042841b78-1760551520634.webp	800	549	webp	85	86308	cmgsax47v03hmh9i6tpkdbovv
cmgsax56g03hyh9i6tpwumon5	/public/images/thumbnails/74e9b41b-26a8-4c82-87bb-7b355d597797-1760551521806.webp	150	150	webp	80	4188	cmgsax56d03hth9i6z1y6w81l
cmgsax6ps03i6h9i6wup7r11w	/public/images/thumbnails/bd40d4ea-565d-48ee-ac99-9046ebd0f867-1760551523048.webp	150	150	webp	80	8950	cmgsax6pn03i0h9i6ldqyl8c3
cmgsax86x03iah9i6t365lt2z	/public/images/medium/48812d0b-83e1-4220-bd47-6e494422be06-1760551525037.webp	800	562	webp	85	48862	cmgsax86s03i7h9i67hnkke9d
cmgsax95n03ikh9i63tmu5bcv	/public/images/full/968a9875-805c-4ba3-a558-2907d7b9e6d5-1760551526960.webp	2295	2386	webp	90	363130	cmgsax95k03ieh9i6n27n7nwa
cmgsaxafe03irh9i6u23erkk2	/public/images/medium/01e605ab-dc0e-47b2-8a65-c4064e468db9-1760551528205.webp	800	1030	webp	85	156418	cmgsaxafa03ilh9i6khle3fgi
cmgsaxbft03iwh9i67d7eyl8q	/public/images/full/d5cf0a2a-1315-4003-b4a5-d6a7eecf2b1b-1760551529859.webp	2358	2371	webp	90	385026	cmgsaxbfr03ish9i6p26bnvvi
cmgsaxchm03j4h9i6npckcixl	/public/images/full/1582964d-f60e-40ad-82c8-5a879b9c3a68-1760551531160.webp	2889	2121	webp	90	530786	cmgsaxchi03izh9i6dd2j5eir
cmgsaxe5103jbh9i6win8log4	/public/images/full/17ddc3b3-6ae0-4e24-b6ac-9a22e3ad47af-1760551532525.webp	3529	2698	webp	90	1105388	cmgsaxe4z03j6h9i69wef6w7f
cmgsaxftv03jih9i6blw0fn2h	/public/images/medium/89968773-e572-415b-acad-2ce6af9dba63-1760551534666.webp	800	475	webp	85	85878	cmgsaxftq03jdh9i675ug5p46
cmgsaxgpi03joh9i6ixkyuov0	/public/images/medium/3d24839a-8363-40d2-b431-3c7361ac5e4f-1760551536857.webp	800	547	webp	85	73026	cmgsaxgpe03jkh9i606y1pej0
cmgsaxi7b03jxh9i6f1zthpjc	/public/images/full/cec26e0c-ba95-4576-952f-2863ef3ebd8d-1760551537986.webp	3997	2464	webp	90	858384	cmgsaxi7803jrh9i66exizyi4
cmgsaxj4u03k4h9i6cyq9g530	/public/images/thumbnails/3c4d5bed-87d1-47f5-8241-115e066b19e8-1760551539923.webp	150	150	webp	80	5530	cmgsaxj4p03jyh9i6e0sjbze1
cmgsaxlvh03k9h9i6nhfqsa1x	/public/images/medium/11159d71-1bbb-42e6-a8d8-5cda3c6d79bb-1760551541151.webp	800	544	webp	85	88248	cmgsaxlve03k5h9i6vc97ytyg
cmgsaxojb03kgh9i6v51nx5ur	/public/images/thumbnails/e295fd8d-34e6-4c6b-8e59-08682aae64fd-1760551544696.webp	150	150	webp	80	7864	cmgsaxoj603kch9i6w7r5so66
cmgsaxq5n03kph9i6myaqt2cq	/public/images/medium/8b23abc2-89c1-488c-a9a5-e535dd655227-1760551548135.webp	800	1050	webp	85	138492	cmgsaxq5i03kjh9i67ko7xu91
cmgsaxs4w03kth9i6t728jl7a	/public/images/thumbnails/b3cb6feb-9ec5-48b2-910e-c7654120eda8-1760551550239.webp	150	150	webp	80	8188	cmgsaxs4u03kqh9i69olenjov
cmgsaxt4k03l1h9i6gb20gz3o	/public/images/medium/93d0e987-0db1-4903-ac30-089e9a096338-1760551552798.webp	800	599	webp	85	52136	cmgsaxt4g03kxh9i6y74n78q6
cmgsaxvtu03l9h9i6j5cdtka6	/public/images/full/a0863bc8-ad7a-4e86-87a6-c984f358c420-1760551554096.webp	4981	3432	webp	90	2047952	cmgsaxvtp03l4h9i6bbvadevz
cmgsaxxaz03lfh9i6fmoenw8y	/public/images/medium/eeb72861-3add-40f9-9e28-9d6c143072e3-1760551557596.webp	800	1040	webp	85	176546	cmgsaxxav03lbh9i63tru1ojg
cmgsaxyxu03lmh9i60ccjs4xq	/public/images/medium/a8d82897-2215-41c7-97fb-c75f0d1eff33-1760551559501.webp	800	1078	webp	85	160038	cmgsaxyxo03lih9i62n0b36eu
cmgsaxyxu03llh9i6ovlac4gm	/public/images/thumbnails/a8d82897-2215-41c7-97fb-c75f0d1eff33-1760551559501.webp	150	150	webp	80	7982	cmgsaxyxo03lih9i62n0b36eu
cmgsaxyxu03loh9i63t1ftm7o	/public/images/full/a8d82897-2215-41c7-97fb-c75f0d1eff33-1760551559501.webp	2686	3619	webp	90	890858	cmgsaxyxo03lih9i62n0b36eu
cmgsaxzue03lvh9i600s8kx82	/public/images/thumbnails/587458b1-13ec-4837-b97a-9face68a7323-1760551561620.webp	150	150	webp	80	5826	cmgsaxzua03lph9i6nolfznic
cmgsaxzue03luh9i6ev6oqm6b	/public/images/medium/587458b1-13ec-4837-b97a-9face68a7323-1760551561620.webp	800	1070	webp	85	93604	cmgsaxzua03lph9i6nolfznic
cmgsaxzue03lth9i6tbu24fir	/public/images/full/587458b1-13ec-4837-b97a-9face68a7323-1760551561620.webp	1889	2527	webp	90	315466	cmgsaxzua03lph9i6nolfznic
cmgsay0vg03lyh9i6tfqclill	/public/images/medium/554313f3-db37-4398-943b-d375f9fa176b-1760551562792.webp	800	584	webp	85	79418	cmgsay0va03lwh9i67tsrm6wn
cmgsay0vh03m0h9i60rvhervs	/public/images/thumbnails/554313f3-db37-4398-943b-d375f9fa176b-1760551562792.webp	150	150	webp	80	6926	cmgsay0va03lwh9i67tsrm6wn
cmgsay0vh03m2h9i6nvw4yyu3	/public/images/full/554313f3-db37-4398-943b-d375f9fa176b-1760551562792.webp	2904	2121	webp	90	505516	cmgsay0va03lwh9i67tsrm6wn
cmgsay1ov03m9h9i61eyzlzx8	/public/images/full/09a8fa96-b8f1-4647-b989-7ce06d1546b1-1760551564126.webp	2607	1840	webp	90	341004	cmgsay1os03m3h9i6ipplzdci
cmgsay1ov03m7h9i6w9tb1pnj	/public/images/thumbnails/09a8fa96-b8f1-4647-b989-7ce06d1546b1-1760551564126.webp	150	150	webp	80	6510	cmgsay1os03m3h9i6ipplzdci
cmgsay1ov03m8h9i69osvb72j	/public/images/medium/09a8fa96-b8f1-4647-b989-7ce06d1546b1-1760551564126.webp	800	565	webp	85	58906	cmgsay1os03m3h9i6ipplzdci
cmgsay2if03meh9i6mvez72en	/public/images/medium/7c787499-9371-4ede-9b01-1b98a650b755-1760551565186.webp	800	575	webp	85	47760	cmgsay2id03mah9i6tgsuagng
cmgsay2if03mfh9i6zsn8spg3	/public/images/thumbnails/7c787499-9371-4ede-9b01-1b98a650b755-1760551565186.webp	150	150	webp	80	5570	cmgsay2id03mah9i6tgsuagng
cmgsay2if03mgh9i696a2r6d4	/public/images/full/7c787499-9371-4ede-9b01-1b98a650b755-1760551565186.webp	2670	1918	webp	90	313874	cmgsay2id03mah9i6tgsuagng
cmgsay3ak03mmh9i6ntup0czl	/public/images/full/98498dea-b0d1-4449-86ce-130ed9877b7e-1760551566245.webp	2498	1794	webp	90	327350	cmgsay3ai03mhh9i6hls5u4yf
cmgsay3ak03mlh9i6op5s969h	/public/images/medium/98498dea-b0d1-4449-86ce-130ed9877b7e-1760551566245.webp	800	575	webp	85	66202	cmgsay3ai03mhh9i6hls5u4yf
cmgsay3ak03mnh9i67euubok1	/public/images/thumbnails/98498dea-b0d1-4449-86ce-130ed9877b7e-1760551566245.webp	150	150	webp	80	6500	cmgsay3ai03mhh9i6hls5u4yf
cmgsay46z03msh9i6e92vbst4	/public/images/medium/bba4be89-ab8e-4e0b-9323-6aeddb299c03-1760551567262.webp	800	548	webp	85	73412	cmgsay46x03moh9i6l03qypre
cmgsay46z03mrh9i6be4j4i8m	/public/images/thumbnails/bba4be89-ab8e-4e0b-9323-6aeddb299c03-1760551567262.webp	150	150	webp	80	6848	cmgsay46x03moh9i6l03qypre
cmgsay7k903n0h9i6htmlc63e	/public/images/medium/926801f5-2f36-48f7-9557-261facc2c5f7-1760551568447.webp	800	573	webp	85	87016	cmgsay7k503mvh9i6d7er1xob
cmgsay8o303n8h9i6wlat8sz0	/public/images/thumbnails/59d53161-ec44-41ac-b72f-aff218d8146f-1760551572788.webp	150	150	webp	80	6450	cmgsay8nx03n2h9i6jgnc24br
cmgsay9t903neh9i6l90s86do	/public/images/medium/f8f46202-4a51-44a8-bdcb-0b93df023b4d-1760551574227.webp	800	592	webp	85	89112	cmgsay9t403n9h9i6bus4tzmf
cmgsayb4a03nkh9i68ugspbzx	/public/images/full/cf8d8f69-98d2-4532-91bc-2743983c4de2-1760551575714.webp	2951	2293	webp	90	722844	cmgsayb4603ngh9i6fgzwrd91
cmgsayctu03nth9i66edi0qr5	/public/images/thumbnails/aa648975-ba83-4656-8646-76d7611e2938-1760551577409.webp	150	150	webp	80	5818	cmgsayctp03nnh9i6djjvvjo1
cmgsayf0j03nxh9i6jsqpy70m	/public/images/medium/ef276a56-2424-42eb-ad1c-4bdabad9e07b-1760551579623.webp	800	1208	webp	85	262666	cmgsayf0h03nuh9i6zzref5n2
cmgsayi2s03o7h9i6pue94y0v	/public/images/full/59f87524-627f-4e39-94d6-c7d6ff2f25ab-1760551582467.webp	5153	3463	webp	90	2667030	cmgsayi2p03o1h9i60vzveh1v
cmgsayj5u03oeh9i660x2xcuv	/public/images/thumbnails/32f1f8fd-7671-4573-8132-ebcb442a68de-1760551586421.webp	150	150	webp	80	7760	cmgsayj5p03o8h9i6afvp16yp
cmgsaylkl03ojh9i6u5riothv	/public/images/thumbnails/094cc89c-bffe-4233-b550-3f56ef386e81-1760551587832.webp	150	150	webp	80	6388	cmgsaylkh03ofh9i6ranmmzq7
cmgsayo8z03oqh9i69ixr44mh	/public/images/full/2ff9ccc4-9aee-4596-934e-d305d5f64e3f-1760551590952.webp	3385	4841	webp	90	1692006	cmgsayo8x03omh9i69e3rw5xy
cmgsayr8603ozh9i6q3w8dwmu	/public/images/thumbnails/bf7e671b-4604-42a9-bb79-fa4b0dc9767d-1760551594421.webp	150	150	webp	80	9108	cmgsayr7y03oth9i6t6u8mdax
cmgsayt6503p6h9i67flm64vc	/public/images/thumbnails/b610abad-8928-48fc-9c48-f4a3919c804d-1760551598281.webp	150	150	webp	80	6320	cmgsayt6303p0h9i69566r8nv
cmgsayusy03p9h9i6b48sjx7e	/public/images/thumbnails/d52a0076-9f64-4750-b228-e8fb688c42dc-1760551600796.webp	150	150	webp	80	7522	cmgsayusw03p7h9i6osph7pv8
cmgsayw8t03pjh9i64epr81tu	/public/images/full/ae1906d0-4d00-4b27-aa87-724246cdd96f-1760551602913.webp	2576	3322	webp	90	823936	cmgsayw8r03peh9i67qv8ssvz
cmgsayyv403pqh9i6az2qkbjv	/public/images/thumbnails/f6b8cf8e-49b2-4de0-a627-72f2a8a0c6ae-1760551604792.webp	150	150	webp	80	8594	cmgsayyv103plh9i6zpc125gf
cmgsaz0va03pwh9i6qduim5c9	/public/images/full/3179d781-d268-4b25-9d98-c97bc1a4eab9-1760551608181.webp	2979	4357	webp	90	1048852	cmgsaz0v403psh9i6kihpe4vz
cmgsaz2s603q5h9i6goi7tyfm	/public/images/full/38b52490-4448-487e-b3a8-53778181f137-1760551610782.webp	4399	2995	webp	90	869534	cmgsaz2s103pzh9i69b5xacui
cmgsaz46i03qch9i6bppxu2r9	/public/images/full/c388f86d-7707-46d0-9ab1-67f512f75301-1760551613259.webp	2520	3543	webp	90	603324	cmgsaz46e03q6h9i6e7o9nxi8
cmgsaz53703qih9i6vjw5umpn	/public/images/thumbnails/74b5f156-db68-40fa-a3de-a0dfa40a1464-1760551615069.webp	150	150	webp	80	5722	cmgsaz53403qdh9i69uu1i9ea
cmgsaz60303qph9i6rfy5xllt	/public/images/medium/b531f38e-cb6a-43ed-98d3-db25851da7d4-1760551616246.webp	800	579	webp	85	45326	cmgsaz60003qkh9i6ph2pkj2n
cmgsaz6xg03qxh9i6tu3jzw60	/public/images/medium/b07d2d32-b7ef-4e3e-b741-051cca68b8b3-1760551617424.webp	800	603	webp	85	65990	cmgsaz6xe03qrh9i6a0ozwifa
cmgsaz9dn03r3h9i6roagktlz	/public/images/thumbnails/e748c05b-04eb-446a-bc16-3d36b23eaf9c-1760551618634.webp	150	150	webp	80	5586	cmgsaz9dj03qyh9i60zttlyp2
cmgsazaeg03r9h9i6hy5g9ac8	/public/images/thumbnails/32794cd6-c6a2-44fa-aff6-cf486819a737-1760551621808.webp	150	150	webp	80	5138	cmgsazaed03r5h9i6l0xc5orq
cmgsazbrl03rhh9i651yormro	/public/images/full/50e28921-c593-4d90-86ab-767738972c81-1760551623133.webp	2498	3385	webp	90	643398	cmgsazbri03rch9i6jpqdbtf5
cmgsazclk03rlh9i6aup6f2sd	/public/images/thumbnails/7ec75d5e-d01f-4c44-9df4-2ca046584551-1760551624894.webp	150	150	webp	80	7774	cmgsazclg03rjh9i67qqskbzk
cmgsaze6h03rth9i6yma4fbdv	/public/images/medium/3156219e-51b2-4e90-aed3-dd5a71315952-1760551625983.webp	800	505	webp	85	108818	cmgsaze6b03rqh9i6qzwzj5t2
cmgsazfvl03s3h9i64uvd194t	/public/images/full/25928b1e-32c1-4afa-9497-3d059b1462a9-1760551628030.webp	2632	4122	webp	90	711314	cmgsazfvg03rxh9i6m6e3w10f
cmgsazu0k03s9h9i6xnfei8un	/public/images/medium/f7b22872-29bc-4bf7-8ef0-4ccdd7337dee-1760551630247.webp	800	1165	webp	85	185444	cmgsazu0g03s4h9i60xeopc0n
cmgsazv5s03sgh9i6ig497e7k	/public/images/medium/f9031109-2580-4cd6-bde4-2beb587628f6-1760551648548.webp	800	1088	webp	85	128488	cmgsazv5o03sbh9i67z088hgx
cmgsazxdd03snh9i6veo6h6x6	/public/images/medium/8c0d48b6-7034-422f-abfd-abe82d4818cc-1760551650037.webp	800	501	webp	85	56080	cmgsazxda03sih9i6imlsuvqc
cmgsazzsx03svh9i61jwff4ie	/public/images/medium/44bb639d-55fc-4cfe-b077-1d0f51332971-1760551652908.webp	800	526	webp	85	117902	cmgsazzst03sph9i672sgocs6
cmgsb01sr03t0h9i6poqwyzsi	/public/images/medium/4bf49012-2f32-4414-bde6-83f65d0a9a02-1760551656061.webp	800	1274	webp	85	103002	cmgsb01so03swh9i6bd69j9ca
cmgsb03bq03t7h9i6ajtjly97	/public/images/medium/316dedd2-3ec3-4197-aa00-55aa13c484f1-1760551658640.webp	800	1154	webp	85	140884	cmgsb03bn03t3h9i649abgpq7
cmgsb04jn03tfh9i6ark79cb7	/public/images/full/1f4bd734-2253-4138-9bc7-b3a706a294c6-1760551660614.webp	2632	2696	webp	90	517696	cmgsb04jj03tah9i6o3fr7x4k
cmgsb05z803tmh9i6nihk5orc	/public/images/thumbnails/11323b6c-3363-4f85-a76b-3a99a566a3a3-1760551662197.webp	150	150	webp	80	5736	cmgsb05z403thh9i6y7znw41z
cmgsb07lh03tth9i695wjv7aj	/public/images/thumbnails/92fc8142-1b5d-45ad-85bd-43fa7a995f65-1760551664060.webp	150	150	webp	80	7364	cmgsb07lf03toh9i6hhs2k1rt
cmgsb09d803u0h9i6mmuuqmew	/public/images/thumbnails/558a7675-fd25-425e-8f69-1ca590fc7e55-1760551666157.webp	150	150	webp	80	6080	cmgsb09d603tvh9i6b98pslub
cmgsb0b0803u8h9i69fmecj9g	/public/images/medium/dfab9525-2d75-41d7-9fc7-24a10e96ca81-1760551668444.webp	800	533	webp	85	74352	cmgsb0b0403u2h9i647j87441
cmgsb0dyb03udh9i6rgo6b7dk	/public/images/full/147b891a-036f-4c97-8595-d281142ead81-1760551670582.webp	4903	3353	webp	90	2947098	cmgsb0dy703u9h9i6kv1arfay
cmgsb0gtn03umh9i62ymvzaps	/public/images/full/b2604acf-b6b0-44cc-8e83-169696aa8d18-1760551674394.webp	4903	3338	webp	90	3036554	cmgsb0gth03ugh9i6oirq1621
cmgsb0i9w03uth9i6xo3uenm0	/public/images/full/0e0f0fe0-458d-4a82-ae6e-64c2efc078ee-1760551678111.webp	4013	2511	webp	90	598324	cmgsb0i9q03unh9i6xwzfl6xr
cmgsb0jga03uzh9i6pv7fz1p6	/public/images/medium/9d7a41ef-ee5e-4a58-8590-d3cf65fbef9c-1760551679997.webp	800	1133	webp	85	111720	cmgsb0jg703uuh9i6hmxtdjvn
cmgsay46z03muh9i63rknd5f3	/public/images/full/bba4be89-ab8e-4e0b-9323-6aeddb299c03-1760551567262.webp	2723	1864	webp	90	447690	cmgsay46x03moh9i6l03qypre
cmgsay7k903mzh9i6twgvntwz	/public/images/thumbnails/926801f5-2f36-48f7-9557-261facc2c5f7-1760551568447.webp	150	150	webp	80	7064	cmgsay7k503mvh9i6d7er1xob
cmgsay8o303n6h9i6edvzt74r	/public/images/full/59d53161-ec44-41ac-b72f-aff218d8146f-1760551572788.webp	3014	2230	webp	90	570354	cmgsay8nx03n2h9i6jgnc24br
cmgsay9t903nfh9i6un5io31g	/public/images/full/f8f46202-4a51-44a8-bdcb-0b93df023b4d-1760551574227.webp	3014	2230	webp	90	638622	cmgsay9t403n9h9i6bus4tzmf
cmgsayb4a03njh9i6sc72cgz0	/public/images/thumbnails/cf8d8f69-98d2-4532-91bc-2743983c4de2-1760551575714.webp	150	150	webp	80	9620	cmgsayb4603ngh9i6fgzwrd91
cmgsayctu03nsh9i6gdftx77o	/public/images/full/aa648975-ba83-4656-8646-76d7611e2938-1760551577409.webp	2639	4009	webp	90	881832	cmgsayctp03nnh9i6djjvvjo1
cmgsayf0k03o0h9i6v0erww7v	/public/images/thumbnails/ef276a56-2424-42eb-ad1c-4bdabad9e07b-1760551579623.webp	150	150	webp	80	7168	cmgsayf0h03nuh9i6zzref5n2
cmgsayi2s03o5h9i6dtz7w9as	/public/images/thumbnails/59f87524-627f-4e39-94d6-c7d6ff2f25ab-1760551582467.webp	150	150	webp	80	6978	cmgsayi2p03o1h9i60vzveh1v
cmgsayj5u03odh9i6xvzo8rcz	/public/images/full/32f1f8fd-7671-4573-8132-ebcb442a68de-1760551586421.webp	2967	2277	webp	90	505256	cmgsayj5p03o8h9i6afvp16yp
cmgsaylkl03olh9i6y7gttmrm	/public/images/full/094cc89c-bffe-4233-b550-3f56ef386e81-1760551587832.webp	4966	3431	webp	90	1239508	cmgsaylkh03ofh9i6ranmmzq7
cmgsayo8z03ooh9i6tm4wl66e	/public/images/thumbnails/2ff9ccc4-9aee-4596-934e-d305d5f64e3f-1760551590952.webp	150	150	webp	80	6670	cmgsayo8x03omh9i69e3rw5xy
cmgsayr8403oxh9i6trv0kmt1	/public/images/full/bf7e671b-4604-42a9-bb79-fa4b0dc9767d-1760551594421.webp	5091	3322	webp	90	3000946	cmgsayr7y03oth9i6t6u8mdax
cmgsayt6503p4h9i6njtklga1	/public/images/medium/b610abad-8928-48fc-9c48-f4a3919c804d-1760551598281.webp	800	1166	webp	85	220028	cmgsayt6303p0h9i69566r8nv
cmgsayusy03pdh9i64emty7cw	/public/images/full/d52a0076-9f64-4750-b228-e8fb688c42dc-1760551600796.webp	3857	2683	webp	90	963822	cmgsayusw03p7h9i6osph7pv8
cmgsayw8t03pih9i6xsak0rae	/public/images/thumbnails/ae1906d0-4d00-4b27-aa87-724246cdd96f-1760551602913.webp	150	150	webp	80	7752	cmgsayw8r03peh9i67qv8ssvz
cmgsayyv403prh9i6nb0jxopo	/public/images/medium/f6b8cf8e-49b2-4de0-a627-72f2a8a0c6ae-1760551604792.webp	800	540	webp	85	96166	cmgsayyv103plh9i6zpc125gf
cmgsaz0va03pvh9i66e3zfkmn	/public/images/thumbnails/3179d781-d268-4b25-9d98-c97bc1a4eab9-1760551608181.webp	150	150	webp	80	9554	cmgsaz0v403psh9i6kihpe4vz
cmgsaz2s603q4h9i6hpu76y6x	/public/images/thumbnails/38b52490-4448-487e-b3a8-53778181f137-1760551610782.webp	150	150	webp	80	8238	cmgsaz2s103pzh9i69b5xacui
cmgsaz46h03q9h9i6wkq73a63	/public/images/thumbnails/c388f86d-7707-46d0-9ab1-67f512f75301-1760551613259.webp	150	150	webp	80	5850	cmgsaz46e03q6h9i6e7o9nxi8
cmgsaz53703qhh9i6zqx0a8hb	/public/images/full/74b5f156-db68-40fa-a3de-a0dfa40a1464-1760551615069.webp	2826	2027	webp	90	344848	cmgsaz53403qdh9i69uu1i9ea
cmgsaz60303qoh9i6uv3n6zq2	/public/images/thumbnails/b531f38e-cb6a-43ed-98d3-db25851da7d4-1760551616246.webp	150	150	webp	80	5132	cmgsaz60003qkh9i6ph2pkj2n
cmgsaz6xg03qvh9i6dt4ofnhj	/public/images/thumbnails/b07d2d32-b7ef-4e3e-b741-051cca68b8b3-1760551617424.webp	150	150	webp	80	6700	cmgsaz6xe03qrh9i6a0ozwifa
cmgsaz9dn03r2h9i63s8hnqav	/public/images/full/e748c05b-04eb-446a-bc16-3d36b23eaf9c-1760551618634.webp	3381	5267	webp	90	869380	cmgsaz9dj03qyh9i60zttlyp2
cmgsazaeg03rah9i60431imqt	/public/images/medium/32794cd6-c6a2-44fa-aff6-cf486819a737-1760551621808.webp	800	1029	webp	85	90022	cmgsazaed03r5h9i6l0xc5orq
cmgsazbrl03rih9i6pj8tga17	/public/images/medium/50e28921-c593-4d90-86ab-767738972c81-1760551623133.webp	800	1084	webp	85	109240	cmgsazbri03rch9i6jpqdbtf5
cmgsazclk03rnh9i6stl8q03n	/public/images/medium/7ec75d5e-d01f-4c44-9df4-2ca046584551-1760551624894.webp	800	665	webp	85	81614	cmgsazclg03rjh9i67qqskbzk
cmgsaze6h03rwh9i6apkcdurk	/public/images/full/3156219e-51b2-4e90-aed3-dd5a71315952-1760551625983.webp	3779	2386	webp	90	1276480	cmgsaze6b03rqh9i6qzwzj5t2
cmgsazfvl03s1h9i62z3qrvlq	/public/images/thumbnails/25928b1e-32c1-4afa-9497-3d059b1462a9-1760551628030.webp	150	150	webp	80	3708	cmgsazfvg03rxh9i6m6e3w10f
cmgsazu0j03s6h9i6dj8ojuv6	/public/images/thumbnails/f7b22872-29bc-4bf7-8ef0-4ccdd7337dee-1760551630247.webp	150	150	webp	80	7920	cmgsazu0g03s4h9i60xeopc0n
cmgsazv5s03shh9i64retkxv3	/public/images/full/f9031109-2580-4cd6-bde4-2beb587628f6-1760551648548.webp	2139	2909	webp	90	575878	cmgsazv5o03sbh9i67z088hgx
cmgsazxdd03soh9i65y40gn88	/public/images/full/8c0d48b6-7034-422f-abfd-abe82d4818cc-1760551650037.webp	4890	3066	webp	90	1240852	cmgsazxda03sih9i6imlsuvqc
cmgsazzsx03sth9i6fjjfyjk5	/public/images/full/44bb639d-55fc-4cfe-b077-1d0f51332971-1760551652908.webp	4444	2923	webp	90	2651608	cmgsazzst03sph9i672sgocs6
cmgsb01sr03t2h9i6kwvxuttj	/public/images/full/4bf49012-2f32-4414-bde6-83f65d0a9a02-1760551656061.webp	2872	4573	webp	90	892610	cmgsb01so03swh9i6bd69j9ca
cmgsb03bq03t9h9i6os9embgm	/public/images/thumbnails/316dedd2-3ec3-4197-aa00-55aa13c484f1-1760551658640.webp	150	150	webp	80	7866	cmgsb03bn03t3h9i649abgpq7
cmgsb04jn03tgh9i6p74vr8kv	/public/images/thumbnails/1f4bd734-2253-4138-9bc7-b3a706a294c6-1760551660614.webp	150	150	webp	80	7464	cmgsb04jj03tah9i6o3fr7x4k
cmgsb05z803tjh9i6xc1txnvr	/public/images/full/11323b6c-3363-4f85-a76b-3a99a566a3a3-1760551662197.webp	2476	3744	webp	90	471446	cmgsb05z403thh9i6y7znw41z
cmgsb07lh03tuh9i6fer5hoko	/public/images/full/92fc8142-1b5d-45ad-85bd-43fa7a995f65-1760551664060.webp	4091	2464	webp	90	1101930	cmgsb07lf03toh9i6hhs2k1rt
cmgsb09d803u1h9i6l0560vq0	/public/images/full/558a7675-fd25-425e-8f69-1ca590fc7e55-1760551666157.webp	2636	4107	webp	90	1042940	cmgsb09d603tvh9i6b98pslub
cmgsb0b0803u6h9i6y13r5v7p	/public/images/thumbnails/dfab9525-2d75-41d7-9fc7-24a10e96ca81-1760551668444.webp	150	150	webp	80	7988	cmgsb0b0403u2h9i647j87441
cmgsb0dyb03ueh9i69n79ke0t	/public/images/medium/147b891a-036f-4c97-8595-d281142ead81-1760551670582.webp	800	547	webp	85	96680	cmgsb0dy703u9h9i6kv1arfay
cmgsb0gtn03ukh9i6840bw9qj	/public/images/medium/b2604acf-b6b0-44cc-8e83-169696aa8d18-1760551674394.webp	800	545	webp	85	96732	cmgsb0gth03ugh9i6oirq1621
cmgsb0i9v03uph9i6ah2q9te1	/public/images/medium/0e0f0fe0-458d-4a82-ae6e-64c2efc078ee-1760551678111.webp	800	500	webp	85	52732	cmgsb0i9q03unh9i6xwzfl6xr
cmgsb0jga03v0h9i6znyu52yo	/public/images/full/9d7a41ef-ee5e-4a58-8590-d3cf65fbef9c-1760551679997.webp	2170	3073	webp	90	530756	cmgsb0jg703uuh9i6hmxtdjvn
cmgsay7k903n1h9i6co3pofjw	/public/images/full/926801f5-2f36-48f7-9557-261facc2c5f7-1760551568447.webp	5466	3917	webp	90	2224934	cmgsay7k503mvh9i6d7er1xob
cmgsay8o303n7h9i66zn6l74l	/public/images/medium/59d53161-ec44-41ac-b72f-aff218d8146f-1760551572788.webp	800	592	webp	85	74278	cmgsay8nx03n2h9i6jgnc24br
cmgsay9t903ndh9i6q9kltmuz	/public/images/thumbnails/f8f46202-4a51-44a8-bdcb-0b93df023b4d-1760551574227.webp	150	150	webp	80	7204	cmgsay9t403n9h9i6bus4tzmf
cmgsayb4b03nmh9i6cq7pgfd7	/public/images/medium/cf8d8f69-98d2-4532-91bc-2743983c4de2-1760551575714.webp	800	622	webp	85	114756	cmgsayb4603ngh9i6fgzwrd91
cmgsayctt03nph9i6bq1hmywg	/public/images/medium/aa648975-ba83-4656-8646-76d7611e2938-1760551577409.webp	800	1215	webp	85	135188	cmgsayctp03nnh9i6djjvvjo1
cmgsayf0j03nyh9i68aiwdrez	/public/images/full/ef276a56-2424-42eb-ad1c-4bdabad9e07b-1760551579623.webp	2779	4196	webp	90	1665918	cmgsayf0h03nuh9i6zzref5n2
cmgsayi2s03o6h9i6h7qyrdg1	/public/images/medium/59f87524-627f-4e39-94d6-c7d6ff2f25ab-1760551582467.webp	800	537	webp	85	81290	cmgsayi2p03o1h9i60vzveh1v
cmgsayj5u03och9i6zm6tlxko	/public/images/medium/32f1f8fd-7671-4573-8132-ebcb442a68de-1760551586421.webp	800	614	webp	85	86222	cmgsayj5p03o8h9i6afvp16yp
cmgsaylkl03okh9i6pvl1dqfb	/public/images/medium/094cc89c-bffe-4233-b550-3f56ef386e81-1760551587832.webp	800	552	webp	85	73114	cmgsaylkh03ofh9i6ranmmzq7
cmgsayo9003osh9i6rkab1ela	/public/images/medium/2ff9ccc4-9aee-4596-934e-d305d5f64e3f-1760551590952.webp	800	1144	webp	85	206962	cmgsayo8x03omh9i69e3rw5xy
cmgsayr8403ovh9i6xszjmq80	/public/images/medium/bf7e671b-4604-42a9-bb79-fa4b0dc9767d-1760551594421.webp	800	522	webp	85	109468	cmgsayr7y03oth9i6t6u8mdax
cmgsayt6503p5h9i68kidncks	/public/images/full/b610abad-8928-48fc-9c48-f4a3919c804d-1760551598281.webp	2686	3915	webp	90	1568024	cmgsayt6303p0h9i69566r8nv
cmgsayusy03pch9i6lwau83z2	/public/images/medium/d52a0076-9f64-4750-b228-e8fb688c42dc-1760551600796.webp	800	556	webp	85	107656	cmgsayusw03p7h9i6osph7pv8
cmgsayw8t03pkh9i6a89qjrhf	/public/images/medium/ae1906d0-4d00-4b27-aa87-724246cdd96f-1760551602913.webp	800	1032	webp	85	149064	cmgsayw8r03peh9i67qv8ssvz
cmgsayyv403pph9i69o1n4fy7	/public/images/full/f6b8cf8e-49b2-4de0-a627-72f2a8a0c6ae-1760551604792.webp	4919	3322	webp	90	2071702	cmgsayyv103plh9i6zpc125gf
cmgsaz0vc03pyh9i62iuy9jq6	/public/images/medium/3179d781-d268-4b25-9d98-c97bc1a4eab9-1760551608181.webp	800	1170	webp	85	174934	cmgsaz0v403psh9i6kihpe4vz
cmgsaz2s603q3h9i6yx8kelk8	/public/images/medium/38b52490-4448-487e-b3a8-53778181f137-1760551610782.webp	800	544	webp	85	70720	cmgsaz2s103pzh9i69b5xacui
cmgsaz46h03qah9i66s15j9fb	/public/images/medium/c388f86d-7707-46d0-9ab1-67f512f75301-1760551613259.webp	800	1124	webp	85	125196	cmgsaz46e03q6h9i6e7o9nxi8
cmgsaz53703qjh9i6j5lti3ld	/public/images/medium/74b5f156-db68-40fa-a3de-a0dfa40a1464-1760551615069.webp	800	574	webp	85	55294	cmgsaz53403qdh9i69uu1i9ea
cmgsaz60303qqh9i625j4k8bt	/public/images/full/b531f38e-cb6a-43ed-98d3-db25851da7d4-1760551616246.webp	2842	2059	webp	90	275560	cmgsaz60003qkh9i6ph2pkj2n
cmgsaz6xg03qwh9i6b00u2tsm	/public/images/full/b07d2d32-b7ef-4e3e-b741-051cca68b8b3-1760551617424.webp	2795	2106	webp	90	375036	cmgsaz6xe03qrh9i6a0ozwifa
cmgsaz9dn03r4h9i6trc9tch1	/public/images/medium/e748c05b-04eb-446a-bc16-3d36b23eaf9c-1760551618634.webp	800	1246	webp	85	95440	cmgsaz9dj03qyh9i60zttlyp2
cmgsazaeg03rbh9i6bu1kryf3	/public/images/full/32794cd6-c6a2-44fa-aff6-cf486819a737-1760551621808.webp	2061	2651	webp	90	416200	cmgsazaed03r5h9i6l0xc5orq
cmgsazbrl03rgh9i6qlqxdrj6	/public/images/thumbnails/50e28921-c593-4d90-86ab-767738972c81-1760551623133.webp	150	150	webp	80	6588	cmgsazbri03rch9i6jpqdbtf5
cmgsazcll03rph9i6g7et8c6r	/public/images/full/7ec75d5e-d01f-4c44-9df4-2ca046584551-1760551624894.webp	2420	2012	webp	90	381938	cmgsazclg03rjh9i67qqskbzk
cmgsaze6h03ruh9i6z4v7zday	/public/images/thumbnails/3156219e-51b2-4e90-aed3-dd5a71315952-1760551625983.webp	150	150	webp	80	6296	cmgsaze6b03rqh9i6qzwzj5t2
cmgsazfvl03s0h9i6we9rsjst	/public/images/medium/25928b1e-32c1-4afa-9497-3d059b1462a9-1760551628030.webp	800	1253	webp	85	116676	cmgsazfvg03rxh9i6m6e3w10f
cmgsazu0k03sah9i654sqhnmj	/public/images/full/f7b22872-29bc-4bf7-8ef0-4ccdd7337dee-1760551630247.webp	4727	6883	webp	90	2951758	cmgsazu0g03s4h9i60xeopc0n
cmgsazv5s03sfh9i6w6bdy1i1	/public/images/thumbnails/f9031109-2580-4cd6-bde4-2beb587628f6-1760551648548.webp	150	150	webp	80	6794	cmgsazv5o03sbh9i67z088hgx
cmgsazxdd03smh9i6t6w8w6hd	/public/images/thumbnails/8c0d48b6-7034-422f-abfd-abe82d4818cc-1760551650037.webp	150	150	webp	80	5888	cmgsazxda03sih9i6imlsuvqc
cmgsazzsx03suh9i69o0f895j	/public/images/thumbnails/44bb639d-55fc-4cfe-b077-1d0f51332971-1760551652908.webp	150	150	webp	80	8476	cmgsazzst03sph9i672sgocs6
cmgsb01sr03t1h9i6ojgefn3r	/public/images/thumbnails/4bf49012-2f32-4414-bde6-83f65d0a9a02-1760551656061.webp	150	150	webp	80	6392	cmgsb01so03swh9i6bd69j9ca
cmgsb03bq03t8h9i6je6phka7	/public/images/full/316dedd2-3ec3-4197-aa00-55aa13c484f1-1760551658640.webp	2565	3699	webp	90	670986	cmgsb03bn03t3h9i649abgpq7
cmgsb04jn03teh9i6fd366mbn	/public/images/medium/1f4bd734-2253-4138-9bc7-b3a706a294c6-1760551660614.webp	800	819	webp	85	106300	cmgsb04jj03tah9i6o3fr7x4k
cmgsb05z903tnh9i6lpd7sddu	/public/images/medium/11323b6c-3363-4f85-a76b-3a99a566a3a3-1760551662197.webp	800	1210	webp	85	88430	cmgsb05z403thh9i6y7znw41z
cmgsb07lh03tsh9i6arnwz81n	/public/images/medium/92fc8142-1b5d-45ad-85bd-43fa7a995f65-1760551664060.webp	800	482	webp	85	78304	cmgsb07lf03toh9i6hhs2k1rt
cmgsb09d803tzh9i63wm01bqi	/public/images/medium/558a7675-fd25-425e-8f69-1ca590fc7e55-1760551666157.webp	800	1246	webp	85	150668	cmgsb09d603tvh9i6b98pslub
cmgsb0b0803u7h9i6j0p8ug4z	/public/images/full/dfab9525-2d75-41d7-9fc7-24a10e96ca81-1760551668444.webp	4056	2701	webp	90	880866	cmgsb0b0403u2h9i647j87441
cmgsb0dyb03ufh9i6jtrr9g5m	/public/images/thumbnails/147b891a-036f-4c97-8595-d281142ead81-1760551670582.webp	150	150	webp	80	8004	cmgsb0dy703u9h9i6kv1arfay
cmgsb0gtn03ulh9i6papoxrji	/public/images/thumbnails/b2604acf-b6b0-44cc-8e83-169696aa8d18-1760551674394.webp	150	150	webp	80	7676	cmgsb0gth03ugh9i6oirq1621
cmgsb0i9w03ush9i68z2w0f4c	/public/images/thumbnails/0e0f0fe0-458d-4a82-ae6e-64c2efc078ee-1760551678111.webp	150	150	webp	80	6836	cmgsb0i9q03unh9i6xwzfl6xr
cmgsb0jga03uyh9i68j0dmrpg	/public/images/thumbnails/9d7a41ef-ee5e-4a58-8590-d3cf65fbef9c-1760551679997.webp	150	150	webp	80	5482	cmgsb0jg703uuh9i6hmxtdjvn
cmgsb0ko903v6h9i6lwctjs1p	/public/images/full/51823f3e-a14d-4e2c-87ba-157ffc671a72-1760551681516.webp	2295	3042	webp	90	468570	cmgsb0ko603v1h9i6raelvo8g
cmgsb0ko903v7h9i641v2zrh0	/public/images/thumbnails/51823f3e-a14d-4e2c-87ba-157ffc671a72-1760551681516.webp	150	150	webp	80	5816	cmgsb0ko603v1h9i6raelvo8g
cmgsb0m6n03vch9i6775nw6mi	/public/images/medium/75cbcba3-ae10-4ebf-9107-2db15842f5bd-1760551683099.webp	800	515	webp	85	47830	cmgsb0m6k03v8h9i68a7ezg49
cmgsb0ns903vkh9i6kkkigs9u	/public/images/medium/c7df550c-ba2d-4109-858c-18ab3086714b-1760551685056.webp	800	1264	webp	85	104634	cmgsb0ns603vfh9i63twkbajc
cmgsb0pbc03vsh9i637hoo3r4	/public/images/medium/3f51db2c-dc05-4290-a71c-6013ed83f586-1760551687132.webp	800	1307	webp	85	83670	cmgsb0pba03vmh9i6jt6gcg4r
cmgsb0qod03vwh9i6m6bsgdbo	/public/images/medium/283cdfb2-4032-409c-a657-9448ed7120f5-1760551689115.webp	800	1102	webp	85	144228	cmgsb0qob03vth9i63fn9iilg
cmgsb0sef03w6h9i600h0y0zf	/public/images/medium/73ce761f-087b-482b-bbe8-30cc4556c58d-1760551690877.webp	800	575	webp	85	123046	cmgsb0se803w0h9i6clrmmpt6
cmgsb0u4x03wdh9i6ur7g09xi	/public/images/full/a58996e7-f2e8-4a7f-992f-1db214b36ec7-1760551693110.webp	3451	2667	webp	90	1642656	cmgsb0u4s03w7h9i6j9w04hea
cmgsb0vfx03wkh9i6w312c7ze	/public/images/medium/fb536b19-a1e8-491d-864f-f940ee4a0f35-1760551695362.webp	800	615	webp	85	120464	cmgsb0vfu03weh9i65gj58fka
cmgsb0w4e03wqh9i66kzkttcv	/public/images/full/0e49d608-f55d-468e-a736-9309c2631575-1760551697049.webp	2141	1738	webp	90	248554	cmgsb0w4a03wlh9i6dm4vzyek
cmgsb0x4g03wyh9i6lguiuxpq	/public/images/full/ef0c6d67-9de2-4a37-9533-47a0c392c8b2-1760551697938.webp	2811	2090	webp	90	464406	cmgsb0x4e03wsh9i68uqm73qg
cmgsb0yim03x4h9i6rtjdjm4o	/public/images/thumbnails/9e966aff-8d85-431f-9051-ba652fe46edd-1760551699234.webp	150	150	webp	80	4972	cmgsb0yij03wzh9i6cjz764gz
cmgsb10bb03xah9i6o18a79mp	/public/images/full/3c990d46-83c9-4838-af15-f679ffb1e9c5-1760551701040.webp	3982	2573	webp	90	1453998	cmgsb10b603x6h9i6ylqog3jq
cmgsb13kc03xhh9i6p895ct85	/public/images/thumbnails/81244371-abc8-4fbe-b95d-1091440eaaa8-1760551703374.webp	150	150	webp	80	4954	cmgsb13k903xdh9i6ln2ze02b
cmgsb14ku03xqh9i61zd612r3	/public/images/full/61141ab8-e741-4e8c-9fd8-f76e699a7ad3-1760551707587.webp	2982	2152	webp	90	460228	cmgsb14kq03xkh9i6e4hlf9x0
cmgsb16xc03xwh9i67vpzk3vp	/public/images/full/614f6a66-d4ab-4c33-8b06-020fb29ce88f-1760551708894.webp	4263	3322	webp	90	1503924	cmgsb16x703xrh9i6w50jeqdi
cmgsb194b03y1h9i6fcctm9c0	/public/images/medium/577ffc71-1ab2-4b7c-a47d-d8c33745d800-1760551711945.webp	800	707	webp	85	87156	cmgsb194703xyh9i6kae3wy5b
cmgsb1b3t03y9h9i6ah7pdlue	/public/images/full/1d84360c-aabd-4cf2-ad0e-43b4a1773209-1760551714776.webp	3896	3163	webp	90	1483446	cmgsb1b3o03y5h9i6udknkxn7
cmgsb1d3v03ygh9i623amrzt5	/public/images/full/50bdb92d-798d-4c07-b588-11f7ede3ac67-1760551717352.webp	3896	3163	webp	90	1386490	cmgsb1d3r03ych9i6sqz5moyr
cmgsb1gq203ynh9i6qhtkh8ff	/public/images/medium/d4e12e90-267b-4921-9ed3-d806451da915-1760551719957.webp	800	525	webp	85	89340	cmgsb1gpy03yjh9i6cbmxlvxm
cmgsb1isf03ywh9i6huz8owr9	/public/images/full/455de66d-1074-43ff-a018-51e1055eb875-1760551724648.webp	2698	4107	webp	90	1844502	cmgsb1is903yqh9i6jl3f4tdn
cmgsb1jyk03z2h9i6bi2l6gqo	/public/images/thumbnails/05b9330d-b597-468f-949f-492b339501fb-1760551727310.webp	150	150	webp	80	6760	cmgsb1jyg03yxh9i67ioexkdy
cmgsb1lkv03z8h9i6ividtpxr	/public/images/full/26b86f3f-b9f1-4c64-b479-9e5b357e8e15-1760551728827.webp	2529	3931	webp	90	841440	cmgsb1lkr03z4h9i6x86konla
cmgsb1nc503zfh9i640jwz22i	/public/images/full/581da918-2cb7-4578-8fca-286f92eb9cde-1760551730930.webp	2529	3931	webp	90	1132232	cmgsb1nc003zbh9i68wseaocj
cmgsb1ouk03zmh9i61itzm9tr	/public/images/medium/4b63a095-ff8c-4974-91ac-45671a58b1bc-1760551733207.webp	800	636	webp	85	73628	cmgsb1oui03zih9i65w1xdzue
cmgsb1px103zth9i6rmm0qw5g	/public/images/full/c912c710-3805-4d38-87af-cadc5f4070e2-1760551735168.webp	2155	2589	webp	90	564866	cmgsb1pwx03zph9i65q9azngo
cmgsb1si70402h9i6zmcx63r3	/public/images/full/54aa6453-c083-4201-9c23-5308326ea556-1760551736556.webp	3545	4960	webp	90	1484636	cmgsb1si403zwh9i605drjpsy
cmgsb1u4a0408h9i6fk1g3y1h	/public/images/thumbnails/69036415-862c-4a39-b6b4-4c588d5ca2f3-1760551739901.webp	150	150	webp	80	3840	cmgsb1u440403h9i63xzc1gvr
cmgsb1y4h040fh9i6v0qzh1ou	/public/images/full/8e4edbd9-2142-4e94-8333-9005e376e8a2-1760551742000.webp	3685	5662	webp	90	3825988	cmgsb1y4a040ah9i6yj86hlhb
cmgsb202n040kh9i640sorbbh	/public/images/thumbnails/b82f60ca-2ab4-4682-8ed8-617ae2d423ac-1760551747190.webp	150	150	webp	80	7886	cmgsb202k040hh9i67drr90ak
cmgsb234c040uh9i6vipeg0z3	/public/images/thumbnails/0b77ed55-b76e-4c90-8b3a-c67e07a821f8-1760551749715.webp	150	150	webp	80	5990	cmgsb2345040oh9i6q1b10u2w
cmgsb25b40410h9i69512z3io	/public/images/medium/6a2fc192-d654-4c93-86bb-f9e40a676a93-1760551753666.webp	800	977	webp	85	79836	cmgsb25an040vh9i65g3mh16v
cmgsb27fr0416h9i6ilxcy9fy	/public/images/medium/e7b17bb2-11e6-431e-b91b-8994ee2eaabe-1760551756532.webp	800	1163	webp	85	148812	cmgsb27fb0412h9i61xk9zzf8
cmgsb2av7041fh9i6fkkbcave	/public/images/full/279497a5-a803-4d02-98b1-8b6e51831345-1760551759276.webp	5242	3276	webp	90	1143246	cmgsb2auz0419h9i6wb8raxq8
cmgsb2clp041kh9i6uthhxme7	/public/images/thumbnails/14062d58-0cc3-460b-bb9b-4b3d2805201b-1760551763709.webp	150	150	webp	80	3018	cmgsb2clf041gh9i6a3rkh8y2
cmgsb2g5y041sh9i6gtyp1ult	/public/images/medium/37a792fe-0dbf-4550-bca0-6dea5886660c-1760551766035.webp	800	615	webp	85	117560	cmgsb2g5s041nh9i6py1vmurl
cmgsb2hz7041yh9i6i27kcntp	/public/images/full/afd40f1f-e4f2-4181-9309-fe92297fbde6-1760551770568.webp	2545	4071	webp	90	823038	cmgsb2hz0041uh9i6x5zkbvco
cmgsb2jop0424h9i6hxubbd7l	/public/images/medium/80f7f454-d0e6-4d6d-ab78-ec71f133ee52-1760551772929.webp	800	563	webp	85	86336	cmgsb2jom0421h9i65pbf63pk
cmgsb2msx042ch9i6a9gx5fqk	/public/images/full/8a2b2793-5f1c-4923-8b05-28264601ba8e-1760551775141.webp	3478	5059	webp	90	1925284	cmgsb2msu0428h9i6j9gi2zhs
cmgsb2oht042jh9i65a5tii8u	/public/images/medium/fcf3efe4-cf06-4139-ac5c-359fdd585139-1760551779176.webp	800	1124	webp	85	55330	cmgsb2ohp042fh9i6xyw4eunt
cmgsb2qh7042qh9i6kr2nalez	/public/images/medium/76fd3e18-1160-44dc-9573-9a1b492c5378-1760551781364.webp	800	1103	webp	85	139090	cmgsb2qgw042mh9i6bfkywk8r
cmgsb2taf042wh9i6bzwib67j	/public/images/thumbnails/1f8af138-b117-4867-9017-933e088c2528-1760551783951.webp	150	150	webp	80	6078	cmgsb2ta8042th9i6rye3wb50
cmgsb2vve0436h9i68wkj6rkj	/public/images/medium/6d59ab10-993a-4194-9808-cfb9d61021ce-1760551787589.webp	800	547	webp	85	69104	cmgsb2vv80430h9i62snl6goe
cmgsb2yjs043dh9i6tt2tia00	/public/images/medium/ebe7bd2c-815c-4b52-b53f-4393b6c50b09-1760551790936.webp	800	544	webp	85	81336	cmgsb2yjl0437h9i69y96w5kk
cmgsb0ko903v5h9i62q2nrzba	/public/images/medium/51823f3e-a14d-4e2c-87ba-157ffc671a72-1760551681516.webp	800	1060	webp	85	95820	cmgsb0ko603v1h9i6raelvo8g
cmgsb0m6n03vdh9i6juysdnzk	/public/images/thumbnails/75cbcba3-ae10-4ebf-9107-2db15842f5bd-1760551683099.webp	150	150	webp	80	5420	cmgsb0m6k03v8h9i68a7ezg49
cmgsb0ns903vjh9i62ijzworx	/public/images/full/c7df550c-ba2d-4109-858c-18ab3086714b-1760551685056.webp	2576	4071	webp	90	756974	cmgsb0ns603vfh9i63twkbajc
cmgsb0pbc03voh9i64tqotq23	/public/images/thumbnails/3f51db2c-dc05-4290-a71c-6013ed83f586-1760551687132.webp	150	150	webp	80	4770	cmgsb0pba03vmh9i6jt6gcg4r
cmgsb0qod03vzh9i6dcdldlnj	/public/images/full/283cdfb2-4032-409c-a657-9448ed7120f5-1760551689115.webp	2389	3291	webp	90	702746	cmgsb0qob03vth9i63fn9iilg
cmgsb0sef03w4h9i6xwh8q724	/public/images/thumbnails/73ce761f-087b-482b-bbe8-30cc4556c58d-1760551690877.webp	150	150	webp	80	6400	cmgsb0se803w0h9i6clrmmpt6
cmgsb0u4x03w9h9i616q8bqiv	/public/images/thumbnails/a58996e7-f2e8-4a7f-992f-1db214b36ec7-1760551693110.webp	150	150	webp	80	7796	cmgsb0u4s03w7h9i6j9w04hea
cmgsb0vfx03wih9i6l0g3h077	/public/images/full/fb536b19-a1e8-491d-864f-f940ee4a0f35-1760551695362.webp	2920	2246	webp	90	869650	cmgsb0vfu03weh9i65gj58fka
cmgsb0w4e03wph9i6a804zq0m	/public/images/thumbnails/0e49d608-f55d-468e-a736-9309c2631575-1760551697049.webp	150	150	webp	80	6790	cmgsb0w4a03wlh9i6dm4vzyek
cmgsb0x4g03wxh9i6hhz0j6a4	/public/images/thumbnails/ef0c6d67-9de2-4a37-9533-47a0c392c8b2-1760551697938.webp	150	150	webp	80	6972	cmgsb0x4e03wsh9i68uqm73qg
cmgsb0yim03x3h9i6zkb59fr5	/public/images/medium/9e966aff-8d85-431f-9051-ba652fe46edd-1760551699234.webp	800	1075	webp	85	108176	cmgsb0yij03wzh9i6cjz764gz
cmgsb10bb03xch9i6uyxfxt4e	/public/images/medium/3c990d46-83c9-4838-af15-f679ffb1e9c5-1760551701040.webp	800	517	webp	85	108124	cmgsb10b603x6h9i6ylqog3jq
cmgsb13kc03xgh9i6uydtiexx	/public/images/full/81244371-abc8-4fbe-b95d-1091440eaaa8-1760551703374.webp	3732	5319	webp	90	2572986	cmgsb13k903xdh9i6ln2ze02b
cmgsb14ku03xph9i6l08233vv	/public/images/medium/61141ab8-e741-4e8c-9fd8-f76e699a7ad3-1760551707587.webp	800	577	webp	85	61482	cmgsb14kq03xkh9i6e4hlf9x0
cmgsb16xc03xxh9i6n6jtb5kb	/public/images/medium/614f6a66-d4ab-4c33-8b06-020fb29ce88f-1760551708894.webp	800	623	webp	85	93798	cmgsb16x703xrh9i6w50jeqdi
cmgsb194b03y2h9i6nvv286sx	/public/images/thumbnails/577ffc71-1ab2-4b7c-a47d-d8c33745d800-1760551711945.webp	150	150	webp	80	5686	cmgsb194703xyh9i6kae3wy5b
cmgsb1b3t03yah9i67qmbsi6b	/public/images/medium/1d84360c-aabd-4cf2-ad0e-43b4a1773209-1760551714776.webp	800	649	webp	85	112082	cmgsb1b3o03y5h9i6udknkxn7
cmgsb1d3v03yhh9i629t49nez	/public/images/thumbnails/50bdb92d-798d-4c07-b588-11f7ede3ac67-1760551717352.webp	150	150	webp	80	7904	cmgsb1d3r03ych9i6sqz5moyr
cmgsb1gq203yph9i6f98xg5jc	/public/images/full/d4e12e90-267b-4921-9ed3-d806451da915-1760551719957.webp	6246	4100	webp	90	1969592	cmgsb1gpy03yjh9i6cbmxlvxm
cmgsb1isf03ysh9i6t54ktwt6	/public/images/thumbnails/455de66d-1074-43ff-a018-51e1055eb875-1760551724648.webp	150	150	webp	80	8104	cmgsb1is903yqh9i6jl3f4tdn
cmgsb1jyk03z3h9i6mr8ntwgf	/public/images/full/05b9330d-b597-468f-949f-492b339501fb-1760551727310.webp	2364	2897	webp	90	522276	cmgsb1jyg03yxh9i67ioexkdy
cmgsb1lkv03z9h9i6ggsa61bo	/public/images/medium/26b86f3f-b9f1-4c64-b479-9e5b357e8e15-1760551728827.webp	800	1244	webp	85	153272	cmgsb1lkr03z4h9i6x86konla
cmgsb1nc503zhh9i6iotk1oei	/public/images/thumbnails/581da918-2cb7-4578-8fca-286f92eb9cde-1760551730930.webp	150	150	webp	80	4912	cmgsb1nc003zbh9i68wseaocj
cmgsb1ouk03zoh9i6iw4tpvj5	/public/images/full/4b63a095-ff8c-4974-91ac-45671a58b1bc-1760551733207.webp	3357	2667	webp	90	784008	cmgsb1oui03zih9i65w1xdzue
cmgsb1px103zvh9i63h3w4q02	/public/images/thumbnails/c912c710-3805-4d38-87af-cadc5f4070e2-1760551735168.webp	150	150	webp	80	8646	cmgsb1pwx03zph9i65q9azngo
cmgsb1si703zyh9i60bhw5oku	/public/images/thumbnails/54aa6453-c083-4201-9c23-5308326ea556-1760551736556.webp	150	150	webp	80	7396	cmgsb1si403zwh9i605drjpsy
cmgsb1u4a0407h9i69v2b5x70	/public/images/full/69036415-862c-4a39-b6b4-4c588d5ca2f3-1760551739901.webp	2545	3884	webp	90	740114	cmgsb1u440403h9i63xzc1gvr
cmgsb1y4g040ch9i6mxrm1uce	/public/images/thumbnails/8e4edbd9-2142-4e94-8333-9005e376e8a2-1760551742000.webp	150	150	webp	80	6860	cmgsb1y4a040ah9i6yj86hlhb
cmgsb202n040nh9i6qw022oaw	/public/images/full/b82f60ca-2ab4-4682-8ed8-617ae2d423ac-1760551747190.webp	2932	4279	webp	90	810840	cmgsb202k040hh9i67drr90ak
cmgsb234c040sh9i6omkxo9sv	/public/images/medium/0b77ed55-b76e-4c90-8b3a-c67e07a821f8-1760551749715.webp	800	1214	webp	85	154304	cmgsb2345040oh9i6q1b10u2w
cmgsb25av040xh9i6nk4pwohy	/public/images/thumbnails/6a2fc192-d654-4c93-86bb-f9e40a676a93-1760551753666.webp	150	150	webp	80	4064	cmgsb25an040vh9i65g3mh16v
cmgsb27fr0415h9i6kce4ex4x	/public/images/thumbnails/e7b17bb2-11e6-431e-b91b-8994ee2eaabe-1760551756532.webp	150	150	webp	80	8160	cmgsb27fb0412h9i61xk9zzf8
cmgsb2av6041dh9i6xffvxz36	/public/images/thumbnails/279497a5-a803-4d02-98b1-8b6e51831345-1760551759276.webp	150	150	webp	80	5816	cmgsb2auz0419h9i6wb8raxq8
cmgsb2clp041jh9i6bp8vsul5	/public/images/medium/14062d58-0cc3-460b-bb9b-4b3d2805201b-1760551763709.webp	800	948	webp	85	106030	cmgsb2clf041gh9i6a3rkh8y2
cmgsb2g5y041th9i65ex5b4h7	/public/images/full/37a792fe-0dbf-4550-bca0-6dea5886660c-1760551766035.webp	5059	3884	webp	90	2064668	cmgsb2g5s041nh9i6py1vmurl
cmgsb2hz7041zh9i6rvij7znq	/public/images/medium/afd40f1f-e4f2-4181-9309-fe92297fbde6-1760551770568.webp	800	1280	webp	85	141192	cmgsb2hz0041uh9i6x5zkbvco
cmgsb2jop0427h9i6vtc5d0m0	/public/images/full/80f7f454-d0e6-4d6d-ab78-ec71f133ee52-1760551772929.webp	3654	2573	webp	90	951686	cmgsb2jom0421h9i65pbf63pk
cmgsb2msy042eh9i6egw28ikz	/public/images/medium/8a2b2793-5f1c-4923-8b05-28264601ba8e-1760551775141.webp	800	1163	webp	85	238790	cmgsb2msu0428h9i6j9gi2zhs
cmgsb2oht042ih9i6yi5u3bxv	/public/images/thumbnails/fcf3efe4-cf06-4139-ac5c-359fdd585139-1760551779176.webp	150	150	webp	80	2840	cmgsb2ohp042fh9i6xyw4eunt
cmgsb2qh7042sh9i6ux3114ha	/public/images/full/76fd3e18-1160-44dc-9573-9a1b492c5378-1760551781364.webp	2545	3509	webp	90	905348	cmgsb2qgw042mh9i6bfkywk8r
cmgsb2tag042zh9i6flgt99zm	/public/images/full/1f8af138-b117-4867-9017-933e088c2528-1760551783951.webp	2995	4399	webp	90	780430	cmgsb2ta8042th9i6rye3wb50
cmgsb2vve0435h9i6j79nfsq1	/public/images/thumbnails/6d59ab10-993a-4194-9808-cfb9d61021ce-1760551787589.webp	150	150	webp	80	7740	cmgsb2vv80430h9i62snl6goe
cmgsb2yjp0439h9i6cqs036mo	/public/images/thumbnails/ebe7bd2c-815c-4b52-b53f-4393b6c50b09-1760551790936.webp	150	150	webp	80	8510	cmgsb2yjl0437h9i69y96w5kk
cmgsb0m6n03veh9i6rhzis37u	/public/images/full/75cbcba3-ae10-4ebf-9107-2db15842f5bd-1760551683099.webp	3951	2542	webp	90	718896	cmgsb0m6k03v8h9i68a7ezg49
cmgsb0ns903vlh9i60waazf0k	/public/images/thumbnails/c7df550c-ba2d-4109-858c-18ab3086714b-1760551685056.webp	150	150	webp	80	5610	cmgsb0ns603vfh9i63twkbajc
cmgsb0pbc03vrh9i6didnqbqm	/public/images/full/3f51db2c-dc05-4290-a71c-6013ed83f586-1760551687132.webp	2483	4055	webp	90	564362	cmgsb0pba03vmh9i6jt6gcg4r
cmgsb0qod03vxh9i6vfit8zc8	/public/images/thumbnails/283cdfb2-4032-409c-a657-9448ed7120f5-1760551689115.webp	150	150	webp	80	8110	cmgsb0qob03vth9i63fn9iilg
cmgsb0sef03w5h9i60ncoczuw	/public/images/full/73ce761f-087b-482b-bbe8-30cc4556c58d-1760551690877.webp	3560	2558	webp	90	1667864	cmgsb0se803w0h9i6clrmmpt6
cmgsb0u4x03wch9i6ns4n61zn	/public/images/medium/a58996e7-f2e8-4a7f-992f-1db214b36ec7-1760551693110.webp	800	618	webp	85	145646	cmgsb0u4s03w7h9i6j9w04hea
cmgsb0vfx03wjh9i6tzl4fxul	/public/images/thumbnails/fb536b19-a1e8-491d-864f-f940ee4a0f35-1760551695362.webp	150	150	webp	80	9480	cmgsb0vfu03weh9i65gj58fka
cmgsb0w4e03wrh9i6c2dram5l	/public/images/medium/0e49d608-f55d-468e-a736-9309c2631575-1760551697049.webp	800	649	webp	85	67260	cmgsb0w4a03wlh9i6dm4vzyek
cmgsb0x4g03wvh9i624t2vxdu	/public/images/medium/ef0c6d67-9de2-4a37-9533-47a0c392c8b2-1760551697938.webp	800	595	webp	85	74992	cmgsb0x4e03wsh9i68uqm73qg
cmgsb0yim03x5h9i6865abjwv	/public/images/full/9e966aff-8d85-431f-9051-ba652fe46edd-1760551699234.webp	2436	3275	webp	90	788308	cmgsb0yij03wzh9i6cjz764gz
cmgsb10bb03xbh9i6eh2vtltk	/public/images/thumbnails/3c990d46-83c9-4838-af15-f679ffb1e9c5-1760551701040.webp	150	150	webp	80	8172	cmgsb10b603x6h9i6ylqog3jq
cmgsb13kc03xjh9i68745j0i2	/public/images/medium/81244371-abc8-4fbe-b95d-1091440eaaa8-1760551703374.webp	800	1140	webp	85	176160	cmgsb13k903xdh9i6ln2ze02b
cmgsb14ku03xoh9i6r2har8cz	/public/images/thumbnails/61141ab8-e741-4e8c-9fd8-f76e699a7ad3-1760551707587.webp	150	150	webp	80	5860	cmgsb14kq03xkh9i6e4hlf9x0
cmgsb16xb03xth9i6eomny001	/public/images/thumbnails/614f6a66-d4ab-4c33-8b06-020fb29ce88f-1760551708894.webp	150	150	webp	80	6266	cmgsb16x703xrh9i6w50jeqdi
cmgsb194b03y4h9i6kqvpntxo	/public/images/full/577ffc71-1ab2-4b7c-a47d-d8c33745d800-1760551711945.webp	3884	3435	webp	90	1324848	cmgsb194703xyh9i6kae3wy5b
cmgsb1b3t03ybh9i6b9792f0s	/public/images/thumbnails/1d84360c-aabd-4cf2-ad0e-43b4a1773209-1760551714776.webp	150	150	webp	80	8244	cmgsb1b3o03y5h9i6udknkxn7
cmgsb1d3v03yih9i6gal4cz9j	/public/images/medium/50bdb92d-798d-4c07-b588-11f7ede3ac67-1760551717352.webp	800	649	webp	85	104144	cmgsb1d3r03ych9i6sqz5moyr
cmgsb1gq203ymh9i6mjec44jn	/public/images/thumbnails/d4e12e90-267b-4921-9ed3-d806451da915-1760551719957.webp	150	150	webp	80	7608	cmgsb1gpy03yjh9i6cbmxlvxm
cmgsb1isf03yvh9i66qiukkwa	/public/images/medium/455de66d-1074-43ff-a018-51e1055eb875-1760551724648.webp	800	1217	webp	85	218044	cmgsb1is903yqh9i6jl3f4tdn
cmgsb1jyk03z1h9i6yg5cvmlf	/public/images/medium/05b9330d-b597-468f-949f-492b339501fb-1760551727310.webp	800	980	webp	85	121972	cmgsb1jyg03yxh9i67ioexkdy
cmgsb1lkv03zah9i67gfca0it	/public/images/thumbnails/26b86f3f-b9f1-4c64-b479-9e5b357e8e15-1760551728827.webp	150	150	webp	80	7412	cmgsb1lkr03z4h9i6x86konla
cmgsb1nc503zgh9i6pht9qzzj	/public/images/medium/581da918-2cb7-4578-8fca-286f92eb9cde-1760551730930.webp	800	1244	webp	85	175048	cmgsb1nc003zbh9i68wseaocj
cmgsb1ouk03zlh9i6c5mzytdy	/public/images/thumbnails/4b63a095-ff8c-4974-91ac-45671a58b1bc-1760551733207.webp	150	150	webp	80	2936	cmgsb1oui03zih9i65w1xdzue
cmgsb1px103zuh9i69nz3yady	/public/images/medium/c912c710-3805-4d38-87af-cadc5f4070e2-1760551735168.webp	800	961	webp	85	147098	cmgsb1pwx03zph9i65q9azngo
cmgsb1si70400h9i6czwybj6f	/public/images/medium/54aa6453-c083-4201-9c23-5308326ea556-1760551736556.webp	800	1120	webp	85	178620	cmgsb1si403zwh9i605drjpsy
cmgsb1u4a0409h9i6t3krlb12	/public/images/medium/69036415-862c-4a39-b6b4-4c588d5ca2f3-1760551739901.webp	800	1221	webp	85	97934	cmgsb1u440403h9i63xzc1gvr
cmgsb1y4h040gh9i6vxhil28r	/public/images/medium/8e4edbd9-2142-4e94-8333-9005e376e8a2-1760551742000.webp	800	1230	webp	85	264262	cmgsb1y4a040ah9i6yj86hlhb
cmgsb202n040mh9i6kwjawskc	/public/images/medium/b82f60ca-2ab4-4682-8ed8-617ae2d423ac-1760551747190.webp	800	1167	webp	85	105092	cmgsb202k040hh9i67drr90ak
cmgsb234c040th9i66eb0orvi	/public/images/full/0b77ed55-b76e-4c90-8b3a-c67e07a821f8-1760551749715.webp	2995	4545	webp	90	1109308	cmgsb2345040oh9i6q1b10u2w
cmgsb25b70411h9i6xum6q7pc	/public/images/full/6a2fc192-d654-4c93-86bb-f9e40a676a93-1760551753666.webp	3212	3922	webp	90	767052	cmgsb25an040vh9i65g3mh16v
cmgsb27fs0418h9i63p2hsow2	/public/images/full/e7b17bb2-11e6-431e-b91b-8994ee2eaabe-1760551756532.webp	2498	3632	webp	90	670196	cmgsb27fb0412h9i61xk9zzf8
cmgsb2av5041bh9i60llpi59r	/public/images/medium/279497a5-a803-4d02-98b1-8b6e51831345-1760551759276.webp	800	500	webp	85	63368	cmgsb2auz0419h9i6wb8raxq8
cmgsb2cn2041mh9i652zvaa9b	/public/images/full/14062d58-0cc3-460b-bb9b-4b3d2805201b-1760551763709.webp	2436	2886	webp	90	715674	cmgsb2clf041gh9i6a3rkh8y2
cmgsb2g5y041rh9i6owuetv6w	/public/images/thumbnails/37a792fe-0dbf-4550-bca0-6dea5886660c-1760551766035.webp	150	150	webp	80	9400	cmgsb2g5s041nh9i6py1vmurl
cmgsb2hz70420h9i60u369v9d	/public/images/thumbnails/afd40f1f-e4f2-4181-9309-fe92297fbde6-1760551770568.webp	150	150	webp	80	6928	cmgsb2hz0041uh9i6x5zkbvco
cmgsb2jop0425h9i6uah7v24q	/public/images/thumbnails/80f7f454-d0e6-4d6d-ab78-ec71f133ee52-1760551772929.webp	150	150	webp	80	5922	cmgsb2jom0421h9i65pbf63pk
cmgsb2msx042ah9i6rp0aguyt	/public/images/thumbnails/8a2b2793-5f1c-4923-8b05-28264601ba8e-1760551775141.webp	150	150	webp	80	8512	cmgsb2msu0428h9i6j9gi2zhs
cmgsb2oht042lh9i6dy5inv29	/public/images/full/fcf3efe4-cf06-4139-ac5c-359fdd585139-1760551779176.webp	2576	3619	webp	90	528970	cmgsb2ohp042fh9i6xyw4eunt
cmgsb2qh7042ph9i6c34ahs08	/public/images/thumbnails/76fd3e18-1160-44dc-9573-9a1b492c5378-1760551781364.webp	150	150	webp	80	5144	cmgsb2qgw042mh9i6bfkywk8r
cmgsb2taf042xh9i6owoqo1mm	/public/images/medium/1f8af138-b117-4867-9017-933e088c2528-1760551783951.webp	800	1175	webp	85	89984	cmgsb2ta8042th9i6rye3wb50
cmgsb2vve0434h9i66qshb1kd	/public/images/full/6d59ab10-993a-4194-9808-cfb9d61021ce-1760551787589.webp	4357	2979	webp	90	872618	cmgsb2vv80430h9i62snl6goe
cmgsb2yjq043bh9i6707okls4	/public/images/full/ebe7bd2c-815c-4b52-b53f-4393b6c50b09-1760551790936.webp	4399	2995	webp	90	889522	cmgsb2yjl0437h9i69y96w5kk
cmgsb30n0043kh9i61667vd30	/public/images/medium/67fa85ca-a5aa-4ea8-8d10-5b6376f1bcbf-1760551794398.webp	800	547	webp	85	60480	cmgsb30mw043eh9i6s46gukxi
cmgsb30mz043ih9i6xz9c6x9w	/public/images/thumbnails/67fa85ca-a5aa-4ea8-8d10-5b6376f1bcbf-1760551794398.webp	150	150	webp	80	7268	cmgsb30mw043eh9i6s46gukxi
cmgsbljfn059dh9i6eoclej0e	/public/images/medium/09aade64-3ece-424a-b500-de8bc2d72d74-1760552658773.webp	800	1231	webp	85	195956	cmgsbljfk0597h9i661d6ejop
cmgsblkgz059ih9i615x8fvgx	/public/images/full/0326e275-ca83-4c11-8ce6-b504a5cc9cbe-1760552661267.webp	3198	2436	webp	90	763420	cmgsblkgv059eh9i61ako5ai7
cmgsblmrt059qh9i6konmvann	/public/images/thumbnails/65db0f36-001c-4194-a0c7-e357f16cd2c5-1760552662618.webp	150	150	webp	80	5322	cmgsblmrq059lh9i6hf5y6s2c
cmgsblnvs059yh9i6kxo36h8y	/public/images/medium/f0039f3f-4bd2-429e-81d1-aa1d3b106481-1760552665593.webp	800	670	webp	85	84212	cmgsblnvp059sh9i6yujbx6at
cmgsblp5605a4h9i6lljbktyt	/public/images/medium/9fc2bf71-12c0-4f4d-bba6-4857b2183882-1760552667034.webp	800	1247	webp	85	98006	cmgsblp54059zh9i6lhynfigz
cmgsblqbw05aah9i6o6obc2m3	/public/images/medium/afea6966-b391-4c84-b2fe-d010c1832584-1760552668668.webp	800	665	webp	85	99674	cmgsblqbt05a6h9i665xoa4ja
cmgsbmelg05e1h9i6k2qiyvxe	/public/images/medium/b0af6a68-4713-427f-80f3-64fb4f99bf41-1760552700294.webp	800	642	webp	85	79696	cmgsbmele05dvh9i6m66tr5ch
cmgsbmgtf05e6h9i616jqfzig	/public/images/medium/f8b163b0-a369-4c7d-a15f-2478c04f0c38-1760552701658.webp	800	581	webp	85	84704	cmgsbmgtc05e2h9i6jud89dhf
cmgsbmin805edh9i60o90azpm	/public/images/full/8cd66730-c5b5-4763-ba27-ef4f1fbaafe4-1760552704536.webp	4950	3416	webp	90	1257402	cmgsbmin605e9h9i6u5pm7ka6
cmgsbne1n05j3h9i6pvoyem85	/public/images/full/5ec20c90-864c-4cf8-a79d-23f4ddb237e5-1760552746722.webp	2483	1762	webp	90	575082	cmgsbne1k05ixh9i6tmmnroha
cmgsbney605j9h9i6uccb628y	/public/images/medium/6748f532-622e-46d6-9fca-e17b332f3649-1760552747596.webp	800	590	webp	85	65854	cmgsbney305j4h9i65ekcjxao
cmgsbngbk05jfh9i6ilksz57q	/public/images/thumbnails/570ef93f-d6f3-4629-bc4c-208c0dbbfa7a-1760552748767.webp	150	150	webp	80	8332	cmgsbngbg05jbh9i64un58w8x
cmgsbnhdz05jmh9i6jb8rqjut	/public/images/thumbnails/8b57726d-c8bc-403f-ad12-329a83b84952-1760552750544.webp	150	150	webp	80	6384	cmgsbnhdw05jih9i6upf90nmr
cmgsbniee05jvh9i6966o1o82	/public/images/full/1fa3aea1-6955-4aa4-ab51-7bd1cc7d6037-1760552751930.webp	2425	3353	webp	90	591342	cmgsbniec05jph9i6c1h7g6cf
cmgsbnle705k0h9i63owfo1ep	/public/images/thumbnails/74fdbe42-e1f5-43f3-b130-b33e6fb79c84-1760552753242.webp	150	150	webp	80	3270	cmgsbnle505jwh9i6isnxeghf
cmgsbnmeb05k9h9i6m1lmbpyl	/public/images/full/fb4475a8-66c3-47c4-a9a8-161c6b084336-1760552757120.webp	3164	2647	webp	90	582666	cmgsbnme805k3h9i6bjsudyip
cmgsbnn3f05kdh9i6b3tc7x5j	/public/images/thumbnails/a6be5d20-472c-490f-be58-3e9165f548db-1760552758418.webp	150	150	webp	80	5140	cmgsbnn3c05kah9i6e4u5o3cl
cmgsbnnts05knh9i6zxk2x1qw	/public/images/thumbnails/4360d5be-a41d-43f3-a210-323deb07e382-1760552759322.webp	150	150	webp	80	7780	cmgsbnntp05khh9i6zerms45a
cmgsbnome05kth9i6x1or1ewp	/public/images/medium/d1d6b1e6-a6d5-4390-b0bf-45abd2e7f130-1760552760271.webp	800	889	webp	85	97682	cmgsbnomc05koh9i6tkzjcegd
cmgsbnq5205kyh9i63jnminwp	/public/images/medium/23bf721a-98e0-4a95-8b06-d4cb0dd5b7bb-1760552761305.webp	800	1160	webp	85	102702	cmgsbnq5005kvh9i622yndl6w
cmgsbnrss05l6h9i6ienu2bwi	/public/images/thumbnails/e3bc52f1-e67f-4001-b770-2609e1fb5349-1760552763273.webp	150	150	webp	80	6584	cmgsbnrsq05l2h9i6m0qsdqb9
cmgsbntbc05leh9i6yxchgnfm	/public/images/medium/148addbe-befd-4410-b375-ab5d906a8d67-1760552765422.webp	800	771	webp	85	97632	cmgsbntba05l9h9i6htm1dy3r
cmgsbnuol05lkh9i63an4azu8	/public/images/full/cc2c3064-9926-4fb1-82a4-209f8d5a505c-1760552767385.webp	2989	3699	webp	90	1005574	cmgsbnuoi05lgh9i63p6hicbd
cmgsbnvvz05lrh9i6iid74u4a	/public/images/thumbnails/afd9ae10-a46a-4297-8088-f1915ebf2a8f-1760552769159.webp	150	150	webp	80	7406	cmgsbnvvx05lnh9i63nnzvbto
cmgsbnwlg05lzh9i6vpysud2j	/public/images/full/3f02feab-a287-4aa7-9ed2-a39add861392-1760552770718.webp	2088	2567	webp	90	305796	cmgsbnwlf05luh9i6q8eck0ui
cmgscffta05m3h9i6zoez65ys	/public/images/thumbnails/27bfba8c-d5e3-479f-9e7d-8881d5ed63fa-1760554055344.webp	150	150	webp	80	5076	cmgscffsq05m1h9i6xzezowaq
cmgscfftr05m5h9i66o9o36me	/public/images/medium/27bfba8c-d5e3-479f-9e7d-8881d5ed63fa-1760554055344.webp	800	610	webp	85	16758	cmgscffsq05m1h9i6xzezowaq
cmgsb30mz043hh9i610sfgiic	/public/images/full/67fa85ca-a5aa-4ea8-8d10-5b6376f1bcbf-1760551794398.webp	4357	2979	webp	90	791704	cmgsb30mw043eh9i6s46gukxi
cmgsb34ux043nh9i65mkeuyp3	/public/images/medium/76b941a9-fe27-4543-a8dc-c5c76016ab65-1760551797115.webp	800	1243	webp	85	167508	cmgsb34ut043lh9i695frnuhl
cmgsb34vs043ph9i673gtf6g8	/public/images/thumbnails/76b941a9-fe27-4543-a8dc-c5c76016ab65-1760551797115.webp	150	150	webp	80	7680	cmgsb34ut043lh9i695frnuhl
cmgsb34vu043rh9i69alfou6o	/public/images/full/76b941a9-fe27-4543-a8dc-c5c76016ab65-1760551797115.webp	3794	5896	webp	90	4497006	cmgsb34ut043lh9i695frnuhl
cmgsb36so043yh9i6nibyuvre	/public/images/thumbnails/09e96aec-7624-4f21-82a6-7956ab5577c2-1760551802608.webp	150	150	webp	80	4516	cmgsb36sj043sh9i6zlcjwyyv
cmgsb36so043wh9i6qg3od7lz	/public/images/medium/09e96aec-7624-4f21-82a6-7956ab5577c2-1760551802608.webp	800	1265	webp	85	192940	cmgsb36sj043sh9i6zlcjwyyv
cmgsb36so043xh9i6a3pc5scf	/public/images/full/09e96aec-7624-4f21-82a6-7956ab5577c2-1760551802608.webp	2597	4106	webp	90	1229832	cmgsb36sj043sh9i6zlcjwyyv
cmgsb386p0443h9i6mfa2axrj	/public/images/medium/7d0afece-c0cb-4c04-a9ea-902a2f6cde62-1760551805087.webp	800	1308	webp	85	105280	cmgsb386l043zh9i6rnezb780
cmgsb386p0444h9i6brh6s005	/public/images/thumbnails/7d0afece-c0cb-4c04-a9ea-902a2f6cde62-1760551805087.webp	150	150	webp	80	5948	cmgsb386l043zh9i6rnezb780
cmgsb386p0445h9i672el78mh	/public/images/full/7d0afece-c0cb-4c04-a9ea-902a2f6cde62-1760551805087.webp	2275	3721	webp	90	472838	cmgsb386l043zh9i6rnezb780
cmgsb3a0j044ch9i60tpsdg6z	/public/images/thumbnails/cc0b5f32-b13d-4d20-b5b1-d72d58c11bfd-1760551806884.webp	150	150	webp	80	6874	cmgsb3a0g0446h9i6wzqx1c3i
cmgsb3a0j044bh9i6abypyka8	/public/images/medium/cc0b5f32-b13d-4d20-b5b1-d72d58c11bfd-1760551806884.webp	800	1202	webp	85	204462	cmgsb3a0g0446h9i6wzqx1c3i
cmgsb3a0j044ah9i6itxwuppj	/public/images/full/cc0b5f32-b13d-4d20-b5b1-d72d58c11bfd-1760551806884.webp	2589	3888	webp	90	1375702	cmgsb3a0g0446h9i6wzqx1c3i
cmgsb3dc6044hh9i6bkx294q2	/public/images/full/6ddb94ef-f2b0-471b-ad74-01d004a9c63c-1760551809268.webp	3681	5835	webp	90	1785456	cmgsb3dc1044dh9i60cnw0vft
cmgsb3dc6044gh9i6sk0rm168	/public/images/thumbnails/6ddb94ef-f2b0-471b-ad74-01d004a9c63c-1760551809268.webp	150	150	webp	80	6684	cmgsb3dc1044dh9i60cnw0vft
cmgsb3dc7044jh9i69g1q1qgq	/public/images/medium/6ddb94ef-f2b0-471b-ad74-01d004a9c63c-1760551809268.webp	800	1268	webp	85	167358	cmgsb3dc1044dh9i60cnw0vft
cmgsb3f0e044nh9i6lwt4kdc9	/public/images/medium/a74a8cce-04ac-44d9-9815-18000bab03b5-1760551813565.webp	800	1226	webp	85	132112	cmgsb3f09044kh9i64jzei1ux
cmgsb3f0e044qh9i64bjkf5h7	/public/images/full/a74a8cce-04ac-44d9-9815-18000bab03b5-1760551813565.webp	2527	3872	webp	90	853482	cmgsb3f09044kh9i64jzei1ux
cmgsb3f0e044ph9i62sll7ku9	/public/images/thumbnails/a74a8cce-04ac-44d9-9815-18000bab03b5-1760551813565.webp	150	150	webp	80	6052	cmgsb3f09044kh9i64jzei1ux
cmgsb3i2m044uh9i6eewg4r4x	/public/images/thumbnails/384a9f89-1cee-4889-9bd3-5fb230f34593-1760551815724.webp	150	150	webp	80	8362	cmgsb3i2g044rh9i6v7l37ven
cmgsb3i2m044vh9i6tb71zdid	/public/images/full/384a9f89-1cee-4889-9bd3-5fb230f34593-1760551815724.webp	5044	3775	webp	90	2057534	cmgsb3i2g044rh9i6v7l37ven
cmgsb3i2o044xh9i6rfw6izbx	/public/images/medium/384a9f89-1cee-4889-9bd3-5fb230f34593-1760551815724.webp	800	598	webp	85	112966	cmgsb3i2g044rh9i6v7l37ven
cmgsb3jme0453h9i6bl3lbts9	/public/images/thumbnails/ca2dea2d-022d-46df-b548-8fe11fe71c6b-1760551819701.webp	150	150	webp	80	7790	cmgsb3jmc044yh9i66nfsgzvh
cmgsb3jme0454h9i64ihznzmm	/public/images/full/ca2dea2d-022d-46df-b548-8fe11fe71c6b-1760551819701.webp	2514	3603	webp	90	798300	cmgsb3jmc044yh9i66nfsgzvh
cmgsb3jme0452h9i6kbmdtasd	/public/images/medium/ca2dea2d-022d-46df-b548-8fe11fe71c6b-1760551819701.webp	800	1146	webp	85	150906	cmgsb3jmc044yh9i66nfsgzvh
cmgsb43eh0457h9i6gbumdaox	/public/images/thumbnails/23e6464c-422a-4342-b9f3-a54e441452de-1760551821714.webp	150	150	webp	80	6048	cmgsb43ea0455h9i6zhufot50
cmgsb43eh0459h9i6uh24skth	/public/images/medium/23e6464c-422a-4342-b9f3-a54e441452de-1760551821714.webp	800	548	webp	85	94752	cmgsb43ea0455h9i6zhufot50
cmgsb43ej045bh9i66dy11deo	/public/images/full/23e6464c-422a-4342-b9f3-a54e441452de-1760551821714.webp	8064	5530	webp	90	3735504	cmgsb43ea0455h9i6zhufot50
cmgsb44sp045hh9i68ttob179	/public/images/thumbnails/9b2c0086-4160-4f2b-9192-955f87c3bfda-1760551847349.webp	150	150	webp	80	4010	cmgsb44sl045ch9i6om640vy1
cmgsb44sp045gh9i6xkwemm8v	/public/images/medium/9b2c0086-4160-4f2b-9192-955f87c3bfda-1760551847349.webp	800	628	webp	85	90382	cmgsb44sl045ch9i6om640vy1
cmgsb44sp045ih9i6m0ud5cia	/public/images/full/9b2c0086-4160-4f2b-9192-955f87c3bfda-1760551847349.webp	3228	2535	webp	90	836120	cmgsb44sl045ch9i6om640vy1
cmgsb45zx045nh9i6qjl483o6	/public/images/thumbnails/650854d7-b76c-4210-bf83-405d0f8ec4d6-1760551849151.webp	150	150	webp	80	5220	cmgsb45zt045jh9i6x0kw7owg
cmgsb45zx045oh9i6jifjbh0k	/public/images/full/650854d7-b76c-4210-bf83-405d0f8ec4d6-1760551849151.webp	2361	3016	webp	90	435820	cmgsb45zt045jh9i6x0kw7owg
cmgsb45zx045ph9i6isdlqrmk	/public/images/medium/650854d7-b76c-4210-bf83-405d0f8ec4d6-1760551849151.webp	800	1022	webp	85	84712	cmgsb45zt045jh9i6x0kw7owg
cmgsb47hn045wh9i6swxhhirz	/public/images/thumbnails/5c5e3218-a6ca-415c-8b78-887c38bb6703-1760551850705.webp	150	150	webp	80	6706	cmgsb47hi045qh9i6s2w9uci6
cmgsb47hn045uh9i62f1ywdmo	/public/images/medium/5c5e3218-a6ca-415c-8b78-887c38bb6703-1760551850705.webp	800	605	webp	85	83888	cmgsb47hi045qh9i6s2w9uci6
cmgsb47hn045vh9i6ytrvsyvd	/public/images/full/5c5e3218-a6ca-415c-8b78-887c38bb6703-1760551850705.webp	3565	2695	webp	90	747630	cmgsb47hi045qh9i6s2w9uci6
cmgsb48kv0462h9i6y86q4tn2	/public/images/full/2255d111-6f48-4adc-8dac-b6e60ddef048-1760551852635.webp	2473	2599	webp	90	482940	cmgsb48kt045xh9i62tt42ylw
cmgsb48kv0461h9i67b6zj357	/public/images/thumbnails/2255d111-6f48-4adc-8dac-b6e60ddef048-1760551852635.webp	150	150	webp	80	7030	cmgsb48kt045xh9i62tt42ylw
cmgsb48kv0463h9i68g7gv5ln	/public/images/medium/2255d111-6f48-4adc-8dac-b6e60ddef048-1760551852635.webp	800	841	webp	85	75318	cmgsb48kt045xh9i62tt42ylw
cmgsb49sn0468h9i6ie7kxrdd	/public/images/medium/80d16b51-51c3-4e8b-9d9d-2a79b9f96ca8-1760551854052.webp	800	592	webp	85	65328	cmgsb49si0464h9i61mf4r6fb
cmgsb49sn0467h9i6hvykfi51	/public/images/thumbnails/80d16b51-51c3-4e8b-9d9d-2a79b9f96ca8-1760551854052.webp	150	150	webp	80	8182	cmgsb49si0464h9i61mf4r6fb
cmgsb49sn046ah9i6fyf43a39	/public/images/full/80d16b51-51c3-4e8b-9d9d-2a79b9f96ca8-1760551854052.webp	3228	2390	webp	90	418874	cmgsb49si0464h9i61mf4r6fb
cmgsb4bb6046gh9i6x1gncvny	/public/images/full/e29bbb42-3fcd-41e5-885e-e2ad881e895b-1760551855624.webp	3212	2519	webp	90	673844	cmgsb4bb0046bh9i69rjevfs1
cmgsb4cfr046oh9i6s3b7x0rv	/public/images/full/eb911e1e-00c6-4bb5-8934-dc8c2f92aa33-1760551857585.webp	2409	2647	webp	90	476502	cmgsb4cfo046ih9i6csmhzxgb
cmgsb4wb8046vh9i6p9byw1o6	/public/images/thumbnails/68c45ea3-9bd2-4c8d-9545-d5c5d218fea0-1760551859054.webp	150	150	webp	80	8106	cmgsb4wb0046ph9i669azpjqz
cmgsb4zz20472h9i6jeojtdv6	/public/images/thumbnails/bb8b00d0-348a-4ca6-9601-c30b19bf4876-1760551884817.webp	150	150	webp	80	8010	cmgsb4zyy046wh9i6rgkbyjgr
cmgsb53rk0478h9i6o00qmcg9	/public/images/medium/fc809317-1c2b-46e6-a82d-516f7594e2af-1760551889570.webp	800	562	webp	85	66602	cmgsb53rf0473h9i6ahod9gv3
cmgsb55va047gh9i6urw5y14z	/public/images/full/49af696e-9627-41df-8183-9c84cf283336-1760551894472.webp	2521	4075	webp	90	569876	cmgsb55v3047ah9i6xzhq3a5s
cmgsb5773047mh9i62tlh6w5l	/public/images/full/0ebc7983-6451-4371-b5c2-32779eb555cc-1760551897202.webp	2088	2647	webp	90	375300	cmgsb576x047hh9i672qx0126
cmgsb5ae0047uh9i6gl7wr5xn	/public/images/medium/dd4d8a14-8684-4d71-8309-07a6f9986b9b-1760551898925.webp	800	1124	webp	85	158552	cmgsb5adw047oh9i619sde7zd
cmgsb5faz047xh9i62x56x0zv	/public/images/thumbnails/c3df6612-f952-4f5e-94ad-390406d6535e-1760551903069.webp	150	150	webp	80	9616	cmgsb5faw047vh9i6kmpgfz8r
cmgsb5gpc0488h9i6qbjtl2ex	/public/images/full/1673f4b9-9573-492f-839d-e84f49bca57c-1760551909425.webp	2764	2917	webp	90	581744	cmgsb5gpa0482h9i658tseb01
cmgsb5jor048fh9i6slv4siec	/public/images/full/027f691e-f28e-4ad1-82d9-e79a94ee9cc7-1760551911235.webp	3357	5085	webp	90	2069688	cmgsb5jop0489h9i6sv26uv45
cmgsb5lak048mh9i68k45whem	/public/images/medium/046c48ba-8215-4935-8a7b-7340364ba3a5-1760551915103.webp	800	880	webp	85	128828	cmgsb5lag048gh9i6tkx9xd6v
cmgsb69fm048rh9i6q79uu5b3	/public/images/full/467bf1ec-8d2a-448a-af3b-fa9fd191e9ed-1760551947204.webp	2859	2246	webp	90	479222	cmgsb69fi048nh9i6gjsl023u
cmgsb6b8a048yh9i6u0q160rk	/public/images/medium/89107657-4741-4547-b088-01bd17067a10-1760551917202.webp	800	1069	webp	85	149282	cmgsb6b85048uh9i6ai7gcvq4
cmgsb6bob0495h9i6d2jn3d9d	/public/images/medium/e19f1b9f-7b91-47d2-abf7-904fda086027-1760551948467.webp	800	566	webp	85	59704	cmgsb6bo90491h9i6mbntdhsw
cmgsb6g77049ch9i6ng0bcqj8	/public/images/medium/87f6b6ad-b3a0-43e4-85ec-0d3817fc1c3b-1760551951381.webp	800	1258	webp	85	93632	cmgsb6g740498h9i6upsl6a00
cmgsb6l5i049lh9i6vt9mvgnn	/public/images/thumbnails/c836aed1-45cb-45a8-aaf4-aac050c18848-1760551957247.webp	150	150	webp	80	5120	cmgsb6l5f049fh9i6467cdfdg
cmgsb6qi4049qh9i6j7jz5cad	/public/images/thumbnails/f498096a-9a32-414c-8ff2-38b36259df72-1760551963661.webp	150	150	webp	80	4660	cmgsb6qi2049mh9i6nc2c0arj
cmgsb6vjj049xh9i6lydz5akk	/public/images/thumbnails/6067ec42-f50b-452e-bfc2-02606fd4f08c-1760551970592.webp	150	150	webp	80	3844	cmgsb6vjd049th9i6dnjixt8n
cmgsb71sf04a5h9i6xsx3z8x0	/public/images/thumbnails/ce34a86f-6173-4cc9-8995-87872d7c6afe-1760551977132.webp	150	150	webp	80	3864	cmgsb71sb04a0h9i6qyaos8tt
cmgsb78mo04ach9i6d62iicox	/public/images/thumbnails/c0360d24-c267-4aed-b040-88856e54eba0-1760551985251.webp	150	150	webp	80	6786	cmgsb78mi04a7h9i6rtdvhqeg
cmgsb7k4j04ajh9i6mlasjfaq	/public/images/medium/e8063433-e9f7-4b03-ae9e-eaa226a331f1-1760551994098.webp	800	1216	webp	85	138062	cmgsb7k4c04aeh9i6hz4wpqx0
cmgsb7l3204aph9i6yc44z8c3	/public/images/full/b98d9172-4a1e-4af7-9722-270574762eac-1760552008979.webp	2420	2262	webp	90	252700	cmgsb7l2x04alh9i6uslk95xj
cmgsb7o1f04ayh9i6us0legi3	/public/images/full/e059fd9b-5574-476a-8049-5d5d505914c3-1760552010235.webp	3435	5163	webp	90	1645950	cmgsb7o1b04ash9i6l3izjv4w
cmgsb7p6904b4h9i6hdym6058	/public/images/thumbnails/6ca011c8-48c1-4d72-8734-869b2fe5c845-1760552014056.webp	150	150	webp	80	7156	cmgsb7p6604azh9i68ejs1zow
cmgsb7rlk04bbh9i6yqlvmqq2	/public/images/full/55aa7529-90ca-4d6a-8b6a-9855a402bed8-1760552015526.webp	2748	4523	webp	90	1800422	cmgsb7rlh04b6h9i6m8g6txmt
cmgsb7tmc04bhh9i6avte7v1u	/public/images/thumbnails/bfec01b2-ae3c-4d71-9a90-6d6e50d8a74b-1760552018672.webp	150	150	webp	80	7914	cmgsb7tm904bdh9i6azz9hv2f
cmgsb7ve804boh9i6i3yhec0e	/public/images/full/a37d2156-dc99-4a41-8c1c-f119f2f85361-1760552021290.webp	2698	3763	webp	90	823620	cmgsb7ve004bkh9i62h1jx6pa
cmgsb8g7g04bth9i6esdta4xl	/public/images/full/d472965c-6f71-4f6b-bd29-182072b3173b-1760552023610.webp	6120	8423	webp	90	2066806	cmgsb8g7b04brh9i6bd9zxdkf
cmgsb8h8604c4h9i6nn3ivbi2	/public/images/medium/1028ae0f-c2c0-460c-841e-bbaff6a89bcf-1760552050569.webp	800	1170	webp	85	143486	cmgsb8h8304byh9i6hdrho43q
cmgsb8j3504c9h9i64qi8aq4t	/public/images/thumbnails/2c3fb46e-e273-498e-8dab-1afdfee364c8-1760552051888.webp	150	150	webp	80	7690	cmgsb8j3104c5h9i6fx6ebx3b
cmgsb8mzi04cgh9i6aagr9tm2	/public/images/full/be8fcb8f-c76c-415f-aeb8-b57267abc457-1760552054304.webp	3591	5397	webp	90	4449982	cmgsb8mzd04cch9i6049qc4ol
cmgsb8qzy04cnh9i6rtnpomb1	/public/images/thumbnails/99739104-00e0-4386-83f2-e8fe0a5d6d36-1760552059350.webp	150	150	webp	80	5972	cmgsb8qzs04cjh9i66ou2uko8
cmgsb8vam04cuh9i6tmr7yt59	/public/images/thumbnails/ec21c83e-a578-4a2e-87ea-8f3ce7728c55-1760552064569.webp	150	150	webp	80	5878	cmgsb8vae04cqh9i6lpa65hv1
cmgsb8yza04d2h9i6uqzv3hvl	/public/images/medium/2c8fec11-419a-43e1-a75a-336da9315248-1760552070139.webp	800	646	webp	85	90922	cmgsb8yz604cxh9i62fo2bc2r
cmgsb93ew04dah9i6dr4w5fgd	/public/images/full/2c9fd953-5b4f-432b-baf2-2c1942355ac7-1760552074903.webp	3935	5311	webp	90	3575642	cmgsb93ej04d4h9i6cds3447t
cmgsb97et04ddh9i6qrld8hkd	/public/images/thumbnails/4bd122fd-9b24-4bd1-bb35-549adfe35199-1760552080673.webp	150	150	webp	80	7926	cmgsb97ek04dbh9i6b4u2g88d
cmgsb99o204doh9i6y2soacwt	/public/images/full/47c78c97-8ac4-45d5-bef3-20b356a73206-1760552085840.webp	2979	4528	webp	90	1151466	cmgsb99nz04dih9i6j3tx171x
cmgsb9b8404dth9i6kqnswbip	/public/images/thumbnails/9418ebcc-a1c5-4bb5-8c1a-3a31e2789602-1760552088739.webp	150	150	webp	80	6560	cmgsb9b7w04dph9i6hq5qfa9q
cmgsb9ccc04e1h9i6g1y2kkcw	/public/images/medium/1ec843cb-44c5-4a27-a0b9-e3807af056ab-1760552090767.webp	800	676	webp	85	89614	cmgsb9cca04dwh9i6ue9fmj5o
cmgsb9eq004e7h9i61kv6s1ti	/public/images/medium/fc734f32-92bb-4b3b-93d2-af26ae868e4c-1760552092200.webp	800	558	webp	85	69926	cmgsb9epm04e3h9i6gfd2u3tt
cmgsb9ib604efh9i62k76cs31	/public/images/medium/2e9d5ca4-07ff-4d3a-b911-49f21d6c7110-1760552095316.webp	800	573	webp	85	108916	cmgsb9ib304eah9i6jo9mseye
cmgsblkgz059jh9i61ajibxlq	/public/images/thumbnails/0326e275-ca83-4c11-8ce6-b504a5cc9cbe-1760552661267.webp	150	150	webp	80	8172	cmgsblkgv059eh9i61ako5ai7
cmgsb4bb6046fh9i6ik2nhrj3	/public/images/medium/e29bbb42-3fcd-41e5-885e-e2ad881e895b-1760551855624.webp	800	627	webp	85	78800	cmgsb4bb0046bh9i69rjevfs1
cmgsb4cfr046nh9i6qfb6397e	/public/images/thumbnails/eb911e1e-00c6-4bb5-8934-dc8c2f92aa33-1760551857585.webp	150	150	webp	80	6974	cmgsb4cfo046ih9i6csmhzxgb
cmgsb4wb6046rh9i6q8o23gch	/public/images/full/68c45ea3-9bd2-4c8d-9545-d5c5d218fea0-1760551859054.webp	7778	5359	webp	90	3615124	cmgsb4wb0046ph9i669azpjqz
cmgsb4zz20471h9i6izvu9gku	/public/images/full/bb8b00d0-348a-4ca6-9601-c30b19bf4876-1760551884817.webp	5601	3810	webp	90	1189058	cmgsb4zyy046wh9i6rgkbyjgr
cmgsb53rk0477h9i64dnak02f	/public/images/thumbnails/fc809317-1c2b-46e6-a82d-516f7594e2af-1760551889570.webp	150	150	webp	80	4980	cmgsb53rf0473h9i6ahod9gv3
cmgsb55v9047fh9i6jweihlss	/public/images/thumbnails/49af696e-9627-41df-8183-9c84cf283336-1760551894472.webp	150	150	webp	80	6642	cmgsb55v3047ah9i6xzhq3a5s
cmgsb5773047nh9i6mo2bdf2w	/public/images/medium/0ebc7983-6451-4371-b5c2-32779eb555cc-1760551897202.webp	800	1014	webp	85	100866	cmgsb576x047hh9i672qx0126
cmgsb5ae0047th9i6d965gn2j	/public/images/full/dd4d8a14-8684-4d71-8309-07a6f9986b9b-1760551898925.webp	3177	4464	webp	90	2155884	cmgsb5adw047oh9i619sde7zd
cmgsb5fb0047zh9i6dkdskapo	/public/images/medium/c3df6612-f952-4f5e-94ad-390406d6535e-1760551903069.webp	800	1170	webp	85	174004	cmgsb5faw047vh9i6kmpgfz8r
cmgsb5gpc0486h9i6ctvibclo	/public/images/thumbnails/1673f4b9-9573-492f-839d-e84f49bca57c-1760551909425.webp	150	150	webp	80	6524	cmgsb5gpa0482h9i658tseb01
cmgsb5jor048dh9i6s9g4m77h	/public/images/medium/027f691e-f28e-4ad1-82d9-e79a94ee9cc7-1760551911235.webp	800	1212	webp	85	202378	cmgsb5jop0489h9i6sv26uv45
cmgsb5lak048lh9i60cixe1se	/public/images/thumbnails/046c48ba-8215-4935-8a7b-7340364ba3a5-1760551915103.webp	150	150	webp	80	6710	cmgsb5lag048gh9i6tkx9xd6v
cmgsb69fm048th9i6cg80jsij	/public/images/medium/467bf1ec-8d2a-448a-af3b-fa9fd191e9ed-1760551947204.webp	800	629	webp	85	66090	cmgsb69fi048nh9i6gjsl023u
cmgsb6b8a048zh9i6n5ki6fcq	/public/images/thumbnails/89107657-4741-4547-b088-01bd17067a10-1760551917202.webp	150	150	webp	80	8970	cmgsb6b85048uh9i6ai7gcvq4
cmgsb6boc0497h9i6fuh7ed46	/public/images/full/e19f1b9f-7b91-47d2-abf7-904fda086027-1760551948467.webp	4972	3523	webp	90	1178220	cmgsb6bo90491h9i6mbntdhsw
cmgsb6g77049dh9i6ftrg8s64	/public/images/thumbnails/87f6b6ad-b3a0-43e4-85ec-0d3817fc1c3b-1760551951381.webp	150	150	webp	80	4586	cmgsb6g740498h9i6upsl6a00
cmgsb6l5i049hh9i60y3pcwyt	/public/images/medium/c836aed1-45cb-45a8-aaf4-aac050c18848-1760551957247.webp	800	529	webp	85	67844	cmgsb6l5f049fh9i6467cdfdg
cmgsb6qi4049sh9i6wlj4azsw	/public/images/full/f498096a-9a32-414c-8ff2-38b36259df72-1760551963661.webp	7738	5139	webp	90	1609984	cmgsb6qi2049mh9i6nc2c0arj
cmgsb6vjj049yh9i6iffsj6sa	/public/images/medium/6067ec42-f50b-452e-bfc2-02606fd4f08c-1760551970592.webp	800	497	webp	85	41982	cmgsb6vjd049th9i6dnjixt8n
cmgsb71sf04a6h9i6dql57slg	/public/images/full/ce34a86f-6173-4cc9-8995-87872d7c6afe-1760551977132.webp	7778	5139	webp	90	1326700	cmgsb71sb04a0h9i6qyaos8tt
cmgsb78mo04abh9i6iswrdpfc	/public/images/medium/c0360d24-c267-4aed-b040-88856e54eba0-1760551985251.webp	800	523	webp	85	60056	cmgsb78mi04a7h9i6rtdvhqeg
cmgsb7k4j04agh9i66ttccmjj	/public/images/thumbnails/e8063433-e9f7-4b03-ae9e-eaa226a331f1-1760551994098.webp	150	150	webp	80	6046	cmgsb7k4c04aeh9i6hz4wpqx0
cmgsb7l3204aqh9i64amygb47	/public/images/thumbnails/b98d9172-4a1e-4af7-9722-270574762eac-1760552008979.webp	150	150	webp	80	4878	cmgsb7l2x04alh9i6uslk95xj
cmgsb7o1f04axh9i6zqggj31m	/public/images/thumbnails/e059fd9b-5574-476a-8049-5d5d505914c3-1760552010235.webp	150	150	webp	80	6568	cmgsb7o1b04ash9i6l3izjv4w
cmgsb7p6904b5h9i6bgit9esy	/public/images/full/6ca011c8-48c1-4d72-8734-869b2fe5c845-1760552014056.webp	2764	2090	webp	90	596524	cmgsb7p6604azh9i68ejs1zow
cmgsb7rlk04bah9i61q7le2dg	/public/images/medium/55aa7529-90ca-4d6a-8b6a-9855a402bed8-1760552015526.webp	800	1316	webp	85	276308	cmgsb7rlh04b6h9i6m8g6txmt
cmgsb7tmc04bih9i6lt0hkfcp	/public/images/medium/bfec01b2-ae3c-4d71-9a90-6d6e50d8a74b-1760552018672.webp	800	1305	webp	85	229800	cmgsb7tm904bdh9i6azz9hv2f
cmgsb7ve804bph9i6rrs6qme4	/public/images/medium/a37d2156-dc99-4a41-8c1c-f119f2f85361-1760552021290.webp	800	1115	webp	85	113438	cmgsb7ve004bkh9i62h1jx6pa
cmgsb8g7i04bwh9i6mwp8xlwm	/public/images/medium/d472965c-6f71-4f6b-bd29-182072b3173b-1760552023610.webp	800	1101	webp	85	83186	cmgsb8g7b04brh9i6bd9zxdkf
cmgsb8h8604c2h9i6rdz0z52o	/public/images/full/1028ae0f-c2c0-460c-841e-bbaff6a89bcf-1760552050569.webp	1793	2623	webp	90	427634	cmgsb8h8304byh9i6hdrho43q
cmgsb8j3504cah9i6ffx7fqqo	/public/images/medium/2c3fb46e-e273-498e-8dab-1afdfee364c8-1760552051888.webp	800	810	webp	85	114558	cmgsb8j3104c5h9i6fx6ebx3b
cmgsb8mzi04chh9i6bowaniij	/public/images/thumbnails/be8fcb8f-c76c-415f-aeb8-b57267abc457-1760552054304.webp	150	150	webp	80	5916	cmgsb8mzd04cch9i6049qc4ol
cmgsb8qzy04cph9i6frjpc9eo	/public/images/medium/99739104-00e0-4386-83f2-e8fe0a5d6d36-1760552059350.webp	800	532	webp	85	115158	cmgsb8qzs04cjh9i66ou2uko8
cmgsb8vak04csh9i69cxosbii	/public/images/medium/ec21c83e-a578-4a2e-87ea-8f3ce7728c55-1760552064569.webp	800	1202	webp	85	318954	cmgsb8vae04cqh9i6lpa65hv1
cmgsb8yza04d3h9i6ss6eo0bh	/public/images/full/2c8fec11-419a-43e1-a75a-336da9315248-1760552070139.webp	5543	4477	webp	90	2092604	cmgsb8yz604cxh9i62fo2bc2r
cmgsb93ev04d8h9i60m6pw1r1	/public/images/thumbnails/2c9fd953-5b4f-432b-baf2-2c1942355ac7-1760552074903.webp	150	150	webp	80	7568	cmgsb93ej04d4h9i6cds3447t
cmgsb97eu04dfh9i6e83adly6	/public/images/medium/4bd122fd-9b24-4bd1-bb35-549adfe35199-1760552080673.webp	800	1224	webp	85	158886	cmgsb97ek04dbh9i6b4u2g88d
cmgsb99o204dnh9i6fklwl8t0	/public/images/medium/47c78c97-8ac4-45d5-bef3-20b356a73206-1760552085840.webp	800	1216	webp	85	135164	cmgsb99nz04dih9i6j3tx171x
cmgsb9b8404dvh9i6gxsffssz	/public/images/full/9418ebcc-a1c5-4bb5-8c1a-3a31e2789602-1760552088739.webp	4044	2854	webp	90	861192	cmgsb9b7w04dph9i6hq5qfa9q
cmgsb9ccc04e2h9i6yfty34me	/public/images/full/1ec843cb-44c5-4a27-a0b9-e3807af056ab-1760552090767.webp	3132	2647	webp	90	552564	cmgsb9cca04dwh9i6ue9fmj5o
cmgsb9epw04e5h9i6gvdhzh29	/public/images/thumbnails/fc734f32-92bb-4b3b-93d2-af26ae868e4c-1760552092200.webp	150	150	webp	80	6928	cmgsb9epm04e3h9i6gfd2u3tt
cmgsb9ib604egh9i650nnqjc3	/public/images/full/2e9d5ca4-07ff-4d3a-b911-49f21d6c7110-1760552095316.webp	5220	3738	webp	90	1573610	cmgsb9ib304eah9i6jo9mseye
cmgsblmrt059ph9i6jwz3st1r	/public/images/full/65db0f36-001c-4194-a0c7-e357f16cd2c5-1760552662618.webp	3463	4981	webp	90	2509980	cmgsblmrq059lh9i6hf5y6s2c
cmgsb4bb6046hh9i6mmxw4h7y	/public/images/thumbnails/e29bbb42-3fcd-41e5-885e-e2ad881e895b-1760551855624.webp	150	150	webp	80	7026	cmgsb4bb0046bh9i69rjevfs1
cmgsb4cfr046mh9i6vh3htddf	/public/images/medium/eb911e1e-00c6-4bb5-8934-dc8c2f92aa33-1760551857585.webp	800	879	webp	85	79082	cmgsb4cfo046ih9i6csmhzxgb
cmgsb4wb7046th9i6o7575yfj	/public/images/medium/68c45ea3-9bd2-4c8d-9545-d5c5d218fea0-1760551859054.webp	800	551	webp	85	126926	cmgsb4wb0046ph9i669azpjqz
cmgsb4zz20470h9i6jhhqzdnp	/public/images/medium/bb8b00d0-348a-4ca6-9601-c30b19bf4876-1760551884817.webp	800	544	webp	85	68788	cmgsb4zyy046wh9i6rgkbyjgr
cmgsb53rk0479h9i6i1j07ek6	/public/images/full/fc809317-1c2b-46e6-a82d-516f7594e2af-1760551889570.webp	5106	3588	webp	90	1964572	cmgsb53rf0473h9i6ahod9gv3
cmgsb55v9047dh9i65vnl6yf7	/public/images/medium/49af696e-9627-41df-8183-9c84cf283336-1760551894472.webp	800	1293	webp	85	97460	cmgsb55v3047ah9i6xzhq3a5s
cmgsb5773047lh9i6seyegod5	/public/images/thumbnails/0ebc7983-6451-4371-b5c2-32779eb555cc-1760551897202.webp	150	150	webp	80	7916	cmgsb576x047hh9i672qx0126
cmgsb5adz047qh9i6wm15a5a7	/public/images/thumbnails/dd4d8a14-8684-4d71-8309-07a6f9986b9b-1760551898925.webp	150	150	webp	80	5664	cmgsb5adw047oh9i619sde7zd
cmgsb5fb00481h9i6wl667d9m	/public/images/full/c3df6612-f952-4f5e-94ad-390406d6535e-1760551903069.webp	3743	5472	webp	90	3598388	cmgsb5faw047vh9i6kmpgfz8r
cmgsb5gpc0487h9i6cwf43sdj	/public/images/medium/1673f4b9-9573-492f-839d-e84f49bca57c-1760551909425.webp	800	844	webp	85	92586	cmgsb5gpa0482h9i658tseb01
cmgsb5jor048ch9i6t6i82g3u	/public/images/thumbnails/027f691e-f28e-4ad1-82d9-e79a94ee9cc7-1760551911235.webp	150	150	webp	80	6000	cmgsb5jop0489h9i6sv26uv45
cmgsb5lak048kh9i6fqomeuna	/public/images/full/046c48ba-8215-4935-8a7b-7340364ba3a5-1760551915103.webp	2779	3057	webp	90	805556	cmgsb5lag048gh9i6tkx9xd6v
cmgsb69fl048ph9i6pdg7wpd4	/public/images/thumbnails/467bf1ec-8d2a-448a-af3b-fa9fd191e9ed-1760551947204.webp	150	150	webp	80	5626	cmgsb69fi048nh9i6gjsl023u
cmgsb6b8a0490h9i67jfkfzco	/public/images/full/89107657-4741-4547-b088-01bd17067a10-1760551917202.webp	5887	7862	webp	90	6926882	cmgsb6b85048uh9i6ai7gcvq4
cmgsb6bob0494h9i6mhy6brjy	/public/images/thumbnails/e19f1b9f-7b91-47d2-abf7-904fda086027-1760551948467.webp	150	150	webp	80	3814	cmgsb6bo90491h9i6mbntdhsw
cmgsb6g77049eh9i65xcpo26g	/public/images/full/87f6b6ad-b3a0-43e4-85ec-0d3817fc1c3b-1760551951381.webp	4819	7578	webp	90	1099898	cmgsb6g740498h9i6upsl6a00
cmgsb6l5i049kh9i6ve40vszv	/public/images/full/c836aed1-45cb-45a8-aaf4-aac050c18848-1760551957247.webp	7678	5079	webp	90	1827166	cmgsb6l5f049fh9i6467cdfdg
cmgsb6qi4049rh9i6g74j6vke	/public/images/medium/f498096a-9a32-414c-8ff2-38b36259df72-1760551963661.webp	800	531	webp	85	56142	cmgsb6qi2049mh9i6nc2c0arj
cmgsb6vjj049zh9i6gylo5xbv	/public/images/full/6067ec42-f50b-452e-bfc2-02606fd4f08c-1760551970592.webp	7758	4819	webp	90	1387452	cmgsb6vjd049th9i6dnjixt8n
cmgsb71se04a2h9i6hz0wopjq	/public/images/medium/ce34a86f-6173-4cc9-8995-87872d7c6afe-1760551977132.webp	800	528	webp	85	42370	cmgsb71sb04a0h9i6qyaos8tt
cmgsb78mo04adh9i6sowi15u5	/public/images/full/c0360d24-c267-4aed-b040-88856e54eba0-1760551985251.webp	7758	5079	webp	90	1916198	cmgsb78mi04a7h9i6rtdvhqeg
cmgsb7k4j04akh9i66nzlqifm	/public/images/full/e8063433-e9f7-4b03-ae9e-eaa226a331f1-1760551994098.webp	5079	7718	webp	90	2240432	cmgsb7k4c04aeh9i6hz4wpqx0
cmgsb7l3204arh9i6kalpvveg	/public/images/medium/b98d9172-4a1e-4af7-9722-270574762eac-1760552008979.webp	800	748	webp	85	46460	cmgsb7l2x04alh9i6uslk95xj
cmgsb7o1f04awh9i6imzf5vkh	/public/images/medium/e059fd9b-5574-476a-8049-5d5d505914c3-1760552010235.webp	800	1203	webp	85	176540	cmgsb7o1b04ash9i6l3izjv4w
cmgsb7p6904b3h9i63aq79oxp	/public/images/medium/6ca011c8-48c1-4d72-8734-869b2fe5c845-1760552014056.webp	800	605	webp	85	99646	cmgsb7p6604azh9i68ejs1zow
cmgsb7rlk04bch9i6zfvb0rbf	/public/images/thumbnails/55aa7529-90ca-4d6a-8b6a-9855a402bed8-1760552015526.webp	150	150	webp	80	6826	cmgsb7rlh04b6h9i6m8g6txmt
cmgsb7tmc04bjh9i6k6fo92od	/public/images/full/bfec01b2-ae3c-4d71-9a90-6d6e50d8a74b-1760552018672.webp	2651	4325	webp	90	1177832	cmgsb7tm904bdh9i6azz9hv2f
cmgsb7ve804bqh9i6msgpifsb	/public/images/thumbnails/a37d2156-dc99-4a41-8c1c-f119f2f85361-1760552021290.webp	150	150	webp	80	4716	cmgsb7ve004bkh9i62h1jx6pa
cmgsb8g7i04bxh9i6dst6y48u	/public/images/thumbnails/d472965c-6f71-4f6b-bd29-182072b3173b-1760552023610.webp	150	150	webp	80	3948	cmgsb8g7b04brh9i6bd9zxdkf
cmgsb8h8604c3h9i6adysl4b8	/public/images/thumbnails/1028ae0f-c2c0-460c-841e-bbaff6a89bcf-1760552050569.webp	150	150	webp	80	7496	cmgsb8h8304byh9i6hdrho43q
cmgsb8j3504cbh9i61s67oz1m	/public/images/full/2c3fb46e-e273-498e-8dab-1afdfee364c8-1760552051888.webp	3388	3432	webp	90	993540	cmgsb8j3104c5h9i6fx6ebx3b
cmgsb8mzi04cih9i6244s9k5e	/public/images/medium/be8fcb8f-c76c-415f-aeb8-b57267abc457-1760552054304.webp	800	1202	webp	85	266336	cmgsb8mzd04cch9i6049qc4ol
cmgsb8qzy04coh9i6okyx2ita	/public/images/full/99739104-00e0-4386-83f2-e8fe0a5d6d36-1760552059350.webp	5397	3591	webp	90	5565182	cmgsb8qzs04cjh9i66ou2uko8
cmgsblmrt059rh9i6viomb62m	/public/images/medium/65db0f36-001c-4194-a0c7-e357f16cd2c5-1760552662618.webp	800	1151	webp	85	220188	cmgsblmrq059lh9i6hf5y6s2c
cmgsblnvs059wh9i6w1jmc4gg	/public/images/full/f0039f3f-4bd2-429e-81d1-aa1d3b106481-1760552665593.webp	3279	2745	webp	90	861362	cmgsblnvp059sh9i6yujbx6at
cmgsblp5605a5h9i65bsd8hei	/public/images/full/9fc2bf71-12c0-4f4d-bba6-4857b2183882-1760552667034.webp	2592	4040	webp	90	578716	cmgsblp54059zh9i6lhynfigz
cmgsblqbv05a8h9i6f7taw50t	/public/images/thumbnails/afea6966-b391-4c84-b2fe-d010c1832584-1760552668668.webp	150	150	webp	80	5414	cmgsblqbt05a6h9i665xoa4ja
cmgsblr2b05ajh9i6n88zpr5u	/public/images/full/2954fbcc-dd2d-47f1-ac3b-3eba385a7329-1760552670203.webp	1717	2698	webp	90	455126	cmgsblr2705adh9i64ei3eli8
cmgsblsmq05aqh9i6zbmfutov	/public/images/full/e29e253b-f183-4382-90fd-192d39760bba-1760552671159.webp	4403	3041	webp	90	1281702	cmgsblsmo05akh9i6y2sq8avm
cmgsbltze05axh9i61refxmhq	/public/images/thumbnails/7d1826c2-4725-4ffa-ba2d-0ddf401a2514-1760552673190.webp	150	150	webp	80	6376	cmgsbltzc05arh9i63bw4trp2
cmgsblv7m05b4h9i6libof0lf	/public/images/full/3348b349-1c24-4d09-923c-22f35dc9f8d2-1760552674938.webp	2654	4087	webp	90	598762	cmgsblv7k05ayh9i6q4ij4orm
cmgsblwdl05bbh9i6nlx9v9ez	/public/images/thumbnails/8179831f-3599-4611-b34d-655a09857bac-1760552676528.webp	150	150	webp	80	5854	cmgsblwdj05b5h9i6mfe4ughy
cmgsblxvq05beh9i6n1bpah6t	/public/images/thumbnails/3d0fe59b-456e-49ba-98fc-238a40cac5a1-1760552678051.webp	150	150	webp	80	6468	cmgsblxvn05bch9i6x0w9kpvh
cmgsb8vb304cwh9i69iridw3f	/public/images/full/ec21c83e-a578-4a2e-87ea-8f3ce7728c55-1760552064569.webp	3591	5397	webp	90	5610652	cmgsb8vae04cqh9i6lpa65hv1
cmgsb8yza04d0h9i6uo8cyrmi	/public/images/thumbnails/2c8fec11-419a-43e1-a75a-336da9315248-1760552070139.webp	150	150	webp	80	8446	cmgsb8yz604cxh9i62fo2bc2r
cmgsb93ev04d7h9i6g5ci6gwh	/public/images/medium/2c9fd953-5b4f-432b-baf2-2c1942355ac7-1760552074903.webp	800	1080	webp	85	160120	cmgsb93ej04d4h9i6cds3447t
cmgsb97ew04dhh9i68cuepjfd	/public/images/full/4bd122fd-9b24-4bd1-bb35-549adfe35199-1760552080673.webp	3774	5776	webp	90	2309888	cmgsb97ek04dbh9i6b4u2g88d
cmgsb99o204dlh9i682155ljl	/public/images/thumbnails/47c78c97-8ac4-45d5-bef3-20b356a73206-1760552085840.webp	150	150	webp	80	5932	cmgsb99nz04dih9i6j3tx171x
cmgsb9b8304drh9i6jggyfv22	/public/images/medium/9418ebcc-a1c5-4bb5-8c1a-3a31e2789602-1760552088739.webp	800	564	webp	85	57658	cmgsb9b7w04dph9i6hq5qfa9q
cmgsb9ccc04e0h9i619k3vv4j	/public/images/thumbnails/1ec843cb-44c5-4a27-a0b9-e3807af056ab-1760552090767.webp	150	150	webp	80	7838	cmgsb9cca04dwh9i6ue9fmj5o
cmgsb9eq004e9h9i6ggv2sh6q	/public/images/full/fc734f32-92bb-4b3b-93d2-af26ae868e4c-1760552092200.webp	4992	3484	webp	90	1025288	cmgsb9epm04e3h9i6gfd2u3tt
cmgsb9ib604ech9i61hux2jus	/public/images/thumbnails/2e9d5ca4-07ff-4d3a-b911-49f21d6c7110-1760552095316.webp	150	150	webp	80	10590	cmgsb9ib304eah9i6jo9mseye
cmgsb9ndf04elh9i6dhhyitex	/public/images/full/dd1f23e8-f25e-4c48-97bc-7cc201d0ee07-1760552099940.webp	3726	5262	webp	90	2379306	cmgsb9nda04ehh9i6pxnmfokk
cmgsb9ndf04ejh9i6fhscd3ho	/public/images/thumbnails/dd1f23e8-f25e-4c48-97bc-7cc201d0ee07-1760552099940.webp	150	150	webp	80	8006	cmgsb9nda04ehh9i6pxnmfokk
cmgsb9ne904enh9i6aqul4nf9	/public/images/medium/dd1f23e8-f25e-4c48-97bc-7cc201d0ee07-1760552099940.webp	800	1130	webp	85	205972	cmgsb9nda04ehh9i6pxnmfokk
cmgsb9q7y04euh9i6cz6loahp	/public/images/full/d7391cdd-8260-4719-affe-c10b846f9c4f-1760552106539.webp	3307	4544	webp	90	872312	cmgsb9q7s04eoh9i6kdbri21d
cmgsb9q7x04erh9i6kdbf59vk	/public/images/medium/d7391cdd-8260-4719-affe-c10b846f9c4f-1760552106539.webp	800	1100	webp	85	89358	cmgsb9q7s04eoh9i6kdbri21d
cmgsb9q7x04esh9i6nipflsjy	/public/images/thumbnails/d7391cdd-8260-4719-affe-c10b846f9c4f-1760552106539.webp	150	150	webp	80	7012	cmgsb9q7s04eoh9i6kdbri21d
cmgsb9sys04f0h9i6itn8mbzr	/public/images/full/c6de35d6-2c07-40ca-af07-5fa171aead8e-1760552110207.webp	3291	4606	webp	90	585996	cmgsb9syk04evh9i6v5i4vii0
cmgsb9sys04ezh9i61jepg7d4	/public/images/medium/c6de35d6-2c07-40ca-af07-5fa171aead8e-1760552110207.webp	800	1120	webp	85	49788	cmgsb9syk04evh9i6v5i4vii0
cmgsb9sys04f1h9i64wf2bk4f	/public/images/thumbnails/c6de35d6-2c07-40ca-af07-5fa171aead8e-1760552110207.webp	150	150	webp	80	3958	cmgsb9syk04evh9i6v5i4vii0
cmgsb9wqw04f7h9i6fpe9rb7e	/public/images/medium/b0bf7e77-92b7-4cc7-ac49-48fc6a5c06db-1760552113764.webp	800	561	webp	85	85074	cmgsb9wqu04f2h9i6ukq7votf
cmgsb9wqw04f8h9i66kysv5rf	/public/images/full/b0bf7e77-92b7-4cc7-ac49-48fc6a5c06db-1760552113764.webp	5231	3666	webp	90	1386614	cmgsb9wqu04f2h9i6ukq7votf
cmgsb9wqw04f6h9i6jdewrl3d	/public/images/thumbnails/b0bf7e77-92b7-4cc7-ac49-48fc6a5c06db-1760552113764.webp	150	150	webp	80	8480	cmgsb9wqu04f2h9i6ukq7votf
cmgsb9yw004feh9i67uzodsql	/public/images/full/7bf2ba6d-729e-4ffd-99f6-8a3dd8763b6b-1760552118652.webp	3997	2636	webp	90	839668	cmgsb9yvv04f9h9i684o0rkbx
cmgsb9yw004ffh9i6hsa9gn17	/public/images/medium/7bf2ba6d-729e-4ffd-99f6-8a3dd8763b6b-1760552118652.webp	800	528	webp	85	60856	cmgsb9yvv04f9h9i684o0rkbx
cmgsb9yw004fdh9i6nrw3teh4	/public/images/thumbnails/7bf2ba6d-729e-4ffd-99f6-8a3dd8763b6b-1760552118652.webp	150	150	webp	80	4660	cmgsb9yvv04f9h9i684o0rkbx
cmgsba0iy04fih9i64bbjhv40	/public/images/medium/63bd390f-5138-4f35-944d-a30ca05fbc05-1760552121426.webp	800	548	webp	85	41404	cmgsba0is04fgh9i66nj3k9ii
cmgsba0iz04fmh9i6xk6vz1ec	/public/images/full/63bd390f-5138-4f35-944d-a30ca05fbc05-1760552121426.webp	3529	2417	webp	90	434270	cmgsba0is04fgh9i66nj3k9ii
cmgsba0iz04flh9i6pwn75rgx	/public/images/thumbnails/63bd390f-5138-4f35-944d-a30ca05fbc05-1760552121426.webp	150	150	webp	80	5164	cmgsba0is04fgh9i66nj3k9ii
cmgsba2hc04fqh9i6ftd6ukff	/public/images/medium/c987be5a-2bea-4fbc-8fec-1a660cde1ec8-1760552123544.webp	800	1075	webp	85	95894	cmgsba2h004fnh9i64fzvtkch
cmgsba2hc04fsh9i697znw67h	/public/images/thumbnails/c987be5a-2bea-4fbc-8fec-1a660cde1ec8-1760552123544.webp	150	150	webp	80	5686	cmgsba2h004fnh9i64fzvtkch
cmgsba2hc04fth9i6xgi8ux4d	/public/images/full/c987be5a-2bea-4fbc-8fec-1a660cde1ec8-1760552123544.webp	2681	3603	webp	90	669676	cmgsba2h004fnh9i64fzvtkch
cmgsba61o04fyh9i6nenzr3zj	/public/images/full/096c3964-bded-4437-a1f5-13ca6f3a4161-1760552126092.webp	5294	3603	webp	90	1668254	cmgsba61h04fuh9i64t16vybw
cmgsba61o04g0h9i6delwfrg4	/public/images/thumbnails/096c3964-bded-4437-a1f5-13ca6f3a4161-1760552126092.webp	150	150	webp	80	6122	cmgsba61h04fuh9i64t16vybw
cmgsba61o04fzh9i6bgyepbi8	/public/images/medium/096c3964-bded-4437-a1f5-13ca6f3a4161-1760552126092.webp	800	544	webp	85	64830	cmgsba61h04fuh9i64t16vybw
cmgsba9vg04g5h9i63aa87roh	/public/images/medium/16698130-20b9-4975-bdc0-68261c5ec6bd-1760552130720.webp	800	1102	webp	85	110008	cmgsba9vb04g1h9i6beurmq10
cmgsba9vg04g7h9i6ne8x347q	/public/images/full/16698130-20b9-4975-bdc0-68261c5ec6bd-1760552130720.webp	3833	5279	webp	90	1258418	cmgsba9vb04g1h9i6beurmq10
cmgsba9vg04g4h9i6smk4bcmo	/public/images/thumbnails/16698130-20b9-4975-bdc0-68261c5ec6bd-1760552130720.webp	150	150	webp	80	7152	cmgsba9vb04g1h9i6beurmq10
cmgsbaec404gah9i6uoawg6ls	/public/images/thumbnails/4df7cc42-9f42-4339-a5c6-47d417ac8b34-1760552135675.webp	150	150	webp	80	8848	cmgsbaec204g8h9i6t749hwf1
cmgsbaec404gdh9i6u4jkzcrt	/public/images/medium/4df7cc42-9f42-4339-a5c6-47d417ac8b34-1760552135675.webp	800	570	webp	85	82384	cmgsbaec204g8h9i6t749hwf1
cmgsbaec404geh9i6y8uz7d8v	/public/images/full/4df7cc42-9f42-4339-a5c6-47d417ac8b34-1760552135675.webp	5278	3759	webp	90	1336576	cmgsbaec204g8h9i6t749hwf1
cmgsbahhk04gjh9i6t0dfxyko	/public/images/full/165b32cc-eacd-4c29-9d86-44933b08fb54-1760552141441.webp	5091	3665	webp	90	1082610	cmgsbahhh04gfh9i690btdwp1
cmgsbahhk04glh9i66g8e1hbq	/public/images/medium/165b32cc-eacd-4c29-9d86-44933b08fb54-1760552141441.webp	800	576	webp	85	50702	cmgsbahhh04gfh9i690btdwp1
cmgsbahhk04gkh9i6w8hoe6k7	/public/images/thumbnails/165b32cc-eacd-4c29-9d86-44933b08fb54-1760552141441.webp	150	150	webp	80	5942	cmgsbahhh04gfh9i690btdwp1
cmgsbajp604gsh9i64ntfl4zm	/public/images/full/13c3d986-1656-4788-a4a5-13ef02d55781-1760552145527.webp	3225	4483	webp	90	789888	cmgsbajp304gmh9i6xfp7rj06
cmgsbajp604grh9i60qhq15fb	/public/images/thumbnails/13c3d986-1656-4788-a4a5-13ef02d55781-1760552145527.webp	150	150	webp	80	4928	cmgsbajp304gmh9i6xfp7rj06
cmgsbam5e04gyh9i68br41ftb	/public/images/medium/23bf70a1-209b-4618-8880-df64f8408677-1760552148391.webp	800	1118	webp	85	93870	cmgsbam5b04gth9i6dfp8o2il
cmgsbaobf04h3h9i6udcm36zo	/public/images/medium/e35c7955-6f32-48b3-b41d-6cd07ef30b93-1760552151573.webp	800	572	webp	85	57584	cmgsbaobd04h0h9i6ac2tbwi0
cmgsbarb104h9h9i6yksi4hx5	/public/images/medium/70d70acc-74ee-40d2-9326-db4b4e359dd3-1760552154388.webp	800	1101	webp	85	131930	cmgsbaray04h7h9i6do56oz12
cmgsbb7h704hkh9i6bgtdd2af	/public/images/full/15ef6fc3-b737-4fd4-8c8f-266f97881b7d-1760552158269.webp	5908	8169	webp	90	2884668	cmgsbb7h504heh9i653zkb3c6
cmgsbb9pl04hqh9i69qgh059x	/public/images/thumbnails/938f91ba-35e1-47c7-b528-312e740ffc0e-1760552179215.webp	150	150	webp	80	9718	cmgsbb9pi04hlh9i6nt42rjr0
cmgsbbbvy04hwh9i6e31371qt	/public/images/full/7e869bf1-9765-45c4-9a44-b1d7d528257a-1760552182109.webp	5340	3697	webp	90	1251164	cmgsbbbvu04hsh9i680b761ad
cmgsbbdl004i4h9i6ebeomzw2	/public/images/thumbnails/a5866442-1560-4833-b72d-ab2dee785b23-1760552184934.webp	150	150	webp	80	6838	cmgsbbdkr04hzh9i6r3edl1q3
cmgsbbgn304ibh9i6dpj4vwxp	/public/images/thumbnails/f03be9b3-f1c5-4b25-8f8a-787aa6aab99a-1760552187137.webp	150	150	webp	80	10046	cmgsbbgmz04i6h9i6nleqji7r
cmgsbbjmx04iih9i6qohdbzbk	/public/images/medium/1d0afbda-92d1-404f-87d4-af829209d2f5-1760552191087.webp	800	580	webp	85	60446	cmgsbbjmu04idh9i6c3c2kppk
cmgsbbmoh04iph9i6zxpyeec4	/public/images/thumbnails/0b44f7e7-270b-4962-b3ad-1144bf613c32-1760552194975.webp	150	150	webp	80	7476	cmgsbbmof04ikh9i6kz6xxe7o
cmgsbbpwb04ixh9i6ryltac1i	/public/images/medium/7e7d26ee-9df6-4caa-b923-8791f7ebd076-1760552198911.webp	800	1059	webp	85	72146	cmgsbbpw804irh9i6sgp3mwln
cmgsbbt7704j3h9i6cr623ntl	/public/images/medium/d4acbc57-ae65-4215-80b9-8f81da29cccc-1760552203088.webp	800	583	webp	85	128620	cmgsbbt7304iyh9i61r5w30jp
cmgsbbvgb04jbh9i6gli0hf3e	/public/images/medium/6d97fab4-17b8-43ef-b85e-74701b41d15e-1760552207362.webp	800	1116	webp	85	90024	cmgsbbvg904j5h9i602lfqfwp
cmgsbbxig04jhh9i6y8fj0ymq	/public/images/medium/d487cd32-1454-4cf1-836e-94d8e7d9f3f8-1760552210285.webp	800	1102	webp	85	92256	cmgsbbxie04jch9i6ivydyurw
cmgsbbzoh04jnh9i6tlip9b7e	/public/images/full/acada9f6-e48f-4064-82a4-1ef2629008a3-1760552212959.webp	5184	3868	webp	90	1493238	cmgsbbzoc04jjh9i6316ib22t
cmgsbc1xm04jvh9i6phq7b8ki	/public/images/full/e216943f-1ede-41d7-89ac-071bb79f96aa-1760552215768.webp	5372	3931	webp	90	1225656	cmgsbc1xk04jqh9i6fe2x4geu
cmgsbc49j04k2h9i67fwrgqrb	/public/images/medium/246cabea-eda5-4148-8ffb-2cb082d360c4-1760552218686.webp	800	1139	webp	85	105228	cmgsbc49g04jxh9i6ahifcqea
cmgsbc6bo04kah9i6de75u19f	/public/images/thumbnails/9893a771-2775-4c7d-9dad-92354d2712d1-1760552221706.webp	150	150	webp	80	5344	cmgsbc6bm04k4h9i65uywyowf
cmgsbc8hv04kgh9i6k0zqblga	/public/images/medium/0ed4fa87-9183-4fe2-a3e2-7869d88d2649-1760552224372.webp	800	1093	webp	85	154232	cmgsbc8ht04kbh9i69v86m2fd
cmgsbc9tl04klh9i6w8pjq3ju	/public/images/thumbnails/77c75675-d86a-44d8-ac7e-1c9bc40a15b4-1760552227188.webp	150	150	webp	80	5706	cmgsbc9tj04kih9i6t925l6m5
cmgsbcb2x04kuh9i6vshdk1kt	/public/images/thumbnails/7409a449-a889-46b6-8823-fb1837cf6b06-1760552228903.webp	150	150	webp	80	6692	cmgsbcb2v04kph9i64wv0jd4x
cmgsbcc4y04l1h9i6oe72migk	/public/images/medium/49c585ca-e0a3-4870-93fb-282944d901f6-1760552230538.webp	800	1264	webp	85	150010	cmgsbcc4w04kwh9i6hgh945ug
cmgsbcdpo04l7h9i60ylt3ssf	/public/images/medium/97feb573-053e-45d2-81fc-75834e1193f1-1760552231909.webp	800	1104	webp	85	192714	cmgsbcdpm04l3h9i662j5zpq1
cmgsbcg3f04lgh9i69o4paupn	/public/images/full/63259dbd-144b-427e-84b6-23f3cfb432d9-1760552233958.webp	5169	3525	webp	90	2255462	cmgsbcg3c04lah9i6xuqsxyyw
cmgsbci5e04lmh9i62tt53fxd	/public/images/medium/5d8a080b-3d7d-4e3e-bb20-d5577f4e5918-1760552237038.webp	800	990	webp	85	120360	cmgsbci5c04lhh9i682754n2l
cmgsbcj0f04luh9i67tu3cyrh	/public/images/full/3133c096-133a-4e5e-ab2c-027c69f1a410-1760552239698.webp	2043	3060	webp	90	451776	cmgsbcj0d04loh9i6cia0yfci
cmgsbcjv304lyh9i6ym632ywi	/public/images/thumbnails/b1e55aaa-c088-452a-9fa5-4705620374d1-1760552240814.webp	150	150	webp	80	8386	cmgsbcjv004lvh9i6mxvovl4z
cmgsbckry04m8h9i6ycel6gus	/public/images/medium/b9566c40-f1d2-48e3-9d5d-70a4c6cb62ba-1760552241919.webp	800	1134	webp	85	104264	cmgsbckrv04m2h9i6g6w87xmq
cmgsbclyv04meh9i6su1mp05e	/public/images/medium/68b6d763-0e58-4b5e-95cf-ff6377118e31-1760552243104.webp	800	1064	webp	85	92996	cmgsbclyt04m9h9i69jziw4p7
cmgsbcn9d04mlh9i6d9nz6zgi	/public/images/medium/9233f14d-e9fd-4e0d-a2fe-2315e9b2ec3a-1760552244650.webp	800	515	webp	85	113836	cmgsbcn9b04mgh9i6v7j71ym4
cmgsbco3604mth9i6saxff5b7	/public/images/full/67f9fac4-dbcc-4e64-974a-1a5952cfc798-1760552246321.webp	2779	2121	webp	90	463022	cmgsbco3404mnh9i6u8dbw9yx
cmgsbcpqn04mxh9i65701jk7j	/public/images/thumbnails/20e9dcb6-f0e6-4091-a9ef-73b13dcf7b13-1760552247401.webp	150	150	webp	80	7414	cmgsbcpql04muh9i6265n1z3b
cmgsbcrfc04n5h9i64z403toc	/public/images/full/248747ff-b806-4ac5-9d40-254dd06874b4-1760552249539.webp	3725	3699	webp	90	765054	cmgsbcrf904n1h9i67cweofq7
cmgsbct7w04neh9i6iijstwjl	/public/images/thumbnails/9ef87968-de15-4044-8076-a13783b851b6-1760552251722.webp	150	150	webp	80	7418	cmgsbct7s04n8h9i6uuunq6mc
cmgsbcv5204nkh9i6ojv5y5c2	/public/images/medium/3b0626e5-08cc-4c3a-8159-1f5f00ef09b5-1760552254042.webp	800	775	webp	85	100282	cmgsbcv4y04nfh9i6ntwxltk8
cmgsbcxd704nqh9i6n7voefn3	/public/images/full/25405920-2ccc-43d6-b648-1d28e1069088-1760552256536.webp	3614	3788	webp	90	794660	cmgsbcxcu04nmh9i6op4qmnch
cmgsbcz4l04nxh9i6x6i1j9sp	/public/images/thumbnails/0b5a6ab1-d08b-4513-abbb-c4f1c8258997-1760552259428.webp	150	150	webp	80	9678	cmgsbcz4j04nth9i6zj098qan
cmgsbd11f04o5h9i66rv2a7pm	/public/images/full/e5ce4879-420f-40b8-a652-27ca14018375-1760552261702.webp	3703	3788	webp	90	1014202	cmgsbd11804o0h9i6kr4dbxag
cmgsbd4vk04o9h9i6cmidc9zm	/public/images/thumbnails/9626b916-075e-4df8-8bbf-1ca09bb337fe-1760552264208.webp	150	150	webp	80	7192	cmgsbd4vg04o7h9i6y1wwzmsr
cmgsbd9py04oih9i68c2zk3eg	/public/images/medium/5fd4bd9f-9b0f-4b13-814a-ffe2a47560f2-1760552269193.webp	800	819	webp	85	105022	cmgsbd9pl04oeh9i6dd0bbndk
cmgsblnvs059xh9i6gebhi4d6	/public/images/thumbnails/f0039f3f-4bd2-429e-81d1-aa1d3b106481-1760552665593.webp	150	150	webp	80	4426	cmgsblnvp059sh9i6yujbx6at
cmgsblp5605a2h9i68w60ntuw	/public/images/thumbnails/9fc2bf71-12c0-4f4d-bba6-4857b2183882-1760552667034.webp	150	150	webp	80	6466	cmgsblp54059zh9i6lhynfigz
cmgsbajp604gqh9i6jw7c5k3y	/public/images/medium/13c3d986-1656-4788-a4a5-13ef02d55781-1760552145527.webp	800	1112	webp	85	65520	cmgsbajp304gmh9i6xfp7rj06
cmgsbam5e04gwh9i6e0fyshe5	/public/images/thumbnails/23bf70a1-209b-4618-8880-df64f8408677-1760552148391.webp	150	150	webp	80	6256	cmgsbam5b04gth9i6dfp8o2il
cmgsbaobf04h6h9i6erf57xj2	/public/images/full/e35c7955-6f32-48b3-b41d-6cd07ef30b93-1760552151573.webp	5153	3686	webp	90	1313768	cmgsbaobd04h0h9i6ac2tbwi0
cmgsbarb204hdh9i6aj2nwwk3	/public/images/thumbnails/70d70acc-74ee-40d2-9326-db4b4e359dd3-1760552154388.webp	150	150	webp	80	7842	cmgsbaray04h7h9i6do56oz12
cmgsbb7h704hgh9i67snf9msq	/public/images/thumbnails/15ef6fc3-b737-4fd4-8c8f-266f97881b7d-1760552158269.webp	150	150	webp	80	5678	cmgsbb7h504heh9i653zkb3c6
cmgsbb9pl04hrh9i6ovyall1f	/public/images/full/938f91ba-35e1-47c7-b528-312e740ffc0e-1760552179215.webp	3875	5300	webp	90	1580424	cmgsbb9pi04hlh9i6nt42rjr0
cmgsbbbvy04hyh9i65z7244tj	/public/images/thumbnails/7e869bf1-9765-45c4-9a44-b1d7d528257a-1760552182109.webp	150	150	webp	80	7786	cmgsbbbvu04hsh9i680b761ad
cmgsbbdl004i5h9i6t756qmmu	/public/images/full/a5866442-1560-4833-b72d-ab2dee785b23-1760552184934.webp	3857	2698	webp	90	873252	cmgsbbdkr04hzh9i6r3edl1q3
cmgsbbgn304iah9i6x9b6mxrw	/public/images/medium/f03be9b3-f1c5-4b25-8f8a-787aa6aab99a-1760552187137.webp	800	571	webp	85	113044	cmgsbbgmz04i6h9i6nleqji7r
cmgsbbjmx04ifh9i6t0byqfbl	/public/images/thumbnails/1d0afbda-92d1-404f-87d4-af829209d2f5-1760552191087.webp	150	150	webp	80	5256	cmgsbbjmu04idh9i6c3c2kppk
cmgsbbmoh04iqh9i6qucbzyp0	/public/images/full/0b44f7e7-270b-4962-b3ad-1144bf613c32-1760552194975.webp	5091	3775	webp	90	1317082	cmgsbbmof04ikh9i6kz6xxe7o
cmgsbbpwb04ivh9i6bw5x33pp	/public/images/thumbnails/7e7d26ee-9df6-4caa-b923-8791f7ebd076-1760552198911.webp	150	150	webp	80	5278	cmgsbbpw804irh9i6sgp3mwln
cmgsbbt7704j2h9i6d5suk05r	/public/images/thumbnails/d4acbc57-ae65-4215-80b9-8f81da29cccc-1760552203088.webp	150	150	webp	80	8098	cmgsbbt7304iyh9i61r5w30jp
cmgsbbvgb04jah9i69v3vo9ij	/public/images/full/6d97fab4-17b8-43ef-b85e-74701b41d15e-1760552207362.webp	3770	5258	webp	90	1089784	cmgsbbvg904j5h9i602lfqfwp
cmgsbbxig04jih9i6di5ju783	/public/images/thumbnails/d487cd32-1454-4cf1-836e-94d8e7d9f3f8-1760552210285.webp	150	150	webp	80	6340	cmgsbbxie04jch9i6ivydyurw
cmgsbbzoh04joh9i6rbrsbywz	/public/images/thumbnails/acada9f6-e48f-4064-82a4-1ef2629008a3-1760552212959.webp	150	150	webp	80	9220	cmgsbbzoc04jjh9i6316ib22t
cmgsbc1xm04juh9i64w3urgsb	/public/images/thumbnails/e216943f-1ede-41d7-89ac-071bb79f96aa-1760552215768.webp	150	150	webp	80	5784	cmgsbc1xk04jqh9i6fe2x4geu
cmgsbc49j04k1h9i6fcyb0epf	/public/images/thumbnails/246cabea-eda5-4148-8ffb-2cb082d360c4-1760552218686.webp	150	150	webp	80	6724	cmgsbc49g04jxh9i6ahifcqea
cmgsbc6bo04k9h9i68zwwy9ir	/public/images/medium/9893a771-2775-4c7d-9dad-92354d2712d1-1760552221706.webp	800	1093	webp	85	79366	cmgsbc6bm04k4h9i65uywyowf
cmgsbc8hv04kdh9i64cuvffn9	/public/images/thumbnails/0ed4fa87-9183-4fe2-a3e2-7869d88d2649-1760552224372.webp	150	150	webp	80	8854	cmgsbc8ht04kbh9i69v86m2fd
cmgsbc9tl04koh9i6csdvu5hd	/public/images/full/77c75675-d86a-44d8-ac7e-1c9bc40a15b4-1760552227188.webp	4278	2885	webp	90	831648	cmgsbc9tj04kih9i6t925l6m5
cmgsbcb2x04kvh9i6y8z5krbg	/public/images/medium/7409a449-a889-46b6-8823-fb1837cf6b06-1760552228903.webp	800	533	webp	85	58318	cmgsbcb2v04kph9i64wv0jd4x
cmgsbcc4y04kzh9i6msox5gsl	/public/images/thumbnails/49c585ca-e0a3-4870-93fb-282944d901f6-1760552230538.webp	150	150	webp	80	7900	cmgsbcc4w04kwh9i6hgh945ug
cmgsbcdpo04l9h9i6s2q853ys	/public/images/full/97feb573-053e-45d2-81fc-75834e1193f1-1760552231909.webp	2840	3919	webp	90	1483254	cmgsbcdpm04l3h9i662j5zpq1
cmgsbcg3f04leh9i6qc6gg3ea	/public/images/thumbnails/63259dbd-144b-427e-84b6-23f3cfb432d9-1760552233958.webp	150	150	webp	80	6484	cmgsbcg3c04lah9i6xuqsxyyw
cmgsbci5e04lkh9i6z4bff32f	/public/images/thumbnails/5d8a080b-3d7d-4e3e-bb20-d5577f4e5918-1760552237038.webp	150	150	webp	80	7808	cmgsbci5c04lhh9i682754n2l
cmgsbcj0f04lth9i69s0bj6j0	/public/images/medium/3133c096-133a-4e5e-ab2c-027c69f1a410-1760552239698.webp	800	1198	webp	85	125426	cmgsbcj0d04loh9i6cia0yfci
cmgsbcjv304lzh9i6h437no80	/public/images/medium/b1e55aaa-c088-452a-9fa5-4705620374d1-1760552240814.webp	800	1131	webp	85	115622	cmgsbcjv004lvh9i6mxvovl4z
cmgsbckrx04m4h9i6la8z4wnn	/public/images/thumbnails/b9566c40-f1d2-48e3-9d5d-70a4c6cb62ba-1760552241919.webp	150	150	webp	80	6828	cmgsbckrv04m2h9i6g6w87xmq
cmgsbclyv04mdh9i6u340yawh	/public/images/full/68b6d763-0e58-4b5e-95cf-ff6377118e31-1760552243104.webp	2686	3572	webp	90	740488	cmgsbclyt04m9h9i69jziw4p7
cmgsbcn9d04mmh9i6opvve59r	/public/images/full/9233f14d-e9fd-4e0d-a2fe-2315e9b2ec3a-1760552244650.webp	3826	2464	webp	90	1444842	cmgsbcn9b04mgh9i6v7j71ym4
cmgsbco3604mrh9i68mlqku93	/public/images/thumbnails/67f9fac4-dbcc-4e64-974a-1a5952cfc798-1760552246321.webp	150	150	webp	80	7610	cmgsbco3404mnh9i6u8dbw9yx
cmgsbcpqo04n0h9i6qtq2lioc	/public/images/full/20e9dcb6-f0e6-4091-a9ef-73b13dcf7b13-1760552247401.webp	3614	3677	webp	90	842190	cmgsbcpql04muh9i6265n1z3b
cmgsbcrfc04n6h9i6gbjgtgvs	/public/images/medium/248747ff-b806-4ac5-9d40-254dd06874b4-1760552249539.webp	800	794	webp	85	85024	cmgsbcrf904n1h9i67cweofq7
cmgsbct7w04ndh9i69kojs84l	/public/images/full/9ef87968-de15-4044-8076-a13783b851b6-1760552251722.webp	3703	3744	webp	90	888450	cmgsbct7s04n8h9i6uuunq6mc
cmgsbcv5204njh9i6v15eg06q	/public/images/full/3b0626e5-08cc-4c3a-8159-1f5f00ef09b5-1760552254042.webp	3658	3543	webp	90	828060	cmgsbcv4y04nfh9i6ntwxltk8
cmgsbcxd804nsh9i6pf3lzqvu	/public/images/medium/25405920-2ccc-43d6-b648-1d28e1069088-1760552256536.webp	800	839	webp	85	92362	cmgsbcxcu04nmh9i6op4qmnch
cmgsbcz4l04nyh9i65avz9cwv	/public/images/medium/0b5a6ab1-d08b-4513-abbb-c4f1c8258997-1760552259428.webp	800	804	webp	85	150030	cmgsbcz4j04nth9i6zj098qan
cmgsbd11e04o3h9i61jgcyha4	/public/images/thumbnails/e5ce4879-420f-40b8-a652-27ca14018375-1760552261702.webp	150	150	webp	80	7102	cmgsbd11804o0h9i6kr4dbxag
cmgsbd4vo04obh9i6gyad8fuw	/public/images/medium/9626b916-075e-4df8-8bbf-1ca09bb337fe-1760552264208.webp	800	819	webp	85	125018	cmgsbd4vg04o7h9i6y1wwzmsr
cmgsbd9pt04ogh9i61ldlc5pg	/public/images/thumbnails/5fd4bd9f-9b0f-4b13-814a-ffe2a47560f2-1760552269193.webp	150	150	webp	80	6792	cmgsbd9pl04oeh9i6dd0bbndk
cmgsblqbw05ach9i6fdpm1lt2	/public/images/full/afea6966-b391-4c84-b2fe-d010c1832584-1760552668668.webp	3341	2776	webp	90	1002896	cmgsblqbt05a6h9i665xoa4ja
cmgsblr2b05ahh9i6jj453h89	/public/images/thumbnails/2954fbcc-dd2d-47f1-ac3b-3eba385a7329-1760552670203.webp	150	150	webp	80	8526	cmgsblr2705adh9i64ei3eli8
cmgsbam5e04gzh9i6ur1ckgpe	/public/images/full/23bf70a1-209b-4618-8880-df64f8408677-1760552148391.webp	3686	5153	webp	90	1167306	cmgsbam5b04gth9i6dfp8o2il
cmgsbaobf04h4h9i6241b9ihd	/public/images/thumbnails/e35c7955-6f32-48b3-b41d-6cd07ef30b93-1760552151573.webp	150	150	webp	80	5994	cmgsbaobd04h0h9i6ac2tbwi0
cmgsbarb204hbh9i6618glk8l	/public/images/full/70d70acc-74ee-40d2-9326-db4b4e359dd3-1760552154388.webp	3791	5216	webp	90	1493814	cmgsbaray04h7h9i6do56oz12
cmgsbb7h704hjh9i6p99ccwcm	/public/images/medium/15ef6fc3-b737-4fd4-8c8f-266f97881b7d-1760552158269.webp	800	1106	webp	85	129258	cmgsbb7h504heh9i653zkb3c6
cmgsbb9pl04hph9i6vglany2w	/public/images/medium/938f91ba-35e1-47c7-b528-312e740ffc0e-1760552179215.webp	800	1094	webp	85	156718	cmgsbb9pi04hlh9i6nt42rjr0
cmgsbbbvy04hxh9i6kz0r5udz	/public/images/medium/7e869bf1-9765-45c4-9a44-b1d7d528257a-1760552182109.webp	800	554	webp	85	66370	cmgsbbbvu04hsh9i680b761ad
cmgsbbdl004i3h9i66isijc80	/public/images/medium/a5866442-1560-4833-b72d-ab2dee785b23-1760552184934.webp	800	560	webp	85	97454	cmgsbbdkr04hzh9i6r3edl1q3
cmgsbbgn304ich9i6qgrcb7mi	/public/images/full/f03be9b3-f1c5-4b25-8f8a-787aa6aab99a-1760552187137.webp	5153	3681	webp	90	1376454	cmgsbbgmz04i6h9i6nleqji7r
cmgsbbjmx04ijh9i60kcfc406	/public/images/full/1d0afbda-92d1-404f-87d4-af829209d2f5-1760552191087.webp	5122	3712	webp	90	1155378	cmgsbbjmu04idh9i6c3c2kppk
cmgsbbmoh04ioh9i692ymcu03	/public/images/medium/0b44f7e7-270b-4962-b3ad-1144bf613c32-1760552194975.webp	800	593	webp	85	94370	cmgsbbmof04ikh9i6kz6xxe7o
cmgsbbpwb04iwh9i6lb93w4vj	/public/images/full/7e7d26ee-9df6-4caa-b923-8791f7ebd076-1760552198911.webp	4021	5321	webp	90	1263886	cmgsbbpw804irh9i6sgp3mwln
cmgsbbt7704j4h9i6iglbxbxs	/public/images/full/d4acbc57-ae65-4215-80b9-8f81da29cccc-1760552203088.webp	5262	3837	webp	90	1885402	cmgsbbt7304iyh9i61r5w30jp
cmgsbbvgb04j7h9i6dlx19lg9	/public/images/thumbnails/6d97fab4-17b8-43ef-b85e-74701b41d15e-1760552207362.webp	150	150	webp	80	5916	cmgsbbvg904j5h9i602lfqfwp
cmgsbbxig04jgh9i6r7z4h3km	/public/images/full/d487cd32-1454-4cf1-836e-94d8e7d9f3f8-1760552210285.webp	3833	5279	webp	90	1171004	cmgsbbxie04jch9i6ivydyurw
cmgsbbzoh04jph9i65qe0rfjh	/public/images/medium/acada9f6-e48f-4064-82a4-1ef2629008a3-1760552212959.webp	800	597	webp	85	84564	cmgsbbzoc04jjh9i6316ib22t
cmgsbc1xm04jwh9i6oyg6l106	/public/images/medium/e216943f-1ede-41d7-89ac-071bb79f96aa-1760552215768.webp	800	585	webp	85	57988	cmgsbc1xk04jqh9i6fe2x4geu
cmgsbc49j04k3h9i610rg9z2a	/public/images/full/246cabea-eda5-4148-8ffb-2cb082d360c4-1760552218686.webp	3707	5279	webp	90	1300450	cmgsbc49g04jxh9i6ahifcqea
cmgsbc6bo04k8h9i65u36xdi9	/public/images/full/9893a771-2775-4c7d-9dad-92354d2712d1-1760552221706.webp	3759	5137	webp	90	1235006	cmgsbc6bm04k4h9i65uywyowf
cmgsbc8hv04khh9i6a3ln1ugj	/public/images/full/0ed4fa87-9183-4fe2-a3e2-7869d88d2649-1760552224372.webp	3759	5137	webp	90	1508650	cmgsbc8ht04kbh9i69v86m2fd
cmgsbc9tl04knh9i6mp5n8kxc	/public/images/medium/77c75675-d86a-44d8-ac7e-1c9bc40a15b4-1760552227188.webp	800	540	webp	85	71116	cmgsbc9tj04kih9i6t925l6m5
cmgsbcb2x04kth9i62uxi02zo	/public/images/full/7409a449-a889-46b6-8823-fb1837cf6b06-1760552228903.webp	3841	2558	webp	90	708766	cmgsbcb2v04kph9i64wv0jd4x
cmgsbcc4y04l2h9i6vtckjkt1	/public/images/full/49c585ca-e0a3-4870-93fb-282944d901f6-1760552230538.webp	2134	3373	webp	90	746606	cmgsbcc4w04kwh9i6hgh945ug
cmgsbcdpo04l8h9i6ntyfpkn5	/public/images/thumbnails/97feb573-053e-45d2-81fc-75834e1193f1-1760552231909.webp	150	150	webp	80	7582	cmgsbcdpm04l3h9i662j5zpq1
cmgsbcg3f04lfh9i6umhy6vgb	/public/images/medium/63259dbd-144b-427e-84b6-23f3cfb432d9-1760552233958.webp	800	546	webp	85	54116	cmgsbcg3c04lah9i6xuqsxyyw
cmgsbci5e04lnh9i6y3ttv51g	/public/images/full/5d8a080b-3d7d-4e3e-bb20-d5577f4e5918-1760552237038.webp	3530	4369	webp	90	1186416	cmgsbci5c04lhh9i682754n2l
cmgsbcj0f04lrh9i6zcv3lo3p	/public/images/thumbnails/3133c096-133a-4e5e-ab2c-027c69f1a410-1760552239698.webp	150	150	webp	80	6668	cmgsbcj0d04loh9i6cia0yfci
cmgsbcjv304m1h9i6c5fsrj5c	/public/images/full/b1e55aaa-c088-452a-9fa5-4705620374d1-1760552240814.webp	2121	2998	webp	90	418330	cmgsbcjv004lvh9i6mxvovl4z
cmgsbckry04m6h9i6ojifeob7	/public/images/full/b9566c40-f1d2-48e3-9d5d-70a4c6cb62ba-1760552241919.webp	2137	3029	webp	90	413156	cmgsbckrv04m2h9i6g6w87xmq
cmgsbclyv04mfh9i68ikim4nz	/public/images/thumbnails/68b6d763-0e58-4b5e-95cf-ff6377118e31-1760552243104.webp	150	150	webp	80	4084	cmgsbclyt04m9h9i69jziw4p7
cmgsbcn9d04mjh9i62adwenej	/public/images/thumbnails/9233f14d-e9fd-4e0d-a2fe-2315e9b2ec3a-1760552244650.webp	150	150	webp	80	7838	cmgsbcn9b04mgh9i6v7j71ym4
cmgsbco3604msh9i6linmmzb1	/public/images/medium/67f9fac4-dbcc-4e64-974a-1a5952cfc798-1760552246321.webp	800	611	webp	85	89334	cmgsbco3404mnh9i6u8dbw9yx
cmgsbcpqn04myh9i63vviq7f6	/public/images/medium/20e9dcb6-f0e6-4091-a9ef-73b13dcf7b13-1760552247401.webp	800	814	webp	85	103140	cmgsbcpql04muh9i6265n1z3b
cmgsbcrfc04n7h9i63l69h931	/public/images/thumbnails/248747ff-b806-4ac5-9d40-254dd06874b4-1760552249539.webp	150	150	webp	80	5644	cmgsbcrf904n1h9i67cweofq7
cmgsbct7w04nch9i6dorldqel	/public/images/medium/9ef87968-de15-4044-8076-a13783b851b6-1760552251722.webp	800	809	webp	85	98262	cmgsbct7s04n8h9i6uuunq6mc
cmgsbcv5204nlh9i6hrmretqu	/public/images/thumbnails/3b0626e5-08cc-4c3a-8159-1f5f00ef09b5-1760552254042.webp	150	150	webp	80	6322	cmgsbcv4y04nfh9i6ntwxltk8
cmgsbcxd404noh9i6d2yp6vgq	/public/images/thumbnails/25405920-2ccc-43d6-b648-1d28e1069088-1760552256536.webp	150	150	webp	80	6732	cmgsbcxcu04nmh9i6op4qmnch
cmgsbcz4l04nzh9i6wf913s9m	/public/images/full/0b5a6ab1-d08b-4513-abbb-c4f1c8258997-1760552259428.webp	3703	3721	webp	90	1171690	cmgsbcz4j04nth9i6zj098qan
cmgsbd11g04o6h9i6cbnckd1p	/public/images/medium/e5ce4879-420f-40b8-a652-27ca14018375-1760552261702.webp	800	819	webp	85	127366	cmgsbd11804o0h9i6kr4dbxag
cmgsbd4vq04odh9i6vfkhcpfi	/public/images/full/9626b916-075e-4df8-8bbf-1ca09bb337fe-1760552264208.webp	3658	3744	webp	90	1057380	cmgsbd4vg04o7h9i6y1wwzmsr
cmgsbd9pz04okh9i66tx9vhx8	/public/images/full/5fd4bd9f-9b0f-4b13-814a-ffe2a47560f2-1760552269193.webp	3681	3766	webp	90	927814	cmgsbd9pl04oeh9i6dd0bbndk
cmgsbdeas04oph9i6s4b0i61x	/public/images/medium/9ac91af8-b56f-447f-9c14-60927de91cd1-1760552275458.webp	800	785	webp	85	70004	cmgsbdeak04olh9i67hy2u3gl
cmgsbdear04onh9i6a0j56cs7	/public/images/thumbnails/9ac91af8-b56f-447f-9c14-60927de91cd1-1760552275458.webp	150	150	webp	80	5066	cmgsbdeak04olh9i67hy2u3gl
cmgsbdeav04orh9i66ikqasch	/public/images/full/9ac91af8-b56f-447f-9c14-60927de91cd1-1760552275458.webp	3814	3744	webp	90	774436	cmgsbdeak04olh9i67hy2u3gl
cmgsbdkup04ovh9i6vqmtopr0	/public/images/thumbnails/816c2e2f-cd02-4c35-9434-aa532b306bc2-1760552281412.webp	150	150	webp	80	8132	cmgsbdkui04osh9i63o55rr54
cmgsbdox604p5h9i66wtv0yrt	/public/images/full/5a143e73-cc13-491b-b00c-d1688b542572-1760552289889.webp	4060	2667	webp	90	925634	cmgsbdowm04ozh9i6xqxin98k
cmgsbdutj04p9h9i69iwfk9su	/public/images/medium/ed8c9569-8c1f-427f-ba1d-a339c9ded081-1760552295165.webp	800	527	webp	85	48656	cmgsbduta04p6h9i6atjfth1s
cmgsbdxu804pih9i6ojdp38jh	/public/images/thumbnails/5166677d-dd8f-4119-850b-20b75f93f3a4-1760552302810.webp	150	150	webp	80	5266	cmgsbdxu204pdh9i6qs2qdtoa
cmgsbe1wi04poh9i6icdj6psj	/public/images/medium/12c13bb6-f224-4fe4-ac4e-58c7ea13eac3-1760552306711.webp	800	1191	webp	85	158872	cmgsbe1w504pkh9i6z5jcxrya
cmgsbe4vq04pxh9i6kwbuszun	/public/images/medium/56fdca4e-85f7-48d7-bc3c-853245539b32-1760552311988.webp	800	1162	webp	85	201974	cmgsbe4vo04prh9i6uuesx79f
cmgsbe7ly04q1h9i6m5p9fqwx	/public/images/medium/1b0fa75c-54a4-40a1-99e0-1fe003278c80-1760552315823.webp	800	1186	webp	85	165046	cmgsbe7lw04pyh9i6956fdxy7
cmgsbea9h04q9h9i6ohi7pzyv	/public/images/thumbnails/59bd2726-f89a-4cbe-b674-4fe0d74284f0-1760552319356.webp	150	150	webp	80	7150	cmgsbea9e04q5h9i6rp8u6j3y
cmgsbecwl04qhh9i6cqouu9td	/public/images/thumbnails/acc8ebdf-4f17-4c92-ace7-e635f11d8a8e-1760552322791.webp	150	150	webp	80	6718	cmgsbecwe04qch9i64w1sjm8x
cmgsbeg2u04qoh9i6ruddr0sc	/public/images/thumbnails/430060fb-45bd-415e-805b-3091e523c5e0-1760552326219.webp	150	150	webp	80	6182	cmgsbeg2p04qjh9i60hty84z4
cmgsbeizf04quh9i6gylaobr7	/public/images/thumbnails/1ca40fb2-2512-41d1-b036-b5c26bc20cd9-1760552330336.webp	150	150	webp	80	6438	cmgsbeiza04qqh9i6zr3vg6c4
cmgsbemvb04r1h9i6gsbc6zh5	/public/images/thumbnails/5a8f14bb-0d16-4fb2-8dc1-41591d934239-1760552334097.webp	150	150	webp	80	7116	cmgsbemv404qxh9i6880cxiq7
cmgsbeqqx04r8h9i6muh6z3xu	/public/images/medium/e759e23e-89a3-445c-9dea-4ca904f6f862-1760552339162.webp	800	551	webp	85	92380	cmgsbeqqq04r4h9i64oc5dns1
cmgsbevq604rhh9i6dgu4rp8w	/public/images/thumbnails/38e44ff3-cc0f-4019-8a93-cae941b2f193-1760552344176.webp	150	150	webp	80	8138	cmgsbevpw04rbh9i6djjkse7v
cmgsbf06m04rmh9i61vaoajqp	/public/images/thumbnails/556e192f-60bf-4224-87d2-f082622fd467-1760552350648.webp	150	150	webp	80	6728	cmgsbf06f04rih9i6eokzhjsg
cmgsbf5qp04rth9i6h1zgrb3c	/public/images/thumbnails/fa680a31-ddc7-4523-8eaf-70c60a3e7cb1-1760552356419.webp	150	150	webp	80	5506	cmgsbf5qk04rph9i68hp1ouf4
cmgsbfb7304s1h9i6dje87zlk	/public/images/full/209b0d9e-56f1-407e-be7c-2fb7231442ab-1760552363612.webp	5137	3447	webp	90	1799992	cmgsbfb6r04rwh9i6hc1ymo1t
cmgsbfgdv04s8h9i6dgtd2cye	/public/images/full/819dbb2c-73be-4ccc-865e-3879ed1a180f-1760552370683.webp	5059	3416	webp	90	2511706	cmgsbfgds04s3h9i6jrm27ew2
cmgsbfiw004seh9i6i5md8ywe	/public/images/medium/7444ebf1-c440-42be-bf32-9b318b689ff0-1760552377376.webp	800	540	webp	85	67424	cmgsbfivx04sah9i6nlecac7v
cmgsbfkt704skh9i6q5xejjxa	/public/images/medium/e1148260-2d0b-4aae-8ff3-5d55873cb868-1760552380632.webp	800	552	webp	85	89294	cmgsbfkt404shh9i6ijmpq2hc
cmgsbfmjo04suh9i6e5gsmip2	/public/images/full/8393059f-1517-4d25-8ea3-b15d4b65f60f-1760552383117.webp	5012	3369	webp	90	1246396	cmgsbfmjm04soh9i647pv4pl5
cmgsbfoto04t1h9i6tehscw97	/public/images/thumbnails/098bb0b9-08d2-4a7e-b82f-19d93e9cd7c1-1760552385368.webp	150	150	webp	80	6304	cmgsbfotl04svh9i6mzyysqhy
cmgsbfrtz04t7h9i606zfyzmb	/public/images/medium/e5dd6bc3-79c3-4e47-ac1c-f663d12fbfa7-1760552388326.webp	800	540	webp	85	67620	cmgsbfrtw04t2h9i6pwnfda96
cmgsbfwq804tdh9i6ou7wjrhw	/public/images/medium/dda77339-cd7c-4917-85bb-cc0e4b072a08-1760552392215.webp	800	544	webp	85	77862	cmgsbfwpt04t9h9i650grodtl
cmgsbg15h04tih9i6rhksf2z8	/public/images/thumbnails/7c8a5adb-328c-489c-b9b2-ab4ec8b333c0-1760552398585.webp	150	150	webp	80	7448	cmgsbg15c04tgh9i64e63fr27
cmgsblr2b05aih9i6g9xarf80	/public/images/medium/2954fbcc-dd2d-47f1-ac3b-3eba385a7329-1760552670203.webp	800	1257	webp	85	176936	cmgsblr2705adh9i64ei3eli8
cmgsblsmq05aoh9i6zbpwtjg7	/public/images/thumbnails/e29e253b-f183-4382-90fd-192d39760bba-1760552671159.webp	150	150	webp	80	7862	cmgsblsmo05akh9i6y2sq8avm
cmgsbltze05avh9i68qqg8h9s	/public/images/medium/7d1826c2-4725-4ffa-ba2d-0ddf401a2514-1760552673190.webp	800	1269	webp	85	181244	cmgsbltzc05arh9i63bw4trp2
cmgsblv7m05b1h9i62rrrfc86	/public/images/medium/3348b349-1c24-4d09-923c-22f35dc9f8d2-1760552674938.webp	800	1232	webp	85	91532	cmgsblv7k05ayh9i6q4ij4orm
cmgsblwdl05b9h9i6yyt5qa80	/public/images/medium/8179831f-3599-4611-b34d-655a09857bac-1760552676528.webp	800	536	webp	85	48048	cmgsblwdj05b5h9i6mfe4ughy
cmgsblxvq05bih9i65wfl7f9l	/public/images/full/3d0fe59b-456e-49ba-98fc-238a40cac5a1-1760552678051.webp	2576	4024	webp	90	1738506	cmgsblxvn05bch9i6x0w9kpvh
cmgsblz5o05bnh9i6m06hh894	/public/images/medium/b31e4493-8967-4b5c-be51-b0d4b55bba57-1760552679992.webp	800	1232	webp	85	140666	cmgsblz5l05bjh9i6jb1w5btx
cmgsblzx705buh9i68dvp7qb6	/public/images/medium/918bef4d-2dfb-4316-8cde-308730becf67-1760552681643.webp	800	1027	webp	85	122660	cmgsblzx505bqh9i6dx1fewht
cmgsbm0u805c3h9i6mokc001o	/public/images/full/4c41c8ca-b9f7-4d22-ae44-2e647c1c0682-1760552682635.webp	2623	2667	webp	90	531742	cmgsbm0u505bxh9i6zpwsws50
cmgsbm1px05c9h9i67l2cbfjs	/public/images/thumbnails/e8ea3dad-11c8-45e9-b47c-73deee53ddee-1760552683824.webp	150	150	webp	80	8012	cmgsbm1pu05c4h9i6dczxw0yp
cmgsbm2bs05ceh9i6gorx94an	/public/images/medium/cea7e4ed-daa4-4f70-8b22-b45780e4236f-1760552684963.webp	800	459	webp	85	61390	cmgsbm2bq05cbh9i6c39k8cdg
cmgsbm3uy05coh9i6tp0zewpw	/public/images/full/5eeb0fcb-0236-490e-a0c7-061eca372191-1760552685756.webp	2839	4278	webp	90	1147022	cmgsbm3uv05cih9i6ffuffyk3
cmgsbm4zv05cth9i6t7pthg27	/public/images/thumbnails/f6328e5d-e2fb-4eb0-a8c8-9f176eb229ce-1760552687737.webp	150	150	webp	80	7790	cmgsbm4zr05cph9i65tce9yyu
cmgsbm74405d2h9i6g9smwlx6	/public/images/full/e303d453-3d7f-4d66-9ba7-dffc5e03486d-1760552689220.webp	5122	3587	webp	90	1734868	cmgsbm74105cwh9i6a0xl90cr
cmgsbm8mp05d8h9i61sz7d5r3	/public/images/full/117c1eed-e654-40e1-81d1-b025effac85b-1760552691959.webp	4357	2979	webp	90	918978	cmgsbm8mn05d3h9i65w13wnkc
cmgsbm9wd05deh9i6nl3vdtb1	/public/images/thumbnails/8f42fbfb-460a-4816-af79-fabcf2a61bec-1760552693919.webp	150	150	webp	80	7692	cmgsbm9wa05dah9i6678voouo
cmgsbmb4o05dlh9i6q3s94lhx	/public/images/thumbnails/ea57571e-d560-494a-96c9-a02a1e3928d0-1760552695567.webp	150	150	webp	80	4652	cmgsbmb4l05dhh9i6qzlv2z8b
cmgsbmdjo05duh9i6u3ui3c4v	/public/images/thumbnails/bcf84f63-0383-4380-85da-474d8f315f4e-1760552697174.webp	150	150	webp	80	7064	cmgsbmdjm05doh9i6d7pe4skt
cmgsbdkuq04oxh9i6zuos7pju	/public/images/full/816c2e2f-cd02-4c35-9434-aa532b306bc2-1760552281412.webp	3919	5177	webp	90	1162128	cmgsbdkui04osh9i63o55rr54
cmgsbdoww04p1h9i6k8bhh0xa	/public/images/thumbnails/5a143e73-cc13-491b-b00c-d1688b542572-1760552289889.webp	150	150	webp	80	6968	cmgsbdowm04ozh9i6xqxin98k
cmgsbdutk04pch9i62jae1ubm	/public/images/full/ed8c9569-8c1f-427f-ba1d-a339c9ded081-1760552295165.webp	5091	3353	webp	90	1480270	cmgsbduta04p6h9i6atjfth1s
cmgsbdxu804phh9i65xglsvxj	/public/images/medium/5166677d-dd8f-4119-850b-20b75f93f3a4-1760552302810.webp	800	542	webp	85	45082	cmgsbdxu204pdh9i6qs2qdtoa
cmgsbe1wk04pqh9i6j4ma2eej	/public/images/full/12c13bb6-f224-4fe4-ac4e-58c7ea13eac3-1760552306711.webp	3351	4986	webp	90	1577484	cmgsbe1w504pkh9i6z5jcxrya
cmgsbe4vq04pth9i6qil8d39h	/public/images/thumbnails/56fdca4e-85f7-48d7-bc3c-853245539b32-1760552311988.webp	150	150	webp	80	7138	cmgsbe4vo04prh9i6uuesx79f
cmgsbe7ly04q4h9i6p9ms4hnj	/public/images/full/1b0fa75c-54a4-40a1-99e0-1fe003278c80-1760552315823.webp	3435	5091	webp	90	1410838	cmgsbe7lw04pyh9i6956fdxy7
cmgsbea9h04q8h9i6y1krbvpj	/public/images/medium/59bd2726-f89a-4cbe-b674-4fe0d74284f0-1760552319356.webp	800	1134	webp	85	164096	cmgsbea9e04q5h9i6rp8u6j3y
cmgsbecwl04qih9i6c6sx90lg	/public/images/medium/acc8ebdf-4f17-4c92-ace7-e635f11d8a8e-1760552322791.webp	800	525	webp	85	51106	cmgsbecwe04qch9i64w1sjm8x
cmgsbeg2u04qph9i60hca61di	/public/images/full/430060fb-45bd-415e-805b-3091e523c5e0-1760552326219.webp	4966	3213	webp	90	1820740	cmgsbeg2p04qjh9i60hty84z4
cmgsbeizf04qth9i6gj6p1cwy	/public/images/full/1ca40fb2-2512-41d1-b036-b5c26bc20cd9-1760552330336.webp	3498	5174	webp	90	1744852	cmgsbeiza04qqh9i6zr3vg6c4
cmgsbemvc04r3h9i6569si60t	/public/images/full/5a8f14bb-0d16-4fb2-8dc1-41591d934239-1760552334097.webp	3602	5091	webp	90	2059208	cmgsbemv404qxh9i6880cxiq7
cmgsbeqqy04rah9i6y7e0yana	/public/images/full/e759e23e-89a3-445c-9dea-4ca904f6f862-1760552339162.webp	4888	3369	webp	90	2293054	cmgsbeqqq04r4h9i64oc5dns1
cmgsbevq204rdh9i69abzamqm	/public/images/medium/38e44ff3-cc0f-4019-8a93-cae941b2f193-1760552344176.webp	800	1162	webp	85	178900	cmgsbevpw04rbh9i6djjkse7v
cmgsbf06m04roh9i6by9g0jzm	/public/images/medium/556e192f-60bf-4224-87d2-f082622fd467-1760552350648.webp	800	551	webp	85	88000	cmgsbf06f04rih9i6eokzhjsg
cmgsbf5qq04rvh9i62bwm5ae5	/public/images/full/fa680a31-ddc7-4523-8eaf-70c60a3e7cb1-1760552356419.webp	5075	3494	webp	90	2028268	cmgsbf5qk04rph9i68hp1ouf4
cmgsblsmq05aph9i65bzixmrb	/public/images/medium/e29e253b-f183-4382-90fd-192d39760bba-1760552671159.webp	800	553	webp	85	79990	cmgsblsmo05akh9i6y2sq8avm
cmgsbltze05awh9i6jlt8jcuy	/public/images/full/7d1826c2-4725-4ffa-ba2d-0ddf401a2514-1760552673190.webp	2576	4087	webp	90	1063570	cmgsbltzc05arh9i63bw4trp2
cmgsblv7m05b2h9i6dbv0pn8f	/public/images/thumbnails/3348b349-1c24-4d09-923c-22f35dc9f8d2-1760552674938.webp	150	150	webp	80	5990	cmgsblv7k05ayh9i6q4ij4orm
cmgsblwdl05bah9i6v5m1huxb	/public/images/full/8179831f-3599-4611-b34d-655a09857bac-1760552676528.webp	3982	2667	webp	90	641716	cmgsblwdj05b5h9i6mfe4ughy
cmgsblxvq05bhh9i6pv25hf89	/public/images/medium/3d0fe59b-456e-49ba-98fc-238a40cac5a1-1760552678051.webp	800	1250	webp	85	249904	cmgsblxvn05bch9i6x0w9kpvh
cmgsblz5o05bph9i6eb6oul2i	/public/images/thumbnails/b31e4493-8967-4b5c-be51-b0d4b55bba57-1760552679992.webp	150	150	webp	80	5336	cmgsblz5l05bjh9i6jb1w5btx
cmgsblzx705bwh9i6gipu4muk	/public/images/full/918bef4d-2dfb-4316-8cde-308730becf67-1760552681643.webp	2077	2667	webp	90	414684	cmgsblzx505bqh9i6dx1fewht
cmgsbm0u805c1h9i6r8n5qxax	/public/images/thumbnails/4c41c8ca-b9f7-4d22-ae44-2e647c1c0682-1760552682635.webp	150	150	webp	80	3954	cmgsbm0u505bxh9i6zpwsws50
cmgsbm1px05c8h9i6jantbj7x	/public/images/medium/e8ea3dad-11c8-45e9-b47c-73deee53ddee-1760552683824.webp	800	578	webp	85	127800	cmgsbm1pu05c4h9i6dczxw0yp
cmgsbm2bs05cfh9i61plyqvr5	/public/images/thumbnails/cea7e4ed-daa4-4f70-8b22-b45780e4236f-1760552684963.webp	150	150	webp	80	5800	cmgsbm2bq05cbh9i6c39k8cdg
cmgsbm3ux05cmh9i6vq90u406	/public/images/medium/5eeb0fcb-0236-490e-a0c7-061eca372191-1760552685756.webp	800	1206	webp	85	195144	cmgsbm3uv05cih9i6ffuffyk3
cmgsbm4zv05cuh9i6rkp525px	/public/images/medium/f6328e5d-e2fb-4eb0-a8c8-9f176eb229ce-1760552687737.webp	800	954	webp	85	123958	cmgsbm4zr05cph9i65tce9yyu
cmgsbm74405d0h9i6ecgg1e96	/public/images/thumbnails/e303d453-3d7f-4d66-9ba7-dffc5e03486d-1760552689220.webp	150	150	webp	80	9564	cmgsbm74105cwh9i6a0xl90cr
cmgsbm8mp05d9h9i6hoiaznw0	/public/images/thumbnails/117c1eed-e654-40e1-81d1-b025effac85b-1760552691959.webp	150	150	webp	80	9830	cmgsbm8mn05d3h9i65w13wnkc
cmgsbm9wd05dgh9i62jwnwmx9	/public/images/full/8f42fbfb-460a-4816-af79-fabcf2a61bec-1760552693919.webp	3875	2743	webp	90	799272	cmgsbm9wa05dah9i6678voouo
cmgsbmb4o05dmh9i6r020i249	/public/images/medium/ea57571e-d560-494a-96c9-a02a1e3928d0-1760552695567.webp	800	591	webp	85	56188	cmgsbmb4l05dhh9i6qzlv2z8b
cmgsbmdjo05dth9i6u6y1afex	/public/images/medium/bcf84f63-0383-4380-85da-474d8f315f4e-1760552697174.webp	800	551	webp	85	96360	cmgsbmdjm05doh9i6d7pe4skt
cmgsbmkmu05ejh9i6m5tku6pa	/public/images/thumbnails/16e6a267-2770-478e-95c3-56e5a8686a7d-1760552706902.webp	150	150	webp	80	8134	cmgsbmkmp05egh9i6a26tnltk
cmgsbmlps05eth9i6s8qaoheb	/public/images/thumbnails/7000d8a3-ea04-4070-8c83-53c2c6c76263-1760552709499.webp	150	150	webp	80	8494	cmgsbmlpo05enh9i6knu1hly1
cmgsbmmv605eyh9i6nn6z796x	/public/images/thumbnails/e4488623-d233-4daa-a25f-66ad3bd23b13-1760552710878.webp	150	150	webp	80	9338	cmgsbmmv405euh9i6zfosbim2
cmgsbmnle05f5h9i6ho8uq5gf	/public/images/medium/1e1f50ab-81a5-4461-86eb-8bb14496d2ac-1760552712371.webp	800	564	webp	85	61680	cmgsbmnlb05f1h9i6d2p2e1zf
cmgsbmprl05fbh9i6uz2x5v03	/public/images/thumbnails/b9917bba-2b33-4fbf-a940-6cf6ac6432ae-1760552713323.webp	150	150	webp	80	8632	cmgsbmprj05f8h9i6trz6nwk3
cmgsbmqug05fkh9i6lbj3zoto	/public/images/medium/6a8f2e0d-beca-4255-ba93-0a9bdca17764-1760552716130.webp	800	649	webp	85	81516	cmgsbmqub05ffh9i6zpayz43z
cmgsbmsw605fqh9i6qr6jgp2h	/public/images/medium/7573b61f-4e6f-48ca-93c8-b336ac076291-1760552717529.webp	800	595	webp	85	78472	cmgsbmsw405fmh9i6cst12azc
cmgsbmtzv05fxh9i64ro9a3z7	/public/images/thumbnails/89868dc2-9655-4c1b-b25d-9118343276b6-1760552720184.webp	150	150	webp	80	5734	cmgsbmtzr05fth9i62gpk6ocp
cmgsbmw5705g5h9i6blh5d29k	/public/images/medium/c0a8a368-b8bc-4a62-9779-281b770122d6-1760552721618.webp	800	553	webp	85	66134	cmgsbmw5305g0h9i6ub04phdb
cmgsbmwwn05gdh9i65n1y1tth	/public/images/full/b3abc26d-0f82-46d4-b8cd-854555069007-1760552724392.webp	2077	2636	webp	90	443848	cmgsbmwwl05g7h9i6bdbxeurn
cmgsbdkuq04oyh9i6orglkwal	/public/images/medium/816c2e2f-cd02-4c35-9434-aa532b306bc2-1760552281412.webp	800	1057	webp	85	112710	cmgsbdkui04osh9i63o55rr54
cmgsbdox504p3h9i6ddryvo2e	/public/images/medium/5a143e73-cc13-491b-b00c-d1688b542572-1760552289889.webp	800	525	webp	85	73706	cmgsbdowm04ozh9i6xqxin98k
cmgsbdutj04pah9i6cr3pu41a	/public/images/thumbnails/ed8c9569-8c1f-427f-ba1d-a339c9ded081-1760552295165.webp	150	150	webp	80	5820	cmgsbduta04p6h9i6atjfth1s
cmgsbdxu804pjh9i60humdjgf	/public/images/full/5166677d-dd8f-4119-850b-20b75f93f3a4-1760552302810.webp	5044	3416	webp	90	1200208	cmgsbdxu204pdh9i6qs2qdtoa
cmgsbe1wf04pmh9i6scstbzhe	/public/images/thumbnails/12c13bb6-f224-4fe4-ac4e-58c7ea13eac3-1760552306711.webp	150	150	webp	80	4620	cmgsbe1w504pkh9i6z5jcxrya
cmgsbe4vq04pwh9i6dbwgiya6	/public/images/full/56fdca4e-85f7-48d7-bc3c-853245539b32-1760552311988.webp	3435	4986	webp	90	1849652	cmgsbe4vo04prh9i6uuesx79f
cmgsbe7ly04q3h9i6n0ovdf8y	/public/images/thumbnails/1b0fa75c-54a4-40a1-99e0-1fe003278c80-1760552315823.webp	150	150	webp	80	7436	cmgsbe7lw04pyh9i6956fdxy7
cmgsbea9h04qbh9i6aouso1v7	/public/images/full/59bd2726-f89a-4cbe-b674-4fe0d74284f0-1760552319356.webp	3518	4986	webp	90	1491782	cmgsbea9e04q5h9i6rp8u6j3y
cmgsbecwl04qgh9i6qko822y9	/public/images/full/acc8ebdf-4f17-4c92-ace7-e635f11d8a8e-1760552322791.webp	5091	3338	webp	90	1504562	cmgsbecwe04qch9i64w1sjm8x
cmgsbeg2s04qlh9i651i0tijm	/public/images/medium/430060fb-45bd-415e-805b-3091e523c5e0-1760552326219.webp	800	518	webp	85	82934	cmgsbeg2p04qjh9i60hty84z4
cmgsbeizh04qwh9i6u7snwrbh	/public/images/medium/1ca40fb2-2512-41d1-b036-b5c26bc20cd9-1760552330336.webp	800	1183	webp	85	174462	cmgsbeiza04qqh9i6zr3vg6c4
cmgsbemvc04r2h9i6p4oo788x	/public/images/medium/5a8f14bb-0d16-4fb2-8dc1-41591d934239-1760552334097.webp	800	1130	webp	85	198982	cmgsbemv404qxh9i6880cxiq7
cmgsbeqqw04r6h9i6t467v90l	/public/images/thumbnails/e759e23e-89a3-445c-9dea-4ca904f6f862-1760552339162.webp	150	150	webp	80	7202	cmgsbeqqq04r4h9i64oc5dns1
cmgsbevq404rfh9i6224vhbdp	/public/images/full/38e44ff3-cc0f-4019-8a93-cae941b2f193-1760552344176.webp	3494	5075	webp	90	1569016	cmgsbevpw04rbh9i6djjkse7v
cmgsbf06m04rnh9i62m7v450q	/public/images/full/556e192f-60bf-4224-87d2-f082622fd467-1760552350648.webp	5075	3494	webp	90	1988222	cmgsbf06f04rih9i6eokzhjsg
cmgsbf5qp04rsh9i6957pwpww	/public/images/medium/fa680a31-ddc7-4523-8eaf-70c60a3e7cb1-1760552356419.webp	800	551	webp	85	74222	cmgsbf5qk04rph9i68hp1ouf4
cmgsbfb7304s2h9i6tpaota2m	/public/images/thumbnails/209b0d9e-56f1-407e-be7c-2fb7231442ab-1760552363612.webp	150	150	webp	80	5474	cmgsbfb6r04rwh9i6hc1ymo1t
cmgsbfb7304ryh9i6s69ah8mu	/public/images/medium/209b0d9e-56f1-407e-be7c-2fb7231442ab-1760552363612.webp	800	536	webp	85	72888	cmgsbfb6r04rwh9i6hc1ymo1t
cmgsbfgdv04s7h9i61yqn9v8i	/public/images/medium/819dbb2c-73be-4ccc-865e-3879ed1a180f-1760552370683.webp	800	541	webp	85	86052	cmgsbfgds04s3h9i6jrm27ew2
cmgsbfgdv04s9h9i612jeq9oq	/public/images/thumbnails/819dbb2c-73be-4ccc-865e-3879ed1a180f-1760552370683.webp	150	150	webp	80	7428	cmgsbfgds04s3h9i6jrm27ew2
cmgsbfiw004sfh9i611pkjb7v	/public/images/full/7444ebf1-c440-42be-bf32-9b318b689ff0-1760552377376.webp	5012	3385	webp	90	1554244	cmgsbfivx04sah9i6nlecac7v
cmgsbfiw004sgh9i66b8n2r1d	/public/images/thumbnails/7444ebf1-c440-42be-bf32-9b318b689ff0-1760552377376.webp	150	150	webp	80	6602	cmgsbfivx04sah9i6nlecac7v
cmgsbfkt704snh9i6ul675l3x	/public/images/full/e1148260-2d0b-4aae-8ff3-5d55873cb868-1760552380632.webp	4934	3400	webp	90	1676232	cmgsbfkt404shh9i6ijmpq2hc
cmgsbfkt704slh9i6av2r5hd3	/public/images/thumbnails/e1148260-2d0b-4aae-8ff3-5d55873cb868-1760552380632.webp	150	150	webp	80	7128	cmgsbfkt404shh9i6ijmpq2hc
cmgsbfmjo04ssh9i65us0s6yx	/public/images/thumbnails/8393059f-1517-4d25-8ea3-b15d4b65f60f-1760552383117.webp	150	150	webp	80	5970	cmgsbfmjm04soh9i647pv4pl5
cmgsbfmjo04sth9i6r3dgrifi	/public/images/medium/8393059f-1517-4d25-8ea3-b15d4b65f60f-1760552383117.webp	800	538	webp	85	73030	cmgsbfmjm04soh9i647pv4pl5
cmgsbfotn04sxh9i6nqc4prk5	/public/images/medium/098bb0b9-08d2-4a7e-b82f-19d93e9cd7c1-1760552385368.webp	800	539	webp	85	64556	cmgsbfotl04svh9i6mzyysqhy
cmgsbfoto04szh9i6ve27euji	/public/images/full/098bb0b9-08d2-4a7e-b82f-19d93e9cd7c1-1760552385368.webp	4934	3322	webp	90	1599366	cmgsbfotl04svh9i6mzyysqhy
cmgsbfrtz04t8h9i6g1o1rh15	/public/images/full/e5dd6bc3-79c3-4e47-ac1c-f663d12fbfa7-1760552388326.webp	4758	3209	webp	90	1198548	cmgsbfrtw04t2h9i6pwnfda96
cmgsbfrtz04t6h9i69k74zhzy	/public/images/thumbnails/e5dd6bc3-79c3-4e47-ac1c-f663d12fbfa7-1760552388326.webp	150	150	webp	80	7202	cmgsbfrtw04t2h9i6pwnfda96
cmgsbfwq504tbh9i6bqluykwe	/public/images/thumbnails/dda77339-cd7c-4917-85bb-cc0e4b072a08-1760552392215.webp	150	150	webp	80	8254	cmgsbfwpt04t9h9i650grodtl
cmgsbfwqb04tfh9i6nlhfqzy4	/public/images/full/dda77339-cd7c-4917-85bb-cc0e4b072a08-1760552392215.webp	4718	3209	webp	90	1197704	cmgsbfwpt04t9h9i650grodtl
cmgsbg15j04tmh9i61jsamyqu	/public/images/medium/7c8a5adb-328c-489c-b9b2-ab4ec8b333c0-1760552398585.webp	800	538	webp	85	74104	cmgsbg15c04tgh9i64e63fr27
cmgsbg15j04tkh9i6pi83ld4o	/public/images/full/7c8a5adb-328c-489c-b9b2-ab4ec8b333c0-1760552398585.webp	4798	3229	webp	90	1144694	cmgsbg15c04tgh9i64e63fr27
cmgsbg3x004trh9i6rh9892id	/public/images/thumbnails/042765ea-e13d-4ee6-8701-4f5818479a0f-1760552404317.webp	150	150	webp	80	6984	cmgsbg3wl04tnh9i6eqr72356
cmgsbg3ww04tph9i6bil2iz1u	/public/images/medium/042765ea-e13d-4ee6-8701-4f5818479a0f-1760552404317.webp	800	1186	webp	85	118448	cmgsbg3wl04tnh9i6eqr72356
cmgsbg3y104tth9i6dvaseuif	/public/images/full/042765ea-e13d-4ee6-8701-4f5818479a0f-1760552404317.webp	2496	3701	webp	90	739642	cmgsbg3wl04tnh9i6eqr72356
cmgsbg7fm04tyh9i655dzb2df	/public/images/full/9f6fc31b-d9b2-4235-a4b1-3dc8bdac8b35-1760552407958.webp	2555	3666	webp	90	901780	cmgsbg7ff04tuh9i6q595uqis
cmgsbg7fm04u0h9i69cvisgk0	/public/images/thumbnails/9f6fc31b-d9b2-4235-a4b1-3dc8bdac8b35-1760552407958.webp	150	150	webp	80	8096	cmgsbg7ff04tuh9i6q595uqis
cmgsbg7fm04tzh9i6khns5d6n	/public/images/medium/9f6fc31b-d9b2-4235-a4b1-3dc8bdac8b35-1760552407958.webp	800	1148	webp	85	164890	cmgsbg7ff04tuh9i6q595uqis
cmgsbgal704u3h9i6r5zo6r1o	/public/images/thumbnails/ef3bb82c-5641-4658-b4e5-958d17e7f288-1760552412441.webp	150	150	webp	80	7142	cmgsbgakw04u1h9i66s17cclf
cmgsbgala04u5h9i66cl9tsf4	/public/images/medium/ef3bb82c-5641-4658-b4e5-958d17e7f288-1760552412441.webp	800	1145	webp	85	159264	cmgsbgakw04u1h9i66s17cclf
cmgsbgald04u7h9i6pxuwpiqb	/public/images/full/ef3bb82c-5641-4658-b4e5-958d17e7f288-1760552412441.webp	2576	3687	webp	90	898006	cmgsbgakw04u1h9i66s17cclf
cmgsbgcy604uch9i6eflou5sk	/public/images/thumbnails/9eae75a7-216f-4a67-b0a0-2cabb2ecd842-1760552416565.webp	150	150	webp	80	7268	cmgsbgcxz04u8h9i6gup8horn
cmgsbgf7504ukh9i6yoxhpwim	/public/images/full/cda6a0eb-5e39-410e-ade7-f97a16e13cee-1760552419589.webp	2561	3556	webp	90	890094	cmgsbgf6x04ufh9i6hnla6pzu
cmgsbgjvu04ush9i6ayo98ijd	/public/images/full/30e98037-c174-403d-af0e-b8e79a023f19-1760552422519.webp	5169	3759	webp	90	1916436	cmgsbgjvc04umh9i6p1vih8qe
cmgsbglo004uzh9i68ojk2hjl	/public/images/medium/c45bd683-b882-423a-8521-d327d22b274a-1760552428591.webp	800	834	webp	85	115474	cmgsbglnq04uth9i6raq2q9wt
cmgsbgnot04v4h9i6sw4gnhgy	/public/images/medium/0b8a9b1a-2128-465f-b433-6a9fe2973fbe-1760552430898.webp	800	556	webp	85	65842	cmgsbgnom04v0h9i6wqru2hkl
cmgsbgpvk04vbh9i6jqq0ppzf	/public/images/medium/02f9afce-1c65-47f3-88bc-54e88a8a763e-1760552433512.webp	800	567	webp	85	85068	cmgsbgpvb04v7h9i6c0vdjn5f
cmgsbgs3004vjh9i6co8u7fim	/public/images/thumbnails/0add761f-147a-4d96-ba13-f69f6216797d-1760552436343.webp	150	150	webp	80	6720	cmgsbgs2t04veh9i6r5iivlua
cmgsbgu6404vrh9i61qzixi9e	/public/images/thumbnails/9caf0f37-9821-444c-8450-7b3e3e92d225-1760552439208.webp	150	150	webp	80	7562	cmgsbgu6204vlh9i68hc2ppnt
cmgsbgwpd04vwh9i6d2vecqjo	/public/images/full/fc2e24f9-50bb-4129-b1c1-e792face13e4-1760552441907.webp	3621	2962	webp	90	781084	cmgsbgwp304vsh9i6uj8hhx90
cmgsbgziq04w2h9i6w2hh6iiu	/public/images/medium/524a7d26-e99a-4b12-b02c-9ddb698a73df-1760552445192.webp	800	989	webp	85	90330	cmgsbgzii04vzh9i614nvn75h
cmgsbh2wm04wch9i6m11na9yf	/public/images/medium/3fe24868-f15c-4a81-8b5d-518c7d3d398e-1760552448885.webp	800	587	webp	85	77150	cmgsbh2wb04w6h9i6jph0eu5o
cmgsbh4i104wjh9i61y08rxjq	/public/images/medium/9e6e1c50-2ddb-467f-8aef-8b4587ecac79-1760552453236.webp	800	1050	webp	85	91172	cmgsbh4hy04wdh9i6e669kbz5
cmgsbhuas04wmh9i6nitzxbhv	/public/images/full/f00c66e1-258f-4676-9a81-11daabf34af0-1760552485355.webp	4319	2959	webp	90	1030550	cmgsbhuam04wkh9i6qmejqcgc
cmgsbhunf04wwh9i6g5dtql88	/public/images/full/d7424621-60e4-4388-bf08-47c304eecf9c-1760552455321.webp	5153	6954	webp	90	5963104	cmgsbhumw04wrh9i6g9tzue71
cmgsbhx6g04x2h9i6e7u9i7u2	/public/images/full/35608fd6-15f3-46a6-aea1-19d0431773e6-1760552488730.webp	4087	2799	webp	90	1225660	cmgsbhx6c04wyh9i6uxyyez7f
cmgsbi08c04x9h9i6mcw2hoq8	/public/images/medium/88941667-0fdc-4905-8c14-15381d9ac86a-1760552492465.webp	800	1197	webp	85	128946	cmgsbi08404x5h9i64otxivo4
cmgsbi28t04xhh9i69dlx3c7l	/public/images/thumbnails/a2993695-ff92-430e-93f4-4995eafc1843-1760552496422.webp	150	150	webp	80	6148	cmgsbi28o04xch9i68nrav36o
cmgsbi3vk04xph9i6rngqx4t2	/public/images/medium/9653559b-768c-4fd2-959a-861d2b2249f1-1760552499029.webp	800	812	webp	85	96282	cmgsbi3va04xjh9i6fb0j5ya1
cmgsbi6zl04xsh9i6elh8n9c1	/public/images/medium/9cca6403-42e0-44b5-9d06-089d2581e8d2-1760552501162.webp	800	804	webp	85	90638	cmgsbi6zb04xqh9i6rrkry3iw
cmgsbi8j004y3h9i6vzuxiq65	/public/images/medium/11e18ae3-56fa-40e6-b5b7-c1c20798830e-1760552505184.webp	800	1045	webp	85	80202	cmgsbi8is04xxh9i6f874249v
cmgsbiazd04y8h9i6rqslt9wz	/public/images/medium/be6bd131-2117-4a38-bd29-039acb24e76c-1760552507172.webp	800	969	webp	85	99078	cmgsbiaz604y4h9i6nakxuy7v
cmgsbicnd04yfh9i66ghoe3e8	/public/images/medium/c3d78c4f-d570-42b0-80ba-b4ebb9253782-1760552510351.webp	800	978	webp	85	125892	cmgsbicn804ybh9i6xvmc7i9r
cmgsbifi404ymh9i6ihbad533	/public/images/medium/8f5c287f-c79e-4d70-8496-da55ce29f0f9-1760552512511.webp	800	1206	webp	85	171536	cmgsbifht04yih9i6dya6nhdl
cmgsbihoo04ysh9i6pqru6gub	/public/images/medium/a32bdf05-c793-4bba-a4db-4b47303785d7-1760552516221.webp	800	520	webp	85	59842	cmgsbihof04yph9i6qrkp2d59
cmgsbik9n04yyh9i6t6ugxte5	/public/images/thumbnails/f3624db7-fe91-446a-879e-65d4daeb2e68-1760552519052.webp	150	150	webp	80	5888	cmgsbik9d04ywh9i652bwbig2
cmgsbil6r04z9h9i60by8q3ns	/public/images/full/91ac7bbd-38b5-4207-b4a4-a91d66e5d9c9-1760552522382.webp	1421	1887	webp	90	251296	cmgsbil6l04z3h9i6gjda120c
cmgsbinjg04zch9i6g0il38xg	/public/images/thumbnails/9ad29d57-d561-4f0a-a0ed-d8077f0f8934-1760552523581.webp	150	150	webp	80	7540	cmgsbinj304zah9i66nv8hggz
cmgsbiq6v04znh9i67cbyh1z8	/public/images/thumbnails/abbaaa62-bd1e-4836-883d-3f8045d8712e-1760552526629.webp	150	150	webp	80	9282	cmgsbiq6n04zhh9i67ixvyu8q
cmgsbistl04zth9i6yz1bgngs	/public/images/medium/a1dfaf00-5808-46d4-9792-080c5cd150eb-1760552530070.webp	800	985	webp	85	153494	cmgsbistg04zoh9i6klqmewjn
cmgsbivbl0501h9i670wf1jb5	/public/images/full/8fbe6e9e-bd3d-4185-8b69-eaf693fd7b2b-1760552533472.webp	4357	2714	webp	90	939216	cmgsbivbe04zvh9i6g4krqvaf
cmgsbiy460504h9i6bxy3h3mr	/public/images/medium/b315a2b5-8c7c-4fdf-952b-91275605cb78-1760552536709.webp	800	1251	webp	85	220000	cmgsbiy3x0502h9i6a2rfhg79
cmgsbj0ex050fh9i64e15y7a3	/public/images/full/40aae580-3c6d-4db6-b8bc-e306db1685c5-1760552540340.webp	4091	2511	webp	90	764112	cmgsbj0et0509h9i6v3nqtwqq
cmgsbj47u050lh9i6h8ah8d8z	/public/images/medium/dd6f381a-82be-4504-8f91-9e51a7fe8b89-1760552543320.webp	800	588	webp	85	102898	cmgsbj47n050gh9i6rbehqrxe
cmgsbj65c050rh9i650habamr	/public/images/medium/512850f1-fb86-4716-bf1f-90c5c1ee0723-1760552548251.webp	800	610	webp	85	93966	cmgsbj65a050nh9i62v5v9zgm
cmgsbj89t0510h9i6xujpsw1n	/public/images/thumbnails/1259d078-7c5b-4feb-aaea-936748330d46-1760552550743.webp	150	150	webp	80	6020	cmgsbj89p050uh9i6xzfi0xqg
cmgsbj9se0513h9i6lzrfmspe	/public/images/thumbnails/2d614e1b-e727-4205-8acc-a3a3855f7ac7-1760552553500.webp	150	150	webp	80	7524	cmgsbj9s60511h9i6hw5d7os3
cmgsbjbio051eh9i6eog17jjd	/public/images/medium/c6ddb12e-02cb-4f1a-826e-e0c03c143a26-1760552555476.webp	800	826	webp	85	101498	cmgsbjbii0518h9i6cehh7va1
cmgsbjd3o051kh9i6e8mej4e1	/public/images/thumbnails/6ea0abed-34c6-44c8-a8c5-add0c6f158fb-1760552557705.webp	150	150	webp	80	3946	cmgsbjd3g051fh9i6c3zmdzjp
cmgsbjend051qh9i69v66oyi7	/public/images/medium/079c1c4c-9ce7-41dd-9b73-836f31d5d0c2-1760552559755.webp	800	729	webp	85	96296	cmgsbjen7051mh9i66kd1hac9
cmgsbjg3r051xh9i6k0u1ccpa	/public/images/medium/761c29ef-840c-48fd-8a13-8b2d32a29003-1760552561773.webp	800	705	webp	85	74766	cmgsbjg3n051th9i6ez09ow4k
cmgsbjhjl0525h9i6ld4xsyzu	/public/images/thumbnails/1d78e6aa-bc35-4f7a-82dc-e238e570a77f-1760552563642.webp	150	150	webp	80	7736	cmgsbjhjg0520h9i64fnz8isz
cmgsbjj5m052bh9i6h5j3l9qz	/public/images/thumbnails/e9cb9814-ea1c-4827-a666-388435f852d1-1760552565506.webp	150	150	webp	80	5972	cmgsbjj5f0527h9i6hjwgit5p
cmgsbjkpt052ih9i6c5gwsl8m	/public/images/medium/eecb2380-44cf-47cf-9478-3b03ef5ac1c1-1760552567608.webp	800	832	webp	85	110318	cmgsbjkpq052eh9i60a8hyv1c
cmgsbgcy604ubh9i669gav5tn	/public/images/medium/9eae75a7-216f-4a67-b0a0-2cabb2ecd842-1760552416565.webp	800	561	webp	85	77820	cmgsbgcxz04u8h9i6gup8horn
cmgsbgf7504ulh9i6x523o4fe	/public/images/thumbnails/cda6a0eb-5e39-410e-ade7-f97a16e13cee-1760552419589.webp	150	150	webp	80	6068	cmgsbgf6x04ufh9i6hnla6pzu
cmgsbgjvt04uoh9i6bq9gzqs2	/public/images/thumbnails/30e98037-c174-403d-af0e-b8e79a023f19-1760552422519.webp	150	150	webp	80	6820	cmgsbgjvc04umh9i6p1vih8qe
cmgsbglo004uxh9i6wvhlmfak	/public/images/full/c45bd683-b882-423a-8521-d327d22b274a-1760552428591.webp	2467	2573	webp	90	575416	cmgsbglnq04uth9i6raq2q9wt
cmgsbgnot04v5h9i66ho7glcn	/public/images/thumbnails/0b8a9b1a-2128-465f-b433-6a9fe2973fbe-1760552430898.webp	150	150	webp	80	7450	cmgsbgnom04v0h9i6wqru2hkl
cmgsbgpvl04vdh9i69aheei62	/public/images/full/02f9afce-1c65-47f3-88bc-54e88a8a763e-1760552433512.webp	3654	2589	webp	90	852792	cmgsbgpvb04v7h9i6c0vdjn5f
cmgsbgs3004vih9i62azf52zo	/public/images/medium/0add761f-147a-4d96-ba13-f69f6216797d-1760552436343.webp	800	1181	webp	85	117770	cmgsbgs2t04veh9i6r5iivlua
cmgsbgu6404vqh9i6qxdsp9os	/public/images/full/9caf0f37-9821-444c-8450-7b3e3e92d225-1760552439208.webp	3638	2464	webp	90	870352	cmgsbgu6204vlh9i68hc2ppnt
cmgsbgwpd04vuh9i64tivwrbi	/public/images/medium/fc2e24f9-50bb-4129-b1c1-e792face13e4-1760552441907.webp	800	655	webp	85	84472	cmgsbgwp304vsh9i6uj8hhx90
cmgsbgziq04w3h9i6gpvto9tq	/public/images/full/524a7d26-e99a-4b12-b02c-9ddb698a73df-1760552445192.webp	2900	3587	webp	90	653948	cmgsbgzii04vzh9i614nvn75h
cmgsbh2wl04w9h9i67ocfgh06	/public/images/full/3fe24868-f15c-4a81-8b5d-518c7d3d398e-1760552448885.webp	3529	2589	webp	90	827242	cmgsbh2wb04w6h9i6jph0eu5o
cmgsbh4i104whh9i6sqdlh6wu	/public/images/thumbnails/9e6e1c50-2ddb-467f-8aef-8b4587ecac79-1760552453236.webp	150	150	webp	80	5542	cmgsbh4hy04wdh9i6e669kbz5
cmgsbhuau04woh9i6yys4voe0	/public/images/thumbnails/f00c66e1-258f-4676-9a81-11daabf34af0-1760552485355.webp	150	150	webp	80	6570	cmgsbhuam04wkh9i6qmejqcgc
cmgsbhung04wxh9i6r15cd74m	/public/images/medium/d7424621-60e4-4388-bf08-47c304eecf9c-1760552455321.webp	800	1080	webp	85	150450	cmgsbhumw04wrh9i6g9tzue71
cmgsbhx6h04x4h9i6a9745rnk	/public/images/medium/35608fd6-15f3-46a6-aea1-19d0431773e6-1760552488730.webp	800	548	webp	85	92366	cmgsbhx6c04wyh9i6uxyyez7f
cmgsbi08c04x8h9i6qjnp72fd	/public/images/full/88941667-0fdc-4905-8c14-15381d9ac86a-1760552492465.webp	2995	4479	webp	90	1097678	cmgsbi08404x5h9i64otxivo4
cmgsbi28t04xgh9i60pazdtta	/public/images/full/a2993695-ff92-430e-93f4-4995eafc1843-1760552496422.webp	3703	2562	webp	90	524656	cmgsbi28o04xch9i68nrav36o
cmgsbi3vk04xnh9i6ujyeuju9	/public/images/full/9653559b-768c-4fd2-959a-861d2b2249f1-1760552499029.webp	2610	2651	webp	90	528374	cmgsbi3va04xjh9i6fb0j5ya1
cmgsbi6zl04xwh9i64vzc3kwz	/public/images/full/9cca6403-42e0-44b5-9d06-089d2581e8d2-1760552501162.webp	3569	3587	webp	90	1125320	cmgsbi6zb04xqh9i6rrkry3iw
cmgsbi8j004y1h9i69obkkuyo	/public/images/full/11e18ae3-56fa-40e6-b5b7-c1c20798830e-1760552505184.webp	2030	2652	webp	90	344712	cmgsbi8is04xxh9i6f874249v
cmgsbiaze04yah9i6133ttp2d	/public/images/full/be6bd131-2117-4a38-bd29-039acb24e76c-1760552507172.webp	3034	3677	webp	90	654820	cmgsbiaz604y4h9i6nakxuy7v
cmgsbicnd04ygh9i6ljqosuw5	/public/images/thumbnails/c3d78c4f-d570-42b0-80ba-b4ebb9253782-1760552510351.webp	150	150	webp	80	7462	cmgsbicn804ybh9i6xvmc7i9r
cmgsbifi404ylh9i634cavq0w	/public/images/full/8f5c287f-c79e-4d70-8496-da55ce29f0f9-1760552512511.webp	2639	3978	webp	90	1050498	cmgsbifht04yih9i6dya6nhdl
cmgsbihoo04yvh9i63zfqs2jb	/public/images/full/a32bdf05-c793-4bba-a4db-4b47303785d7-1760552516221.webp	3982	2589	webp	90	844000	cmgsbihof04yph9i6qrkp2d59
cmgsbik9p04z2h9i6oapg63bd	/public/images/medium/f3624db7-fe91-446a-879e-65d4daeb2e68-1760552519052.webp	800	1245	webp	85	139508	cmgsbik9d04ywh9i652bwbig2
cmgsbil6p04z5h9i6xotib7j8	/public/images/thumbnails/91ac7bbd-38b5-4207-b4a4-a91d66e5d9c9-1760552522382.webp	150	150	webp	80	7134	cmgsbil6l04z3h9i6gjda120c
cmgsbinjh04zgh9i6xms6ik0j	/public/images/full/9ad29d57-d561-4f0a-a0ed-d8077f0f8934-1760552523581.webp	2592	3993	webp	90	933142	cmgsbinj304zah9i66nv8hggz
cmgsbiq6v04zlh9i6i4jlaync	/public/images/medium/abbaaa62-bd1e-4836-883d-3f8045d8712e-1760552526629.webp	800	1273	webp	85	234904	cmgsbiq6n04zhh9i67ixvyu8q
cmgsbistl04zuh9i67c3ugdrm	/public/images/thumbnails/a1dfaf00-5808-46d4-9792-080c5cd150eb-1760552530070.webp	150	150	webp	80	7072	cmgsbistg04zoh9i6klqmewjn
cmgsbivbj04zyh9i69h40m7bm	/public/images/thumbnails/8fbe6e9e-bd3d-4185-8b69-eaf693fd7b2b-1760552533472.webp	150	150	webp	80	7544	cmgsbivbe04zvh9i6g4krqvaf
cmgsbiy470506h9i6we5on79o	/public/images/thumbnails/b315a2b5-8c7c-4fdf-952b-91275605cb78-1760552536709.webp	150	150	webp	80	9512	cmgsbiy3x0502h9i6a2rfhg79
cmgsbj0ex050dh9i6donin1bo	/public/images/medium/40aae580-3c6d-4db6-b8bc-e306db1685c5-1760552540340.webp	800	491	webp	85	59940	cmgsbj0et0509h9i6v3nqtwqq
cmgsbj47u050mh9i65vh5gmqp	/public/images/thumbnails/dd6f381a-82be-4504-8f91-9e51a7fe8b89-1760552543320.webp	150	150	webp	80	7564	cmgsbj47n050gh9i6rbehqrxe
cmgsbj65c050sh9i6xrdi9pnf	/public/images/thumbnails/512850f1-fb86-4716-bf1f-90c5c1ee0723-1760552548251.webp	150	150	webp	80	8086	cmgsbj65a050nh9i62v5v9zgm
cmgsbj89t050zh9i6kk35gyzm	/public/images/medium/1259d078-7c5b-4feb-aaea-936748330d46-1760552550743.webp	800	556	webp	85	74478	cmgsbj89p050uh9i6xzfi0xqg
cmgsbj9sg0517h9i6l2t4q132	/public/images/full/2d614e1b-e727-4205-8acc-a3a3855f7ac7-1760552553500.webp	2561	2652	webp	90	517916	cmgsbj9s60511h9i6hw5d7os3
cmgsbjbio051ch9i6fv7c2977	/public/images/full/c6ddb12e-02cb-4f1a-826e-e0c03c143a26-1760552555476.webp	2573	2654	webp	90	632562	cmgsbjbii0518h9i6cehh7va1
cmgsbjd3o051lh9i6czsygsq0	/public/images/medium/6ea0abed-34c6-44c8-a8c5-add0c6f158fb-1760552557705.webp	800	809	webp	85	53480	cmgsbjd3g051fh9i6c3zmdzjp
cmgsbjene051sh9i6hljd2f5d	/public/images/full/079c1c4c-9ce7-41dd-9b73-836f31d5d0c2-1760552559755.webp	2483	2262	webp	90	460238	cmgsbjen7051mh9i66kd1hac9
cmgsbjg3r051wh9i6nyob7t5y	/public/images/thumbnails/761c29ef-840c-48fd-8a13-8b2d32a29003-1760552561773.webp	150	150	webp	80	6384	cmgsbjg3n051th9i6ez09ow4k
cmgsbjhjl0524h9i6f19vaavz	/public/images/medium/1d78e6aa-bc35-4f7a-82dc-e238e570a77f-1760552563642.webp	800	913	webp	85	103176	cmgsbjhjg0520h9i64fnz8isz
cmgsbjj5n052dh9i6mcjuwrby	/public/images/full/e9cb9814-ea1c-4827-a666-388435f852d1-1760552565506.webp	2342	2417	webp	90	400736	cmgsbjj5f0527h9i6hjwgit5p
cmgsbjkpt052jh9i6n6gy43yn	/public/images/full/eecb2380-44cf-47cf-9478-3b03ef5ac1c1-1760552567608.webp	2295	2386	webp	90	464616	cmgsbjkpq052eh9i60a8hyv1c
cmgsbgcy704ueh9i6w8ze313v	/public/images/full/9eae75a7-216f-4a67-b0a0-2cabb2ecd842-1760552416565.webp	3669	2573	webp	90	878852	cmgsbgcxz04u8h9i6gup8horn
cmgsbgf7504ujh9i62ckfx4qe	/public/images/medium/cda6a0eb-5e39-410e-ade7-f97a16e13cee-1760552419589.webp	800	1111	webp	85	161604	cmgsbgf6x04ufh9i6hnla6pzu
cmgsbgjvu04urh9i658bp5e07	/public/images/medium/30e98037-c174-403d-af0e-b8e79a023f19-1760552422519.webp	800	581	webp	85	93604	cmgsbgjvc04umh9i6p1vih8qe
cmgsbglo004uyh9i6n842v2av	/public/images/thumbnails/c45bd683-b882-423a-8521-d327d22b274a-1760552428591.webp	150	150	webp	80	7472	cmgsbglnq04uth9i6raq2q9wt
cmgsbgnot04v6h9i6c7ri96zd	/public/images/full/0b8a9b1a-2128-465f-b433-6a9fe2973fbe-1760552430898.webp	3591	2495	webp	90	618186	cmgsbgnom04v0h9i6wqru2hkl
cmgsbgpvj04v9h9i67otluj8s	/public/images/thumbnails/02f9afce-1c65-47f3-88bc-54e88a8a763e-1760552433512.webp	150	150	webp	80	7378	cmgsbgpvb04v7h9i6c0vdjn5f
cmgsbgs3004vkh9i6uiamj79i	/public/images/full/0add761f-147a-4d96-ba13-f69f6216797d-1760552436343.webp	2514	3712	webp	90	746910	cmgsbgs2t04veh9i6r5iivlua
cmgsbgu6404vph9i6phmh5w0h	/public/images/medium/9caf0f37-9821-444c-8450-7b3e3e92d225-1760552439208.webp	800	542	webp	85	86404	cmgsbgu6204vlh9i68hc2ppnt
cmgsbgwpe04vyh9i61awmgpx5	/public/images/thumbnails/fc2e24f9-50bb-4129-b1c1-e792face13e4-1760552441907.webp	150	150	webp	80	6642	cmgsbgwp304vsh9i6uj8hhx90
cmgsbgzit04w5h9i6ix31j15f	/public/images/thumbnails/524a7d26-e99a-4b12-b02c-9ddb698a73df-1760552445192.webp	150	150	webp	80	5304	cmgsbgzii04vzh9i614nvn75h
cmgsbh2wl04wah9i65z9s6nhy	/public/images/thumbnails/3fe24868-f15c-4a81-8b5d-518c7d3d398e-1760552448885.webp	150	150	webp	80	7712	cmgsbh2wb04w6h9i6jph0eu5o
cmgsbh4i104wih9i65c9pedpx	/public/images/full/9e6e1c50-2ddb-467f-8aef-8b4587ecac79-1760552453236.webp	2406	3159	webp	90	519536	cmgsbh4hy04wdh9i6e669kbz5
cmgsbhuav04wqh9i680744ohu	/public/images/medium/f00c66e1-258f-4676-9a81-11daabf34af0-1760552485355.webp	800	548	webp	85	56648	cmgsbhuam04wkh9i6qmejqcgc
cmgsbhune04wth9i6plfh4lnp	/public/images/thumbnails/d7424621-60e4-4388-bf08-47c304eecf9c-1760552455321.webp	150	150	webp	80	6152	cmgsbhumw04wrh9i6g9tzue71
cmgsbhx6g04x1h9i6iv5foug9	/public/images/thumbnails/35608fd6-15f3-46a6-aea1-19d0431773e6-1760552488730.webp	150	150	webp	80	5948	cmgsbhx6c04wyh9i6uxyyez7f
cmgsbi08d04xbh9i6sb2i1j6b	/public/images/thumbnails/88941667-0fdc-4905-8c14-15381d9ac86a-1760552492465.webp	150	150	webp	80	6070	cmgsbi08404x5h9i64otxivo4
cmgsbi28t04xih9i6a0hkehwu	/public/images/medium/a2993695-ff92-430e-93f4-4995eafc1843-1760552496422.webp	800	554	webp	85	53542	cmgsbi28o04xch9i68nrav36o
cmgsbi3vk04xoh9i61o1z9vx8	/public/images/thumbnails/9653559b-768c-4fd2-959a-861d2b2249f1-1760552499029.webp	150	150	webp	80	7408	cmgsbi3va04xjh9i6fb0j5ya1
cmgsbi6zl04xvh9i6orbi8lgs	/public/images/thumbnails/9cca6403-42e0-44b5-9d06-089d2581e8d2-1760552501162.webp	150	150	webp	80	5008	cmgsbi6zb04xqh9i6rrkry3iw
cmgsbi8iz04xzh9i6pc7k5nw7	/public/images/thumbnails/11e18ae3-56fa-40e6-b5b7-c1c20798830e-1760552505184.webp	150	150	webp	80	4074	cmgsbi8is04xxh9i6f874249v
cmgsbiazd04y7h9i6zrx6jh79	/public/images/thumbnails/be6bd131-2117-4a38-bd29-039acb24e76c-1760552507172.webp	150	150	webp	80	8056	cmgsbiaz604y4h9i6nakxuy7v
cmgsbicnd04yhh9i6su2r0vev	/public/images/full/c3d78c4f-d570-42b0-80ba-b4ebb9253782-1760552510351.webp	2092	2558	webp	90	466350	cmgsbicn804ybh9i6xvmc7i9r
cmgsbifi404yoh9i6xng09vvo	/public/images/thumbnails/8f5c287f-c79e-4d70-8496-da55ce29f0f9-1760552512511.webp	150	150	webp	80	6142	cmgsbifht04yih9i6dya6nhdl
cmgsbihoo04yth9i68j3o8l5y	/public/images/thumbnails/a32bdf05-c793-4bba-a4db-4b47303785d7-1760552516221.webp	150	150	webp	80	6568	cmgsbihof04yph9i6qrkp2d59
cmgsbik9p04z0h9i6egg6ch43	/public/images/full/f3624db7-fe91-446a-879e-65d4daeb2e68-1760552519052.webp	2576	4009	webp	90	842546	cmgsbik9d04ywh9i652bwbig2
cmgsbil6q04z7h9i616j3lrz5	/public/images/medium/91ac7bbd-38b5-4207-b4a4-a91d66e5d9c9-1760552522382.webp	800	1062	webp	85	110022	cmgsbil6l04z3h9i6gjda120c
cmgsbinjg04zeh9i6tv7ffxgn	/public/images/medium/9ad29d57-d561-4f0a-a0ed-d8077f0f8934-1760552523581.webp	800	1232	webp	85	163070	cmgsbinj304zah9i66nv8hggz
cmgsbiq6v04zmh9i65pmqyh52	/public/images/full/abbaaa62-bd1e-4836-883d-3f8045d8712e-1760552526629.webp	2498	3977	webp	90	1335520	cmgsbiq6n04zhh9i67ixvyu8q
cmgsbistl04zsh9i6iqf9knrd	/public/images/full/a1dfaf00-5808-46d4-9792-080c5cd150eb-1760552530070.webp	2951	3634	webp	90	1118294	cmgsbistg04zoh9i6klqmewjn
cmgsbivbj04zzh9i6x34xq8qi	/public/images/medium/8fbe6e9e-bd3d-4185-8b69-eaf693fd7b2b-1760552533472.webp	800	498	webp	85	76420	cmgsbivbe04zvh9i6g4krqvaf
cmgsbiy480508h9i6c2o86mdm	/public/images/full/b315a2b5-8c7c-4fdf-952b-91275605cb78-1760552536709.webp	2496	3904	webp	90	1116064	cmgsbiy3x0502h9i6a2rfhg79
cmgsbj0ex050eh9i6usqsvmxi	/public/images/thumbnails/40aae580-3c6d-4db6-b8bc-e306db1685c5-1760552540340.webp	150	150	webp	80	6588	cmgsbj0et0509h9i6v3nqtwqq
cmgsbj47u050kh9i68ldrm1m6	/public/images/full/dd6f381a-82be-4504-8f91-9e51a7fe8b89-1760552543320.webp	4731	3478	webp	90	1823136	cmgsbj47n050gh9i6rbehqrxe
cmgsbj65c050th9i6d0web4ie	/public/images/full/512850f1-fb86-4716-bf1f-90c5c1ee0723-1760552548251.webp	3232	2464	webp	90	804064	cmgsbj65a050nh9i62v5v9zgm
cmgsbj89t050yh9i6uucuu24w	/public/images/full/1259d078-7c5b-4feb-aaea-936748330d46-1760552550743.webp	3701	2573	webp	90	703778	cmgsbj89p050uh9i6xzfi0xqg
cmgsbj9sf0515h9i6vwjweumr	/public/images/medium/2d614e1b-e727-4205-8acc-a3a3855f7ac7-1760552553500.webp	800	829	webp	85	95424	cmgsbj9s60511h9i6hw5d7os3
cmgsbjbio051bh9i64juyre7w	/public/images/thumbnails/c6ddb12e-02cb-4f1a-826e-e0c03c143a26-1760552555476.webp	150	150	webp	80	7718	cmgsbjbii0518h9i6cehh7va1
cmgsbjd3o051jh9i62onyw3e2	/public/images/full/6ea0abed-34c6-44c8-a8c5-add0c6f158fb-1760552557705.webp	2561	2589	webp	90	442642	cmgsbjd3g051fh9i6c3zmdzjp
cmgsbjend051ph9i6coxo5qxd	/public/images/thumbnails/079c1c4c-9ce7-41dd-9b73-836f31d5d0c2-1760552559755.webp	150	150	webp	80	7270	cmgsbjen7051mh9i66kd1hac9
cmgsbjg3r051zh9i6znex82q7	/public/images/full/761c29ef-840c-48fd-8a13-8b2d32a29003-1760552561773.webp	2514	2215	webp	90	388938	cmgsbjg3n051th9i6ez09ow4k
cmgsbjhjl0526h9i6iubrgs2w	/public/images/full/1d78e6aa-bc35-4f7a-82dc-e238e570a77f-1760552563642.webp	2077	2371	webp	90	401996	cmgsbjhjg0520h9i64fnz8isz
cmgsbjj5m052ah9i6v5qfubrf	/public/images/medium/e9cb9814-ea1c-4827-a666-388435f852d1-1760552565506.webp	800	826	webp	85	78830	cmgsbjj5f0527h9i6hjwgit5p
cmgsbjkpt052kh9i63wwpx50g	/public/images/thumbnails/eecb2380-44cf-47cf-9478-3b03ef5ac1c1-1760552567608.webp	150	150	webp	80	8746	cmgsbjkpq052eh9i60a8hyv1c
cmgsbjm0t052nh9i6wgko1cgv	/public/images/thumbnails/af28c86f-b566-4c85-8f7c-678270d22f20-1760552569617.webp	150	150	webp	80	5526	cmgsbjm0o052lh9i6w7jskjzz
cmgsbjnji052yh9i66bpp5pey	/public/images/full/4f069248-30f7-4fe8-adf1-c09b0ed8b6d4-1760552571318.webp	2311	2371	webp	90	417984	cmgsbjnjb052sh9i6ag2epwql
cmgsbjos40535h9i6xnel5k3e	/public/images/full/ba11fd71-e4e8-405d-a2ae-609381b3f5e6-1760552573292.webp	2264	2262	webp	90	244858	cmgsbjorv052zh9i6s3m7iwbk
cmgsbjqgc0539h9i6rdt0gvgi	/public/images/medium/284c6d24-b1fb-44e9-bf1e-96f83ae33e7e-1760552574895.webp	800	907	webp	85	135636	cmgsbjqg00536h9i6t5o3zx04
cmgsbjsbo053hh9i6t0a95n4v	/public/images/full/b82b47cd-8d30-4c67-861b-a16e68fe1b3f-1760552577091.webp	1795	2449	webp	90	329432	cmgsbjsbe053dh9i6al88twgq
cmgsblz5o05boh9i6ekd50jvo	/public/images/full/b31e4493-8967-4b5c-be51-b0d4b55bba57-1760552679992.webp	2654	4087	webp	90	774012	cmgsblz5l05bjh9i6jb1w5btx
cmgsblzx705bsh9i696bfwvmq	/public/images/thumbnails/918bef4d-2dfb-4316-8cde-308730becf67-1760552681643.webp	150	150	webp	80	7402	cmgsblzx505bqh9i6dx1fewht
cmgsbm0u805c2h9i6dgwb4m54	/public/images/medium/4c41c8ca-b9f7-4d22-ae44-2e647c1c0682-1760552682635.webp	800	813	webp	85	66600	cmgsbm0u505bxh9i6zpwsws50
cmgsbm1px05cah9i6qwxmwln4	/public/images/full/e8ea3dad-11c8-45e9-b47c-73deee53ddee-1760552683824.webp	2873	2074	webp	90	806754	cmgsbm1pu05c4h9i6dczxw0yp
cmgsbm2bs05chh9i6qfxdgov3	/public/images/full/cea7e4ed-daa4-4f70-8b22-b45780e4236f-1760552684963.webp	2555	1466	webp	90	356496	cmgsbm2bq05cbh9i6c39k8cdg
cmgsbm3ux05clh9i6k6al3ccw	/public/images/thumbnails/5eeb0fcb-0236-490e-a0c7-061eca372191-1760552685756.webp	150	150	webp	80	7574	cmgsbm3uv05cih9i6ffuffyk3
cmgsbm4zv05cvh9i6v6lxqaea	/public/images/full/f6328e5d-e2fb-4eb0-a8c8-9f176eb229ce-1760552687737.webp	2723	3247	webp	90	809666	cmgsbm4zr05cph9i65tce9yyu
cmgsbm74405d1h9i6yec5oph2	/public/images/medium/e303d453-3d7f-4d66-9ba7-dffc5e03486d-1760552689220.webp	800	560	webp	85	119656	cmgsbm74105cwh9i6a0xl90cr
cmgsbm8mp05d7h9i6iqizcosu	/public/images/medium/117c1eed-e654-40e1-81d1-b025effac85b-1760552691959.webp	800	547	webp	85	83756	cmgsbm8mn05d3h9i65w13wnkc
cmgsbm9wd05dfh9i6wr5gn5ep	/public/images/medium/8f42fbfb-460a-4816-af79-fabcf2a61bec-1760552693919.webp	800	566	webp	85	70338	cmgsbm9wa05dah9i6678voouo
cmgsbmb4o05dnh9i6dz2c59x6	/public/images/full/ea57571e-d560-494a-96c9-a02a1e3928d0-1760552695567.webp	3654	2698	webp	90	787796	cmgsbmb4l05dhh9i6qzlv2z8b
cmgsbmdjo05dsh9i6u5hu3a0e	/public/images/full/bcf84f63-0383-4380-85da-474d8f315f4e-1760552697174.webp	5200	3587	webp	90	3141176	cmgsbmdjm05doh9i6d7pe4skt
cmgsbmkna05emh9i6xth42xou	/public/images/medium/16e6a267-2770-478e-95c3-56e5a8686a7d-1760552706902.webp	800	581	webp	85	81342	cmgsbmkmp05egh9i6a26tnltk
cmgsbmlps05erh9i6tc74nw7v	/public/images/medium/7000d8a3-ea04-4070-8c83-53c2c6c76263-1760552709499.webp	800	586	webp	85	74124	cmgsbmlpo05enh9i6knu1hly1
cmgsbmmv605exh9i6767480rd	/public/images/medium/e4488623-d233-4daa-a25f-66ad3bd23b13-1760552710878.webp	800	1017	webp	85	208788	cmgsbmmv405euh9i6zfosbim2
cmgsbmnle05f4h9i65wi8x5d9	/public/images/thumbnails/1e1f50ab-81a5-4461-86eb-8bb14496d2ac-1760552712371.webp	150	150	webp	80	6106	cmgsbmnlb05f1h9i6d2p2e1zf
cmgsbmprl05fdh9i6907vtd6y	/public/images/medium/b9917bba-2b33-4fbf-a940-6cf6ac6432ae-1760552713323.webp	800	1167	webp	85	205990	cmgsbmprj05f8h9i6trz6nwk3
cmgsbmqug05fjh9i6imvwapes	/public/images/thumbnails/6a8f2e0d-beca-4255-ba93-0a9bdca17764-1760552716130.webp	150	150	webp	80	7156	cmgsbmqub05ffh9i6zpayz43z
cmgsbmsw605fph9i69rp4sz4k	/public/images/thumbnails/7573b61f-4e6f-48ca-93c8-b336ac076291-1760552717529.webp	150	150	webp	80	7432	cmgsbmsw405fmh9i6cst12azc
cmgsbmtzv05fzh9i6inn34227	/public/images/medium/89868dc2-9655-4c1b-b25d-9118343276b6-1760552720184.webp	800	644	webp	85	66136	cmgsbmtzr05fth9i62gpk6ocp
cmgsbmw5705g4h9i66dvfy6he	/public/images/full/c0a8a368-b8bc-4a62-9779-281b770122d6-1760552721618.webp	5169	3572	webp	90	1980382	cmgsbmw5305g0h9i6ub04phdb
cmgsbmwwn05gch9i6g62f44of	/public/images/medium/b3abc26d-0f82-46d4-b8cd-854555069007-1760552724392.webp	800	1015	webp	85	128788	cmgsbmwwl05g7h9i6bdbxeurn
cmgsbmy6o05ghh9i6hlh8h9x0	/public/images/thumbnails/847f2db1-1658-4824-bcaa-dd161c878ed5-1760552725385.webp	150	150	webp	80	5728	cmgsbmy6m05geh9i6jqi9odgb
cmgsbmysa05grh9i6mq6cdp1f	/public/images/full/099cdc42-8035-441f-913d-044304d121bd-1760552727038.webp	1654	1969	webp	90	382184	cmgsbmys805glh9i6ryj1x1yd
cmgsbn01805gvh9i6xofdgbv1	/public/images/medium/19b059a6-b1bf-406b-a42b-68d9e5a5c815-1760552727819.webp	800	551	webp	85	92118	cmgsbn01605gsh9i6oxq73vrm
cmgsbn12405h4h9i6ydhsfuyk	/public/images/medium/cb5accb8-a596-4148-9423-86121094e660-1760552729442.webp	800	1064	webp	85	201894	cmgsbn12205gzh9i6o07wqbma
cmgsbn1zx05hbh9i6fpl407ca	/public/images/medium/09a8ad25-939d-47d5-b570-ac3c10441ec7-1760552730765.webp	800	1149	webp	85	89800	cmgsbn1zv05h6h9i6v67wuixn
cmgsbn2zt05hhh9i6mzbfsp67	/public/images/medium/0284b504-1e0b-4612-beff-3f9cb254929b-1760552731983.webp	800	1066	webp	85	56478	cmgsbn2zr05hdh9i672ph0f5n
cmgsbn40705hqh9i6cnclfdh7	/public/images/full/4da7618b-7819-448c-ba0b-a931b52c365a-1760552733273.webp	2311	3307	webp	90	638058	cmgsbn40505hkh9i6krvswxmo
cmgsbn50i05huh9i60kh4ievt	/public/images/medium/d1979e9a-1577-469a-9f81-1e3e8ee8bff6-1760552734584.webp	800	1077	webp	85	100838	cmgsbn50g05hrh9i6uz6qod3i
cmgsbn76205i1h9i6243ot2jb	/public/images/thumbnails/fb5f1a0e-afa6-46e9-b67d-d6ffaf1cafa3-1760552735894.webp	150	150	webp	80	6520	cmgsbn75z05hyh9i6t8p7lzi0
cmgsbn81505iah9i6068m8wn6	/public/images/medium/1ee39c6b-e087-4439-9fef-d1a5de4893b5-1760552738684.webp	800	1149	webp	85	82294	cmgsbn81305i5h9i6s3bv9vv4
cmgsbna0m05igh9i6cblmdq1w	/public/images/medium/9b2e8fd2-25f5-4915-bb16-1f62185ee649-1760552739806.webp	800	525	webp	85	96680	cmgsbna0k05ich9i6pxqdl4sd
cmgsbnbd405inh9i6r2bukz7f	/public/images/medium/beea9111-0edf-4061-b8d8-a331d7040b13-1760552742375.webp	800	1145	webp	85	180322	cmgsbnbd205ijh9i61rbmvjk7
cmgsbndde05ivh9i68sq9tqhk	/public/images/medium/f9745a6f-5264-4fd1-831a-497917e4a2c2-1760552744125.webp	800	550	webp	85	70090	cmgsbnddc05iqh9i6kbrm103t
cmgsbne1n05j2h9i6edk1uy9f	/public/images/thumbnails/5ec20c90-864c-4cf8-a79d-23f4ddb237e5-1760552746722.webp	150	150	webp	80	9898	cmgsbne1k05ixh9i6tmmnroha
cmgsbney605j8h9i66zfzovid	/public/images/thumbnails/6748f532-622e-46d6-9fca-e17b332f3649-1760552747596.webp	150	150	webp	80	7520	cmgsbney305j4h9i65ekcjxao
cmgsbngbk05jhh9i6kjl9gz3z	/public/images/full/570ef93f-d6f3-4629-bc4c-208c0dbbfa7a-1760552748767.webp	2389	3993	webp	90	778518	cmgsbngbg05jbh9i64un58w8x
cmgsbjm0v052ph9i65g4j943d	/public/images/medium/af28c86f-b566-4c85-8f7c-678270d22f20-1760552569617.webp	800	799	webp	85	74278	cmgsbjm0o052lh9i6w7jskjzz
cmgsbjnji052vh9i60a5exs7e	/public/images/thumbnails/4f069248-30f7-4fe8-adf1-c09b0ed8b6d4-1760552571318.webp	150	150	webp	80	8012	cmgsbjnjb052sh9i6ag2epwql
cmgsbjos40533h9i6sxjslna2	/public/images/medium/ba11fd71-e4e8-405d-a2ae-609381b3f5e6-1760552573292.webp	800	799	webp	85	54630	cmgsbjorv052zh9i6s3m7iwbk
cmgsbjqgd053ch9i6ukolqjhn	/public/images/thumbnails/284c6d24-b1fb-44e9-bf1e-96f83ae33e7e-1760552574895.webp	150	150	webp	80	9432	cmgsbjqg00536h9i6t5o3zx04
cmgsbjsbo053ih9i6xqzaimuo	/public/images/thumbnails/b82b47cd-8d30-4c67-861b-a16e68fe1b3f-1760552577091.webp	150	150	webp	80	4928	cmgsbjsbe053dh9i6al88twgq
cmgsbmelg05dxh9i6dkdi6xwy	/public/images/thumbnails/b0af6a68-4713-427f-80f3-64fb4f99bf41-1760552700294.webp	150	150	webp	80	7480	cmgsbmele05dvh9i6m66tr5ch
cmgsbmgtf05e8h9i6i0d39bim	/public/images/full/f8b163b0-a369-4c7d-a15f-2478c04f0c38-1760552701658.webp	5169	3759	webp	90	2207026	cmgsbmgtc05e2h9i6jud89dhf
cmgsbmin805efh9i663v5im4r	/public/images/medium/8cd66730-c5b5-4763-ba27-ef4f1fbaafe4-1760552704536.webp	800	552	webp	85	75728	cmgsbmin605e9h9i6u5pm7ka6
cmgsbmkmu05ekh9i6tcddeuvz	/public/images/full/16e6a267-2770-478e-95c3-56e5a8686a7d-1760552706902.webp	5262	3821	webp	90	1280090	cmgsbmkmp05egh9i6a26tnltk
cmgsbmlps05esh9i68qk9ik30	/public/images/full/7000d8a3-ea04-4070-8c83-53c2c6c76263-1760552709499.webp	3623	2652	webp	90	669654	cmgsbmlpo05enh9i6knu1hly1
cmgsbmmv605f0h9i6chlyytug	/public/images/full/e4488623-d233-4daa-a25f-66ad3bd23b13-1760552710878.webp	2576	3275	webp	90	1058470	cmgsbmmv405euh9i6zfosbim2
cmgsbmnle05f7h9i6o73tm4zl	/public/images/full/1e1f50ab-81a5-4461-86eb-8bb14496d2ac-1760552712371.webp	2873	2027	webp	90	420102	cmgsbmnlb05f1h9i6d2p2e1zf
cmgsbmprl05feh9i6o325z49d	/public/images/full/b9917bba-2b33-4fbf-a940-6cf6ac6432ae-1760552713323.webp	3560	5195	webp	90	1732394	cmgsbmprj05f8h9i6trz6nwk3
cmgsbmqug05flh9i6qjqrdlht	/public/images/full/6a8f2e0d-beca-4255-ba93-0a9bdca17764-1760552716130.webp	3326	2698	webp	90	647134	cmgsbmqub05ffh9i6zpayz43z
cmgsbmsw605fsh9i6vdmx70ue	/public/images/full/7573b61f-4e6f-48ca-93c8-b336ac076291-1760552717529.webp	5137	3822	webp	90	1235704	cmgsbmsw405fmh9i6cst12azc
cmgsbmtzv05fyh9i6oftzlr0k	/public/images/full/89868dc2-9655-4c1b-b25d-9118343276b6-1760552720184.webp	3451	2776	webp	90	639890	cmgsbmtzr05fth9i62gpk6ocp
cmgsbmw5705g6h9i6y97l7q5p	/public/images/thumbnails/c0a8a368-b8bc-4a62-9779-281b770122d6-1760552721618.webp	150	150	webp	80	6648	cmgsbmw5305g0h9i6ub04phdb
cmgsbmwwn05g9h9i6v80unnmf	/public/images/thumbnails/b3abc26d-0f82-46d4-b8cd-854555069007-1760552724392.webp	150	150	webp	80	7692	cmgsbmwwl05g7h9i6bdbxeurn
cmgsbmy6o05gjh9i6gtu62owt	/public/images/medium/847f2db1-1658-4824-bcaa-dd161c878ed5-1760552725385.webp	800	1165	webp	85	86378	cmgsbmy6m05geh9i6jqi9odgb
cmgsbmy6o05gkh9i6rgvg3o0q	/public/images/full/847f2db1-1658-4824-bcaa-dd161c878ed5-1760552725385.webp	2764	4024	webp	90	646858	cmgsbmy6m05geh9i6jqi9odgb
cmgsbmysa05goh9i6d9m6xiq0	/public/images/medium/099cdc42-8035-441f-913d-044304d121bd-1760552727038.webp	800	952	webp	85	135574	cmgsbmys805glh9i6ryj1x1yd
cmgsbmysa05gqh9i6y4bhlb02	/public/images/thumbnails/099cdc42-8035-441f-913d-044304d121bd-1760552727038.webp	150	150	webp	80	6082	cmgsbmys805glh9i6ryj1x1yd
cmgsbn01805gwh9i6bn3bafwq	/public/images/thumbnails/19b059a6-b1bf-406b-a42b-68d9e5a5c815-1760552727819.webp	150	150	webp	80	7790	cmgsbn01605gsh9i6oxq73vrm
cmgsbn01805gyh9i6ox1b5dd0	/public/images/full/19b059a6-b1bf-406b-a42b-68d9e5a5c815-1760552727819.webp	3872	2667	webp	90	978314	cmgsbn01605gsh9i6oxq73vrm
cmgsbn12405h2h9i6buqmildz	/public/images/thumbnails/cb5accb8-a596-4148-9423-86121094e660-1760552729442.webp	150	150	webp	80	6742	cmgsbn12205gzh9i6o07wqbma
cmgsbn12405h5h9i6ihdrkh22	/public/images/full/cb5accb8-a596-4148-9423-86121094e660-1760552729442.webp	2311	3073	webp	90	1010102	cmgsbn12205gzh9i6o07wqbma
cmgsbn1zx05hah9i6143bc88z	/public/images/full/09a8ad25-939d-47d5-b570-ac3c10441ec7-1760552730765.webp	2280	3275	webp	90	424288	cmgsbn1zv05h6h9i6v67wuixn
cmgsbn1zx05hch9i6n6pkvtzy	/public/images/thumbnails/09a8ad25-939d-47d5-b570-ac3c10441ec7-1760552730765.webp	150	150	webp	80	5072	cmgsbn1zv05h6h9i6v67wuixn
cmgsbn2zt05hih9i6cv5ewdm4	/public/images/thumbnails/0284b504-1e0b-4612-beff-3f9cb254929b-1760552731983.webp	150	150	webp	80	2802	cmgsbn2zr05hdh9i672ph0f5n
cmgsbn2zt05hjh9i62xlchbak	/public/images/full/0284b504-1e0b-4612-beff-3f9cb254929b-1760552731983.webp	2529	3369	webp	90	459104	cmgsbn2zr05hdh9i672ph0f5n
cmgsbn40705hph9i6tt98kjuc	/public/images/medium/4da7618b-7819-448c-ba0b-a931b52c365a-1760552733273.webp	800	1145	webp	85	151630	cmgsbn40505hkh9i6krvswxmo
cmgsbn40705hoh9i6qkg8lowm	/public/images/thumbnails/4da7618b-7819-448c-ba0b-a931b52c365a-1760552733273.webp	150	150	webp	80	7164	cmgsbn40505hkh9i6krvswxmo
cmgsbn50i05hvh9i69b4mfc74	/public/images/thumbnails/d1979e9a-1577-469a-9f81-1e3e8ee8bff6-1760552734584.webp	150	150	webp	80	6092	cmgsbn50g05hrh9i6uz6qod3i
cmgsbn50i05hxh9i6h0g162bf	/public/images/full/d1979e9a-1577-469a-9f81-1e3e8ee8bff6-1760552734584.webp	2480	3341	webp	90	557886	cmgsbn50g05hrh9i6uz6qod3i
cmgsbn76205i4h9i6qjv67b8l	/public/images/full/fb5f1a0e-afa6-46e9-b67d-d6ffaf1cafa3-1760552735894.webp	5258	3686	webp	90	1857382	cmgsbn75z05hyh9i6t8p7lzi0
cmgsbn76205i2h9i6yfv4ref5	/public/images/medium/fb5f1a0e-afa6-46e9-b67d-d6ffaf1cafa3-1760552735894.webp	800	561	webp	85	65028	cmgsbn75z05hyh9i6t8p7lzi0
cmgsbn81505i8h9i6uin2pjxt	/public/images/thumbnails/1ee39c6b-e087-4439-9fef-d1a5de4893b5-1760552738684.webp	150	150	webp	80	6246	cmgsbn81305i5h9i6s3bv9vv4
cmgsbn81505ibh9i6lfkpfh6g	/public/images/full/1ee39c6b-e087-4439-9fef-d1a5de4893b5-1760552738684.webp	2248	3229	webp	90	358360	cmgsbn81305i5h9i6s3bv9vv4
cmgsbna0m05ifh9i64knn681y	/public/images/full/9b2e8fd2-25f5-4915-bb16-1f62185ee649-1760552739806.webp	4872	3198	webp	90	2486148	cmgsbna0k05ich9i6pxqdl4sd
cmgsbna0m05iih9i67iqsit38	/public/images/thumbnails/9b2e8fd2-25f5-4915-bb16-1f62185ee649-1760552739806.webp	150	150	webp	80	5234	cmgsbna0k05ich9i6pxqdl4sd
cmgsbnbd405ioh9i6iax25jzw	/public/images/thumbnails/beea9111-0edf-4061-b8d8-a331d7040b13-1760552742375.webp	150	150	webp	80	7120	cmgsbnbd205ijh9i61rbmvjk7
cmgsbnbd405iph9i696pxf3nl	/public/images/full/beea9111-0edf-4061-b8d8-a331d7040b13-1760552742375.webp	2833	4055	webp	90	954554	cmgsbnbd205ijh9i61rbmvjk7
cmgsbndde05iuh9i6lsljbwar	/public/images/full/f9745a6f-5264-4fd1-831a-497917e4a2c2-1760552744125.webp	4856	3338	webp	90	2049662	cmgsbnddc05iqh9i6kbrm103t
cmgsbjm0x052rh9i6mspyvg17	/public/images/full/af28c86f-b566-4c85-8f7c-678270d22f20-1760552569617.webp	2342	2339	webp	90	409712	cmgsbjm0o052lh9i6w7jskjzz
cmgsbjnji052wh9i6ybjd5s9b	/public/images/medium/4f069248-30f7-4fe8-adf1-c09b0ed8b6d4-1760552571318.webp	800	821	webp	85	100922	cmgsbjnjb052sh9i6ag2epwql
cmgsbjos30531h9i6ls3c2jhc	/public/images/thumbnails/ba11fd71-e4e8-405d-a2ae-609381b3f5e6-1760552573292.webp	150	150	webp	80	5030	cmgsbjorv052zh9i6s3m7iwbk
cmgsbjqgc053ah9i655ih8pk4	/public/images/full/284c6d24-b1fb-44e9-bf1e-96f83ae33e7e-1760552574895.webp	2092	2371	webp	90	505436	cmgsbjqg00536h9i6t5o3zx04
cmgsbjsbo053jh9i6reft1uji	/public/images/medium/b82b47cd-8d30-4c67-861b-a16e68fe1b3f-1760552577091.webp	800	1091	webp	85	99022	cmgsbjsbe053dh9i6al88twgq
cmgsbmelg05e0h9i6shbct9zm	/public/images/full/b0af6a68-4713-427f-80f3-64fb4f99bf41-1760552700294.webp	3341	2683	webp	90	657626	cmgsbmele05dvh9i6m66tr5ch
cmgsbmgtf05e5h9i6hkln4uv1	/public/images/thumbnails/f8b163b0-a369-4c7d-a15f-2478c04f0c38-1760552701658.webp	150	150	webp	80	8928	cmgsbmgtc05e2h9i6jud89dhf
cmgsbmin805eeh9i6ty5hr2qa	/public/images/thumbnails/8cd66730-c5b5-4763-ba27-ef4f1fbaafe4-1760552704536.webp	150	150	webp	80	7196	cmgsbmin605e9h9i6u5pm7ka6
cmgsbndde05iwh9i6d3yggn37	/public/images/thumbnails/f9745a6f-5264-4fd1-831a-497917e4a2c2-1760552744125.webp	150	150	webp	80	5104	cmgsbnddc05iqh9i6kbrm103t
cmgsbne1n05j1h9i6gr8sc9j1	/public/images/medium/5ec20c90-864c-4cf8-a79d-23f4ddb237e5-1760552746722.webp	800	568	webp	85	120360	cmgsbne1k05ixh9i6tmmnroha
cmgsbney605jah9i696aorxfz	/public/images/full/6748f532-622e-46d6-9fca-e17b332f3649-1760552747596.webp	3170	2339	webp	90	499932	cmgsbney305j4h9i65ekcjxao
cmgsbngbk05jeh9i6apy9t8j0	/public/images/medium/570ef93f-d6f3-4629-bc4c-208c0dbbfa7a-1760552748767.webp	800	1337	webp	85	190480	cmgsbngbg05jbh9i64un58w8x
cmgsbnhdz05jlh9i69ano8dt7	/public/images/medium/8b57726d-c8bc-403f-ad12-329a83b84952-1760552750544.webp	800	980	webp	85	153890	cmgsbnhdw05jih9i6upf90nmr
cmgsbnhe005joh9i67w2z3isd	/public/images/full/8b57726d-c8bc-403f-ad12-329a83b84952-1760552750544.webp	2554	3128	webp	90	918428	cmgsbnhdw05jih9i6upf90nmr
cmgsbniee05juh9i6todpn8hf	/public/images/thumbnails/1fa3aea1-6955-4aa4-ab51-7bd1cc7d6037-1760552751930.webp	150	150	webp	80	5660	cmgsbniec05jph9i6c1h7g6cf
cmgsbniee05jth9i6cp612pdn	/public/images/medium/1fa3aea1-6955-4aa4-ab51-7bd1cc7d6037-1760552751930.webp	800	1106	webp	85	117642	cmgsbniec05jph9i6c1h7g6cf
cmgsbnle705jzh9i6z6ii51yc	/public/images/medium/74fdbe42-e1f5-43f3-b130-b33e6fb79c84-1760552753242.webp	800	509	webp	85	33936	cmgsbnle505jwh9i6isnxeghf
cmgsbnle705k2h9i6kqiufl44	/public/images/full/74fdbe42-e1f5-43f3-b130-b33e6fb79c84-1760552753242.webp	7578	4819	webp	90	1006792	cmgsbnle505jwh9i6isnxeghf
cmgsbnmea05k6h9i6islkim4w	/public/images/thumbnails/fb4475a8-66c3-47c4-a9a8-161c6b084336-1760552757120.webp	150	150	webp	80	4722	cmgsbnme805k3h9i6bjsudyip
cmgsbnmea05k7h9i6enk74ma9	/public/images/medium/fb4475a8-66c3-47c4-a9a8-161c6b084336-1760552757120.webp	800	669	webp	85	58860	cmgsbnme805k3h9i6bjsudyip
cmgsbnn3f05kgh9i6kgdmb6j0	/public/images/full/a6be5d20-472c-490f-be58-3e9165f548db-1760552758418.webp	2072	2551	webp	90	301676	cmgsbnn3c05kah9i6e4u5o3cl
cmgsbnn3f05kfh9i6m81sit6y	/public/images/medium/a6be5d20-472c-490f-be58-3e9165f548db-1760552758418.webp	800	985	webp	85	77278	cmgsbnn3c05kah9i6e4u5o3cl
cmgsbnnts05klh9i6t466368q	/public/images/medium/4360d5be-a41d-43f3-a210-323deb07e382-1760552759322.webp	800	1210	webp	85	122514	cmgsbnntp05khh9i6zerms45a
cmgsbnnts05kmh9i6mjous620	/public/images/full/4360d5be-a41d-43f3-a210-323deb07e382-1760552759322.webp	1718	2599	webp	90	319036	cmgsbnntp05khh9i6zerms45a
cmgsbnome05kuh9i63f9synta	/public/images/full/d1d6b1e6-a6d5-4390-b0bf-45abd2e7f130-1760552760271.webp	2280	2535	webp	90	464054	cmgsbnomc05koh9i6tkzjcegd
cmgsbnome05ksh9i6qc8bbrrm	/public/images/thumbnails/d1d6b1e6-a6d5-4390-b0bf-45abd2e7f130-1760552760271.webp	150	150	webp	80	5654	cmgsbnomc05koh9i6tkzjcegd
cmgsbnq5205l1h9i6cc5slof2	/public/images/full/23bf721a-98e0-4a95-8b06-d4cb0dd5b7bb-1760552761305.webp	3120	4525	webp	90	845844	cmgsbnq5005kvh9i622yndl6w
cmgsbnq5205kzh9i6cfu2v3nz	/public/images/thumbnails/23bf721a-98e0-4a95-8b06-d4cb0dd5b7bb-1760552761305.webp	150	150	webp	80	6204	cmgsbnq5005kvh9i622yndl6w
cmgsbnrss05l7h9i6rpeyezhl	/public/images/medium/e3bc52f1-e67f-4001-b770-2609e1fb5349-1760552763273.webp	800	1100	webp	85	98134	cmgsbnrsq05l2h9i6m0qsdqb9
cmgsbnrss05l8h9i6ifb3k645	/public/images/full/e3bc52f1-e67f-4001-b770-2609e1fb5349-1760552763273.webp	3307	4544	webp	90	924588	cmgsbnrsq05l2h9i6m0qsdqb9
cmgsbntbc05lfh9i6suzwcrqk	/public/images/thumbnails/148addbe-befd-4410-b375-ab5d906a8d67-1760552765422.webp	150	150	webp	80	7834	cmgsbntba05l9h9i6htm1dy3r
cmgsbntbc05ldh9i6e4cr1hyo	/public/images/full/148addbe-befd-4410-b375-ab5d906a8d67-1760552765422.webp	3814	3677	webp	90	885740	cmgsbntba05l9h9i6htm1dy3r
cmgsbnuol05lmh9i6b36l3267	/public/images/medium/cc2c3064-9926-4fb1-82a4-209f8d5a505c-1760552767385.webp	800	990	webp	85	111288	cmgsbnuoi05lgh9i63p6hicbd
cmgsbnuol05llh9i6x6irvvnp	/public/images/thumbnails/cc2c3064-9926-4fb1-82a4-209f8d5a505c-1760552767385.webp	150	150	webp	80	4930	cmgsbnuoi05lgh9i63p6hicbd
cmgsbnvvz05lth9i6if7nu98q	/public/images/full/afd9ae10-a46a-4297-8088-f1915ebf2a8f-1760552769159.webp	3919	2542	webp	90	1024226	cmgsbnvvx05lnh9i63nnzvbto
cmgsbnvvz05lsh9i6a4awurnj	/public/images/medium/afd9ae10-a46a-4297-8088-f1915ebf2a8f-1760552769159.webp	800	519	webp	85	96680	cmgsbnvvx05lnh9i63nnzvbto
cmgsbnwlg05m0h9i6ybo20uav	/public/images/thumbnails/3f02feab-a287-4aa7-9ed2-a39add861392-1760552770718.webp	150	150	webp	80	4038	cmgsbnwlf05luh9i6q8eck0ui
cmgsbnwlg05lyh9i6mk8gck5j	/public/images/medium/3f02feab-a287-4aa7-9ed2-a39add861392-1760552770718.webp	800	984	webp	85	70230	cmgsbnwlf05luh9i6q8eck0ui
cmgscffxq05m7h9i6b5sn2hs5	/public/images/full/27bfba8c-d5e3-479f-9e7d-8881d5ed63fa-1760554055344.webp	257	196	webp	90	6946	cmgscffsq05m1h9i6xzezowaq
\.


--
-- TOC entry 3450 (class 0 OID 25052)
-- Dependencies: 219
-- Data for Name: images; Type: TABLE DATA; Schema: public; Owner: ccbl
--

COPY public.images (id, title, "altText", description, notes, people, year, decade, zone, previous_data, patrimonial_value, owner, cultural_fund, "createdAt", "updatedAt") FROM stdin;
cmgs9ge5p0000h9i635tq7c53	niño ciclista en cuasimodo	niño ciclista en cuasimodo	Niño ciclista en Cuasimodo	Premiaban la mejor decoración de biciletas.						4	Rocio Muñoz	Procultura	2025-10-15 17:24:21.805	2025-10-15 17:24:21.805
cmgs9gfh20007h9i6xs9c9mgw	Dos niños frente a casa de piedra	Dos niños frente a casa de piedra	Dos niños frente a casa de piedra en Farellones.		Luis Gallardo y Daniela Celis	hacia 1980	1980	Farellones	ML. Ca.1980. Farellones	4	Familia Gallardo	Procultura	2025-10-15 17:24:23.51	2025-10-15 17:24:23.51
cmgs9gh13000eh9i65dpfsuop	Gol en estadio	Gol en estadio	Gol en estadio en Cerro 18.				1980	Cerro 18	Cerro 18. Club Deportivo Barnechea	4	Rocio Muñoz	Procultura	2025-10-15 17:24:25.527	2025-10-15 17:24:25.527
cmgs9gjsf000lh9i644nbhhpe	Club de Pesca, Caza y Pesca Los Ribereños con su estandarte	Club de Pesca, Caza y Pesca Los Ribereños con su estandarte	Club de Pesca, Caza y Lanzamiento 'Los Rivereños' con su estandarte.			1980-1990	1980	Pueblo de Lo Barnechea		4	Rocio Muñoz	Procultura	2025-10-15 17:24:29.103	2025-10-15 17:24:29.103
cmgs9h4tb000sh9i6mqpcnp0c	Conjunto posando con trajes de La Tirana	Conjunto posando con trajes de La Tirana	Conjunto Folclórico 'Bajo las Alas del Cóndor' posando con trajes de La Tirana.			1980-1990	1980	Pueblo de Lo Barnechea		4	Rocio Muñoz	Procultura	2025-10-15 17:24:56.35	2025-10-15 17:24:56.35
cmgs9h7r7000zh9i64ym196gq	Rodeo en medialuna	Rodeo en medialuna	Rodeo en la medialuna del Cerro 18.			1980-1990	1980	Cerro 18	ML. . Cerro 18	4	Rocio Muñoz	Procultura	2025-10-15 17:25:00.163	2025-10-15 17:25:00.163
cmgs9h8ql0016h9i6kjybjss0	Cumpleaños en mantel de cuadros	Cumpleaños en mantel de cuadros	Celebrando un cumpleaños en El Arrayán.		Jorge Maureira, Enrique Rodríguez y Esteban Dávila	hacia 1979	1970	El Arrayán	Circa 1979. El Arrayán	4	Margarita Gana	Procultura	2025-10-15 17:25:01.438	2025-10-15 17:25:01.438
cmgs9havp001dh9i6ypxqo9jh	Niño escolar	Niño escolar	Un estudiante del Colegio Parroquial Santa Rosa.		Pedro "Robby" Araya Araya	1966	1960	Pueblo de Lo Barnechea	1966. Colegio Parroquial Santa Rosa	4	Ximena Riveros de Araya	Procultura	2025-10-15 17:25:04.214	2025-10-15 17:25:04.214
cmgs9hdr7001kh9i6ztwhykwu	Niño con bola de nieve	Niño con bola de nieve	Jugando con la nieve un día de invierno en la calle Lastra		Pedro "Robby" Araya Araya	1960	1960	Pueblo de Lo Barnechea	importante por linda. 1960. Casa en actual calle Lastra	4	Ximena Riveros de Araya	Procultura	2025-10-15 17:25:07.939	2025-10-15 17:25:07.939
cmgs9hfbp001rh9i6c349woud	Tranque	Tranque	El tranque del sector "La poza" en el Valle Escondido.			1981	1980	Valle Escondido	1981. Sector "La poza" en actual Valle Escondido	4	Ximena Riveros de Araya	Procultura	2025-10-15 17:25:09.973	2025-10-15 17:25:09.973
cmgs9hgw8001yh9i65d225co7	Antiguo establo	Antiguo establo	Antiguo establo del sector "La poza" en el Valle Escondido.			1981	1980	Valle Escondido	1981. Sector "La poza" en actual Valle Escondido	4	Ximena Riveros de Araya	Procultura	2025-10-15 17:25:12.008	2025-10-15 17:25:12.008
cmgs9hiji0025h9i6w26vl5c6	Domadura de caballo	Domadura de caballo	Domadura de caballo en una casa familiar, en la Av. Lo Barnechea.		Pedro Araya Rubio	hacia 1978	1970	Pueblo de Lo Barnechea	Circa 1978. Casa familiar en av. Barnechea	4	Ximena Riveros de Araya	Procultura	2025-10-15 17:25:14.142	2025-10-15 17:25:14.142
cmgs9hjjd002ch9i6eaunp29w	Niña en primera comunión y familia	Niña en primera comunión y familia	Primera Comunión en la Plaza Santa Rosa.		Esteban Riveros Gajardo, Carmen Olivo, Mercedes, Hugo Flores, Ximena Riveros, Luis Riveros, Marìa Inés Gajardo y Luis Flores.	1973	1970	Pueblo de Lo Barnechea	1973. Plaza Santa Rosa.  La niña de enfrente es Elisabeth Olivos	4	Ximena Riveros de Araya	Procultura	2025-10-15 17:25:15.433	2025-10-15 17:25:15.433
cmgs9hl0o002jh9i68p7b7mme	Dos mujeres en traje de baño rojo	Dos mujeres en traje de baño rojo	Dos mujeres en el río de El Arrayán un día de verano.		Ximena Riveros y Mónica Riveros	1980	1980	El Arrayán	buena foto y se ve el rio. El Arrayán	4	Ximena Riveros de Araya	Procultura	2025-10-15 17:25:17.353	2025-10-15 17:25:17.353
cmgs9hn1g002qh9i6e3u22wvz	Grupo comiendo humitas con guitarreo	Grupo comiendo humitas con guitarreo	Comiendo humitas con guitarreo en el sector "La poza" en el Valle Escondido.		Familias Torreblanca Roja y Araya Riveros	1996	1990	Pueblo de Lo Barnechea	1996. Sector la poza 	4	Ximena Riveros de Araya	Procultura	2025-10-15 17:25:19.972	2025-10-15 17:25:19.972
cmgs9hp0t002xh9i6wofv0jbz	Hombre a caballo	Hombre a caballo	Un hombre a caballo.		Pedro Araya Rubio	1986	1980	Pueblo de Lo Barnechea	1986. Pueblo de Lo Barnechea	4	Ximena Riveros de Araya	Procultura	2025-10-15 17:25:22.541	2025-10-15 17:25:22.541
cmgs9hrns0034h9i6apv8wjg6	Cantores con guitarra y arpa	Cantores con guitarra y arpa	Cantores con guitarra y arpa durante una celebración de Navidad 	También se hacían pesebres en vivo 	Jorge Guerra y Robin Araya	hacia 1998	1990	Pueblo de Lo Barnechea	Circa 1998. Canchas	4	Ximena Riveros de Araya	Procultura	2025-10-15 17:25:25.96	2025-10-15 17:25:25.96
cmgs9hshi003bh9i640c5a29s	Mujeres con moto	Mujeres con moto	Mujeres posando con una moto en la calle Lo Barnechea con Los Patos.		Valentina Rojas y Ana Matteo	hacia 1960	1960	Pueblo de Lo Barnechea	Circa 1960. Casa en barnechea con Los patos	4	Ana Matteo Rojas	Procultura	2025-10-15 17:25:27.03	2025-10-15 17:25:27.03
cmgs9htuk003ih9i6nf5rdfc6	Hombres trabajando con andarivel	Hombres trabajando con andarivel	Hombres trabajando en un andarivel en La Disputada	Al parecer el andarivel se utilizaba para trasladar sacos cargados con material hasta Las Condes		1953	1950	Farellones	importante pq aparece La disputada. 1953. cordón del Quempo, cordillera de Lo Barnechea cerca del río Colorado.  La Disputada, se descargaban los sacos en las puertas de Las Condes y se devolvía cargado con sacos vacios y subia gente en los mismos carros	4	Ana Matteo Rojas	Procultura	2025-10-15 17:25:28.797	2025-10-15 17:25:28.797
cmgs9hwcq003ph9i6iwfaukav	Tres amigas con guitarra	Tres amigas con guitarra	Tres amigas con guitarra.		Rosi Caro, Verónica Caro y Gloria Maira	hacia 1970	1970	Pueblo de Lo Barnechea	Circa 1970. Pueblo de Lo Barnechea	4	Ana Matteo Rojas	Procultura	2025-10-15 17:25:32.042	2025-10-15 17:25:32.042
cmgs9hxmr003wh9i6k3r15d3y	Padre e hija frente a pergola	Padre e hija frente a pergola	Padre y su hija frente a una pérgola.		Ernesto Maira y Andrea Maira	hacia 1968	1960	Pueblo de Lo Barnechea	Circa 1968. Casa	4	Ana Matteo Rojas	Procultura	2025-10-15 17:25:33.7	2025-10-15 17:25:33.7
cmgs9i02n0043h9i62tpp5rfo	Desfile de Bomberos	Desfile de Bomberos	Bomberos desfilando por la Av. Lo Barnechea.		Brigada Número 4 Bomberos de Lo Barnechea	1970-1980	1970	Pueblo de Lo Barnechea	Década 1970. Avenida Lo Barnechea	4	Familia Meza Cortés	Procultura	2025-10-15 17:25:36.864	2025-10-15 17:25:36.864
cmgs9i1ox004ah9i6825vym2z	Conjunto musical	Conjunto musical	Conjunto musical en el Teatro Parroquial.		Gustavo Gonzalez en el saxofón, Ramon Meza Pinto en la guitarra, Tuco Amengual en el saxofón, Jorge Labbe en la guitarra y Jorge Valenzuela en la batería.	1957	1950	Población Nebraska	Teatro Parroquial. "Primeros pasos de la Orquesta Mimica de Bill Haley y sus cometas."	4	Familia Meza Cortés	Procultura	2025-10-15 17:25:38.962	2025-10-15 17:25:38.962
cmgs9i37j004hh9i6zehgrdqk	Equipo femenino	Equipo femenino	Equipo femenino de fútbol.			1950-1960	1950	Pueblo de Lo Barnechea	Aparecen arriba, Maria Martinez (2da) y Sofia Silva (6ta). Abajo, Petronila Araya (1ra), Rosa Ester Cortes (3ra), María Araya (5ta) y Paula Astaburuaga (7ma)	4	Familia Meza Cortés	Procultura	2025-10-15 17:25:40.928	2025-10-15 17:25:40.928
cmgsa0rch0167h9i6gkuq1633	Pareja de huasos en la calle	Pareja de huasos en la calle	Pareja de huasos en la calle	Padre e Hijo, Cerro 18				Cerro 18		3	Rocío Muñoz	Procultura	2025-10-15 17:40:12.017	2025-10-15 17:40:12.017
cmgs9i4p6004oh9i6oj7hzxca	Cinco jugadores con pelota	Cinco jugadores con pelota	Cinco jugadores del club en la cancha de Barnechea.		Alberto Labbé, Ramón Meza, Tristán Solis, Rafael Herrera y Fernando Herrera	1959	1950	Pueblo de Lo Barnechea	17/11/1959.. Cancha de Barnechea	4	Familia Meza Cortés	Procultura	2025-10-15 17:25:42.858	2025-10-15 17:25:42.858
cmgs9ia9i0059h9i6yw5sy4nh	Familia frente a su casa	Familia frente a su casa	Familia frente a su casa en la Población Nebraska.		Daniel Quiroz Mendoza, Luz Angelica Quiroz Mendoza, Maria Ester Quiroz Mendoza, al frente Edith Quiroz Mendoza, y mirando el suelo Cecilia Quiroz Mendoza. 	hacia 1963	1960	Población Nebraska	Circa 1963. Población Nebraska	4	Familia Quiroz Mendoza	Procultura	2025-10-15 17:25:50.071	2025-10-15 17:25:50.071
cmgs9ibju005gh9i6kmdt7q7u	Mujer con niño colgando	Mujer con niño colgando	Mujer y niño jugando en la Av. Las Condes.		Cecilia Quiroz y su sobrino Daniel Quiroz	hacia 1982	1980	San Enrique/La Ermita/Las Condes	Circa 1982. Avenida Las Condes	4	Familia Quiroz Mendoza	Procultura	2025-10-15 17:25:51.738	2025-10-15 17:25:51.738
cmgs9ix0q005uh9i6zhofbuma	Conteo de ovejas	Conteo de ovejas	Conteo de ovejas en Fundo Potrero Grande.		Tomás Campos y, atrás, Juan Mandujano.	1960-1970	1960	Farellones	Década de 1960. Fundo Potrero Grande	4	Alfonso Campos	Procultura	2025-10-15 17:26:19.563	2025-10-15 17:26:19.563
cmgs9izsn0061h9i6jdqawzyn	Grupo en celebración	Grupo en celebración	Celebración de la primera piedra de la medialuna de Lo Barnechea. 	Esa medialuna estaba junto al río donde actualmente está el puente de Av. La Dehesa. Más tarde, se trasladó al Cerro 18 Norte.	Al centro, el sacerdote William Reddinton. A su derecha, de poncho, Jorge Guerra. Tambien aparecen varios hermanos del conjunto Los Chicanos.	1960-1961	1960	La Dehesa	ML. 1960 o 1961. Primera piedra de la medialuna, junto al río donde ahora está el puente de Avenida La Dehesa. Después la trasladaron al cerro 18 Norte, porque hicieron un basural en ese lugar. Mujer huasa de la izquierda y del centro son hermanas; el hombre del extremo derecho también. 	4	Jorge Guerra	Procultura	2025-10-15 17:26:23.159	2025-10-15 17:26:23.159
cmgs9j6pt006th9i68mzdhkgq	Procesión de Cuasimodo por Av. Las Condes.	Procesión de Cuasimodo por Av. Las Condes.	Procesión de Cuasimodo por Av. Las Condes.			2000-2010	2000	San Enrique/La Ermita/Las Condes		4		Procultura	2025-10-15 17:26:32.129	2025-10-15 17:26:32.129
cmgs9k1s60077h9i6x29jv17v	Sujetando un toro	Sujetando un toro	Sujetando un toro en el Fundo Potrero Grande.			1985	1980	Farellones	Fundo Potrero Grande. Cuando se metían toros de origen desconocido, como no hay cercos, no se sabe de quién es y es imposible echarlo, se castraba para que no "echara a perder" la genética.	4	Alfonso Campos	Procultura	2025-10-15 17:27:12.39	2025-10-15 17:27:12.39
cmgs9lcim0086h9i6qpqoy6jl	Jinete en Cuasimodo	Jinete en Cuasimodo	Jinete en Cuasimodo.					Pueblo de Lo Barnechea		4	Rocío Muñoz	Procultura	2025-10-15 17:28:12.958	2025-10-15 17:28:12.958
cmgs9lfd5008dh9i6n1gokvbb	Cuasimodistas vestidos con colores	Cuasimodistas vestidos con colores	Grupo con niños en Cuasimodo.			2000-2010	2000	Pueblo de Lo Barnechea		4	Rocío Muñoz	Procultura	2025-10-15 17:28:16.649	2025-10-15 17:28:16.649
cmgs9li0e008kh9i67vsfkqzh	Cuasimodo por la calle	Cuasimodo por la calle	Jinetes en Cuasimodo.			2000-2010	2000	Pueblo de Lo Barnechea		4	Rocío Muñoz	Procultura	2025-10-15 17:28:20.078	2025-10-15 17:28:20.078
cmgs9lndd008yh9i6w5sjl48w	Dos cocineros	Dos cocineros	Dos cocineros en Doña Tina.					El Arrayán	ML. . Doña Tina	4	Rocío Muñoz	Procultura	2025-10-15 17:28:27.025	2025-10-15 17:28:27.025
cmgs9lt3s009ch9i6mqzjkhyt	Auto decorado con estandartes	Auto decorado con estandartes	Auto decorado con estandartes de los clubes de Rodeo y Huasos en El Arrayán.	Desfile para fiestas patrias				El Arrayán	El Arrayan. Estandarte del Club de Huasos de Lo Barnechea y el club de Rodeo Chileno de Lo Barnechea	4	Rocío Muñoz	Procultura	2025-10-15 17:28:34.456	2025-10-15 17:28:34.456
cmgs9i68e004vh9i6wt4gh0zi	Niño en caballo	Niño en caballo	Un niño a caballo arando la tierra.		Manuel Herrera Muñoz 	hacia 1995	1990	Pueblo de Lo Barnechea	Circa 1995. Colegio San Rafael. Estaba arando la tierra con su papá, Manuel Herrera, que cuidaba el colegio y cultivaba en ese lugar. 	4	Familia Muñoz Dotte	Procultura	2025-10-15 17:25:44.846	2025-10-15 17:25:44.846
cmgs9j0xz0068h9i6dalfhvoq	Mujer y niño en casona	Mujer y niño en casona	Mujer y niño en la Casona San Enrique.		Pedro Juan Garrido Medina	1959	1950	San Enrique/La Ermita/Las Condes	album. 1959. Casona ex Municipalidad en San Enrique	4	Cristian Garrido	Procultura	2025-10-15 17:26:24.647	2025-10-15 17:26:24.647
cmgs9j2id006fh9i6iuxbdr58	Niño en triciclo	Niño en triciclo	Niño en triciclo en la calle.		Pedro Juan Garrido Medina	1963	1960	Pueblo de Lo Barnechea	ML. 1963. Calle en Barnechea	4	Cristian Garrido	Procultura	2025-10-15 17:26:26.677	2025-10-15 17:26:26.677
cmgs9klfr007eh9i6lzk2vxua	Representación navideña	Representación navideña	Representación navideña		Conjunto Bajo las Alas del Condor	1980-1990	1980	Pueblo de Lo Barnechea		4	Rocío Muñoz	Procultura	2025-10-15 17:27:37.863	2025-10-15 17:27:37.863
cmgs9l6y6007sh9i6je61g624	Huasos con banderas azules	Huasos con banderas azules	Huasos con banderas del Club de Huasos.	Banderas del club de Huasos						4	Rocío Muñoz	Procultura	2025-10-15 17:28:05.743	2025-10-15 17:28:05.743
cmgs9lz0d009qh9i6jolx0f5r	Partido de futbol con cerro detrás 2	Partido de futbol con cerro detrás 2	Partido de fútbol con vista al cerro.	Había dos equipos, Barnechea y Juventud Catolica, que lo hizo el cura en el año 30 más o menos. Ambos equipos jugaban en la liga Mapocho Las Condes. En la cancha eran bien enemigos, pero después eran todos bien compadres. Jugaban dos veces en el año no más, y se sabía toda la vida de los jugadores asi que les gritaban de todo. Se compartía la única cancha que había.  . . Cerro 18				Pueblo de Lo Barnechea		4	Rocío Muñoz	Procultura	2025-10-15 17:28:42.109	2025-10-15 17:28:42.109
cmgs9m8x500aph9i6onu38nxf	Grupo familiar	Grupo familiar	Grupo familiar.	Casa de Olga Puente, calle Alvarez. Eran vecinos de los Muñoz.	Olga Puente, NN, al extremo derecho Zenón Muñoz. Los niños son de apellido Castillo.	hacia 1965	1960	Pueblo de Lo Barnechea	Copia de foto digitalizada	4	Familia Muñoz Dotte	Procultura	2025-10-15 17:28:54.953	2025-10-15 17:28:54.953
cmgs9i8y10052h9i61ql0uah7	Grupo bailando cueca en la calle	Grupo bailando cueca en la calle	Bailando cueca en la Calle Álvarez.	Se cerraba la calle en Fiestas Patrias y se hacían juegos típicos y bailes. 		1990-2000		Pueblo de Lo Barnechea	Calle Alvarez. Manuel Herrera y Elisa Uribe. A la derecha Elcira Blanco	4	Familia Muñoz Dotte	Procultura	2025-10-15 17:25:48.361	2025-10-15 17:25:48.361
cmgs9isia005nh9i6ic7x38ns	Conjunto musical	Conjunto musical	Conjunto musical Los Rivereños.	Tocaban música chilena de la zona central. Solían tocar en la radio o en festivales de las plazas.	 Alma Rosa, Lorenzo Belmar, Jorge Guerra y Cupertino Durán	hacia 1966	1960	Pueblo de Lo Barnechea	ML. Circa 1966. Estudio de fotográfico "Sandra"	4	Jorge Guerra	Procultura	2025-10-15 17:26:13.714	2025-10-15 17:26:13.714
cmgs9j3yj006mh9i615ovqet2	Serie hombre a caballo 1	Serie hombre a caballo 1	Hombre a caballo en Quempo, cerca del río Colorado, en la cordillera.		Juan "Pelé" Araya	1975	1970	Farellones		4	Familia Araya Meneses	Procultura	2025-10-15 17:26:28.556	2025-10-15 17:26:28.556
cmgs9jmmo0070h9i68wcf3561	Bajando del cerro	Bajando del cerro	Bajando del cerro en la Vega del Morro Redondo, Fundo Potrero Grande.		De celeste al medio, Alfonso Campos; arriba de celeste, Froilán Mandujano.	1985	1980	Farellones	Vega del morro redondo, fundo Potrero Grande	4	Alfonso Campos	Procultura	2025-10-15 17:26:52.752	2025-10-15 17:26:52.752
cmgs9l4cq007lh9i6ec1a72wv	Caballos en medialuna	Caballos en medialuna	Caballos en la medialuna del Cerro 18.	Medialuna Cerro 18		1986-1990	1980	Cerro 18	Fines decada 1980. Cerro 18	4	Rocío Muñoz	Procultura	2025-10-15 17:28:02.378	2025-10-15 17:28:02.378
cmgs9l9r0007zh9i6qfz8z7r2	Niño junto a cuasimodista en bicicleta	Niño junto a cuasimodista en bicicleta	Niño junto a cuasimodista en bicicleta.							4	Rocío Muñoz	Procultura	2025-10-15 17:28:09.372	2025-10-15 17:28:09.372
cmgs9lktz008rh9i6zdyba80v	Bicicletas en Cuasimodo	Bicicletas en Cuasimodo	Bicicletas en Cuasimodo frente a la parroquia Santa Rosa.			2000-2010	2000	Pueblo de Lo Barnechea		4	Rocío Muñoz	Procultura	2025-10-15 17:28:23.735	2025-10-15 17:28:23.735
cmgs9lq750095h9i6scqd7t0a	Desfile de Cuasimodo	Desfile de Cuasimodo	Piscina municipal de "El Arrayán".					El Arrayán		4	Rocío Muñoz	Procultura	2025-10-15 17:28:30.689	2025-10-15 17:28:30.689
cmgs9lw0g009jh9i6t8046ob2	Huaso en prueba ecuestre	Huaso en prueba ecuestre	Huaso en prueba ecuestre en Cancha de Lo Barnechea.	Juegos ecuestres después del Cuasimodo o del 18		1980-1990	1980	Pueblo de Lo Barnechea	ML. Década de 1980. Cancha de Lo Barnechea	4	Rocío Muñoz	Procultura	2025-10-15 17:28:38.224	2025-10-15 17:28:38.224
cmgs9m12u009xh9i6pi3bxv00	Equipo con bandera 2	Equipo con bandera 2	Equipo del CD Lo Barnechea con su bandera	Tercera división	Sergio Madrid, Juan Acuña, nn, Aracena, Yayo Contreras,nn, Galvez, Robi, Chico Reyes, Manguera, Juan Salazar, Chico meneses, Juan Sanhueza. Abajo Molina, nn, Moroco, Manuel Araya, Faundez, Rana, Galvez. 	hacia 1980	1980	Pueblo de Lo Barnechea	Circa 1980. Pueblo de Lo Barnechea	4	Eliseo Villarroel	Procultura	2025-10-15 17:28:44.79	2025-10-15 17:28:44.79
cmgs9m2h100a4h9i6vdw4ptra	Formación de equipo infantil	Formación de equipo infantil	Equipo infantil del CD Lo Barnechea		Infantil de Barnechea	hacia 1980	1980	Pueblo de Lo Barnechea	Circa 1980. Pueblo de Lo Barnechea	4	Eliseo Villarroel	Procultura	2025-10-15 17:28:46.597	2025-10-15 17:28:46.597
cmgs9m4h300abh9i6u04otk50	Equipo femenino con globos	Equipo femenino con globos	Equipo femenino con globos.	Cancha de Barnechea. Presentación anual de la Asociación Las Condes. Calcetineras del Club Barnechea	Calcetineras del Club Barnechea	hacia 1975	1970	Pueblo de Lo Barnechea	Circa 1975. Pueblo de Lo Barnechea	4	Eliseo Villarroel	Procultura	2025-10-15 17:28:49.191	2025-10-15 17:28:49.191
cmgs9m71q00aih9i6lge5ctr0	Micro de los jugadores	Micro de los jugadores	Micro de la delegación del CD Lo Barnechea	Se usó alrededor de 1973	Micro Mapocho Las Condes Pudahuel	1990-2000	1990	Pueblo de Lo Barnechea	Década 1990. Pueblo de Lo Barnechea	4	Eliseo Villarroel	Procultura	2025-10-15 17:28:52.526	2025-10-15 17:28:52.526
cmgs9maav00awh9i63qrvkcgw	Fila de caballos subiendo el cerro	Fila de caballos subiendo el cerro	Fila de caballos subiendo al Arrayán.	Llevando los animales de la familia al Arrayán. Los tenían por el sector cerca de la medialuna, donde vivían. Sectores los campamentos, los arenales. Crecía más el pasto. Subían el papá, hermano, tíos y amigos. 		hacia 1992	1990	El Arrayán	Noviembre 1992 circa. Subían papá, hermano, tíos, amigos.	4	Carlos Araya	Procultura	2025-10-15 17:28:56.743	2025-10-15 17:28:56.743
cmgs9mblv00b3h9i6gnb7oakt	Jinetes y un potrillo en una laguna	Jinetes y un potrillo en una laguna	Jinetes y un potrillo en la laguna Acollarada.	Iban por una semana a acampar, en vacaciones. La mulita de la derecha era hija de la yegua, por eso subía con ellos. Se llega por un sendero que parte en el Santuario de la Naturaleza.	Alejandro Araya, Victor Araya, Cristina Araya, Carlos Araya, Berta Polanco	1985	1980	El Arrayán	1985. Lagunas Acollaradas, se llega por un sendero que parte en el Santuario de la Naturaleza.. Paseo al cerro	4	Carlos Araya	Procultura	2025-10-15 17:28:58.435	2025-10-15 17:28:58.435
cmgs9mdst00bah9i6bczbsf3s	Grupo familiar con su oveja	Grupo familiar con su oveja	Grupo familiar con su oveja cerca de la calle Raúl Labbé.	Oveja era su mascota, muy regalona.	Patricio Bustamante de chaqueta oscura, junto a su esposa e hijos.	1926	1920	Pueblo de Lo Barnechea	1926. Fotos aportadas por Brígida Vera. ML. Cerca de calle Raúl Labbé. Fotografía antigua digitalizada	4	UNCAF	Procultura	2025-10-15 17:29:01.278	2025-10-15 17:29:01.278
cmgs9mfx900bhh9i6g15uh38l	Jinetes. Una de las imágenes más antiguas de la Fiesta de Cuasimodo	Jinetes. Una de las imágenes más antiguas de la Fiesta de Cuasimodo	Jinetes. Una de las imágenes más antiguas de la Fiesta de Cuasimodo	Es una de las imágenes más antiguas de la Fiesta de Cuasimodo. Los jinetes están abajo de la actual Iglesia Santa Rosa, donde estaban las Canchas de Lo Barnechea. Estos podrían ser de los primeros cuasimodistas de la comuna.		hacia 1930	1930	Pueblo de Lo Barnechea	Grupo de jinetes, año 1930. Lugar "abajo, en canchas de Barnechea". Primeros cuasimodos de la comuna. Fotografía antigua digitalizada. UNCAF. Esta misma información está en la planilla original del archivo de procultura: https://docs.google.com/spreadsheets/d/1M3acS8g70f4Iom21bN2tnrVgbe5u38u2/edit?gid=1247537897#gid=1247537897	4	Familia Bustamante	Procultura	2025-10-15 17:29:04.029	2025-10-15 17:29:04.029
cmgs9mhzr00boh9i60mgah0f4	Familia con guitarra	Familia con guitarra	Familia con guitarra.		Familia  Bustamante Celis	1926	1920		Cerca de actual iglesia. Fotografía antigua digitalizada	4	UNCAF	Procultura	2025-10-15 17:29:06.712	2025-10-15 17:29:06.712
cmgs9mjsf00bvh9i6115ymr6y	Puente de Cimbre	Puente de Cimbre	Puente de madera que unía Barnechea con San Enrique y Quinchamalí	La otra forma de cruzar era El Arrayán.		1950-1960	1950	San Enrique/La Ermita/Las Condes	ML. Década de 1950. Ese año fue una pequeña sequía porque normalmente había más agua.. Fotografía antigua digitalizada	4	UNCAF	Procultura	2025-10-15 17:29:09.039	2025-10-15 17:29:09.039
cmgs9mnpv00c2h9i63hskq66c	Hombres con conejos cazados	Hombres con conejos cazados	Hombres con conejos cazados	Cazaban conejos y luego se los repartían entre todos. Se iban para el 18 de septiembre y volvían pasado el 20, 22.	Apoyado en el camión, Gildo Pavez. Sentado a su izquieda, Madrid; a su izquierda Carlos Moya. Echado con un perro, Joaquín Moya. Sosteniendo su cabeza, Jerez. De camisa a cuadros, Luis Robles. A su derecha atrás, Pirula.  			Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	4	Yoconda Moya	Procultura	2025-10-15 17:29:14.131	2025-10-15 17:29:14.131
cmgs9mpif00c9h9i6pry3p0en	Hombres con  mulas cargados	Hombres con  mulas cargados	Hombres con mulas cargadas	Revisar lugar, en planilla original no parece el pueblo	Joaquin Moya, Chino Vera, Carlos Moya	1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	4	Yoconda Moya	Procultura	2025-10-15 17:29:16.456	2025-10-15 17:29:16.456
cmgs9n1ln00dfh9i6jphtp5ll	Dos jóvenes junto a un río	Dos jóvenes junto a un río	Dos jóvenes junto al Río Mapocho, cerca del sector Pastor Fernández.		Tinita x, Virginio Dotte (esposos)	1970-1980	1970	El Arrayán	Década 1970. Río Mapocho, cerca del sector Pastor Fernandez	4	Patricia Dotte	Procultura	2025-10-15 17:29:32.123	2025-10-15 17:29:32.123
cmgs9n9f800eeh9i6wop308js	Club Deportivo Juventud Católica	Club Deportivo Juventud Católica	Club Deportivo Juventud Católica en Canchas, en el actual sector Las Lomas.	Equipo de Barnechea, jugaban contra el Vitacura, el Las Condes, el Tropezón	De pie, Cachuzo. De izq a derecha Domingo Araya, Eduardo Araya, Vicencio, nn, Ulloa. Abajo, el segundo, Rafael Herrera, Juan Gomez, Juan Araya, Juan	hacia 1959	1950	Pueblo de Lo Barnechea	Circa 1959. Canchas, actual Las Lomas	4	María Araya	Procultura	2025-10-15 17:29:42.261	2025-10-15 17:29:42.261
cmgs9ncar00esh9i62jra23iy	Niños bañándose en el río	Niños bañándose en el río	Niños bañándose en el estero del Arrayán.		Hermanos Gutierrez Pereira y amigos	1975	1970	El Arrayán	1975. Estero del Arrayan	4	Rodolfo Gutierrez	Procultura	2025-10-15 17:29:45.986	2025-10-15 17:29:45.986
cmgs9o2h800fdh9i6kjt674wk	Ejercicio de bomberos	Ejercicio de bomberos	Ejercicio de bomberos en cancha de la Católica, en la falda del Cerro 18.	Inaugurando los bomberos de Barnechea	Patricio Villarroel en bautizo de bomberos, brigada B4	1966	1960	Pueblo de Lo Barnechea	1966. Cancha de la católica, falda del cerro 18	4	Patricio Villarroel	Procultura	2025-10-15 17:30:19.916	2025-10-15 17:30:19.916
cmgs9p32z00h4h9i62gb2j26u	Desfile Escuela Básica D 238	Desfile Escuela Básica D 238	Estudiantes de la Escuela Básica D-238 desfilando en Lo Barnechea.	Esta escuela básica se fundó en 1900 como "Escuela 177", pasando a llamarse "D-238 Estados Americanos" en la década de 1960 cuando se construyó el nuevo colegio ubicado en Los Patos con Lo Barnechea.		hacia 1980	1980	Pueblo de Lo Barnechea	Circa 1980. Calle Barnechea	4	Juan Carlos Salas	Procultura	2025-10-15 17:31:07.355	2025-10-15 17:31:07.355
cmgs9pgra00iah9i6v01c3byc	Montaña con nieve	Montaña con nieve	Montañas nevadas en Los Bronces, en la cordillera	Hielos Eternos. Foto tomada por Hernán Jofré, trabajaba en el observatorio de la U. de Chile. Había un observatorio arriba en los Bronces. Su padre Custodio Gana subía los materiales. 		hacia 1959	1950	Farellones	Circa 1959. Los Bronces	4	Margarita Gana	Procultura	2025-10-15 17:31:25.078	2025-10-15 17:31:25.078
cmgs9pj9h00ihh9i6f9w1a68s	Hombres subiendo materiales al observatorio	Hombres subiendo materiales al observatorio	Subiendo materiales al Observatorio Los Bronces de la Universidad de Chile. Cuando la nieve era profunda y las mulas no podían subir amarraban los materiales y los subían con cuerdas.	en la montaña, cuando la nieve era profunda y las mulas no podían subir amarraban los materiales y los subían con cuerdas. Terremoto muy grande en los 60, hubo rodados, su papá estuvo desaparecido con más gente por 15 días , estaban bien, en el campamento /observatorio. Su abuelo tb trabajaba allà y tuvo accidente con el tractor que trabajaba. El campamento estaba tapado con nieve. Gente de la U de chile pagó y subieron en avioneta a buscarlos. Los bajaron en helicóptero y avioneta. Año 62 aprox.. Década de 1960. Observatorio Los Bronces Universidad de Chile	Custodio Gana Hernández, dos personas de la U. de Chile	1960-1970	1960	Farellones	Terremoto muy grande en los 60, hubo rodados, su papá estuvo desaparecido con más gente por 15 días , estaban bien, en el campamento /observatorio. Su abuelo tb trabajaba allà y tuvo accidente con el tractor que trabajaba. El campamento estaba tapado con nieve. Gente de la U de chile pagó y subieron en avioneta a buscarlos. Los bajaron en helicóptero y avioneta. Año 62 aprox.. Década de 1960. Observatorio Los Bronces Universidad de Chile	4	Margarita Gana	Procultura	2025-10-15 17:31:28.325	2025-10-15 17:31:28.325
cmgs9qexy00j2h9i6dnykprxz	Grupo de hombres subiendo en fila por la nieve	Grupo de hombres subiendo en fila por la nieve	Arrieros guiando un grupo de investigadores de la Universidad de Chile que subían a hacer estudios a la montaña.	Guiando gente de la U de Chile que subía a hacer estudios a la montaña. Observarotio Los Bronces	Hernán Jofré, Custodio Gana	hacia 1960	1960	Farellones	Circa 1960. El Arrayán	4	Margarita Gana	Procultura	2025-10-15 17:32:09.382	2025-10-15 17:32:09.382
cmgs9qgfh00j9h9i61j6jboey	Cuatro mineros sentados	Cuatro mineros sentados	Mineros sentados en la Mina San Rafael.	en la montaña	Extremo derecho, Olegario Gana	1960-1970	1960	Farellones	Década de 1960. Mina San Rafael	4	Margarita Gana	Procultura	2025-10-15 17:32:11.309	2025-10-15 17:32:11.309
cmgs9qm8600juh9i6mhss83si	Equipo de fútbol	Equipo de fútbol	Equipo de fútbol	“Selección A de la Asociación Las Condes, segundo puesto”	Eugenio Fuentes, NN, Pan Amasao, Floro Valencia, Benjamin Valencia, Loreto, Guayaca. Abajo: Humberto Dotte, Reyes, Jaime Alvarez, Enrique Besares, NN. 	1945	1940	Pueblo de Lo Barnechea	Chico Meneses o Chico coton pueden sabe. . Pueblo de Lo Barnechea	4	Eliseo Villarroel	Procultura	2025-10-15 17:32:18.822	2025-10-15 17:32:18.822
cmgs9r81w00kfh9i6si5d80wh	Equipo de fútbol	Equipo de fútbol	Equipo de fútbol del CD Lo Barnechea		"El peligroso", 4to es Rogui, Celso, arquero, Chambeco (entrenador). Abajo, Pilo, Mendoza, nn, Moroco, nn.	hacia 1980	1980	Pueblo de Lo Barnechea	Circa 1980. Pueblo de Lo Barnechea	4	Eliseo Villarroel	Procultura	2025-10-15 17:32:47.108	2025-10-15 17:32:47.108
cmgs9riuh00leh9i6nyfpzrqr	Familia ordeñando vaca	Familia ordeñando vaca	Familia ordeñando una vaca en Farellones		Rafael Gallardo Ramos, Luis Alberto Gallardo, María Álvarez Pichilef	hacia 1980	1980	Farellones	ca.1980. Casa en pueblo de Farellones	3	Familia Gallardo	Procultura	2025-10-15 17:33:01.097	2025-10-15 17:33:01.097
cmgs9rl6200lsh9i6m79cd6g6	Grupo	Grupo	Grupo en Camino la Capilla, Farellones	Cámara Polaroid era de Guillermo Gallardo. Omar era contratista de construcción, muy querido en el pueblo. Hoy vive en hogar de ancianos en LB. ca. 1980. Camino la Capilla, Farellones	Omar Flores, Verónica o Nana Martínez, Susana Polanco, Verónica o Nana Martínez, Eugenio Fernández.	hacia 1980	1980	Farellones		3	Familia Gallardo	Procultura	2025-10-15 17:33:04.107	2025-10-15 17:33:04.107
cmgs9roqd00m6h9i62q1ub2i2	Niños de la capilla de Farellones	Niños de la capilla de Farellones	Grupo con niños en la capilla de Farellones		Padre Carlos, niños de La Parva, Colorado y Farellones	hacia 1993	1990	Farellones	ca. 1993. Capilla de Farellones	3	Familia Gallardo	Procultura	2025-10-15 17:33:08.725	2025-10-15 17:33:08.725
cmgs9ms6e00cgh9i6dejgm64n	Desfile de jugadores de fútbol	Desfile de jugadores de fútbol	Desfile de jugadores de fútbol en las canchas abajo de la iglesia.	Fotografía Moneda 716		1945	1940	Pueblo de Lo Barnechea	“Año 45”. Canchas abajo de la iglesia	4	Yoconda Moya	Procultura	2025-10-15 17:29:19.911	2025-10-15 17:29:19.911
cmgs9mvaq00cnh9i61nbsmd43	Equipo de fútbol	Equipo de fútbol	Equipo de fútbol CD Lo Barnechea.		"Los Viejos Crack" : NN, NN, Salcedo, Guaton Cortez, Aracena, Manuel Jorquera, Ramon Orellana y Che Bravo. Abajo: Vargas, Barrera, Pino, Perez, Meneses. 	hacia 1970	1970	Pueblo de Lo Barnechea	Circa 1970. Pueblo de Lo Barnechea	4	Yoconda Moya	Procultura	2025-10-15 17:29:23.929	2025-10-15 17:29:23.929
cmgs9mxa500cuh9i6cmskig4r	Mujer frente a laguna	Mujer frente a laguna	Mujer frente a laguna.	“Recuerdo Paseo a La Dehesa”		1982	1980	La Dehesa		4	Yoconda Moya	Procultura	2025-10-15 17:29:26.525	2025-10-15 17:29:26.525
cmgs9myuz00d1h9i6c2o7v6hk	Sacerdote junto a grupo en cuasimodo	Sacerdote junto a grupo en cuasimodo	Sacerdotes y jinetes durante Cuasimodo		Padre Jimmy Turner, Yegua : Tarea			Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	4	Yoconda Moya	Procultura	2025-10-15 17:29:28.572	2025-10-15 17:29:28.572
cmgs9n0ei00d8h9i6sslffg75	Jóvenes en una laguna	Jóvenes en una laguna	Jóvenes en la laguna Los Trapenses.		Al centro, Patricio Dotte	1970-1980	1970	Los Trapenses	Década 1970. Laguna Los Trapenses	4	Patricia Dotte	Procultura	2025-10-15 17:29:30.57	2025-10-15 17:29:30.57
cmgs9n2ji00dmh9i6drv3wjub	Grupo familiar con el cerro al fondo	Grupo familiar con el cerro al fondo	Grupo familiar con el cerro al fondo.		Nn, nn, Rosa Alcaíno, en brazos Patricio Dotte, Virginio Dotte, mujer con niño en brazos, Tinita con niña en brazos.	1960	1960			4	Patricia Dotte	Procultura	2025-10-15 17:29:33.342	2025-10-15 17:29:33.342
cmgs9n3s200dth9i64ywg64gi	Arenero	Arenero	Arenero a orillas del río Mapocho.		Héctor Torreblanca	1970-1980	1970	San Enrique/La Ermita/Las Condes	Década 1970. Pueblo de Lo Barnechea	4	Familia Soto Torreblanca	Procultura	2025-10-15 17:29:34.947	2025-10-15 17:29:34.947
cmgs9n5aw00e0h9i6ab4l0x4f	Grupo en areneros	Grupo en areneros	Grupo en areneros, posiblemente en las cuatro canchas.	“Pedro Galvez”. Papel Postcard	Segundo abajo desde la izquierda, Héctor Torreblanca	hacia 1950	1950	San Enrique/La Ermita/Las Condes	Circa 1950. Posiblemente en las cuatro canchas.	4	Familia Soto Torreblanca	Procultura	2025-10-15 17:29:36.92	2025-10-15 17:29:36.92
cmgs9n6xq00e7h9i6b50wma8q	Dos jóvenes sobre una roca	Dos jóvenes sobre una roca	Dos jóvenes sobre una roca junto al río Mapocho.		Ramón Herrera y Rafal Pinto	1940	1940	El Arrayán	"01-01-40". Río Mapocho	4	María Araya	Procultura	2025-10-15 17:29:39.038	2025-10-15 17:29:39.038
cmgs9navy00elh9i6q2oj31ux	Cinco niños en el cerro	Cinco niños en el cerro	Cinco niños en el cerro en El Arrayán.		Cristián Gutierrez, Claudio Gutierrez, Felipe Gutierrez, Rafael Gutierrez, Alvaro Gutierrez	1975	1970	El Arrayán	1975. El Arrayán	4	Rodolfo Gutierrez	Procultura	2025-10-15 17:29:44.158	2025-10-15 17:29:44.158
cmgs9ndp100ezh9i6d60bn2x2	Niños jugando a los indios	Niños jugando a los indios	Niños jugando en la casa de Rodolfo Gutiérrez.	Primos , vivian juntos	Claudio Gutierrez, Claudio Gutierrez, Felipe Gutierrez, Rafael Gutierrez, Alvaro Gutierrez, Cristian Gutierrez	1975	1970	El Arrayán	1975. Casa de Rodolfo Gutierrez	4	Rodolfo Gutierrez	Procultura	2025-10-15 17:29:47.798	2025-10-15 17:29:47.798
cmgs9o28d00f6h9i62lrn5noo	Pareja y niño	Pareja y niño	Pareja y niño en San Enrique.	Fotografía ampliada del original antiguo	Amador Moreno, María Magdalena Moreno, Orlando Guerra	1930-1940	1930	San Enrique/La Ermita/Las Condes	Década de 1930. San Enrique	4	Pamela Araya	Procultura	2025-10-15 17:30:19.597	2025-10-15 17:30:19.597
cmgs9o51i00fkh9i6sf9yvfvu	Hombres brindando	Hombres brindando	Familia en el restaurante 'El pollo al Cognac'	Despedida Pedro Araya	Luis Villarroel, Humberto Silva, Pedro Araya, Eliseo Villarroel, Perez.	1970	1970	Pueblo de Lo Barnechea	1970. Pueblo de Lo Barnechea	4	Patricio Villarroel	Procultura	2025-10-15 17:30:23.239	2025-10-15 17:30:23.239
cmgs9oklr00frh9i6859zc3mi	Equipo frente a graderías	Equipo frente a graderías	Equipo frente a las graderías		Gutierrez, Papelito, Ivan Acevedo, Carlos Moya, Juan Sanhueza, Pato Villarroel. Abajo Ricardo Garcia, Hugo Aracena, Victor Conejeras, Nano Molina, Correcaminos.	hacia 1968	1960	Pueblo de Lo Barnechea	Circa 1968. Pueblo de Lo Barnechea	4	Patricio Villarroel	Procultura	2025-10-15 17:30:43.407	2025-10-15 17:30:43.407
cmgs9omiy00fyh9i6jd5xlzn4	Grupo de hombres en un puente	Grupo de hombres en un puente	Grupo de hombres en el puente San Enrique. El reverso de la fotografía dice: "Santiago, Junio 13 / 36".	El reverso de la fotografía dice: "Santiago, Junio 13 / 36. A nuestro amigo Don Antonio Diaz Lira en el día de su onomastico.-p. Osvaldo Miro"	extremo derecho Antonio Díaz Lira y Luis Díaz Lira (dueño de Almacén El Chile en San Enrique). 	1936	1930	San Enrique/La Ermita/Las Condes	"Junio 13 1936". Puente San Enrique	4	Juan Carlos Salas	Procultura	2025-10-15 17:30:45.898	2025-10-15 17:30:45.898
cmgs9ooqe00g5h9i60d6tw5cd	Grupo en cancha de tenis	Grupo en cancha de tenis	Hombres y mujeres en la cancha de tenis en el pueblo de Lo Barnechea	Papel Post Card				Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	4	Juan Carlos Salas	Procultura	2025-10-15 17:30:48.759	2025-10-15 17:30:48.759
cmgs9ot1z00gch9i6v799nizk	Vista local Pollo al Cognac Cerrillos	Vista local Pollo al Cognac Cerrillos	Vista del local 'El pollo al cognac' en la FISA, Cerrillos.			hacia 1964	1960	Santiago	Circa 1964. Local de la FISA, Cerrillos	4	Juan Carlos Salas	Procultura	2025-10-15 17:30:54.359	2025-10-15 17:30:54.359
cmgs9ovpb00gjh9i6stafnz0w	Pareja en terraza de restaurante	Pareja en terraza de restaurante	Pareja en el restaurante de la Hostería Río Abajo.		Juan Salas Ibarra, Rosa Eliana Díaz	1954	1950	El Arrayán	Febrero 1954. Hosteria Rio Abajo	4	Juan Carlos Salas	Procultura	2025-10-15 17:30:57.791	2025-10-15 17:30:57.791
cmgs9oxyj00gqh9i6ndbg7rcu	Hosteria Rio Abajo	Hosteria Rio Abajo	Hostería Río Abajo en El Arrayán.	Antes de que se construyera la terraza	 Atrás, casona de su abuela materna Mercedes Díaz Lira. Adelante, Hostería Río Abajo. La casa de atrás tenía un almacén, Almacén Chile. 	hacia 1952	1950	El Arrayán	Circa 1952. El Arrayán	4	Juan Carlos Salas	Procultura	2025-10-15 17:31:00.714	2025-10-15 17:31:00.714
cmgs9p0iz00gxh9i6pk77wzil	Niñas escolares desfilando	Niñas escolares desfilando	Estudiantes de la Brigada del Tránsito de la Escuela Básica D-238 desfilando en Lo Barnechea.	Desfila la Escuela D-238 Estados Americanos, conocida en el pueblo como "la  Pública".		hacia 1980	1980	Pueblo de Lo Barnechea	Circa 1980. Calle Barnechea	4	Juan Carlos Salas	Procultura	2025-10-15 17:31:04.043	2025-10-15 17:31:04.043
cmgs9p49600hbh9i6lhtswx0j	Niño frente a un tronco seco	Niño frente a un tronco seco	Niño frente a un tronco seco en Lo Barnechea.			1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	4	Ana Matteo Rojas	Procultura	2025-10-15 17:31:08.875	2025-10-15 17:31:08.875
cmgs9p57m00hih9i655qvvrl0	Mujer colgada de torre de alta tensión	Mujer colgada de torre de alta tensión	Mujer trepada a la torre de alta tensión.			1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	4	Ana Matteo Rojas	Procultura	2025-10-15 17:31:10.115	2025-10-15 17:31:10.115
cmgs9tazs00quh9i6frwa9qeo	Mujer cuasimodista	Mujer cuasimodista	Mujer cuasimodista en Avenida Lo Barnechea		María Araya Pinto	1980-1990	1980	Pueblo de Lo Barnechea	Década de 1980. Avenida Barnechea	3	Ximena Riveros de Araya	Procultura	2025-10-15 17:34:24.213	2025-10-15 17:34:24.213
cmgsa0u4o016eh9i61595wl94	Jóvenes en puesto de verduras	Jóvenes en puesto de verduras	Jóvenes en puesto de verduras		Ciclistas de las familias Adasme y Galindo					3	Rocío Muñoz	Procultura	2025-10-15 17:40:15.624	2025-10-15 17:40:15.624
cmgs9p7of00hph9i6o6du1vx2	Candidatas a reina con hombre de pie	Candidatas a reina con hombre de pie	Candidatas a Reina. Atrás aparece un estandarte del Club Deportivo Juventud Catolica	Timbre: C.D. JUVENTUD CATOLICA /FDO. 27 DE JULIO DE 1940 / BARNECHEA LAS CONDES /// Otro timbre: FOTO REPORTAJE SOCIAL "RELAMPAGO" E. Hoffstetter. Grajales 2152- Stgo.	Maria Serrano, Eduvigis Ulloa, Ana Matteo, NN, NN, Jorge Labbe (rey feo)	1959	1950	Pueblo de Lo Barnechea	27 de Febrero 1959. Pueblo de Lo Barnechea	4	Ana Matteo Rojas	Procultura	2025-10-15 17:31:13.311	2025-10-15 17:31:13.311
cmgs9pcqe00i3h9i64dc3rkg4	Carro alegórico de casino	Carro alegórico de casino	Carro alegórico en la Quinta Las Rosas.	Timbre: C.D. JUVENTUD CATOLICA /FDO. 27 DE JULIO DE 1940 / BARNECHEA LAS CONDES /// Otro timbre: FOTO REPORTAJE SOCIAL "RELAMPAGO" E. Hoffstetter. Grajales 2152- Stgo.		1959	1950	Pueblo de Lo Barnechea	27 Febrero 1959. Quinta Las Rosas	4	Ana Matteo Rojas	Procultura	2025-10-15 17:31:19.862	2025-10-15 17:31:19.862
cmgs9qjno00jnh9i6pxmzkn4l	Vista de laguna en la cordillera.	Vista de laguna en la cordillera.	Vista de laguna en la cordillera.					Farellones		4	Margarita Gana	Procultura	2025-10-15 17:32:15.493	2025-10-15 17:32:15.493
cmgs9qqz100k8h9i6bxqnm09i	Equpo junto a niño	Equpo junto a niño	Foto de equipo de futbol		Floro Valencia, "Parafina", nn, Che Bravo, Benjamin Valencia, nn. Abajo. Clavo Molina, Goyito Bravo, Jaime Alvarez, Pelao Alvarez, René Alvarez. 	hacia 1950	1950	Pueblo de Lo Barnechea	Benjamin valencia era famoso "por ser muy bueno pa la pelota". Su equipo fue campeon invicto de la asoc las condes el año 1945. Por eso el escudo del club tiene unas estrellas y tiene un sol, el sol es del 45. . Circa 1950. Pueblo de Lo Barnechea	4	Eliseo Villarroel	Procultura	2025-10-15 17:32:24.973	2025-10-15 17:32:24.973
cmgs9rdr500kth9i6cqv4so3p	Paseo de curso a Pichilemu	Paseo de curso a Pichilemu	Paseo de curso a Pichilemu por el último año de educación básica.	Reverso de la foto es LBCH1118		1977	1970	Otro	Otro	3	Familia Meza Cortés	Procultura	2025-10-15 17:32:54.498	2025-10-15 17:32:54.498
cmgs9rfi400l0h9i6jflyze0j	Reverso foto 1131	Reverso foto 1131	Reverso de postal de gira de estudios. 	Reverso de foto LBCH1117		1977	1970	Otro	Población Nebraska	3	Familia Meza Cortés	Procultura	2025-10-15 17:32:56.765	2025-10-15 17:32:56.765
cmgs9rhhe00l7h9i6jn7yzma8	Equipo con bandera	Equipo con bandera	Equipo del CD Lo Barnechea con su bandera	Tercera división	Pato, Pacharli, Aracena, de rayas Yeyo Contreras, nn, nn, Rogui, Chico Reyes, Manguera, Profe Muñoz. Abajo: Molina, nn, Moroco, Manuel Araya, Faúndez, Rana, Galvez.	hacia 1980	1980	Pueblo de Lo Barnechea	Circa 1980. Pueblo de Lo Barnechea	3	Eliseo Villarroel	Procultura	2025-10-15 17:32:59.33	2025-10-15 17:32:59.33
cmgs9rmme00lzh9i675uf9mn1	Dos hombres frente a kioskos de Farellones	Dos hombres frente a kioskos de Farellones	Dos hombres frente a un kiosko en Farellones	Miguel era funcionario de Carabineros, venía del sur.	Rafael Gallardo, Miguel Lipicheo	1989	1980	Farellones	Estacionamiento de Farellones	3	Familia Gallardo	Procultura	2025-10-15 17:33:05.99	2025-10-15 17:33:05.99
cmgs9rue500mkh9i6f1q8c54b	Coche en procesión de Cuasimodo	Coche en procesión de Cuasimodo	Coche en procesión de Cuasimodo					El Arrayán		3	Clemira Montenegro	Procultura	2025-10-15 17:33:16.061	2025-10-15 17:33:16.061
cmgs9s16h00myh9i6qq05ivpu	Novios en coche de caballos	Novios en coche de caballos	Novios en coche de caballos		Juanito					3	Rocio Muñoz	Procultura	2025-10-15 17:33:24.858	2025-10-15 17:33:24.858
cmgs9s3x300n5h9i6pl9b1gal	Vista del cerro 18	Vista del cerro 18	Vista del cerro 18 en Cerro 18			hacia 2000	2000	Cerro 18	Circa 2000. Cerro 18	3	Rocio Muñoz	Procultura	2025-10-15 17:33:28.408	2025-10-15 17:33:28.408
cmgs9s81600njh9i6h1x3e5hv	Presentación musical	Presentación musical	Presentación musical de conjunto folclórico en la Semana Barnecheina 	instrumentos de musica andina. ¿Sera el conjunto "Antawara"?						3	Rocio Muñoz	Procultura	2025-10-15 17:33:33.738	2025-10-15 17:33:33.738
cmgs9s9vh00nqh9i6gs15w5us	Rodeo	Rodeo	Rodeo							3	Rocio Muñoz	Procultura	2025-10-15 17:33:36.125	2025-10-15 17:33:36.125
cmgs9scta00nxh9i6n5lse4c5	Auto decorado en Cuasimodo	Auto decorado en Cuasimodo	Auto decorado en Cuasimodo			1980-1990	1980			3	Rocio Muñoz	Procultura	2025-10-15 17:33:39.933	2025-10-15 17:33:39.933
cmgs9pa7q00hwh9i6aizrwfuq	Grupo disfrazado con reyes al centro y naipes detràs	Grupo disfrazado con reyes al centro y naipes detràs	Grupo disfrazado con las candidatas a Reina. Celebración del Club Deportivo Juventud Catolica	Timbre: C.D. JUVENTUD CATOLICA /FDO. 27 DE JULIO DE 1940 / BARNECHEA LAS CONDES /// Otro timbre: FOTO REPORTAJE SOCIAL "RELAMPAGO" E. Hoffstetter. Grajales 2152- Stgo.		1959	1950	Pueblo de Lo Barnechea	1959. Pueblo de Lo Barnechea	4	Ana Matteo Rojas	Procultura	2025-10-15 17:31:16.598	2025-10-15 17:31:16.598
cmgs9pln400ioh9i6in6xcxb9	Arriero en una pausa de la subida	Arriero en una pausa de la subida	El arriero Custodio Gana en la cordillera, subiendo al Observatorio Los Bronces de la Universidad de Chile.	en la montaña	Custodio Gana Hernández	1950-1960	1950	Farellones	Década 1950. Pausa en el camino, subiendo a observatorio de la U. de Chile	4	Margarita Gana	Procultura	2025-10-15 17:31:31.408	2025-10-15 17:31:31.408
cmgs9q0eo00ivh9i6hxev2a5z	Mula al frente de fila de hombres subiendo	Mula al frente de fila de hombres subiendo	Mula al frente de una fila de hombres subiendo al Observatorio Los Bronces en la cordillera	"Camino a Los Bronces" en la montaña. Fundación de las Casas A: trajeron familias de Pte Alto, la Reina, Cajon del Maipo, que tuvieran más de 12, 15 niños. Una familia de apellido Vial hizo casas y se las regaló.. Circa 1960. Subiendo camino al observatorio	Primer caminante es Custodio Gana	hacia 1960	1960	Farellones	Fundación de las Casas A: trajeron familias de Pte Alto, la Reina, Cajon del Maipo, que tuvieran más de 12, 15 niños. Una familia de apellido Vial hizo casas y se las regaló.. Circa 1960. Subiendo camino al observatorio	4	Margarita Gana	Procultura	2025-10-15 17:31:50.543	2025-10-15 17:31:50.543
cmgs9qi2m00jgh9i6ow8q5ltb	Hombres descansando la subida	Hombres descansando la subida	Arrieros descansando en la subida de "los barrancones", en el sector del cajón del Arrayán.		Miguel Dávila Gana, Rigoberto Dávila Gana, Olegario Gana Hernández	1988	1980	El Arrayán	27-12-88. Los barrancones, cajón del Arrayán para arriba. Descanso en que descargan los animales. 	4	Margarita Gana	Procultura	2025-10-15 17:32:13.438	2025-10-15 17:32:13.438
cmgs9qp5900k1h9i6p03oewv0	Dos jugadores con pelotas	Dos jugadores con pelotas	Jugadores de futbol con las camisetas de la Juventud Católica y del CD Barnechea	Las canchas eran de tierra.	Tito Romero, Hector Carreño "Bototo"	1960-1970	1960	Pueblo de Lo Barnechea	ML (porque muestra juntos a un integrante de cada club). Década 1960. Cancha de Barnechea, era de tierra	4	Eliseo Villarroel	Procultura	2025-10-15 17:32:22.606	2025-10-15 17:32:22.606
cmgs9rbym00kmh9i60ezi1nxf	Tres jugadores trotando	Tres jugadores trotando	Tres jugadores trotando en la antigua cancha de Barnechea. Atrás se ve la iglesia	Fotografía antigua digitalizada	“Hermanos Meneses y Chico Coton” Adrian Meneses, Antonio Pino, Alberto Meneses	1952	1950	Pueblo de Lo Barnechea	“1952”. Pueblo de Lo Barnechea	4	Eliseo Villarroel	Procultura	2025-10-15 17:32:52.175	2025-10-15 17:32:52.175
cmgs9rjz500llh9i68qf46vje	Pareja de niños frente a edificio	Pareja de niños frente a edificio	Pareja de niños frente a un edificio en Farellones		Adela Gallardo, Luis Gallardo	1980	1980	Farellones	Farellones	3	Familia Gallardo	Procultura	2025-10-15 17:33:02.56	2025-10-15 17:33:02.56
cmgs9rrbj00mdh9i6hbloq3is	Misa en La Ermita	Misa en La Ermita	Misa en La Ermita			2000	2000	Farellones		3	Clemira Montenegro	Procultura	2025-10-15 17:33:12.079	2025-10-15 17:33:12.079
cmgs9rysc00mrh9i6d4uyif8l	Familia frente al cerro	Familia frente al cerro	Familia frente al cerro							3	Clemira Montenegro	Procultura	2025-10-15 17:33:21.756	2025-10-15 17:33:21.756
cmgs9s62200nch9i654yoxl2t	Participante de concurso con los brazos abiertos	Participante de concurso con los brazos abiertos	Participante de concurso en la Semana Barnecheína							3	Rocio Muñoz	Procultura	2025-10-15 17:33:31.178	2025-10-15 17:33:31.178
cmgs9sfsi00o4h9i6mn0n9mz1	Auto decorado en Cuasimodo	Auto decorado en Cuasimodo	Auto decorado en Cuasimodo		Checho Silva 	1980-1990	1980			3	Rocio Muñoz	Procultura	2025-10-15 17:33:43.795	2025-10-15 17:33:43.795
cmgs9sina00obh9i6jp2myxdp	Partido de futbol con cerro detrás	Partido de futbol con cerro detrás	Partido de fútbol con cerro detrás, en cancha de fútbol del Arrayán	CD Lo Barnechea				El Arrayán	Cancha de futbol del Arrayan	3	Rocio Muñoz	Procultura	2025-10-15 17:33:47.494	2025-10-15 17:33:47.494
cmgs9slcj00oih9i60msybon3	Foto CD Barnechea	Foto CD Barnechea	Foto de equipo del CD Lo Barnechea					Pueblo de Lo Barnechea	Club Deportivo Barnechea	3	Rocio Muñoz	Procultura	2025-10-15 17:33:50.995	2025-10-15 17:33:50.995
cmgs9snzi00oph9i6w9mldn85	Grupo de carabineros	Grupo de carabineros	Grupo de carabineros							3	Rocio Muñoz	Procultura	2025-10-15 17:33:54.415	2025-10-15 17:33:54.415
cmgs9spvj00owh9i6pcbox0j8	Presentación folclórica	Presentación folclórica	Presentación folclórica	Semana Barnecheina. Incluia concursos de canto, baile, Miss Pierna, Mister musculo. En la cancha junto a la parroquia.		1980-1990	1980			3	Rocio Muñoz	Procultura	2025-10-15 17:33:56.863	2025-10-15 17:33:56.863
cmgs9srjc00p3h9i6fwfgq58j	Foto equipo celeste con maizales	Foto equipo celeste con maizales	Foto equipo de fútbol celeste con maizales						Equipo de alguna parte de la comuna. Quinchamali?	3	Rocio Muñoz	Procultura	2025-10-15 17:33:59.016	2025-10-15 17:33:59.016
cmgs9suip00pah9i62p3zbxw7	Hombre sosteniendo vaso	Hombre sosteniendo vaso	Hombre sosteniendo vaso						¿Esposo Doña Tina?	3	Rocio Muñoz	Procultura	2025-10-15 17:34:02.882	2025-10-15 17:34:02.882
cmgs9sxfn00phh9i6wv82y0ii	Dos ganadoras Srta. Barnechea 1989	Dos ganadoras Srta. Barnechea 1989	Dos ganadoras del concurso Srta. Barnechea durante la Semana Barnecheína de 1989	Semana Barnecheaina		1989	1980			3	Rocio Muñoz	Procultura	2025-10-15 17:34:06.66	2025-10-15 17:34:06.66
cmgs9t0b900poh9i676wxooak	Srta. Barnechea 1989 habla por micrófono	Srta. Barnechea 1989 habla por micrófono	Srta. Barnechea 1989 habla por micrófono 	Semana Barnecheaina		1989	1980			3	Rocio Muñoz	Procultura	2025-10-15 17:34:10.389	2025-10-15 17:34:10.389
cmgs9t1r200pvh9i6b1edsgv8	Pareja mirando a la cámara	Pareja mirando a la cámara	Pareja mirando a la cámara							3	Rocio Muñoz	Procultura	2025-10-15 17:34:12.255	2025-10-15 17:34:12.255
cmgs9t4fv00q2h9i6cu9y3xmn	Foto equipo CD Barnechea	Foto equipo CD Barnechea	Foto equipo del CD Barnechea							3	Rocio Muñoz	Procultura	2025-10-15 17:34:15.74	2025-10-15 17:34:15.74
cmgs9t5h100q9h9i6emdsx27s	Cumpleaños infantil	Cumpleaños infantil	Cumpleaños infantil en El Arrayán		Guacolda Rodriguez, Andres Gana, escondido, Amada Tapia, en brazos Jorge Maureira, lo sostiene América Gana, nn, la más alta Margarita Gana, de negro Eliana Gana, niña con gorro al centro Gema Dávila, Enrique Rodriguez, Naún Tapia, de pie a la der Andres Gana, Juan Maureira (cumpleañero), en primer plano Celinda Rodriguez	1974	1970	El Arrayán	1974. Casa en El Arrayan	3	Margarita Gana	Procultura	2025-10-15 17:34:17.078	2025-10-15 17:34:17.078
cmgs9t6i600qgh9i60wzih96o	Cumpleaños infantil 2	Cumpleaños infantil 2	Cumpleaños infantil en El Arrayán		Juan Maureira,  Andres Gana, Enrique Rodriguez, Victor Dávila, Gema Dávila, América Gana con Jorge Maureira en brazos, Nancy Dávila, niño, Silvia Gana, Guacolda Rodriguez, Celinda Rodriguez	1974	1970	El Arrayán	1974. Casa en El Arrayan	3	Margarita Gana	Procultura	2025-10-15 17:34:18.414	2025-10-15 17:34:18.414
cmgs9t9af00qnh9i64ei2l7c0	Niña en caballo de cuasimodo	Niña en caballo de cuasimodo	Niña en caballo de cuasimodo	confirmar que es plaza san enrique	Jorge Maureira e hija Carla Maureira	2005	2000	San Enrique/La Ermita/Las Condes	2005. Plaza San Enrique	3	Margarita Gana	Procultura	2025-10-15 17:34:22.023	2025-10-15 17:34:22.023
cmgs9tclg00r1h9i6z16937c4	Primera comunión al aire libre	Primera comunión al aire libre	Primera comunión al aire libre en el Santuario de la Naturaleza en El Arrayán			1993	1990	El Arrayán	1993. Santuario de la Naturaleza El Arrayan	3	Ximena Riveros de Araya	Procultura	2025-10-15 17:34:26.308	2025-10-15 17:34:26.308
cmgs9tk8l00rth9i674ff62fv	Cuatro cuasimodistas de rojo	Cuatro cuasimodistas de rojo	Cuatro cuasimodistas de rojo en las canchas de la comuna	lugar donde realizaban todas las fiestas	Eduardo Araya, Luis Araya, Pedro Araya, Rumaldo Araya. Ese año fueron los campanilleros, es decir, los primeros en llegar. 	hacia 1990	1990	Pueblo de Lo Barnechea	Circa 1990. Canchas de la comuna, donde realizaban todas las fiestas	3	Ximena Riveros de Araya	Procultura	2025-10-15 17:34:36.214	2025-10-15 17:34:36.214
cmgs9tl7i00s0h9i6pp9tvwmx	Dos mujeres y cactus	Dos mujeres y cactus	Dos mujeres con un cactus en Maitenes Bajo (Camino a La Disputada)		Carmen Contreras y prima Salvadora Ubierna	hacia 1952	1950	Farellones	Circa 1952. Maitenes Bajo (camino a disputada)	3	Ana Matteo Rojas	Procultura	2025-10-15 17:34:37.47	2025-10-15 17:34:37.47
cmgs9tosw00seh9i6vwketcuk	Carro alegórico de guitarra	Carro alegórico de guitarra	Carro alegórico de guitarra en Pueblo de Lo Barnechea		Ana Matteo y Gustavo Gonzalez junto a candidatas	1959	1950	Pueblo de Lo Barnechea	1959. Pueblo de Lo Barnechea	3	Ana Matteo Rojas	Procultura	2025-10-15 17:34:42.128	2025-10-15 17:34:42.128
cmgs9tsj600szh9i6a94ujl66	Mujeres y niños en el cerro	Mujeres y niños en el cerro	Mujeres y niños en el cerro	Venían de vuelta de la playa	Con cuello blanco Valentina Rojas con nieto Guillermo Alfredo Orrego Matteo, niña grande Andrea Maira, niña al frente Verónica Maira, a la izq Marcelo Maira (los tres hermanos, hijos de Lucia) de rojo Lucía Solis (nuera)	1977	1970		Abril 1977. Venían de vuelta de la playa	3	Ana Matteo Rojas	Procultura	2025-10-15 17:34:46.962	2025-10-15 17:34:46.962
cmgs9u1ky00tyh9i6msm1fve7	Jugador de futbol lesionado	Jugador de futbol lesionado	Jugador de fútbol lesionado en las canchas de Barnechea		En el suelo: Alberto Meneses, agachado con jockey Jerez, a la derecha de blanco Juan Acuña. 	hacia 1960	1960	Pueblo de Lo Barnechea	Circa 1960. Canchas de Barnechea	3	Alberto Meneses	Procultura	2025-10-15 17:34:58.69	2025-10-15 17:34:58.69
cmgs9u6b300uch9i6m35rahyp	Niños de primera comunión 	Niños de primera comunión 	Niños de primera comunión en la calle El Esfuerzo		Hortensia Araneda, sacerdote padre Mauro, Juan Carlos Ocampo Chavez, Luis Ocampo Chavez, monjita, Manuel Arriagada, niña. 	hacia 1972	1970	Pueblo de Lo Barnechea	Calle el esfuerzo antes era de tierra y piedra. Calle el Esfuerzo	3	María Chavez	Procultura	2025-10-15 17:35:04.815	2025-10-15 17:35:04.815
cmgs9udvr00vbh9i6n9wicxos	Hombre actuando en velada artística	Hombre actuando en velada artística	Hombre actuando en velada artística en el salón parroquial Santa Rosa. Todos los años se hacían esas veladas para la fiesta de Santa Rosa.	Foto Reportaje social “Relampago”	Ramon Meza Pinto actuando el sketch “el carrerista”	1957	1950	Pueblo de Lo Barnechea	31/8/1957.. Salon parroquial Santa Rosa. Todos los años se hacían esas veladas para la fiesta de Santa Rosa. 	3	Familia Meza Cortés	Procultura	2025-10-15 17:35:14.632	2025-10-15 17:35:14.632
cmgs9uhf000vph9i6iuj9noi3	Tres jugadores de Club Catolica	Tres jugadores de Club Catolica	Tres jugadores de Club Católica en las canchas de Lo Barnechea		Ramón Meza Pinto, Humberto Silva, Florentino Valencia	hacia 1960	1960	Pueblo de Lo Barnechea	Circa 1960. Cancha de la comuna	3	Familia Meza Cortés	Procultura	2025-10-15 17:35:19.213	2025-10-15 17:35:19.213
cmgs9uitc00vwh9i6qc2lxvlv	Equipo Juventud Católica completo	Equipo Juventud Católica completo	Foto del equipo Juventud Católica en las canchas de Lo Barnechea		Izq: Chico "de los pitos" Acevedo. 1er jugador Osvaldo “Guayo” Tapia, Pepe Silva, Lucho Novoa, Rucio Portilla, David Araya, Domingo Araya. Abajo: Alberto Labbé, Ramón Meza, Tristán Solis, Rafael Herrera, Fernando "Nano " Herrera. 	1959	1950	Pueblo de Lo Barnechea	Canchas Barnechea	3	Familia Meza Cortés	Procultura	2025-10-15 17:35:21.024	2025-10-15 17:35:21.024
cmgs9ujrc00w3h9i6u4qow7e0	Equipo Juventud Catolica agachado con pelota	Equipo Juventud Catolica agachado con pelota	Equipo Juventud Católica agachado con pelota		1ro Domingo Araya, Rafael Canto,  Rafael Herrera, 4to NN, 5to Lucho Novoa, 6to David Araya. Abajo Alberto Labbé,  Ramiro Araya, Ramón Meza, Pedro Contreras, Freddy Querol.	hacia 1959	1950	Pueblo de Lo Barnechea	Circa 1959. Población Nebraska	3	Familia Meza Cortés	Procultura	2025-10-15 17:35:22.249	2025-10-15 17:35:22.249
cmgs9unkv00whh9i6mimjx7k1	Dos hombres con trofeo	Dos hombres con trofeo	Dos hombres con trofeo en la sede de Juventd Católica	(sede de l eequipo estaba en el templo mormón actual, era de los herrera, que la entregaron al club. Luego se quedo don Alamiro Dotte con su familia, y el sr Herrera se los donó. Luego ellos lo vendieron a los mormones). “Campeonato de Futbol de 1962” Comunal de Las Condes.  (	Ramón Meza y Domingo Araya	1962	1960	Pueblo de Lo Barnechea	Sede de Juventd Católica (templo mormón actual, era de los herrera, que la entregaron al club. Luego se quedo don Alamiro Dotte con su familia, y el sr Herrera se los donó. Luego ellos lo vendieron a los mormones).	3	Familia Meza Cortés	Procultura	2025-10-15 17:35:27.199	2025-10-15 17:35:27.199
cmgs9urpb00woh9i6i9pjtt4w	Preparación de la carga	Preparación de la carga	Preparación de la carga en el Fundo Potrero Grande			1960-1970	1960	Farellones	Década de 1960. Fundo Potrero Grande. Haciendo las cargas para traslado de víveres necesarios para estar arriba (harina, papas, cebolla) en cajones. Cada 15 días se les subían las “raciones” . Están abajo.	3	Alfonso Campos	Procultura	2025-10-15 17:35:32.544	2025-10-15 17:35:32.544
cmgs9ut9x00wvh9i6boym8e1d	Cuatro hombres con caballos en el cerro	Cuatro hombres con caballos en el cerro	Cuatro hombres con caballos en el cerro en Sector Las Retamas		Oscar Molina, Manuel Herrera inclinado con chupalla. En primer plano de azul, Mauricio, quien pidió hacer un paseo a la cordillera. 	hacia 2000	2000		Circa 2000. Sector Las Retamas. Cerro 18	3	Familia Muñoz Dotte	Procultura	2025-10-15 17:35:34.581	2025-10-15 17:35:34.581
cmgs9uust00x2h9i69av75sa9	Grupo de niño	Grupo de niño	Grupo de niños en el Cerro 18 durante una celebración de Navidad para los niños del centro de madres de Lo Barnechea		Fiesta de navidad para los niños del centro de madres Lo Barnechea	hacia 1995	1990	Cerro 18	Circa 1995. Cerro 18. Cerro 18	3	Familia Muñoz Dotte	Procultura	2025-10-15 17:35:36.558	2025-10-15 17:35:36.558
cmgs9uwf100x9h9i6n0pctlcg	Grupo en el río 	Grupo en el río 	Grupo en el río en El Arrayán	en las vertientes, más arriba de la piscina municipal	María Ester Quiroz, Edith Quiroz, Alejandro Miranda mendoza, Cecilia Quiroz Mendoza, isolina Quiroz Mendoza	1977	1970	El Arrayán	22-2-77. vertientes en El Arrayan, más arriba de la piscina municipal	3	Familia Quiroz Mendoza	Procultura	2025-10-15 17:35:38.653	2025-10-15 17:35:38.653
cmgs9v2fm00xnh9i691gofbw6	Mujer en Torres del Paine	Mujer en Torres del Paine	Mujer en Torres del Paine	Vivía de sus rentas, era socia del Stgo Pepperchase. Antes vivia en Punta Arenas. Viajó por todo Chile. Fue siempre soltera.Su papá tenía una empresa Agfa de fotografía.  	Lotte Lebriesch	1970-1980	1970	Otro	Década de 1970. Torres del Paine	3	Familia Quiroz Mendoza	Procultura	2025-10-15 17:35:46.45	2025-10-15 17:35:46.45
cmgs9vcra00ymh9i64d0sn95l	Cuatro mujeres en el río	Cuatro mujeres en el río	Cuatro mujeres de paseo en el río Mapocho, a la altura de las canchas	Iban los domingos de paseo	Ester Quiroz, Carolina Martínez, Nana Martínez, Cecilia Quiroz	1980-1990	1980	Población Nebraska	Década de 1980. Río a la altura de las canchas	3	Familia Quiroz Mendoza	Procultura	2025-10-15 17:35:59.83	2025-10-15 17:35:59.83
cmgs9ted200r8h9i69ixdtir5	Escolares	Escolares	Escolares del Colegio Parroquial Santa Rosa		Profesora René Troncoso, hermana Rosario	hacia 1996	1990	Pueblo de Lo Barnechea	importante porque profesora estuvo muchos años. Circa 1996. Colegio Parroquial Santa Rosa	3	Ximena Riveros de Araya	Procultura	2025-10-15 17:34:28.598	2025-10-15 17:34:28.598
cmgs9tfqw00rfh9i6rh43360q	Cumpleaños infantil	Cumpleaños infantil	Cumpleaños infantil en Av. Lo Barnechea		Pedro Araya Riveros y Jennifer Araya Riveros	1987	1980	Pueblo de Lo Barnechea	1987. Casa Av Barnechea	3	Ximena Riveros de Araya	Procultura	2025-10-15 17:34:30.393	2025-10-15 17:34:30.393
cmgs9tho100rmh9i6h6pv5bw8	Padre e hijo a caballo	Padre e hijo a caballo	Padre e hijo a caballo		Pedro Araya Rubio y Pedro "Robby" Araya Araya	1986	1980	Pueblo de Lo Barnechea	1986. Pueblo de Lo Barnechea	3	Ximena Riveros de Araya	Procultura	2025-10-15 17:34:32.881	2025-10-15 17:34:32.881
cmgs9tps300slh9i669v3dudh	Piscina	Piscina	Piscina en Club de Campo		el primero en el trampolin es Guillermo Alfredo	1976	1970		1976. Club de Campo	3	Ana Matteo Rojas	Procultura	2025-10-15 17:34:43.396	2025-10-15 17:34:43.396
cmgs9tv8c00t6h9i6kuzrcbxb	Mujer joven junto a planta	Mujer joven junto a planta	Mujer joven con una planta en el pueblo de Lo Barnechea		Gloria Maira Olivares	hacia 1970	1970	Pueblo de Lo Barnechea	Circa 1970. Pueblo de Lo Barnechea	3	Ana Matteo Rojas	Procultura	2025-10-15 17:34:50.461	2025-10-15 17:34:50.461
cmgs9txpi00tkh9i645nrbl20	Jóvenes en el cerro	Jóvenes en el cerro	Jóvenes en el cerro en el tranque Los Trapenses	"Recuerdo del tranque la Deesa. Tito, Maira, Pato, Jerardo Garay, Jaime Manrique, Pedro Araya, Ernesto Maira". 	Ana Matteo, al fondo Alejandro Maira, con pies levantados Nana Araya	1969	1960	Los Trapenses	CHEQUEAR. 14-9-69. Tranque Los Trapenses	3	Ana Matteo Rojas	Procultura	2025-10-15 17:34:53.67	2025-10-15 17:34:53.67
cmgs9tyss00trh9i665yzxhv5	Dos hombres con pelota	Dos hombres con pelota	Dos hombres con pelota de fútbol en el estadio debajo de la iglesia		Antonio "Coton" Pino y Antonio Alberto "Chico" Meneses	1951	1950	Pueblo de Lo Barnechea	Estadio debajo de la iglesia	3	Alberto Meneses	Procultura	2025-10-15 17:34:55.083	2025-10-15 17:34:55.083
cmgs9u3k900u5h9i6xlgrsnir	Declamación de poema en semana Barnecheina 	Declamación de poema en semana Barnecheina 	Declamación de poema en la Semana Barnecheina en la Plaza Nido de Águilas	Declamando su poema "Así es mi pueblo", ganador del concurso literario. Semana Barnecheina	Yolanda Cáceres Concha	1984	1980	Pueblo de Lo Barnechea	Marzo 1984. Plaza Nido de Águilas	3	Yolanda Cáceres	Procultura	2025-10-15 17:35:01.257	2025-10-15 17:35:01.257
cmgs9u7ta00ujh9i6usf8tv6w	Pareja Bailando	Pareja Bailando	Pareja bailando en la velada del teatro Parroquial	Ahí se hacían malones bailables	Ester Cortés Jelvez y Ramón Meza Pinto	hacia 1956	1950	Población Nebraska	Circa 1956. Velada del teatro Parroquial, en que hacían malones bailables	3	Familia Meza Cortés	Procultura	2025-10-15 17:35:06.766	2025-10-15 17:35:06.766
cmgs9u9eb00uqh9i6m7t82iwp	Asado	Asado	Asado en El Arrayán		Familia meza Cortés			El Arrayán	Fecha desconocida. El Arrayan	3	Familia Meza Cortés	Procultura	2025-10-15 17:35:08.82	2025-10-15 17:35:08.82
cmgs9ubxp00v4h9i62srn25lo	Huasos y familia de niñas	Huasos y familia de niñas	Huasos y familia de niñas frente a las salas de la Parroquia	Posiblemente Fiesta de Santa Rosa.	Andrea Meza, Ivonne Becker, Margarita Cortes, Rosa Ester Cortes, adelante Ester Meza.	hacia 1967	1960	Pueblo de Lo Barnechea	Circa 1967. Frente a las salas de la parroquia. Posiblemente Fiesta de Santa Rosa.	3	Familia Meza Cortés	Procultura	2025-10-15 17:35:12.108	2025-10-15 17:35:12.108
cmgs9uesy00vih9i6lshaz4hx	Hombre agachado con pelota	Hombre agachado con pelota	Jugador de fútbol con pelota en la cancha de club		Ramón Meza Pinto	hacia 1960	1960	Pueblo de Lo Barnechea	Circa 1960. Cancha de club barnechea	3	Familia Meza Cortés	Procultura	2025-10-15 17:35:15.826	2025-10-15 17:35:15.826
cmgs9ukn200wah9i6hnq8r9rd	Equipo Juventud Catolica frente a arco	Equipo Juventud Catolica frente a arco	Equipo Juventud Católica frente al arco en Barnechea		Osvaldo Tapia, Ramón Meza, Freddy Querol, Manuel Araya, Humberto Silva, Florentino Valencia, David Araya. Abajo: Alberto Labbé, Ricardo Maira, Fernando Herrera, Domingo Araya, Ramiro Araya. 	1957	1950	Pueblo de Lo Barnechea	27/5/1957.. Barnechea	3	Familia Meza Cortés	Procultura	2025-10-15 17:35:23.39	2025-10-15 17:35:23.39
cmgs9v1c100xgh9i605s06l15	Jinetes frente a ovejas que pastan	Jinetes frente a ovejas que pastan	Jinetes frente a ovejas que pastan en Fundo Potrero Grande		Alberto Sotta, atravesado.	1960-1970	1960	Farellones	Década de 1960. Fundo Potrero Grande. Animales están pastando, plena temporada.	3	Alfonso Campos	Procultura	2025-10-15 17:35:45.025	2025-10-15 17:35:45.025
cmgs9v7kn00y1h9i6r11ekh7s	Jóvenes disfrazados	Jóvenes disfrazados	Jóvenes disfrazados en la Escuela pública 177		Edith Quiroz y Juan Valdivia	hacia 1964	1960	Pueblo de Lo Barnechea	ML. circa 1964. Colegio público 177	3	Familia Quiroz Mendoza	Procultura	2025-10-15 17:35:53.112	2025-10-15 17:35:53.112
cmgs9vbe300yfh9i67h1fiyqf	Mujer con niña de la mano	Mujer con niña de la mano	Mujer con niña de la mano en Av. Lo Barnechea		Edith Quiroz y sobrina Carolina Martínez	1980-1990	1980	Pueblo de Lo Barnechea	Década de 1980. Calle Barnechea	3	Familia Quiroz Mendoza	Procultura	2025-10-15 17:35:58.059	2025-10-15 17:35:58.059
cmgs9vesp00z0h9i6e5xnsgdj	Grupo familiar sentado en el pasto	Grupo familiar sentado en el pasto	Grupo familiar sentado en el pasto					Pueblo de Lo Barnechea	ML. . Pueblo de Lo Barnechea	3	Juan Carlos Salas	Procultura	2025-10-15 17:36:02.473	2025-10-15 17:36:02.473
cmgs9vgcb00z7h9i6cpx7jg1m	Arpista	Arpista	Arpista en la calle Lastra		Jorge Guerra	1961	1960	Pueblo de Lo Barnechea	Noviembre 1961. Calle Lastra	3	Jorge Guerra	Procultura	2025-10-15 17:36:04.476	2025-10-15 17:36:04.476
cmgs9vj1a00zeh9i66fzgz4uw	Cuasimodista junto al caballo	Cuasimodista junto al caballo	Cuasimodista junto a su caballo en las canchas donde se hacía la Misa		Jorge Guerra durante la Misa de Cuasimodo	1970-1980	1970	Pueblo de Lo Barnechea	Subian a la cordillera, tb las mujeres, sentadas de lado, a hacer rodeo de cerro. Década de 1970. Canchas donde se hacía la Misa	3	Jorge Guerra	Procultura	2025-10-15 17:36:07.967	2025-10-15 17:36:07.967
cmgs9vlqi00zlh9i6rbj4jsk1	Huaso en rodeo	Huaso en rodeo	Huaso en rodeo en la medialuna del Far West		Jorge Guerra	1970-1980	1970	San Enrique/La Ermita/Las Condes	Década de 1970. Medialuna del Far West	3	Jorge Guerra	Procultura	2025-10-15 17:36:11.466	2025-10-15 17:36:11.466
cmgs9w3nk0106h9i68rd3dtgi	Dos hombres vigilan rebaños a lo lejos	Dos hombres vigilan rebaños a lo lejos	Dos hombres vigilan rebaños a lo lejos en Majada de Santa Lucía, en el Fundo Potrero Grande		Tomás en primera, atrás Juan.	hacia 1970	1970	Farellones	Circa 1970. Majada de Santa Lucía, fundo Potrero Grande. Ovejas y vacas.	3	Alfonso Campos	Procultura	2025-10-15 17:36:34.687	2025-10-15 17:36:34.687
cmgs9w5xy010kh9i6pwpvetvj	Grupo sentado junto a auto de juguete	Grupo sentado junto a auto de juguete	Grupo junto a auto de juguete		Niño menor: Pedro Juan Garrido Medina, mujer a la derecha su mamá Amelia Rosa Medina Leiva	1962	1960	Pueblo de Lo Barnechea	1962. Pueblo de Lo Barnechea	3	Cristian Garrido	Procultura	2025-10-15 17:36:37.654	2025-10-15 17:36:37.654
cmgs9wciv0115h9i6k8mrrb5p	Niños en tranque	Niños en tranque	Niños en el tranque de La Dehesa		Con flotador, pedro Juan Garrido. Con sus primos	1964	1960	La Dehesa	ML. 1964. Tranque La Dehesa	3	Cristian Garrido	Procultura	2025-10-15 17:36:46.184	2025-10-15 17:36:46.184
cmgsa071n0160h9i6u7z70x7i	Equipo de fútbol junto a dos hombres de civil	Equipo de fútbol junto a dos hombres de civil	Equipo de fútbol junto a dos hombres de civil							3	Rocío Muñoz	Procultura	2025-10-15 17:39:45.69	2025-10-15 17:39:45.69
cmgs9tml500s7h9i6ntbgoq7d	Mujer con bebe	Mujer con bebe	Tractor bulldozer en el camino a La Disputada		Lucia Solis con Andres	hacia 1968	1960	Pueblo de Lo Barnechea	CHEQUEAR. Circa 1968. Casa	3	Ana Matteo Rojas	Procultura	2025-10-15 17:34:39.257	2025-10-15 17:34:39.257
cmgs9tr8x00ssh9i65nh2afri	Grupo de mineros frente a galpón	Grupo de mineros frente a galpón	Grupo de mineros frente a un galpón en la Mina La Disputada	Foto tomada por Ana o su papá. Hubo un rodado de nieve que cayó en el casino de obreros y de empleados de la mina. Murió mucha gente. Ver registros del club Católica		hacia 1957	1950	Farellones	importante. Circa 1957. Mina Disputada	3	Ana Matteo Rojas	Procultura	2025-10-15 17:34:45.298	2025-10-15 17:34:45.298
cmgs9tw8k00tdh9i6zqr170oc	Niño junto a planta y pérgola atrás	Niño junto a planta y pérgola atrás	Niño junto a planta y pérgola en el pueblo de Lo Barnechea		Guillermo Alfredo Orrego Matteo	hacia 1977	1970	Pueblo de Lo Barnechea	Circa 1977. Pueblo de Lo Barnechea	3	Ana Matteo Rojas	Procultura	2025-10-15 17:34:51.765	2025-10-15 17:34:51.765
cmgs9uaaw00uxh9i6u4ut91m5	Mujer y dos hombres en río	Mujer y dos hombres en río	Mujer y dos hombres en el Río Mapocho, cerca del puente de cimbra		Ester Cortes	hacia 1950	1950	San Enrique/La Ermita/Las Condes	"1/1/1950. Río Mapocho, cerca del puente de cimbra	3	Familia Meza Cortés	Procultura	2025-10-15 17:35:09.993	2025-10-15 17:35:09.993
cmgs9v4xb00xuh9i6zwytgxe1	Grupo abrazados	Grupo abrazados	Grupo de jovenes en la entrada de su casa en la población Nebraska		Angelica Quiroz, Ana María Olivares, Cecilia Quiroz, Arturo Zuñiga, Alicia, Edith Quiroz, María Ester Quiroz, Rosario Martínez	1976	1970	Población Nebraska	ML. 1976. Puerta de su casa en Pasaje 1, Nebraska	3	Familia Quiroz Mendoza	Procultura	2025-10-15 17:35:49.679	2025-10-15 17:35:49.679
cmgs9v9zm00y8h9i6lhflaso4	Mujer montando	Mujer montando	Mujer montando a caballo en cerros de La Dehesa	donde hacían competencias de cazar zorros (Lotte competía siempre)	Lotte Lebriesch	1970-1980	1970	La Dehesa	ML. Década de 1970. Cerro La Dehesa, donde hacían competencias de cazar zorros (Lotte competía siempre)	3	Familia Quiroz Mendoza	Procultura	2025-10-15 17:35:56.241	2025-10-15 17:35:56.241
cmgs9vdmo00yth9i61xo0c2zv	Grupo frente a una plaza	Grupo frente a una plaza	Grupo frente a una plaza					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	3	Juan Carlos Salas	Procultura	2025-10-15 17:36:00.961	2025-10-15 17:36:00.961
cmgs9vnw700zzh9i66y1t66n0	Serie hombre a caballo 2	Serie hombre a caballo 2	Hombre a caballo en la calle Lastra		Jorge Guerra	1960	1960	Pueblo de Lo Barnechea	1960. Calla Lastra	3	Jorge Guerra	Procultura	2025-10-15 17:36:14.264	2025-10-15 17:36:14.264
cmgs9w4sb010dh9i6q1ifkctx	Mujer con niño en brazos	Mujer con niño en brazos	Mujer con niño en brazos en Las Mercedes		Pedro Juan Garrido Medina	1960	1960		1960. Las Mercedes	3	Cristian Garrido	Procultura	2025-10-15 17:36:36.155	2025-10-15 17:36:36.155
cmgs9vmyz00zsh9i6sblzpxkp	Cuasimodista galopando a caballo	Cuasimodista galopando a caballo	Cuasimodista galopando a caballo en Av. Barnechea		Jorge Guerra	1969	1960	Pueblo de Lo Barnechea	ML. 21-4-69. Avenida Barnechea	3	Jorge Guerra	Procultura	2025-10-15 17:36:13.067	2025-10-15 17:36:13.067
cmgs9w7o3010rh9i62sqmir4i	Niño con triciclo	Niño con triciclo	Niño con triciclo en el pueblo de Lo Barnechea		Pedro Juan Garrido Medina	1963	1960	Pueblo de Lo Barnechea	1963. Pueblo de Lo Barnechea	3	Cristian Garrido	Procultura	2025-10-15 17:36:39.891	2025-10-15 17:36:39.891
cmgs9wamp010yh9i69sfdhtom	Dos niños actuando	Dos niños actuando	Dos niños actuando en Colegio Parroquial Santa Rosa		a la derecha, Pedro Juan Garrido Medina	1966	1960	Pueblo de Lo Barnechea	24-6-66. Colegio parroquial	3	Cristian Garrido	Procultura	2025-10-15 17:36:43.729	2025-10-15 17:36:43.729
cmgs9wg2h011jh9i6s7fs6xam	Hombre sosteniendo pala	Hombre sosteniendo pala	Primera piedra de la población Nido de Águilas	Hombre sosteniendo una pala	Desconocido	1965	1960	Pueblo de Lo Barnechea	ML. 1965. Primera piedra de la población Nido de Águilas	3	Cristian Garrido	Procultura	2025-10-15 17:36:50.777	2025-10-15 17:36:50.777
cmgs9wdl8011ch9i6korvq745	Niños comiendo en patio de casona	Niños comiendo en patio de casona	Niños comiendo en el patio de casona	Casona ex Municipalidad en San Enrique	Familia Garrido junto a amigos o primos	1962	1960	San Enrique/La Ermita/Las Condes	ML. 1962. Casona ex Municipalidad en San Enrique	3	Cristian Garrido	Procultura	2025-10-15 17:36:47.565	2025-10-15 17:36:47.565
cmgs9wj0u011qh9i6rjo3inos	Grupo elegante en postura de primera piedra	Grupo elegante en postura de primera piedra	Grupo elegante en la Primera piedra de la población Nido de Águilas		Ultimo que se ve entero a la derecha, Juan De Dios Garrido	1965	1960	Pueblo de Lo Barnechea	Su bisabuela muriò a los 125. 1965. Primera piedra de la población Nido de Águilas	3	Cristian Garrido	Procultura	2025-10-15 17:36:54.607	2025-10-15 17:36:54.607
cmgs9wly0011xh9i6vk63erms	Dos cuasimodistas en caballos blancos	Dos cuasimodistas en caballos blancos	Dos cuasimodistas en caballos blancos en Av. Lo Barnechea con Raul Labbé		José "Lelo" Araya, Joaquin Araya. Atrás a la izq del espectador, Juan Pablo Araya	2000	2000	Pueblo de Lo Barnechea	2000. Calle Barnechea con Raul Labbe	3	Familia Araya Meneses	Procultura	2025-10-15 17:36:58.392	2025-10-15 17:36:58.392
cmgs9wnck0124h9i62v26qsk6	Dos hombres con bebé	Dos hombres con bebé	Dos hombres con bebé en una casa en la calle Lastra		Adrian Yañez, Claudia Yañez,  Juan "Pelé" Araya	1976	1970	Pueblo de Lo Barnechea	1976. Casa en calle Lastra	3	Familia Araya Meneses	Procultura	2025-10-15 17:37:00.212	2025-10-15 17:37:00.212
cmgs9wov0012bh9i6cxcqs7do	Grupo de hombres con chupalla	Grupo de hombres con chupalla	Grupo de hombres con chupalla en el rodeo de La Ermita		José Miguel Espinoza, José Santiago, Pepe Morales, Alamiro Dotte, Francisco Dotte, Jorge Bea, Sergio Bustamante, "Tato" Romulo Gomez, Juan Mandujano, Joaquin Mallea. Abajo NN	1970-1980	1970	Farellones	ML. Década 1970. Rodeo en La Ermita	3	Familia Araya Meneses	Procultura	2025-10-15 17:37:02.172	2025-10-15 17:37:02.172
cmgs9wq26012ih9i6sjdv9p5i	Dos hombres con niño	Dos hombres con niño	Dos hombres con niño en una casa en la calle Lastra		Juan Vargas (tío), José "Lelo" Araya, Juan "Pele" Araya	1966	1960	Pueblo de Lo Barnechea	1966. Casa en calle Lastra	3	Familia Araya Meneses	Procultura	2025-10-15 17:37:03.726	2025-10-15 17:37:03.726
cmgs9wu7u012ph9i6fvednj9q	Cargando las mulas y recibiendo las raciones	Cargando las mulas y recibiendo las raciones	Cargando las mulas y recibiendo las raciones en el Fundo Potrero Grande			1960-1970	1960	Farellones	ML. Década de 1960. Fundo Potrero Grande	3	Alfonso Campos	Procultura	2025-10-15 17:37:09.113	2025-10-15 17:37:09.113
cmgs9wvqb012wh9i6ak3ehmvv	Serie hombre a caballo 2	Serie hombre a caballo 2	Hombre a caballo en Quempo, cerca del río Colorado, en la cordillera de Lo Barnechea 		Juan "Pelé" Araya	1975	1970	Farellones	1975. Quempo, cordillera de Lo Barnechea cerca del río Colorado	3	Familia Araya Meneses	Procultura	2025-10-15 17:37:11.076	2025-10-15 17:37:11.076
cmgs9wx4f0133h9i6ge5kkxah	Serie hombre a caballo 3	Serie hombre a caballo 3	Hombre a caballo en Quempo, cerca del río Colorado, en la cordillera de Lo Barnechea 		Juan "Pelé" Araya	1975	1970	Farellones	1975. Quempo, cordillera de Lo Barnechea cerca del río Colorado	3	Familia Araya Meneses	Procultura	2025-10-15 17:37:12.88	2025-10-15 17:37:12.88
cmgs9wynu013ah9i61k92wefw	Serie hombre a caballo 5	Serie hombre a caballo 5	Hombre a caballo en Quempo, cerca del río Colorado, en la cordillera de Lo Barnechea 		Juan "Pelé" Araya	1975	1970	Farellones	1975. Quempo, cordillera de Lo Barnechea cerca del río Colorado	3	Familia Araya Meneses	Procultura	2025-10-15 17:37:14.875	2025-10-15 17:37:14.875
cmgs9x1hs013hh9i6q62cwwsk	Jinete junto a laguna pequeña	Jinete junto a laguna pequeña	Jinete junto a laguna en el Sector Lagunita, cerca del Risco de las Vacas Muertas,  en la cordillera 		Juan "Pele" Araya	1975	1970	Farellones	1975. Sector Lagunita, cerca del Risco de las Vacas Muertas	3	Familia Araya Meneses	Procultura	2025-10-15 17:37:18.545	2025-10-15 17:37:18.545
cmgs9x3hf013oh9i6brebn226	Adulto y niño con poncho a caballo	Adulto y niño con poncho a caballo	Adulto y niño con poncho a caballo en la cordillera		Juan "Pelé" Araya y Joaquín Araya	2001	2000	Farellones	2001. Pueblo de Lo Barnechea	3	Familia Araya Meneses	Procultura	2025-10-15 17:37:21.124	2025-10-15 17:37:21.124
cmgs9x4rt013vh9i63a2l19sm	Cuasimodista en bicicleta	Cuasimodista en bicicleta	Cuasimodista en bicicleta			1990-2000	1990	Pueblo de Lo Barnechea		3		Procultura	2025-10-15 17:37:22.794	2025-10-15 17:37:22.794
cmgs9x66b0142h9i6c0xo3vzj	Niño a caballo en la cordillera	Niño a caballo en la cordillera	Niño a caballo en la cordillera			1990-2000	1990	El Arrayán		3		Procultura	2025-10-15 17:37:24.61	2025-10-15 17:37:24.61
cmgs9xamz0149h9i6hlx4bxsd	Recibiendo las raciones	Recibiendo las raciones	Recibiendo las raciones en Sector Ojo de Agua, en el fundo Potrero Grande			1960-1970	1960	Farellones	Década de 1960. Sector Ojo de Agua, fundo Potrero Grande	3	Alfonso Campos	Procultura	2025-10-15 17:37:30.396	2025-10-15 17:37:30.396
cmgs9xdbq014gh9i6ok43qacu	Sacerdote entrega la comunión a adulta mayor durante la Fiesta de Cuasimodo	Sacerdote entrega la comunión a adulta mayor durante la Fiesta de Cuasimodo	Sacerdote entrega la comunión a adulta mayor durante la Fiesta de Cuasimodo			2000-2010	2000	Pueblo de Lo Barnechea		3		Procultura	2025-10-15 17:37:33.879	2025-10-15 17:37:33.879
cmgs9xi28014nh9i68khsbx9t	Cargamento de las mulas	Cargamento de las mulas	Cargamento de las mulas en El Toyo, La Ermita			1981	1980	Farellones	Año 81. El Toyo, La Ermita	3	Alfonso Campos	Procultura	2025-10-15 17:37:40.016	2025-10-15 17:37:40.016
cmgs9xym6014uh9i6nc1d627w	Grupo subiendo a la cordillera	Grupo subiendo a la cordillera	Grupo subiendo a la cordillera en el Fundo Potrero Grande		De chaqueta azul, Tomás Campos. Con parka celeste, Alfonso Campos. De blanco su tío Ricardo Hangermeyer. Rolando Mandujano, cocinero, de pie al medio. A la izquierda quizás Juan.	1985	1980	Farellones	Fundo Potrero Grande. A la subida (llevan mula cargada con los monos). Puntito blanco al fondo es el refugio del ojo de agua.	3	Alfonso Campos	Procultura	2025-10-15 17:38:01.469	2025-10-15 17:38:01.469
cmgs9y6pl0151h9i60ibwhh7a	Limpieza de los caballos	Limpieza de los caballos	Limpieza de los caballos en el Fundo Potrero Grande		Froilán Mandujano, y Alfonso Campos,	1985	1980	Farellones	Fundo Potrero Grande. Al volver en la tarde se bañaba y escobillaba a los caballos antes de soltarlos. Estaban arriba, al final del día de trabajo.	3	Alfonso Campos	Procultura	2025-10-15 17:38:11.962	2025-10-15 17:38:11.962
cmgs9ybhb0158h9i6za9jiul5	Bajando del cerro	Bajando del cerro	Bajando del cerro en el Fundo Potrero Grande		Ricardo Hangermeyer, Alfonso Campos, Juan Mandujano	1985	1980	Farellones	ML. . Fundo Potrero Grande. Bajando a sector Las Tinajas. Quebrada grande que da al río, cajón del río Molina, afluente del Mapocho. Cerros al otro lado es donde hoy está valle Nevado.	3	Alfonso Campos	Procultura	2025-10-15 17:38:18.143	2025-10-15 17:38:18.143
cmgs9yr02015fh9i6jcan8b47	Jinete vadeando laguna	Jinete vadeando laguna	Jinete vadeando laguna en Sector Morro Redondo, Fundo Potrero Grande		Tomás Campos	1985	1980	Farellones	Sector Morro Redondo, Fundo Potrero Grande	3	Alfonso Campos	Procultura	2025-10-15 17:38:38.257	2025-10-15 17:38:38.257
cmgs9z7tj015mh9i632acse7o	Jinetes vadeando laguna	Jinetes vadeando laguna	Jinete vadeando laguna en Sector Morro Redondo, Fundo Potrero Grande		Tomás y Alfonso Campos  /caballo El Barquillo	1985	1980	Farellones		3	Alfonso Campos	Procultura	2025-10-15 17:39:00.033	2025-10-15 17:39:00.033
cmgs9zngx015th9i6ne38yxxx	Grupo junto a laguna	Grupo junto a laguna	Grupo junto a laguna en Sector Morro Redondo, Fundo Potrero Grande			1985	1980	Farellones	Sector Morro Redondo, Fundo Potrero Grande	3	Alfonso Campos	Procultura	2025-10-15 17:39:20.335	2025-10-15 17:39:20.335
cmgsa0wxp016lh9i66nxtsp2q	Niño con chupalla	Niño con chupalla	Niño con chupalla							3	Rocío Muñoz	Procultura	2025-10-15 17:40:19.261	2025-10-15 17:40:19.261
cmgsa15950176h9i67o91o864	Cuasimodo a caballo girando una esquina	Cuasimodo a caballo girando una esquina	Cuasimodo a caballo girando la esquina al frente de la Parroquia	esq Raul Labbe con Barnechea				Pueblo de Lo Barnechea		3	Rocío Muñoz	Procultura	2025-10-15 17:40:30.041	2025-10-15 17:40:30.041
cmgsa1do1017rh9i6sf9ykm9j	Bicicletas en Cuasimodo	Bicicletas en Cuasimodo	Bicicletas en Cuasimodo frente a la Parroquia 	esq Raul Labbe con Barnechea				Pueblo de Lo Barnechea		3	Rocío Muñoz	Procultura	2025-10-15 17:40:40.946	2025-10-15 17:40:40.946
cmgsa1nde018jh9i6qbkzpdwm	Equipo de camiseta rayada	Equipo de camiseta rayada	Equipo de fútbol	camiseta del portero dice "transportas las condes"						3	Rocío Muñoz	Procultura	2025-10-15 17:40:53.522	2025-10-15 17:40:53.522
cmgsa1uhh0194h9i6zbtcf73o	Desfile escolar de frente	Desfile escolar de frente	Desfile escolar en las canchas antiguas de Barnechea 	Seguramente Desfile de Cuasimodo o para el 12 de octubre	Banda colegio Estados Americanos			Pueblo de Lo Barnechea	Canchas antiguas de Barnechea 	3	Rocío Muñoz	Procultura	2025-10-15 17:41:02.741	2025-10-15 17:41:02.741
cmgsa1z84019ih9i6ht4l2nfh	Foto de curso Saint Rose School 4th Junior A 1989	Foto de curso Saint Rose School 4th Junior A 1989	Foto de curso Saint Rose School	 4th Junior A 1989 en Pueblo de Lo Barnechea		1989	1980	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	3	Rocío Muñoz	Procultura	2025-10-15 17:41:08.884	2025-10-15 17:41:08.884
cmgsa29c901aah9i6qgegh2ox	Asistentes a reunion CD Lo Barnechea	Asistentes a reunion CD Lo Barnechea	Asistentes a reunion del CD Lo Barnechea							3	Rocío Muñoz	Procultura	2025-10-15 17:41:21.993	2025-10-15 17:41:21.993
cmgsa2n5y01b9h9i6lget8u7b	Bandera Colodya lo Barnechea Escuela de Fútbol	Bandera Colodya lo Barnechea Escuela de Fútbol	Bandera de "Colodya lo Barnechea - Escuela de Fútbol"							3	Rocío Muñoz	Procultura	2025-10-15 17:41:39.91	2025-10-15 17:41:39.91
cmgsa3hul01cfh9i6lpl7j260	Hombre recibiendo diploma	Hombre recibiendo diploma	Hombre recibiendo un diploma		Renato Mesa, José Salcedo	hacia 1965	1960	Pueblo de Lo Barnechea	Circa 1956. Pueblo de Lo Barnechea	3	Eliseo Villarroel	Procultura	2025-10-15 17:42:19.677	2025-10-15 17:42:19.677
cmgsa3ooi01d0h9i6xkaw9sk6	Equipo infantil frente a arco	Equipo infantil frente a arco	Equipo infantil de fútbol					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	3	Eliseo Villarroel	Procultura	2025-10-15 17:42:28.531	2025-10-15 17:42:28.531
cmgsa49em01deh9i6wftbd1gr	Equipo frente a graderías de piedra	Equipo frente a graderías de piedra	Equipo de fútbol frente a las graderías de piedra		Ramón Orellana, Luis Meza, Humberto Figueroa "charrasqueado", Carlos Legal, Arquero Hernan Veliz, Moraga, Lucho Ortiz, de corbata Ricardo "Micheli" Salazar. Abajo Victor Conejera, Efrain Bravo "Pitilla", Juan Huerta, Luis Villanueva, Héctor "Bototo" Carreño	hacia 1960	1960	Pueblo de Lo Barnechea	“Año 60”. Pueblo de Lo Barnechea	3	Eliseo Villarroel	Procultura	2025-10-15 17:42:55.391	2025-10-15 17:42:55.391
cmgsa4chq01dsh9i6b9ka3h7k	Equipo de rojo	Equipo de rojo	Equipo de rojo, club Álvarez	 Eran de la calle Álvarez, tenían su equipo de la calle, pero no jugaban en la asociación.	Club Álvarez. Arriba: Charolito, nn, nn, Cortisona, Pato Alvarez, Alvarez, Charol chico, Alvarez. 	hacia 1968	1960	Pueblo de Lo Barnechea	El 70 empastaron cancha de Barnechea. Circa 1968. Eran de la calle Álvarez, tenían su equipo de la calle, pero no jugaban en la asociación. 	3	Eliseo Villarroel	Procultura	2025-10-15 17:42:59.391	2025-10-15 17:42:59.391
cmgsa4fle01e6h9i6lpg35ocy	Hombre posando con pelota	Hombre posando con pelota	Jugadores del club posando con una pelota	“Jugadores primer equipo”. Papel postacard	Chico Cotón, Pitilla Bravo, Julio Soto, atrás Renato Meza, Luis Villanueva.	hacia 1960	1960	Pueblo de Lo Barnechea	ML (son jugadores emblemáticos). Cancha Barnechea	3	Eliseo Villarroel	Procultura	2025-10-15 17:43:03.411	2025-10-15 17:43:03.411
cmgsa4mkq01eyh9i6k4kvjbuo	Equipo infantil	Equipo infantil	Equipo infantil en Pueblo de Lo Barnechea		Infantil de Barnechea	hacia 1980	1980	Pueblo de Lo Barnechea	Circa 1980. Pueblo de Lo Barnechea	3	Eliseo Villarroel	Procultura	2025-10-15 17:43:12.459	2025-10-15 17:43:12.459
cmgsa4uxr01fjh9i6ydtsarea	Grupo frente a arco de fútbol	Grupo frente a arco de fútbol	Grupo frente a arco de fútbol en las canchas del club	Presentación de la Asociación Las Condes	Al centro tras la bandera chilena, Digna Cruz (directora), con el botiquín “el masajista” Jere Gálvez, niño doblado con la pelota Juan Huerta; a su derecha Enrique Ortiz, profesora con sombrerito Gladys Moya, a su derecha Eugenia Moya (de blanco). Extremo derecho señora Teresa Soto.	1957	1950	Pueblo de Lo Barnechea	“1957”. Canchas del Club	3	Eliseo Villarroel	Procultura	2025-10-15 17:43:23.295	2025-10-15 17:43:23.295
cmgsa5hcf01g4h9i66idyj2ea	Equipo	Equipo	Equipo de fútbol en las canchas del Club	“Raúl Meza, U Figueroa, A Democo/ E. Meca, L. Oliva, H. Toledo / J. Soto, V. Conejero, A. Pino / A. Meneses, J. Guerta	Raúl Meza, Luis “Neno” Meza, “Charrasqueado” Figueroa, “cuchara”, Alberto Donoso, Héctor “Bototo” Toledo. Abajo: Julio Soto, Víctor Conejera, Antonio “Cotón” Pino, Alberto “Chico” Meneses, Juan Huerta	hacia 1960	1960	Pueblo de Lo Barnechea	ML (porque tenemos todos los nombres). Circa 1960. Canchas del Club	3	Eliseo Villarroel	Procultura	2025-10-15 17:43:52.335	2025-10-15 17:43:52.335
cmgsa0ztq016sh9i6u3ziltkw	Ciclista en Cuasimodo	Ciclista en Cuasimodo	Ciclista en Cuasimodo							3	Rocío Muñoz	Procultura	2025-10-15 17:40:23.006	2025-10-15 17:40:23.006
cmgsa12jf016zh9i622kimfio	Tres ciclistas en cuasimodo	Tres ciclistas en cuasimodo	Ciclistas en Cuasimodo			1990-2000	1990			3	Rocío Muñoz	Procultura	2025-10-15 17:40:26.523	2025-10-15 17:40:26.523
cmgsa1ayc017kh9i64a5c79uv	Bicicletas en medialuna	Bicicletas en medialuna	Bicicletas en la medialuna durante Cuasimodo					Cerro 18	Cerro 18	3	Rocío Muñoz	Procultura	2025-10-15 17:40:37.428	2025-10-15 17:40:37.428
cmgsa1gel017yh9i6tp2a4rpe	Auto rojo en Cuasimodo	Auto rojo en Cuasimodo	Auto rojo en Cuasimodo	esq Raul Labbe con Barnechea				Pueblo de Lo Barnechea		3	Rocío Muñoz	Procultura	2025-10-15 17:40:44.494	2025-10-15 17:40:44.494
cmgsa1lsi018ch9i6cgj56kwm	Coche de caballos llevando al sacerdote	Coche de caballos llevando al sacerdote	Coche de caballos llevando al sacerdote en Cuasimodo	medialuna				Cerro 18		3	Rocío Muñoz	Procultura	2025-10-15 17:40:51.475	2025-10-15 17:40:51.475
cmgsa1x8j019bh9i6v946qr44	Cuasimodistas con banderas subiendo al cerro 18	Cuasimodistas con banderas subiendo al cerro 18	Cuasimodistas con banderas subiendo al cerro 18  	A las 12 se celebraba misa en la medialuna 				Cerro 18		3	Rocío Muñoz	Procultura	2025-10-15 17:41:06.307	2025-10-15 17:41:06.307
cmgsa217r019ph9i6e5yruq7j	Foto de curso Saint Rose School 3rd Junior	Foto de curso Saint Rose School 3rd Junior	Foto de curso Saint Rose School	 3rd Junior en Pueblo de Lo Barnechea		1989	1980	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	3	Rocío Muñoz	Procultura	2025-10-15 17:41:11.463	2025-10-15 17:41:11.463
cmgsa241x019wh9i6djgf4ngf	Equipo rojo y negro celebrando	Equipo rojo y negro celebrando	Equipo celebrando	equipo rojo y negro						3	Rocío Muñoz	Procultura	2025-10-15 17:41:15.142	2025-10-15 17:41:15.142
cmgsa387301buh9i6vat7u1mv	Equipo de fútbol con pelota	Equipo de fútbol con pelota	Equipo de fútbol con pelota	Equipo de cobradores y choferes de la línea Mapocho-Las Condes. Pero engañaban, les hacían contrato pero nunca habían sido cobradores. Una vez ganaron en todo santiago. Algunos de los mejores jugadores de Barnechea iban en la semana  a jugar en ese equipo, porque les daban comida y trago después. 	4to Pedro Contreras (su hijo estuvo en la selección chilena, Jorge Contreras), Luchín Gana. Abajo Chico Cotón, Efrain Bravo Pitilla, Juan Silva, Chico Freddy, Juan Guerrero.	hacia 1965	1960	San Enrique/La Ermita/Las Condes	Porque el club se puede terminar, pero estando eso, no. La gente que juega a la rayuela o algo puede entrar y hacer sus reuniones entrando por atrás, si un club de adulto mayor quiere hacer una reunión, le prestamos la parte de adelante. Que en la esquina, donde hay puros curaos, que se cierre y el fin de semana se pueda hacer una exposicion, se instalen los anticuarios de la plaza. . Circa 1965. Equipo de cobradores y choferes de la línea Mapocho-Las Condes	3	Eliseo Villarroel	Procultura	2025-10-15 17:42:07.168	2025-10-15 17:42:07.168
cmgsa3kks01cmh9i6u9da9rxm	Desfile con bandera de Estados Unidos	Desfile con bandera de Estados Unidos	Desfile con bandera de EE.UU en la cancha de Barnechea, en una conmemoriación tras la muerte de Kennedy	A la izquierda la bandera del equipo Juventud Católica		1963	1960	Pueblo de Lo Barnechea	Canchas de Barnechea, A la izquierda la bandera del equipo Juventud Católica	3	Eliseo Villarroel	Procultura	2025-10-15 17:42:23.212	2025-10-15 17:42:23.212
cmgsa3nlj01cth9i6qg8tcc4x	Equipo de fútbol	Equipo de fútbol	Equipo de fútbol		Yuli, Carlos Moya, Sabando, Gato Sabando, Sergio Aravena "Cuchepo", Bernardo Sabando,. Abajo Ramón Silva, nn, Eliseo Villarroel, Roberto Gonzalez, nn	hacia 1970	1970	Pueblo de Lo Barnechea	Circa 1970. Pueblo de Lo Barnechea	3	Eliseo Villarroel	Procultura	2025-10-15 17:42:27.127	2025-10-15 17:42:27.127
cmgsa4b1901dlh9i6deyshhs9	Equipo de fútbol	Equipo de fútbol	Equipo de fútbol 	Papel Postcard	Equipo externo			Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	3	Eliseo Villarroel	Procultura	2025-10-15 17:42:57.501	2025-10-15 17:42:57.501
cmgsa4l3801erh9i66mngaxrt	Equipo en camarín	Equipo en camarín	Equipo en camarín en Pueblo de Lo Barnechea		Mismos que anterior	hacia 1980	1980	Pueblo de Lo Barnechea	Circa 1980. Pueblo de Lo Barnechea	3	Eliseo Villarroel	Procultura	2025-10-15 17:43:10.532	2025-10-15 17:43:10.532
cmgsa4xmz01fqh9i6we2gpyhk	Jóvenes desfilando con pelota	Jóvenes desfilando con pelota	Jóvenes desfilando con pelota en la cancha de Barnechea	“Club D. Sindical” “Sindical #2” “”E. Figarro” Presentación.	Club deportivo sindical (“Areneros de Vitacura”)	hacia 1940	1940	Pueblo de Lo Barnechea	Circa 1940, no está el colegio. Cancha de Barnechea	3	Eliseo Villarroel	Procultura	2025-10-15 17:43:26.795	2025-10-15 17:43:26.795
cmgsa5k8r01gbh9i62o3a2p1f	Joven entregando espuela a huaso	Joven entregando espuela a huaso	Premio al Huaso Mejor Montado en la fiesta de Cuasimodo, en las Cuatro Canchas		Lorenzo Montengro	1980-1990	1980	Pueblo de Lo Barnechea	Premio Huaso Mejor Montado. Década 1980. Cuatro Canchas, fiesta de Cuasimodo	3	Lorenzo Montenegro	Procultura	2025-10-15 17:43:56.091	2025-10-15 17:43:56.091
cmgsa1827017dh9i6bd6dyvuy	Caballos en Cuasimodo	Caballos en Cuasimodo	Caballos en Cuasimodo	esq Raul Labbe con Barnechea				Pueblo de Lo Barnechea		3	Rocío Muñoz	Procultura	2025-10-15 17:40:33.679	2025-10-15 17:40:33.679
cmgsa1j350185h9i6a308feed	Auto cuasimodista con Crucifijo	Auto cuasimodista con Crucifijo	Auto decorado con crucifijo en Cuasimodo	esq Raul Labbe con Barnechea				Pueblo de Lo Barnechea		3	Rocío Muñoz	Procultura	2025-10-15 17:40:47.968	2025-10-15 17:40:47.968
cmgsa1oyx018qh9i69dz9vwpb	Arbitros y capitanes	Arbitros y capitanes	Arbitros y capitanes							3	Rocío Muñoz	Procultura	2025-10-15 17:40:55.593	2025-10-15 17:40:55.593
cmgsa1rv8018xh9i630j99jul	Huasos alineados en medialuna	Huasos alineados en medialuna	Huasos alineados en la medialuna			hacia 2005	2000	Cerro 18	Circa 2005. Medialuna Cerro 18	3	Rocío Muñoz	Procultura	2025-10-15 17:40:59.348	2025-10-15 17:40:59.348
cmgsa26rs01a3h9i6d49clqg5	Equipo de amarillo	Equipo de amarillo	Equipo de fútbol	CD Barnechea ?						3	Rocío Muñoz	Procultura	2025-10-15 17:41:18.664	2025-10-15 17:41:18.664
cmgsa2c2j01ahh9i69j8i6q3n	Grupo de personas disparando a la orilla del río	Grupo de personas disparando a la orilla del río	Grupo de personas disparando a la orilla del río Mapocho		Club de pesca y caza					3	Rocío Muñoz	Procultura	2025-10-15 17:41:25.532	2025-10-15 17:41:25.532
cmgsa2eto01aoh9i6asiad19e	Jinetes en Cuasimodo	Jinetes en Cuasimodo	Jinetes en Cuasimodo							3	Rocío Muñoz	Procultura	2025-10-15 17:41:29.1	2025-10-15 17:41:29.1
cmgsa2hr901avh9i61rcesh88	Paisaje de cerro	Paisaje de cerro	Paisaje de cerros de la precordillera							3	Rocío Muñoz	Procultura	2025-10-15 17:41:32.901	2025-10-15 17:41:32.901
cmgsa2kh201b2h9i6tw6w1gui	Foto de equipo celeste y blanco	Foto de equipo celeste y blanco	Foto de equipo de fútbol	club juventud catolica?						3	Rocío Muñoz	Procultura	2025-10-15 17:41:36.423	2025-10-15 17:41:36.423
cmgsa2py101bgh9i6niap5nee	Partido fútbol CDLB	Partido fútbol CDLB	Partido fútbol CD Lo Barnechea en las canchas debajo de la Iglesia					Pueblo de Lo Barnechea		3	Rocío Muñoz	Procultura	2025-10-15 17:41:43.514	2025-10-15 17:41:43.514
cmgsa35et01bnh9i6nd5adf39	Equipo de fútbol	Equipo de fútbol	Equipo de fútbol en la cancha de Barnechea		Eugenio Fuentes (presidente del Club), Jaime Alvarez, "Zorro", Lindor Alvarez, Rene Alvarez Guayaca, Lucho Novoa (arquero), Goyito Bravo. Abajo: Clavo Molina, Crespo Humberto Dotte, Floro Valencia, Orlando Pelao Alvarez, Pollo Martínez	hacia 1940	1940	Pueblo de Lo Barnechea	Don Cheo quiere que la sede del club, casa más antigua de la comuna, sea un museo, tener tele, cafeteras, sofa par ver peliculas antiguas, tomar café gratis, que los niños del colegio salgan y pasen a ver las fotos y conversen con sus abuelos… y el que atiende, que lo pague anglo, o que pongan lo que quieran. y que al que le pregunten, sepa la historia, un profesor de historia, algo así que le paguen. . Cancha de Barnechea	3	Eliseo Villarroel	Procultura	2025-10-15 17:42:03.555	2025-10-15 17:42:03.555
cmgsa3b6z01c1h9i6eq0u34om	Brindis de pie	Brindis de pie	Brindis de pie			hacia 1965	1960	Pueblo de Lo Barnechea	Circa 1956. Pueblo de Lo Barnechea	3	Eliseo Villarroel	Procultura	2025-10-15 17:42:11.051	2025-10-15 17:42:11.051
cmgsa3ecm01c8h9i6ib5l2jcd	Hombre hablando desde un podio	Hombre hablando desde un podio	Hombre hablando desde un podio		Renato Mesa, presidente	hacia 1965	1960	Pueblo de Lo Barnechea	Circa 1956. Pueblo de Lo Barnechea	3	Eliseo Villarroel	Procultura	2025-10-15 17:42:15.143	2025-10-15 17:42:15.143
cmgsa46tu01d7h9i6yyzb8rgp	Desfile	Desfile	Presentacion de la Asociación Las Condes, en la cancha de Barnecha	Fotografía antigua digitalizada. Parece que todavía no estaban las mujeres del club.	Orlando Garrido, Digna Cruz, Eugenio Fuentes,. Entre ellos atrás, Julio bello. De traje claro Enrique Campos, de oscuro Eliseo Villarroel. 	hacia 1965	1960	Pueblo de Lo Barnechea	Circa 1965. Presentacion de la asociacion Las Condes, en la cancha de Barnecha. Parece que todavía no estaban las mujeres del club. 	3	Eliseo Villarroel	Procultura	2025-10-15 17:42:52.049	2025-10-15 17:42:52.049
cmgsa4e3f01dzh9i6twywnvsy	Grupo de hombres	Grupo de hombres	Grupo de hombres en aniversario o campeonato de rayuela		Galvez, Chemilico Araya, Silva, Bellito, nn, Rusio Arancibia. Abajo a la der, Moroc, Lucho Bahamondes, Manuel Araya, Pascualito, Abajo Alberto Mendez, Papelito y Pichihuechi. 			Pueblo de Lo Barnechea	Algun aniversario o campeonato de rayuela. 	3	Eliseo Villarroel	Procultura	2025-10-15 17:43:01.468	2025-10-15 17:43:01.468
cmgsa4hch01edh9i64yxzd3rq	Equipo y joven con botiquin	Equipo y joven con botiquin	Equipo y joven con botiquín en la cancha de Lo Barnechea		Oscar Molina, Papelito, Juan Sanhueza, Bahamondes, Bello, León, Luciano. Abajo: Alberto Mendez, Hugo Aracena, Mendez, Eliseo Villarroel, Correcaminos	hacia 1968	1960	Pueblo de Lo Barnechea	Circa 1968. Cancha Barnechea	3	Eliseo Villarroel	Procultura	2025-10-15 17:43:05.681	2025-10-15 17:43:05.681
cmgsa4j6001ekh9i6v6cikq4x	Vista lateral equipo de futbol	Vista lateral equipo de futbol	Vista lateral equipo de fútbol		Mismos que 361			Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	3	Eliseo Villarroel	Procultura	2025-10-15 17:43:08.039	2025-10-15 17:43:08.039
cmgsa4phm01f5h9i67k29ea4z	Ceremonia club deportivo	Ceremonia club deportivo	Ceremonia del club deportivo en las canchas del Club	arco arreglado en el travesaño superior; rené Arlcaverez alias Guayaca lo rompió de un chute”. “2 puesto Familia Cardenas” Presentación del club.	Familia Cárdenas. A la izq Ruben Cárdenas			Pueblo de Lo Barnechea	“1961”. Canchas del Club (arco arreglado en el travesaño superior; rené Arlcaverez alias Guayaca lo rompió de un chute”	3	Eliseo Villarroel	Procultura	2025-10-15 17:43:16.234	2025-10-15 17:43:16.234
cmgsa4s7q01fch9i601v8uqcx	Grupo de jóvenes en celebración	Grupo de jóvenes en celebración	Jóvenes en celebración en La Cerámica, en un salón atrás de la Iglesia	“Aniversario en la cerámica” “en la parroquia”		1972	1970	Pueblo de Lo Barnechea	La Cerámica, salón atrás de la Iglesia	3	Eliseo Villarroel	Procultura	2025-10-15 17:43:19.766	2025-10-15 17:43:19.766
cmgsa50ij01fxh9i6g5uzct1g	Grupo de hombres posando frente a bandera	Grupo de hombres posando frente a bandera	Grupo de hombres posando frente a bandera en el salón La Cerámica	Salon La cerámica	Dirigentes del Barnechea: Renato Meza (presidente), Sergio Salcedo, Carlos Pacheco, José Salcedo, “Toño” Díaz, “Pelao” Reyes, nn, Pascual Barrera, “Flaco” Onell	hacia 1972	1970	Pueblo de Lo Barnechea	Circa 1972. Pueblo de Lo Barnechea	3	Eliseo Villarroel	Procultura	2025-10-15 17:43:30.523	2025-10-15 17:43:30.523
cmgsa5n2r01gih9i6gl32ay6u	Grupo de cuasimodistas	Grupo de cuasimodistas	Grupo de cuasimodistas		Derecha: Vilma Soza, Luis Soza, Lorenzo Montenegro hijo, Emanuel Riveros, Jorge "Chalo" Gonzalo Montenegro,  Lorenzo Montenegro	hacia 1990	1990	Pueblo de Lo Barnechea	1990 aprox. Pueblo de Lo Barnechea	3	Lorenzo Montenegro	Procultura	2025-10-15 17:43:59.763	2025-10-15 17:43:59.763
cmgsa5oxu01gph9i60i84y5rr	Dos hombres en cementerio	Dos hombres en cementerio	Dos hombres en cementerio	"Paseo al Cementerio" General. Ambos son de Barnechea. La familia Dotte viene de un inmigrante italiano, familia muy numerosa de la comuna.	Pedro Dotte Villar y Umberto Muñoz Dotte (sobrino)	1960	1960	Santiago		3	Familia Muñoz Dotte	Procultura	2025-10-15 17:44:02.178	2025-10-15 17:44:02.178
cmgsa5qjb01gwh9i6l6yof2zb	Niña aprendiendo a  caminar	Niña aprendiendo a  caminar	Niña aprendiendo a caminar en el pasaje Los Patos		Mariela Bravo, con su hermano Juan Bravo y mamá Aurora Vera	1980	1980	Pueblo de Lo Barnechea	1980. Casa en pasaje Los Patos	3	Mariela Bravo	Procultura	2025-10-15 17:44:04.247	2025-10-15 17:44:04.247
cmgsa5s8x01h3h9i6aphaegsc	Entierro de niño	Entierro de niño	Entierro de niño en Cementerio General	Niño Luis Enrique Bravo Vera, murió a los dos meses	De lentes José Vicente Bravo Galvez, Aurora Vera Reyes.  Bernarda Bravo Galvez, Ana Galvez Cornejo, José Vicente Bravo Galvez. AUrora Vera Reyes, Rosa Ester Reyes Miranda, Juan Vera Pino, María Sanhueza Galvez. Atrás a la derecha Soledad Sanhueza Galvez.	1960	1960	Santiago	10 de agosto de 1960, ML. Cementerio General	3	Mariela Bravo	Procultura	2025-10-15 17:44:06.465	2025-10-15 17:44:06.465
cmgsa5tx301hah9i6v07radlo	Tres jóvenes sobre una roca	Tres jóvenes sobre una roca	Tres jóvenes sobre una roca en El Toyo	En la cordillera, donde pasaban las vacaciones acampando.	Hessel Toro Valencia, Victor Toro Valencia, Francisco	1979	1970	Farellones	1979. El Toyo, Cordillera, donde pasaban las vacaciones de verano, a acampar.	3	Mariela Bravo	Procultura	2025-10-15 17:44:08.631	2025-10-15 17:44:08.631
cmgsa5vq801hhh9i6pgjqqm05	Niño a caballo	Niño a caballo	Niño a caballo	14 años	Víctor Araya	1990	1990	Pueblo de Lo Barnechea	Febrero 1990. Juego, en la casa	3	Carlos Araya	Procultura	2025-10-15 17:44:10.976	2025-10-15 17:44:10.976
cmgsa5x8e01hoh9i6jkou2zux	Campamento en el cerro	Campamento en el cerro	Campamento en el cerro	Mismos sectores donde dejaban los animales en la veranada. Iban por una semana o algo así.	Cristina Araya, Alejandro Araya (papá), Carlos Araya	hacia 1988	1980	Farellones	Circa 1988. Paseo a la Cordillera en el verano	3	Carlos Araya	Procultura	2025-10-15 17:44:12.926	2025-10-15 17:44:12.926
cmgsa62q301i9h9i6oishdz1n	Niñas de trenzas junto a su padre	Niñas de trenzas junto a su padre	Niñas de trenzas junto a su padre			hacia 1926	1920		Fotografía antigua digitalizada	3	UNCAF	Procultura	2025-10-15 17:44:20.043	2025-10-15 17:44:20.043
cmgsa654401igh9i6m7vzwr4u	Mujer ordeñando	Mujer ordeñando	Mujer ordeñando una vaca en Raúl Labbé	Esa zona era sembrada por la familia Bustamante Celis	Elisa Bustamante (siempre fue soltera)	hacia 1938	1930	Pueblo de Lo Barnechea	1938 o 1939. Frente a la iglesia, por Raúl Labbé; esa zona era sembrada por la familia Bustamante Celis. Fotografía antigua digitalizada	3	UNCAF	Procultura	2025-10-15 17:44:23.14	2025-10-15 17:44:23.14
cmgsa67hw01inh9i67jwfjfv8	Mejor mamá	Mejor mamá	Premiación a la Mejor Mamá en la Escuela 177, en la Fiesta de la Primavera	Fiesta de la primavera, en octubre. Fue elegida unas 2 veces como la mejor mamá. Tenía 13 hijos y los mandaba limpiecitos, pese a vivir a orillas del río (su marido era arenero). El regalo eran ollas. Su mamá se sentía muy feliz. Ella hacía "lavar ropa ajena" y planchar.  A las familias Ariztía, Guzmán.  	Directora Natalia , Rosa Emilia Solis (de familia de la Dehesa. Su mamá quedó viuda en los años 50, con 5 hijos. Sacaba leche y hacía queso, vendía huevo, cebolla, etc. Rosa venía cuando chica a caballo, de La Dehesa a Barnechea trayendo el queso. Su mamá trabajaba para Bernardo Larraín Cotapos, él les daba casa.)	1961	1960	Pueblo de Lo Barnechea	1961. Escuela Pública de Lo barnechea 177, donde hoy están los mormones. Fotografía antigua digitalizada	3	UNCAF	Procultura	2025-10-15 17:44:26.228	2025-10-15 17:44:26.228
cmgsa69fh01iuh9i63p1yrm7t	Familia junto al caballo	Familia junto al caballo	Familia junto a caballo en un campo de La Dehesa	Campo pertenecia a Bernardo Larraín Cotapos	Al centro María Solis, a la derecha Albino Rivero (marido), arriba Esteban Astudillo (viudo de Margarita Solis), a la izquierda Tránsito Solis (madre de María), niño Juan Astudillo (lo crió su abuelita).	1939	1930	La Dehesa	La Dehesa, campo, donde ellos vivían (pertenecía  Bernardo Larraín Cotapos). Fotografía antigua digitalizada	3	UNCAF	Procultura	2025-10-15 17:44:28.733	2025-10-15 17:44:28.733
cmgsa6bh701j1h9i6m5ldajgs	Tres jornaleros	Tres jornaleros	Jornaleros en el campo donde trabajaban, en la actual calle Raúl Labbé	La casa de campo del ministro Valdés, donde ellos trabajan	Tres integrantes de la familia Celis.	1922	1920	Pueblo de Lo Barnechea	Casa de campo del ministro Valdés, donde ellos trabajan. Actual calle Raúl Labbé.. Fotografía antigua digitalizada	3	UNCAF	Procultura	2025-10-15 17:44:31.388	2025-10-15 17:44:31.388
cmgsa6eyq01j8h9i6w42l624f	Mujer a caballo	Mujer a caballo	Mujer a caballo en casa de La Dehesa, en el sector de piscicultura que pertenecía al Ejército		Francisca Solis Maira (madre de Rosa Emilia, abuela de Brígida)	1944	1940	La Dehesa	Casa de La Dehesa, sector piscicultura, que pertenecía al Ejército.. Fotocopia de foto	3	UNCAF	Procultura	2025-10-15 17:44:35.906	2025-10-15 17:44:35.906
cmgsa6jhp01jmh9i6sgkpxlcx	Dos niñas vestidas de chinas	Dos niñas vestidas de chinas	Dos niñas vestidas de chinas en el pasaje Los Patos	(foto repetida en carpetas LBCH2 y LBCH5)	Hilda Valencia y su tía Rosa Leonor Moya	1956	1950	Pueblo de Lo Barnechea	ML. 15 septiembre 1956. Casa en pasaje Los Patos	3	Yoconda Moya	Procultura	2025-10-15 17:44:41.772	2025-10-15 17:44:41.772
cmgsa5z4601hvh9i6xgnbkxy6	Dos niños a caballo	Dos niños a caballo	Dos niños a caballo	Papá los pasó a buscar a caballo al colegio, el día que se bailaba cueca. "Recuerdo de nuestro jardín"	Carlos Araya, Natividad Paz	1987	1980	Pueblo de Lo Barnechea	Diciembre 1987. Papá los pasó a buscar a caballo al colegio, el día que se bailaba cueca.	3	Carlos Araya	Procultura	2025-10-15 17:44:15.367	2025-10-15 17:44:15.367
cmgsa60qg01i2h9i610tmlyis	Cuasimodista niño frente a crucifijo	Cuasimodista niño frente a crucifijo	Niño cuasimodista frente al Cristo del Arrayán	"Un recuerdo del día de cuasimodo. Edad del niño en esta foto 4, años, 8 meses. (El Cristo)". En la mitad del camino del Cuasimodo. Desde los 4 años ya corrían toda la carrera del Cuasimodo.	Victor Araya	1981	1980	El Arrayán	26 de abril de 1981. Cristo del Arrayán, en la mitad del camino del Cuasimodo. Desde los 4 años ya corrían toda la carrera del Cuasimodo.	3	Carlos Araya	Procultura	2025-10-15 17:44:17.463	2025-10-15 17:44:17.463
cmgsa6gui01jfh9i6bh7rlh6r	Grupo de jinetes tras una reja	Grupo de jinetes tras una reja	Jinetes en el antiguo rodeo en La Dehesa		Tercero de izquierda a derecha, Luis Vera	1960-1970	1960	La Dehesa	Década de 1960. Rodeo en La Dehesa. Fotocopia de foto	3	UNCAF	Procultura	2025-10-15 17:44:38.346	2025-10-15 17:44:38.346
cmgsa6mla01jth9i6ryh1es3y	Familia	Familia	Familia en el pueblo de Lo Barnechea	Papel Postcard. 15 marzo 1942.	Alfonso Valencia, Clara Osorio, Luis Valencia. Abajo niñas.	1942	1940	Pueblo de Lo Barnechea	15 de marzo de 1942. Pueblo de Lo Barnechea	3	Yoconda Moya	Procultura	2025-10-15 17:44:45.773	2025-10-15 17:44:45.773
cmgsa6pwu01k0h9i6njetq68x	Familia con perro al frente	Familia con perro al frente	Familia con perro al frente en campo donde vivían, San José de Maipo	Papel Postcard	Clara Osorio, sentado Valencia, y sus hijos. El niño sentado es Benjamìn Valencia.	1924	1920	Otro	Campo donde vivían, San José de Maipo	3	Yoconda Moya	Procultura	2025-10-15 17:44:50.095	2025-10-15 17:44:50.095
cmgsa6sg701k7h9i61hkha4pm	Grupo de hinchas en bus	Grupo de hinchas en bus	Hinchas en bus cuando iban a ver jugar al CD Barnechea 	“Fotografía Mario Vallejos F.”	A la derecha adelante, Yoconda Moya, atrás Juan Carlos Valencia, extremo derecho Hugo Aracena, a su izquieda de bigote, René. Extremo derecho Eliana Meneses, a su izquierda David Aracena. De blanco con mano levantada Manuel “Mula” Araya. Extremo derecho adelante, Araya, Atras de la niña con ojos tapados, Pedro Valencia. Atrás suyo Jimena y nn Tolorsa Meneses. A la derecha suya			Pueblo de Lo Barnechea	revisar. . Bus cuando iban a ver jugar a Barnechea	3	Yoconda Moya	Procultura	2025-10-15 17:44:53.384	2025-10-15 17:44:53.384
cmgsa6u3901keh9i60o76650h	Equipo Deportivo Barnechea	Equipo Deportivo Barnechea	Equipo del CD Barnechea		Benjamín Valencia, Gregorio Salfate, nn, René Alvarez, Lindor Alvarez, Vicente Bravo. Abajo Carlos Perez, Lindor Alvarez (hermano del otro),  Eduardo Martinez,Pedro Contreras			Pueblo de Lo Barnechea	revisar nombres. . Pueblo de Lo Barnechea	3	Yoconda Moya	Procultura	2025-10-15 17:44:55.509	2025-10-15 17:44:55.509
cmgsa6v3m01klh9i64d9odqw0	Cazadores de conejos desayunando	Cazadores de conejos desayunando	Cazadores de conejos desayunando	Revisar lugar. y año No aparenta ser el Pueblo y fecha debe ser posterior a 1955.	Gorro blanco: Nibaldo Villaseca, “pololito”, a su derecha en la foto,  Vicente Bravo, de espaldas Cheo Villarroel, de rojo Carlos Moya	hacia 1955	1950	Pueblo de Lo Barnechea	1955 circa. Pueblo de Lo Barnechea	3	Yoconda Moya	Procultura	2025-10-15 17:44:56.818	2025-10-15 17:44:56.818
cmgsa6x0a01ksh9i6ingawbgm	Cazadores con sus presas	Cazadores con sus presas	Cazadores de conejos desayunando	Revisar lugar. y año No aparenta ser el Pueblo y fecha debe ser posterior a 1955.				Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	3	Yoconda Moya	Procultura	2025-10-15 17:44:59.29	2025-10-15 17:44:59.29
cmgsa6yxe01kzh9i66kuio2bo	Cazadores almorzando	Cazadores almorzando	Cazadores de conejos desayunando	Revisar lugar. y año No aparenta ser el Pueblo y fecha debe ser posterior a 1955.				Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	3	Yoconda Moya	Procultura	2025-10-15 17:45:01.778	2025-10-15 17:45:01.778
cmgsa70qy01l6h9i6qpy0ga4c	Cazadores frente a bus	Cazadores frente a bus	Cazadores de conejos desayunando	Revisar lugar. y año No aparenta ser el Pueblo y fecha debe ser posterior a 1955.				Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	3	Yoconda Moya	Procultura	2025-10-15 17:45:04.139	2025-10-15 17:45:04.139
cmgsa728o01ldh9i6wypymbtm	Mujeres del Club Barnechea junto a niños	Mujeres del Club Barnechea junto a niños	Mujeres del Club Barnechea junto a niños		Derecha, Juanita Moya. Abajo Paulina Valencia. A su izquierda Juan Carlos Valencia. Arriba  de der a izq Eugenia Moya, Rosa Moya, Carlos Moya . Fuera del grupo, Patricio Villaseca.	1970-1980	1970	Pueblo de Lo Barnechea	Década 1970. Pueblo de Lo Barnechea	3	Yoconda Moya	Procultura	2025-10-15 17:45:06.072	2025-10-15 17:45:06.072
cmgsa750a01lkh9i686ei4k9w	Niño en triciclo	Niño en triciclo	Niño en triciclo		Juan Carlos Valencia Moya	hacia 1959	1950	Pueblo de Lo Barnechea	Circa 1959. Pueblo de Lo Barnechea	3	Yoconda Moya	Procultura	2025-10-15 17:45:09.658	2025-10-15 17:45:09.658
cmgsa77pi01lrh9i6ldppnqzz	Familia afuera de la iglesia	Familia afuera de la iglesia	Familia afuera de la Parroquia Santa Rosa		Extremo derecho Ivan Acevedo, Benjamin Valencia, Clarita Valencia, Mario Acevedo, esposa,. Al centro de blanco Pedro, de chaqueta Carlos Moya. A su izq Luisa Bello, Amanda Chacón (extremo izq)	1974	1970	Pueblo de Lo Barnechea	25 de Diciembre de 1974. Parroquia Santa Rosa	3	Yoconda Moya	Procultura	2025-10-15 17:45:13.159	2025-10-15 17:45:13.159
cmgsa7afn01lyh9i6toh4w3a8	Grupo de niñas vestidas de blanco	Grupo de niñas vestidas de blanco	Grupo de niñas vestidas de blanco	Posiblemente se trata de la Fiesta de la Primavera	Tercera de izq a der Paula Valencia			Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	3	Yoconda Moya	Procultura	2025-10-15 17:45:16.691	2025-10-15 17:45:16.691
cmgsa7ctr01m5h9i6ntz35a1s	Grupo almorzando al interior de una casa	Grupo almorzando al interior de una casa	Grupo almorzando al interior de una casa	Posiblemente se trata de la Fiesta de la Primavera	Lucho ortiz, x Ortiz, Amanda Chacón, Paula Valencia, María de Ortiz, Benjamín Valencia, Lucho, Gladys Moya, Nona Moya. De pie a la der Quena Moya y Pedro.	1971	1970	Pueblo de Lo Barnechea	13 de Marzo de 1971. Pueblo de Lo Barnechea	3	Yoconda Moya	Procultura	2025-10-15 17:45:19.791	2025-10-15 17:45:19.791
cmgsa7fjx01mch9i6dukyl4ev	Adultos y niños celebrando en una mesa	Adultos y niños celebrando en una mesa	Adultos y niños celebrando en una mesa en la Av. Lo Barnechea		Dueño de la casa que era sede, donde antes vivió la directora de la escuela,  está de pie con camisa a cuadros y chaqueta blanca. De pie a la izquierda Benjamin Valencia			Pueblo de Lo Barnechea	Calle Barnechea	3	Yoconda Moya	Procultura	2025-10-15 17:45:23.325	2025-10-15 17:45:23.325
cmgsa7i1h01mjh9i6wcox4bf0	Grupo de mujeres en una comida	Grupo de mujeres en una comida	Grupo de mujeres en una comida en sede del CD Barnechea	Celebración de cumpleaños del Club Barnechea; socias y no socias	A la izq sentada Eugenia Moya, primera parada a la izq Yoconda Moya. 4Ta sentada, Rosa Pino. 5Ta parada Bernardita Barrera.			Pueblo de Lo Barnechea	Sede del club Barnechea	3	Yoconda Moya	Procultura	2025-10-15 17:45:26.549	2025-10-15 17:45:26.549
cmgsa7jat01mqh9i6niuzroek	Sacerdote y acólito en coche de Cuasimodo	Sacerdote y acólito en coche de Cuasimodo	Sacerdote y acólito en coche de Cuasimodo	“Fiesta Huasa”	A la izq Tito (hoy sacerdote), padre Jammey Torney Conductor del carro se llama José Gabriel "Lelo" Araya Astudillo	1980	1980	Pueblo de Lo Barnechea	Abril 1980. Pueblo de Lo Barnechea	3	Yoconda Moya	Procultura	2025-10-15 17:45:28.181	2025-10-15 17:45:28.181
cmgsa7lmu01mxh9i6oruq7qwo	Hombre manejando tractor	Hombre manejando tractor	Hombre manejando un tractor		Patricio Dotte	1970-1980	1970			3	Patricia Dotte	Procultura	2025-10-15 17:45:31.206	2025-10-15 17:45:31.206
cmgsa7mq901n4h9i6sfc94ryl	Familia en el campo	Familia en el campo	Familia en el campo en Pastor Fernández, donde vivían y sembraban		Virginio Dotte, Rosa Alcaíno, Lucerina Dotte y Patricio Dotte.	1953	1950	El Arrayán	1953. Terreno en Pastor Fernández, donde vivían y sembraban	3	Patricia Dotte	Procultura	2025-10-15 17:45:32.625	2025-10-15 17:45:32.625
cmgsa7nlq01nbh9i65ybar6fo	Familia con árbol atrás	Familia con árbol atrás	Familia en El Arrayán		Margarita Dotte? Clara Dotte, Patricio Dotte. Arriba Virginio Dotte, Rosa Alcaíno. Niños abajo Adolfo “Toto” Dotte, Ana María Dotte	1960	1960	El Arrayán	1960. El Arrayán	3	Patricia Dotte	Procultura	2025-10-15 17:45:33.759	2025-10-15 17:45:33.759
cmgsa7qbf01nph9i6cbl9w8gf	Tres amigas	Tres amigas	Tres amigas 	“Recuerdo de una amiga que nunca la olvidaré. Margarita / Elia /Amanda”	Margarita Sagal, Elia Torreblanca,  Amanda Moya	hacia 1970	1970	Pueblo de Lo Barnechea	Circa 1970. Pueblo de Lo Barnechea	3	Familia Soto Torreblanca	Procultura	2025-10-15 17:45:37.276	2025-10-15 17:45:37.276
cmgsa80l101ooh9i6uk4hu5ne	Grupo de señoras frente a casona	Grupo de señoras frente a casona	Grupo de señoras frente a la casona de CEMA Chile en Raúl Labbé	Foto la tomó Zenón	Izq atrás Jessica Baez, Rocio Muñoz. A la izquierda abajo María Inés Soto Flores, tapada por ella, Elsa Pino. De camisa a cuadros Susana Prieto, tomandole los hombros, Olguita Puente. De azul Rosa Molina, a su derecha atrás, Patricia Araya. De negro Dorisa Mazuela. Atrás tocandole el hombro, Clorinda Castillo. De gorro rosado, María Dotte, presidenta. A su derecha atrás, con gorrito Marcela Castillo.  A su izquierda con gorrito Dorisa Mazuel. Al centro de blanco con gorrito, María Yañez. Ultima al centro a la derecha, Bernarda Alvarez. Niños: Alejandra Vasquez, Pablo Herrera, otro niño adelante, Catalina Muñoz. 	hacia 1990	1990	Pueblo de Lo Barnechea	Circa 1990. Casona de CEMA Chile en calle Raúl Labbé	3	Familia Soto Torreblanca	Procultura	2025-10-15 17:45:50.582	2025-10-15 17:45:50.582
cmgsa84s301p9h9i6obhio0bb	Niños bajando al río	Niños bajando al río	Niños bajando al río en El Arrayán	Llevan un pájaro arrastrando	Primos Gutierrez y amigos	1975	1970	El Arrayán	1975. El Arrayán	3	Rodolfo Gutierrez	Procultura	2025-10-15 17:45:56.019	2025-10-15 17:45:56.019
cmgsa8haj01r0h9i6he065ru4	Niños montando caballo	Niños montando caballo	Niños montando caballo en la casa de la familia Gutiérrez	Los caballos se metían libremente a la casa porque el portón quedaba siempre abierto	Felipe, Rafael y Mónica Gutierrez	1978	1970	El Arrayán	Octubre 1978. Casa familia Gutierrez	3	Rodolfo Gutierrez	Procultura	2025-10-15 17:46:12.235	2025-10-15 17:46:12.235
cmgsa8r1x01rsh9i6wiat7o9z	Equipo frente al estadio lleno	Equipo frente al estadio lleno	Equipo frente al estadio lleno en Cancha Barnechea	Villarroel hermanos auspiciaba al equipo, tenían negocios, una carnicería	Victor Tudela,  Rodrigo Acevedo "Rogui", Anselmo Retamal "Fachini", Diego Pezoa,  Sergio Valenzela "Pacharli", Pedro Muñoz, nn,  Rodolfo González "Manguera", Raul Peredo Abajo:  "Puchero" Suazo, Negrete, Christian Adriasola, Gustavo Cortez, Patricio Contreras, nn, Viti Conejeras			Cerro 18	Aprovechar esta foto porque tienen todos los nombres. Cancha Barnechea	3	Eliseo Villarroel	Procultura	2025-10-15 17:46:24.885	2025-10-15 17:46:24.885
cmgsa8wf901s6h9i63rymvwgr	Equipos de Colo colo y Barnechea	Equipos de Colo colo y Barnechea	Equipos de Colo colo y Barnechea en Pueblo de Lo Barnechea	Muy poco después del terremoto de marzo de 1985, partido contra Colocolo, a beneficio de los damnificados de las condes, juntaron 50 mil pesos de la época y los entregaron al alcalde	De blanco, Mario Osben, Alfonso Ñecuñir, Jaime Pizarro, Hugo Gonzalez, Raul Ormeño, Pillo Vera, Severino Vasconcelos, Pititori Cabrera, Carlos Caselli. De Barnechea, Patricio Villarroel (dt), nn, Sergio Valenzuela, “Raton” Galvez,  Rodrigo Acevedo, Moroco Eduardo Figueroa, Luis Alvarez, Manuel Araya, Lindor Alvarez, Cachalo (adelante a la izquierda, moreno). Luis Perez, Eduardo Faundez, Juan Gatica.	1985	1980	Pueblo de Lo Barnechea	importante xq sale colocolo. 1985. Pueblo de Lo Barnechea	3	Patricio Villarroel	Procultura	2025-10-15 17:46:31.845	2025-10-15 17:46:31.845
cmgsa8z8601sdh9i67xb1h266	Barnechea jugando en Pinto Duran con un equipo de la selección chilena	Barnechea jugando en Pinto Duran con un equipo de la selección chilena	Barnechea jugando en Pinto Durán con un equipo de la selección chilena	Camisetas regaladas por familia Madrid, famosos, venden panes, viven en las Lomas. Negocio en los quincheros, “los caballos” , señora antigua que tb le decían Tina	Patricio Villarroel (DT), Raul Perez, Luis Alvarez,Rodrigo Acevedo, Aracena, Eduardo Lara, Jaime Arezavala (jugo en tiempo de pedro Araya, comparte con todos, fue jugador profesional, UC, Everton, Deportes concepción), Sergio Valenzuela, Claudio Contreras. Abajo Cachalo, Luis Perez, Eduardo Figueroa Moroco (trabaja en muni), Patricio Contreras, Lindor Alvarez “Nino”, “Raton” Galvez, Gonzalo Sepulveda.	hacia 1984	1980	Otro	Circa 1984. Otro	3	Patricio Villarroel	Procultura	2025-10-15 17:46:35.478	2025-10-15 17:46:35.478
cmgsa94mr01srh9i6y3o4bbzm	Familia en Pollo Al Cognac	Familia en Pollo Al Cognac	Grupo en el Restaurant "El Pollo al Coñac"	Restaurante internacional, su plato es único	Nancy Muñoz, hija, Eliseo Villarroel, niña Estay, Victor Estay, hijo de Victor Estay, Monica Celsi, señora de Victor Estay, Patricio Villarroel y su hijo patricio.	1985	1980	Pueblo de Lo Barnechea	1985. Pueblo de Lo Barnechea	3	Patricio Villarroel	Procultura	2025-10-15 17:46:42.484	2025-10-15 17:46:42.484
cmgsa98mz01t5h9i652grndt1	Familia frente a ventana	Familia frente a ventana	Familia frente a ventana en Pueblo de Lo Barnechea	María vivía a la orilla del río, debajo de donde está la Querencia. 	Quizás la de chal negro, María Comuna. 			Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	3	Juan Carlos Salas	Procultura	2025-10-15 17:46:47.674	2025-10-15 17:46:47.674
cmgsa9adi01tch9i672porsc1	Equipo de fútbol con camiseta a rayas	Equipo de fútbol con camiseta a rayas	Equipo de fútbol con camiseta a rayas en Sector San Enrique		Club Deportivo Cóndor	1950-1960	1950	San Enrique/La Ermita/Las Condes	Década de 1950. Sector San Enrique, entonces llamado Las Condes. 	3	Juan Carlos Salas	Procultura	2025-10-15 17:46:49.927	2025-10-15 17:46:49.927
cmgsa9e7y01tqh9i6mr6b5m7s	Dos parejas frente a matorrales	Dos parejas frente a matorrales	Dos parejas frente a matorrales en San Enrique		Rosa Eliana Diaz , Juan Salas ,NN, NN	1940-1950	1940	San Enrique/La Ermita/Las Condes	Década de 1940. San Enrique	3	Juan Carlos Salas	Procultura	2025-10-15 17:46:54.911	2025-10-15 17:46:54.911
cmgsa9quw01vhh9i6icx47kn1	Joven con bandera	Joven con bandera	Joven con bandera en Pueblo de Lo Barnechea		Ruben Diaz Lira	1930-1940	1930	Pueblo de Lo Barnechea	Década de 1930. Pueblo de Lo Barnechea	3	Juan Carlos Salas	Procultura	2025-10-15 17:47:11.288	2025-10-15 17:47:11.288
cmgsa9sa801voh9i6gcc9ox72	Grupo elegante en las escaleras de la iglesia	Grupo elegante en las escaleras de la iglesia	Grupo elegante en las escaleras de la iglesia en Pueblo de Lo Barnechea		1ro a la izq Ruben Diaz. 2da desde la der Adriana Encina. Hombre a la sombra de una mujer Luis Diaz, junto a su nieto Patricio Salas Diaz	hacia 1946	1940	Pueblo de Lo Barnechea	Circa 1946. Pueblo de Lo Barnechea	3	Juan Carlos Salas	Procultura	2025-10-15 17:47:13.136	2025-10-15 17:47:13.136
cmgsac6zq0248h9i6p5d580fo	Reina y rey	Reina y rey	Reina y rey en Quinta Las Rosas	Carnaval se hacìa en febrero		1959	1950	Pueblo de Lo Barnechea	1959. Quinta Las Rosas	3	Ana Matteo Rojas	Procultura	2025-10-15 17:49:05.51	2025-10-15 17:49:05.51
cmgsa7p6101nih9i6whpdzpz7	Graduación de preescolar	Graduación de preescolar	Graduación de preescolar en Pueblo de Lo Barnechea		Segunda a la derecha, Corina xx Salcedo	1991	1990	Pueblo de Lo Barnechea	La mamá mató a la niña y luego se mató ella. 1991. Pueblo de Lo Barnechea	3	Yoconda Moya	Procultura	2025-10-15 17:45:35.784	2025-10-15 17:45:35.784
cmgsa7sxb01nwh9i6wyr1n0j5	Grupo entre cultivos	Grupo entre cultivos	Grupo de paseo entre cultivos 		Hombre, Héctor Torreblanca, Inés Soto, Patricio Sosa, esposa	hacia 1955	1950	Pueblo de Lo Barnechea	Circa 1955. Paseo	3	Familia Soto Torreblanca	Procultura	2025-10-15 17:45:40.656	2025-10-15 17:45:40.656
cmgsa7xsf01ohh9i61s7yqxcb	Niña en juegos de plaza	Niña en juegos de plaza	Niña en juegos de plaza en Plaza Nido de Águilas		Macarena Soto	1982	1980	Pueblo de Lo Barnechea	1982. Plaza Nido de Águilas	3	Familia Soto Torreblanca	Procultura	2025-10-15 17:45:46.96	2025-10-15 17:45:46.96
cmgsa86a701pgh9i6ohul24lj	Padre e hijo en un auto	Padre e hijo en un auto	Padre e hijo en un auto en El Arrayán	Auto es un MG	Rodolfo Gutierrez y su hijo Felipe Gutierrez	1975	1970	El Arrayán	1975. El Arrayán	3	Rodolfo Gutierrez	Procultura	2025-10-15 17:45:57.967	2025-10-15 17:45:57.967
cmgsa8e9201qmh9i6auuoitw4	Hermanos con una pelota	Hermanos con una pelota	Hermanos con una pelota en El Arrayán		Rafael Gutierrez, Monica Gutierrez, Felipe Gutierrez	1978	1970	El Arrayán	Octubre 1978. El Arrayán	3	Rodolfo Gutierrez	Procultura	2025-10-15 17:46:08.294	2025-10-15 17:46:08.294
cmgsa8iqg01r7h9i64so8a81g	Familia en un puente	Familia en un puente	Familia en un puente camino a Farellones		Lili Pereira, Rafael Gutierrez, Felipe Gutierrez, Rodolfo Gutierrez	1976	1970	Farellones	Enero 1976. Camino a Farellones	3	Rodolfo Gutierrez	Procultura	2025-10-15 17:46:14.105	2025-10-15 17:46:14.105
cmgsa8o3m01rlh9i6nmtmz85h	Familia con guitarras	Familia con guitarras	Familia con guitarras en la casa de la familia Gutiérrez	Ambos hijos tocan varios instrumentos musicales	Rafael Gutierrez, Liliana Pereira, Rodolfo Gutierrez, Felipe Gutierrez, Mónica Gutiérrez	1987	1980	El Arrayán	1987. Casa familia Gutierrez	3	Rodolfo Gutierrez	Procultura	2025-10-15 17:46:21.059	2025-10-15 17:46:21.059
cmgsa8ts901rzh9i6pn9efta8	4 hombres	4 hombres	4 hombres en Pueblo de Lo Barnechea	Partido clásico, Barnechea vs municipal las condes	De oscuro Truco, el primer alcalde designado por Aylwin (provisorios, mientras se organizaba la elección), el tercero es Patricio Villarroel, técnico del Barnechea	1990	1990	Pueblo de Lo Barnechea	1990. Pueblo de Lo Barnechea	3	Patricio Villarroel	Procultura	2025-10-15 17:46:28.426	2025-10-15 17:46:28.426
cmgsa922e01skh9i611ewlvkf	DT recibiendo premio	DT recibiendo premio	DT recibiendo premio en Auditorio en cancha chica. Semana Barnecheina		Patricio Villarroel y Guillermo Torres (director de Deportes de la munipalidad de las Condes)	hacia 1983	1980	Pueblo de Lo Barnechea	Circa 1983. Auditorio en cancha chica. Semana Barnecheina	3	Patricio Villarroel	Procultura	2025-10-15 17:46:39.159	2025-10-15 17:46:39.159
cmgsa9cax01tjh9i64681p3d2	Tres mujeres y niño frente a una casa	Tres mujeres y niño frente a una casa	Tres mujeres y niño frente a una casa en San Enrique		2da Rosa Eliana Diaz Lira	1950-1960	1950	San Enrique/La Ermita/Las Condes	Década de 1950. San Enrique	3	Juan Carlos Salas	Procultura	2025-10-15 17:46:52.426	2025-10-15 17:46:52.426
cmgsa9f7y01txh9i6r3tul2xu	Dos fubtolistas con paisaje de cerro	Dos fubtolistas con paisaje de cerro	Dos fubtolistas con paisaje de cerro en Pueblo de Lo Barnechea		Futbolistas del equipo Condor, Ruben Diaz Lira, NN	hacia 1955	1950	Pueblo de Lo Barnechea	Circa 1955. Pueblo de Lo Barnechea	3	Juan Carlos Salas	Procultura	2025-10-15 17:46:56.207	2025-10-15 17:46:56.207
cmgsa9grz01u4h9i64inc5r5s	Niños a caballo	Niños a caballo	Niños a caballo en San Enrique		Juan Carlos Salas y Patricio Salas	1947	1940	San Enrique/La Ermita/Las Condes	Las Condes, 20-IV-47. San Enrique	3	Juan Carlos Salas	Procultura	2025-10-15 17:46:58.223	2025-10-15 17:46:58.223
cmgsa9lhe01uph9i6y8f1845i	Grupo disfrazado en un puente	Grupo disfrazado en un puente	Grupo disfrazado en el puente San Enrique		2da Rosa Eliana Diaz Lira, 4to Ruben Diaz Lira, 5ta  María Calderón			San Enrique/La Ermita/Las Condes	Puente San Enrique	3	Juan Carlos Salas	Procultura	2025-10-15 17:47:04.323	2025-10-15 17:47:04.323
cmgsa9n0f01uwh9i676bbo80b	Mujeres con niño y bebé en brazos	Mujeres con niño y bebé en brazos	Mujeres con niño y bebé en brazos en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	3	Juan Carlos Salas	Procultura	2025-10-15 17:47:06.304	2025-10-15 17:47:06.304
cmgsa9pup01vah9i6cm33eyla	Dos hombres frente a montañas	Dos hombres frente a montañas	Dos hombres frente a la montañas						Montaña	3	Juan Carlos Salas	Procultura	2025-10-15 17:47:09.985	2025-10-15 17:47:09.985
cmgsa9tvr01vvh9i6kif51dsy	Dos huasos a caballo	Dos huasos a caballo	Dos huasos a caballo en San Enrique	Papel Postal	A la der Luis Diaz en yegua Alazana. 	1950-1960	1950	San Enrique/La Ermita/Las Condes	Década de 1950. San Enrique	3	Juan Carlos Salas	Procultura	2025-10-15 17:47:15.205	2025-10-15 17:47:15.205
cmgsa9wmo01w9h9i6wvro5w9d	Equipo infantil de futbol	Equipo infantil de futbol	Equipo infantil de fútbol en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	3	Juan Carlos Salas	Procultura	2025-10-15 17:47:18.768	2025-10-15 17:47:18.768
cmgsaa1ld01wuh9i681egnlmb	Grupo elegante en salón	Grupo elegante en salón	Grupo elegante en salón en Hosteria La Querencia 	Pertenecía a José Soto.	7mo abajo José Soto. Fila central, 3ro Juan Salas, 6ta Luisa. 8va Yola Soto. Fila de arriba, 3ro Pancho Aranguiz. Fila de abajo, 10mo Ruben Diaz con su hijo Richard Diaz Soto. 	1958	1950	San Enrique/La Ermita/Las Condes	19 marzo 1958. Hosteria La Querencia (pertenecía a José Soto).	3	Juan Carlos Salas	Procultura	2025-10-15 17:47:25.201	2025-10-15 17:47:25.201
cmgsaa68u01xfh9i68mercpgj	Coro de blanco	Coro de blanco	Coro de blanco en la cancha de fútbol		Fresia, Elba, señora, Carmen Medina, Carmen, Clemira Montenegro, Carmen Pino, Irene, Silvia Contreras. Abajo con guitarra, Eugenia. Atrás de todas, Blanca Armijo. 	1995	1990	Pueblo de Lo Barnechea	1995. Cancha de futbol	3	Yolanda Cáceres	Procultura	2025-10-15 17:47:31.23	2025-10-15 17:47:31.23
cmgsaa85z01xmh9i64lz4m1al	Mujer preparando humitas	Mujer preparando humitas	Mujer preparando humitas en El Arrayán		Malu Hancok, Eloisa Contreras	hacia 1989	1980	El Arrayán	Eloisa Contreras de Contreras. Circa 1989. Casa en El Arrayan	3	Juan Contreras Valdivia	Procultura	2025-10-15 17:47:33.719	2025-10-15 17:47:33.719
cmgsaabzu01y0h9i68t85mbty	Pareja Sentada	Pareja Sentada	Pareja sentada en una casa en Los Patos	Fotos tomadas por Ana Matteo y desarrolladas por fotógrafo	Ernesto Maira y Valentina Rojas	hacia 1970	1970	Pueblo de Lo Barnechea	Circa 1970. Casa Los Patos	3	Ana Matteo Rojas	Procultura	2025-10-15 17:47:38.682	2025-10-15 17:47:38.682
cmgsaafj601yeh9i6gvt9migz	Acto escolar 3	Acto escolar 3	Acto escolar en Pueblo de Lo Barnechea			hacia 1956	1950	Pueblo de Lo Barnechea	Circa 1956. Pueblo de Lo Barnechea	3	Juan Carlos Salas	Procultura	2025-10-15 17:47:43.267	2025-10-15 17:47:43.267
cmgsaah2m01ylh9i6yp1u08fr	Mujeres disfrazadas sobre un puente 1	Mujeres disfrazadas sobre un puente 1	Mujeres disfrazadas sobre el puente San Enrique	Papel Tarjeta Postal		1950-1960	1950	San Enrique/La Ermita/Las Condes	Década de 1950. Puente San Enrique	3	Juan Carlos Salas	Procultura	2025-10-15 17:47:45.262	2025-10-15 17:47:45.262
cmgsaaijv01ysh9i62xtt611s	Mujeres disfrazadas sobre un puente 2	Mujeres disfrazadas sobre un puente 2	Mujeres disfrazadas sobre el puente San Enrique	Papel Tarjeta Postal	Primera a la izq: Rosa Eliana Díaz Lira	1950-1960	1950	San Enrique/La Ermita/Las Condes	Década de 1950. Puente San Enrique	3	Juan Carlos Salas	Procultura	2025-10-15 17:47:47.179	2025-10-15 17:47:47.179
cmgsa7urm01o3h9i6p8f5z749	Niña pequeña	Niña pequeña	Niña jugando con tierra en su casa en la calle Lastra		Karla Gallardo	1960	1960	Pueblo de Lo Barnechea	1960. Niña jugando con tierra en un hoyo, en su casa en calle Lastra	3	Familia Soto Torreblanca	Procultura	2025-10-15 17:45:43.042	2025-10-15 17:45:43.042
cmgsa7w0201oah9i6n4nft6yj	Niña con conejo	Niña con conejo	Niña con un conejo en su casa en la calle Lastra	Criaban conejos en su casa en la calle Lastra	Karla Gallardo	1985	1980	Pueblo de Lo Barnechea	1985. Criaban conejos en su casa en calle Lastra	3	Familia Soto Torreblanca	Procultura	2025-10-15 17:45:44.642	2025-10-15 17:45:44.642
cmgsa821d01ovh9i6jneqbnnu	Cuasimodistas pasando bajo un arco	Cuasimodistas pasando bajo un arco	Cuasimodistas pasando bajo un arco		Eduardo Araya (hijo), Pedro Araya Rubio (padre), Rumardo Araya (sobrino)	1969	1960			3	María Araya	Procultura	2025-10-15 17:45:52.464	2025-10-15 17:45:52.464
cmgsa83ea01p2h9i6myp4vapt	Jóvenes en comida	Jóvenes en comida	Jóvenes comiendo en el restaurante “La Querencia”	Celebración de trabajadores de la mina Pérez Caldera (La Disputada)	Tercero de izquierda a derecha, con chaleco azul, Eduardo Araya			San Enrique/La Ermita/Las Condes	Restaurante “La Querencia”, celebración de trabajadores de la mina Pérez Caldera (La Disputada)	3	María Araya	Procultura	2025-10-15 17:45:54.226	2025-10-15 17:45:54.226
cmgsa87if01pnh9i6ejtp82lq	Niños en el cerro	Niños en el cerro	Niños en el cerro en El Arrayán		Primos Gutierrez	1975	1970	El Arrayán	1975. El Arrayán	3	Rodolfo Gutierrez	Procultura	2025-10-15 17:45:59.56	2025-10-15 17:45:59.56
cmgsa88x201puh9i692wzc31g	Padre y niño bañándose en el río	Padre y niño bañándose en el río	Padre y niño bañándose en el río en El Arrayán		Rodolfo Gutierrez y su hijo Felipe Gutierrez	1975	1970	El Arrayán	1975. El Arrayán	3	Rodolfo Gutierrez	Procultura	2025-10-15 17:46:01.382	2025-10-15 17:46:01.382
cmgsa8aca01q1h9i68o9p3vo1	Entrada de autos de la casa Gutierrez	Entrada de autos de la casa Gutierrez	Entrada de autos de la casa Gutierrez en El Arrayán			hacia 1975	1970	El Arrayán	Circa 1975. El Arrayán	3	Rodolfo Gutierrez	Procultura	2025-10-15 17:46:03.227	2025-10-15 17:46:03.227
cmgsa8bns01q8h9i6ydn2inbr	Niños jugando con caballos	Niños jugando con caballos	Niños jugando con caballos en El Arrayán		Rafael y Felipe Gutierrez	1975	1970	El Arrayán	1975. El Arrayán	3	Rodolfo Gutierrez	Procultura	2025-10-15 17:46:04.937	2025-10-15 17:46:04.937
cmgsa8cxg01qfh9i6vomq34jr	Niña con pollito	Niña con pollito	Niña con pollito en El Arrayán		Monica Gutierrez	1979	1970	El Arrayán	1979. El Arrayán	3	Rodolfo Gutierrez	Procultura	2025-10-15 17:46:06.58	2025-10-15 17:46:06.58
cmgsa8fxd01qth9i6470ydcah	Foto familiar	Foto familiar	Fotografía de la familia Gutiérrez	En su casa	Felipe y Rafael Gutierrez, Lili Pereira, Rodolfo Gutierrez, Monica Gutierrez	1978	1970	El Arrayán	1978. Casa familia Gutierrez	3	Rodolfo Gutierrez	Procultura	2025-10-15 17:46:10.465	2025-10-15 17:46:10.465
cmgsa8lgt01reh9i6tevp4vgr	Zerreitug tallando un mascarón de proa	Zerreitug tallando un mascarón de proa	Zerreitug tallando un mascarón de proa en la casa de la familia Gutiérrez		Rodolfo Gutierrez	2000	2000	El Arrayán	2000. Casa familia Gutierrez	3	Rodolfo Gutierrez	Procultura	2025-10-15 17:46:17.645	2025-10-15 17:46:17.645
cmgsa96q401syh9i6jm7mutjr	Reverso foto LBCH720	Reverso foto LBCH720	Dedicatoria a un amigo	"A nuestro amigo Don Antonio Diaz Lira en el día de su onomastico.-p. Osvaldo Miro". Reverso foto LBCH720 en Pueblo de Lo Barnechea, 1936	Cuatro firmas	1936	1930	Pueblo de Lo Barnechea	"Junio 13 1936". Pueblo de Lo Barnechea	3	Juan Carlos Salas	Procultura	2025-10-15 17:46:45.196	2025-10-15 17:46:45.196
cmgsa9isa01ubh9i64h9x4ycs	Grupo posando sobre un auto	Grupo posando sobre un auto	Grupo posando sobre un auto en Pueblo de Lo Barnechea		A la izq adelante con cuello redondo, Maria Calderon. De abrigo negro Rosa Eliana Diaz Lira. 	1950-1960	1950	Pueblo de Lo Barnechea	Década de 1950. Pueblo de Lo Barnechea	3	Juan Carlos Salas	Procultura	2025-10-15 17:47:00.827	2025-10-15 17:47:00.827
cmgsa9k6d01uih9i68g4neqyc	Seis hombres caminando	Seis hombres caminando	Seis hombres caminando en Pueblo de Lo Barnechea		Patricio Salas (ext izq)			Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	3	Juan Carlos Salas	Procultura	2025-10-15 17:47:02.63	2025-10-15 17:47:02.63
cmgsa9oj201v3h9i6r0hjsusk	Mujeres mojándose los pies bajo el puente	Mujeres mojándose los pies bajo el puente	Mujeres mojándose los pies bajo el puente San Enrique		2da Rosa Eliana Diaz			San Enrique/La Ermita/Las Condes	Puente San Enrique	3	Juan Carlos Salas	Procultura	2025-10-15 17:47:08.27	2025-10-15 17:47:08.27
cmgsa9ye801wgh9i6x0mvqq09	Pareja bailando rock and roll	Pareja bailando rock and roll	Pareja bailando rock and roll en Pueblo de Lo Barnechea	Evento en salón parroquial	"Flaco" Gustavo y María Eugenia Salas	1950-1960	1950	Pueblo de Lo Barnechea	Década de 1950. Pueblo de Lo Barnechea	3	Juan Carlos Salas	Procultura	2025-10-15 17:47:21.056	2025-10-15 17:47:21.056
cmgsa9zxh01wnh9i693jukhqs	Hombre a caballo	Hombre a caballo	Hombre a caballo en Pueblo de Lo Barnechea		Luis Diaz Lira	1940-1950	1940	Pueblo de Lo Barnechea	Década de 1940. Pueblo de Lo Barnechea	3	Juan Carlos Salas	Procultura	2025-10-15 17:47:23.045	2025-10-15 17:47:23.045
cmgsaa4c801x8h9i6yfddbtxz	Jóvenes tras el meson de un bar	Jóvenes tras el meson de un bar	Jóvenes tras el mesón del bar de "El Pollo al Cognac"		2da María Eugenia Salas, 4to Jorge Salas, ext der Germán Alvarez	1970-1980	1970	Pueblo de Lo Barnechea	Década de 1970. Pollo al Cognac. 	3	Juan Carlos Salas	Procultura	2025-10-15 17:47:28.761	2025-10-15 17:47:28.761
cmgsaaave01xth9i6tkcbmj5n	Padrinos de bautizo	Padrinos de bautizo	Padrinos de bautizo en El Arrayán	Bautizo de la niña de Sergio	Sergio Navea, Eloisa Contreras, Señora de Sergio, Juan Contreras, padres de Sergio	hacia 1970	1970	El Arrayán	Jugaba en el club Cóndor, del año 47 por ahí. 29 Enero 77. Casa en El Arrayan	3	Juan Contreras Valdivia	Procultura	2025-10-15 17:47:37.227	2025-10-15 17:47:37.227
cmgsaak2h01yzh9i6x63ftq4r	Mujeres disfrazadas sobre un puente 3	Mujeres disfrazadas sobre un puente 3	Mujeres disfrazadas sobre el puente San Enrique	Papel Tarjeta Postal		1950-1960	1950	San Enrique/La Ermita/Las Condes	Década de 1950. Puente San Enrique	3	Juan Carlos Salas	Procultura	2025-10-15 17:47:49.145	2025-10-15 17:47:49.145
cmgsaamjk01z6h9i64c5k0v1a	Trabajadores pollo al cognac	Trabajadores pollo al cognac	Trabajadores del local "El Pollo al Cognac"		Ruben Alvarez, Raul Chamiso, Juan Cordova, Juan Salas Ibarra, Gerardo Salas Ibarra, nn	1973	1970	Pueblo de Lo Barnechea	Febrero 1973. Local Pollo al Cognac	3	Juan Carlos Salas	Procultura	2025-10-15 17:47:52.352	2025-10-15 17:47:52.352
cmgsa9v7q01w2h9i6qyullo2f	Hombres junto a reina de la FISA	Hombres junto a reina de la FISA	Hombres junto a reina de la FISA en el local "El Pollo al Cognac"		izq Juan Salas	1969	1960	Pueblo de Lo Barnechea	1969. Local del Pollo al Cognac en la FISa	3	Juan Carlos Salas	Procultura	2025-10-15 17:47:16.934	2025-10-15 17:47:16.934
cmgsaa2up01x1h9i66x862mro	Grupo afuera del Pollo al Cognac	Grupo afuera del Pollo al Cognac	Grupo afuera de "El Pollo al Cognac" en la Fisa		3ra Rosa Eliana Diaz, 4to Juan Salas junto a trabajadores	hacia 1965	1960	Pueblo de Lo Barnechea	Circa 1965. Local Pollo al Cognac de la Fisa	3	Juan Carlos Salas	Procultura	2025-10-15 17:47:26.833	2025-10-15 17:47:26.833
cmgsaadq901y7h9i6i7r0e3ca	Acto escolar 2	Acto escolar 2	Acto escolar en Pueblo de Lo Barnechea			hacia 1956	1950	Pueblo de Lo Barnechea	Circa 1956. Pueblo de Lo Barnechea	3	Juan Carlos Salas	Procultura	2025-10-15 17:47:40.929	2025-10-15 17:47:40.929
cmgsaap2101zdh9i6789lysd6	Pareja en terraza de restaurante vista desde arriba	Pareja en terraza de restaurante vista desde arriba	Pareja en terraza de restaurante vista desde arriba en la Hostería Río Abajo		Juan Salas Ibarra, Rosa Eliana Díaz	1954	1950	El Arrayán	importante, por linda y emblematica. Febrero 1954. Hosteria Rio Abajo	3	Juan Carlos Salas	Procultura	2025-10-15 17:47:55.61	2025-10-15 17:47:55.61
cmgsaasri01zkh9i6guujvvtz	Pareja del brazo	Pareja del brazo	Pareja del brazo en Pueblo de Lo Barnechea		Juan Salas y Rosa Eliana Díaz	1940-1950	1940	Pueblo de Lo Barnechea	Década de 1940. Pueblo de Lo Barnechea	3	Juan Carlos Salas	Procultura	2025-10-15 17:48:00.414	2025-10-15 17:48:00.414
cmgsaav9t01zrh9i6o2gh3578	Militares desfilando	Militares desfilando	Militares desfilando en Calle Barnechea			hacia 1980	1980	Pueblo de Lo Barnechea	importante pq muestra pueblo. Circa 1980. Calle Barnechea	3	Juan Carlos Salas	Procultura	2025-10-15 17:48:03.666	2025-10-15 17:48:03.666
cmgsaaxkw01zyh9i6zjnwn2j7	Desfile Escuela Especial 254	Desfile Escuela Especial 254	Desfile Escuela Especial 254 en Calle Barnechea			hacia 1980	1980	Pueblo de Lo Barnechea	Circa 1980. Calle Barnechea	3	Juan Carlos Salas	Procultura	2025-10-15 17:48:06.656	2025-10-15 17:48:06.656
cmgsabe0r0205h9i6bd0rnq35	Grupo bajo arcos	Grupo bajo arcos	Grupo bajo arcos en Pueblo de Lo Barnechea		Al centro boxeador Gonfrey Stevens, campeón sudamericano, perdió con un japonés. Atrás al lado, María Eugenia. A su derecha humorista, ¿Ana Gonzalez?	1970-1980	1970	Pueblo de Lo Barnechea	importante pq sale Ana Gonzalez. Década 1970. Pueblo de Lo Barnechea	3	Juan Carlos Salas	Procultura	2025-10-15 17:48:27.963	2025-10-15 17:48:27.963
cmgsabes6020ch9i6hxpb15b0	Niño en columpio	Niño en columpio	Niño en columpio en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	3	Ana Matteo Rojas	Procultura	2025-10-15 17:48:28.951	2025-10-15 17:48:28.951
cmgsabfwk020jh9i623an3xqi	Dos jovenes sobre una roca	Dos jovenes sobre una roca	Dos jóvenes sobre una roca en Pueblo de Lo Barnechea			1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	3	Ana Matteo Rojas	Procultura	2025-10-15 17:48:30.404	2025-10-15 17:48:30.404
cmgsabgy7020qh9i67u42xtw1	Niños sonriendo	Niños sonriendo	Niños sonriendo en Pueblo de Lo Barnechea			1960-1971	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	3	Ana Matteo Rojas	Procultura	2025-10-15 17:48:31.76	2025-10-15 17:48:31.76
cmgsabhvn020xh9i6cpy9wxgb	Familia comiendo al aire libre	Familia comiendo al aire libre	Familia comiendo al aire libre en Pueblo de Lo Barnechea			1960-1970	1960	Pueblo de Lo Barnechea	=C844. Pueblo de Lo Barnechea	3	Ana Matteo Rojas	Procultura	2025-10-15 17:48:32.963	2025-10-15 17:48:32.963
cmgsabic50214h9i6neliboyy	Iglesia	Iglesia	Iglesia en Pueblo de Lo Barnechea			1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	3	Ana Matteo Rojas	Procultura	2025-10-15 17:48:33.557	2025-10-15 17:48:33.557
cmgsabjbf021bh9i6v645esqe	Niño en bicicleta	Niño en bicicleta	Niño en bicicleta en Pueblo de Lo Barnechea			1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	3	Ana Matteo Rojas	Procultura	2025-10-15 17:48:34.828	2025-10-15 17:48:34.828
cmgsabkc5021ih9i68ogh8k58	Hombres en capó de camión	Hombres en capó de camión	Hombres en capó de camión en Pueblo de Lo Barnechea			1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	3	Ana Matteo Rojas	Procultura	2025-10-15 17:48:36.15	2025-10-15 17:48:36.15
cmgsablc3021ph9i632t7dqhz	Camión	Camión	Camión en Pueblo de Lo Barnechea			1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	3	Ana Matteo Rojas	Procultura	2025-10-15 17:48:37.444	2025-10-15 17:48:37.444
cmgsabmac021wh9i6q4b8o8rd	Dos niños	Dos niños	Dos niños en Pueblo de Lo Barnechea			1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	3	Ana Matteo Rojas	Procultura	2025-10-15 17:48:38.676	2025-10-15 17:48:38.676
cmgsabn8m0223h9i6jrjbamj4	Tres niños	Tres niños	Tres niños en Pueblo de Lo Barnechea			1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	3	Ana Matteo Rojas	Procultura	2025-10-15 17:48:39.91	2025-10-15 17:48:39.91
cmgsabo6d022ah9i6wffm47dx	Grupo posando frente a rocas	Grupo posando frente a rocas	Grupo posando frente a rocas 	en Mismo rollo o revelado LBCH901 a 907		1960-1970	1960	Pueblo de Lo Barnechea	Mismo rollo o revelado LBCH901 a 907	3	Ana Matteo Rojas	Procultura	2025-10-15 17:48:41.126	2025-10-15 17:48:41.126
cmgsabp44022hh9i6ixk6dogg	Mujer y bebé	Mujer y bebé	Mujer y bebé en Pueblo de Lo Barnechea			1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	3	Ana Matteo Rojas	Procultura	2025-10-15 17:48:42.34	2025-10-15 17:48:42.34
cmgsabq13022oh9i6yu58f0t0	Dos niños en un árbol	Dos niños en un árbol	Dos niños en un árbol en Pueblo de Lo Barnechea			1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	3	Ana Matteo Rojas	Procultura	2025-10-15 17:48:43.527	2025-10-15 17:48:43.527
cmgsabqyt022vh9i6ejtyrq0q	Mujer frente a casa	Mujer frente a casa	Mujer frente a casa en Pueblo de Lo Barnechea			1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	3	Ana Matteo Rojas	Procultura	2025-10-15 17:48:44.742	2025-10-15 17:48:44.742
cmgsabru20232h9i6wq5ur1nd	Hombre con su caza en el cerro	Hombre con su caza en el cerro	Hombre con su caza en el cerro en Pueblo de Lo Barnechea			1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	3	Ana Matteo Rojas	Procultura	2025-10-15 17:48:45.866	2025-10-15 17:48:45.866
cmgsabu5c0239h9i6k5wopiwf	Reina bailando con naipe	Reina bailando con naipe	Reina bailando con naipe en Pueblo de Lo Barnechea	Timbre: C.D. JUVENTUD CATOLICA /FDO. 27 DE JULIO DE 1940 / BARNECHEA LAS CONDES /// Otro timbre: FOTO REPORTAJE SOCIAL "RELAMPAGO" E. Hoffstetter. Grajales 2152- Stgo.	Ana Matteo 	1959	1950	Pueblo de Lo Barnechea	carnaval se hacìa en febrero. Pueblo de Lo Barnechea	3	Ana Matteo Rojas	Procultura	2025-10-15 17:48:48.864	2025-10-15 17:48:48.864
cmgsabww2023gh9i6f9wuem1e	Grupo disfrazado 	Grupo disfrazado 	Grupo disfrazado en la casa de la familia dell Orto	C. Garrido 97 Barnechea. En lastra al fondo a mano derecha	Al centro adelante, Alicia dell'orto, atrás de ella de blanco su mamá Alicia Pozzi. A la derecha de Alicia en el suelo Ernesto Maira; a su izquierda Luisa Negrete. A la izq arriba Maria Ines Espinoza, Maria Espinoza, Ana María Espinoza, Ana Matteo, ADolfo Dell'orto, Héctor Maira (hermano Ana) Eduardo Caro, con peluca blanca Miguel Angel Maira (hermano). Abajo niña con cintillo Sara Inostroza. De negro atrás Carlos SAnino. De negro Veronica Caro, a su derecha Rosi Caro vestida de hombre. Ultimo a la der Gumercindo. Abajo a la derecha Memo Espinoza. 	1959	1950	Pueblo de Lo Barnechea	Grupo recorrìa las calles: puente nuevo, arrayàn, pueblito. Al año sgte se hacia al reves. 1959. Casa familia dell Orto, en lastra al fondo a mano derecha	3	Ana Matteo Rojas	Procultura	2025-10-15 17:48:52.418	2025-10-15 17:48:52.418
cmgsabzqm023nh9i6sr97x435	Dos mujeres disfrazadas saludan con la falda	Dos mujeres disfrazadas saludan con la falda	Dos mujeres disfrazadas saludan con la falda en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	3	Ana Matteo Rojas	Procultura	2025-10-15 17:48:56.111	2025-10-15 17:48:56.111
cmgsac2hf023uh9i684wos3d6	Grupo disfrazado incluye letrero "peo"	Grupo disfrazado incluye letrero "peo"	Grupo disfrazado incluye letrero "peo" en Pueblo de Lo Barnechea	Recuerdo de la fiesta de disfraces /// C. Garrido 97 Barnechea. LBCH936 es el reverso de la foto con todos los asistentes		1965	1960	Pueblo de Lo Barnechea	30-7-65. Pueblo de Lo Barnechea	3	Ana Matteo Rojas	Procultura	2025-10-15 17:48:59.667	2025-10-15 17:48:59.667
cmgsac5fc0241h9i6msplfpzu	Reverso foto LBCH935	Reverso foto LBCH935	Reverso foto LBCH935 en Pueblo de Lo Barnechea				1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	3	Ana Matteo Rojas	Procultura	2025-10-15 17:49:03.48	2025-10-15 17:49:03.48
cmgsac961024fh9i6obflp06c	Coronación de reina	Coronación de reina	Coronación de reina en Pueblo de Lo Barnechea	Timbre: C.D. JUVENTUD CATOLICA /FDO. 27 DE JULIO DE 1940 / BARNECHEA LAS CONDES /// Otro timbre: FOTO REPORTAJE SOCIAL "RELAMPAGO" E. Hoffstetter. Grajales 2152- Stgo.	Ana Matteo y Gustavo Gonzalez (rey feo, vivia en Puente Nuevo)	1959	1950	Pueblo de Lo Barnechea	1959. Pueblo de Lo Barnechea	3	Ana Matteo Rojas	Procultura	2025-10-15 17:49:08.329	2025-10-15 17:49:08.329
cmgsacahp024mh9i69ahvdwo9	Arriero a caballo	Arriero a caballo	Arriero subiendo la montaña en primavera a caballo	Està todo pelado pero usualmente había nieve, por eso no crece nada	Custodio Gana Hernández	hacia 1966	1960	El Arrayán	Circa 1966. Subiendo, en primavera (està todo pelado pero usualmente había nieve, por eso no crece nada)	3	Margarita Gana	Procultura	2025-10-15 17:49:10.045	2025-10-15 17:49:10.045
cmgsaccz0024th9i6irqa3zpe	Hombres subiendo materiales al observatorio 2	Hombres subiendo materiales al observatorio 2	Hombres subiendo materiales al observatorio en El Arrayán	en la montaña		1960-1970	1960	El Arrayán	En la subida, a veces se quedaban en Perez Caldera a alojar. Década de 1960. El Arrayán	3	Margarita Gana	Procultura	2025-10-15 17:49:13.26	2025-10-15 17:49:13.26
cmgsacvc80257h9i695v0ykgs	Hombre junto a mula cargada	Hombre junto a mula cargada	Hombre junto a mula cargada en "Corral Villa Paulina" en Yerbaloca	Subiendo instrumentos al observatorio de la U. de Chile. En la montaña	Custodio Gana. LBCH952 es el reverso con informacion	1971	1970	El Arrayán	1971. "Corral Villa Paulina"	3	Margarita Gana	Procultura	2025-10-15 17:49:37.064	2025-10-15 17:49:37.064
cmgsae6ai025sh9i6v0qhmxvr	Hombre en cima con cable	Hombre en cima con cable	Hombre en cima con cable en El Arrayán	en la montaña		hacia 1960	1960	El Arrayán	Importante por buena foto. . El Arrayán	3	Margarita Gana	Procultura	2025-10-15 17:50:37.914	2025-10-15 17:50:37.914
cmgsaer6q0266h9i65buhk3k7	Hombre junto a caballo frente a glaciar	Hombre junto a caballo frente a glaciar	Hombre junto a caballo frente a glaciar camino a la mina San Rafael	en la montaña	Antonio Gana	hacia 1959	1950	El Arrayán	Circa 1959. Quizas camino a la mina San Rafael	3	Margarita Gana	Procultura	2025-10-15 17:51:04.994	2025-10-15 17:51:04.994
cmgsafqb2027xh9i6lpjc12sa	Grupo de hombres exhibiendo premios	Grupo de hombres exhibiendo premios	Grupo de hombres exhibiendo premios	Club Deportivo Barnechea				Pueblo de Lo Barnechea		2	Rocío Muñoz	Procultura	2025-10-15 17:51:50.51	2025-10-15 17:51:50.51
cmgsagvr7028ph9i6iorm34yv	5 huasos	5 huasos	5 huasos en Calle Álvarez		Gabriel Araya, Juan Pablo Araya, Joaquin Vicente Araya (nieto), Joaquin Araya, Juan "Pele" Araya (padre)	2016	2010	Pueblo de Lo Barnechea	2016. Calle Alvarez	2	Familia Araya Meneses	Procultura	2025-10-15 17:52:44.227	2025-10-15 17:52:44.227
cmgsah430029hh9i6fir2xefg	Payasos en fiesta de navidad	Payasos en fiesta de navidad	Payasos en fiesta de navidad		Celebración de los vecinos de Calle Álvarez	hacia 1994	1990			2	Rocío Muñoz	Procultura	2025-10-15 17:52:55.02	2025-10-15 17:52:55.02
cmgsah5kl029oh9i63gjpgi0g	Profesora en sala de clases	Profesora en sala de clases	Profesora en sala de clases del Colegio Parroquial	La profesora René Troncoso le hizo clases a varias generaciones.	Profesora René Troncoso	hacia 1996	1990	Pueblo de Lo Barnechea	Circa 1996. Profesora del Colegio Parroquial, hizo clases a varias generaciones.	2	Familia Soto Torreblanca	Procultura	2025-10-15 17:52:56.949	2025-10-15 17:52:56.949
cmgsahals02a9h9i64to2izqx	Casa Zerreitug decorada	Casa Zerreitug decorada	Casa Zerreitug decorada	Casa Gutiérrez		1995	1990	El Arrayán	1995. Casa familia Gutierrez	2	Rodolfo Gutierrez	Procultura	2025-10-15 17:53:03.473	2025-10-15 17:53:03.473
cmgsahcii02agh9i6bmm91ei7	Joven frente a Casa Zerreitug decorada	Joven frente a Casa Zerreitug decorada	Joven frente a Casa Zerreitug decorada 	Casa Gutiérrez	Mónica Gutierrez	1995	1990	El Arrayán	1995. Casa familia Gutierrez	2	Rodolfo Gutierrez	Procultura	2025-10-15 17:53:05.947	2025-10-15 17:53:05.947
cmgsai3r902b1h9i6prs653z2	Mujeres huasas	Mujeres huasas	Mujeres huasas en Pueblo de Lo Barnechea		Silvia Contreras, Adriana Serrano, María Chavez, Eulogia, Carmen Pino, Ema Sanchez	1990-2000	1990	Pueblo de Lo Barnechea	Conjunto de baile del taller de cueca. Década 1990. Pueblo de Lo Barnechea	2	Carmen Pino	Procultura	2025-10-15 17:53:41.253	2025-10-15 17:53:41.253
cmgsai9rq02bmh9i6rfb2y88j	Sector la poza	Sector la poza	Familia en el sector La Poza 	Sigue estando la laguna; pero lo que se ve pelado para atrás es Valle Escondido	Ximena Riveros, Pedro Araya (Robi), Pedro Araya Riveros, Jennifer Araya	hacia 1994	1990	Valle Escondido	Circa 1994. Sigue estando la laguna; pero lo que se ve pelado para atrás es Valle Escondido	2	Ximena Riveros de Araya	Procultura	2025-10-15 17:53:49.046	2025-10-15 17:53:49.046
cmgsaiezl02c0h9i6b0pdalpk	Presentación conjunto folclorico	Presentación conjunto folclorico	Presentación del conjunto folclórico en el Teatro de la Municipalidad de Lo Barnechea		Taller de canto de la Municipalidad, con profesor Francisco Villa (ext derecho)	hacia 1992	1990	Pueblo de Lo Barnechea	Circa 1992. Teatro de la Municipalidad de Barnechea	2	María Chavez	Procultura	2025-10-15 17:53:55.81	2025-10-15 17:53:55.81
cmgsaigkm02c7h9i6czqvkau4	Once de fin de año en pasaje	Once de fin de año en pasaje	Evento de fin de año en pasaje en Pueblo de Lo Barnechea		Joaquín Moya, a la izquierda René Valencia, nn.	1990-2000	1990	Pueblo de Lo Barnechea	Década de 1990. Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 17:53:57.863	2025-10-15 17:53:57.863
cmgsaiico02ceh9i6jgaggcdd	Equipo de fútbol de blanco	Equipo de fútbol de blanco	Equipo de fútbol de blanco			1980-1990	1980			2	Rocio Muñoz	Procultura	2025-10-15 17:54:00.169	2025-10-15 17:54:00.169
cmgsaijq602clh9i6855pjfep	Dos hombres	Dos hombres	Dos hombres en Pueblo de Lo Barnechea		Patricio Villarroel y Orlando Garrido, entrenadores del regional y tercera división	hacia 1980	1980	Pueblo de Lo Barnechea	Circa 1980. Pueblo de Lo Barnechea	2	Eliseo Villarroel	Procultura	2025-10-15 17:54:01.95	2025-10-15 17:54:01.95
cmgsacfle0250h9i6phnkoave	Hombre con mulas en corral	Hombre con mulas en corral	Hombre con mulas en corral e	en la montaña. Pausa en el camino	Olegario Gana Hernández	1950-1960	1950	El Arrayán	Coipa: gorro tubular que se puede bajar hasta el cuello. Década 1950. Pausa en el camino	3	Margarita Gana	Procultura	2025-10-15 17:49:16.658	2025-10-15 17:49:16.658
cmgsadbe8025eh9i6p0edmmcm	Hombre junto a mula cargada con caja	Hombre junto a mula cargada con caja	Hombre junto a mula cargada con caja en Los Bronces	en la montaña	Custodio Gana	hacia 1960	1960	El Arrayán	Circa 1960. Los Bronces	3	Margarita Gana	Procultura	2025-10-15 17:49:57.848	2025-10-15 17:49:57.848
cmgsadqpl025lh9i6rtqldxac	Grupo construyendo	Grupo construyendo	Grupo construyendo en El Arrayán	Construyendo algo que luego se subirìa al campamento de Los Bronces en la montaña	A la izq Hernan Jofre, en primer plano sujetando el marco Custodio Gana	hacia 1960	1960	El Arrayán	Circa 1960. El Arrayán	3	Margarita Gana	Procultura	2025-10-15 17:50:17.72	2025-10-15 17:50:17.72
cmgsaepso025zh9i6mvf5wbt4	Dos hombres montados frente a laguna	Dos hombres montados frente a laguna	Dos hombres montados frente a laguna en Laguna del Plomo	Olegario trabajaba en minas también, en la montaña	Antonio Gana y Olegario Gana (padre)	hacia 1966	1960	Farellones	Circa 1966. Laguna del Plomo	3	Margarita Gana	Procultura	2025-10-15 17:51:03.192	2025-10-15 17:51:03.192
cmgsaespt026dh9i6yq0t3omc	Cuatro mineros de pie	Cuatro mineros de pie	Cuatro mineros de pie en la cumbre San Rafael	en la mina en la montaña	2do de izq a der Luis Dávila, 3ro Olegario Gana	1960-1970	1960	El Arrayán	Década de 1960. "Cumbre San Rafael. Mina."	3	Margarita Gana	Procultura	2025-10-15 17:51:06.978	2025-10-15 17:51:06.978
cmgsafcbc026kh9i6bz3r00c8	Dos hombres a caballo 	Dos hombres a caballo 	Dos hombres a caballo en Las Ortigas, hacia la Yegua Helá	en la montaña	Juan Maureira Gana y Jorge Maureira Gana	2018	2010	El Arrayán	2018. Yendo por Las Ortigas, hacia la Yegua Helá	3	Margarita Gana	Procultura	2025-10-15 17:51:32.376	2025-10-15 17:51:32.376
cmgsafeku026rh9i6hy8f8dm4	Foto Colegio	Foto Colegio	Foto de curso en el Colegio San Juan de Krondstat		Profesor Abelardo Nuñez. Sentadas en la fila central, desde el extremo derecho sentada Berta Lastra, Carmen Rosa, Araceli Maureira	1986	1980	El Arrayán	1986. Colegio San Juan de Crostand	3	Margarita Gana	Procultura	2025-10-15 17:51:35.31	2025-10-15 17:51:35.31
cmgsaffnq026yh9i6t8lb92dx	Padre y familia	Padre y familia	Padre y familia en El Arrayán		Eliana Gana Fajardo, Margarita Gana Fajardo, Custodio Gana, Guacolda Rodriguez, en sus brazos Jorge Maureira, Silvia Gana Fajardo, Graciela Fajardo. Niño abajo Juan Maureira Gana. 	1973	1970	El Arrayán	1973. El Arrayán	3	Margarita Gana	Procultura	2025-10-15 17:51:36.71	2025-10-15 17:51:36.71
cmgsafgp10275h9i6yu5t43fd	Mujer frente a camino	Mujer frente a camino	Mujer frente a camino		Margarita Gana	1973	1970	El Arrayán	El Arrayán, julio 1973	3	Margarita Gana	Procultura	2025-10-15 17:51:38.053	2025-10-15 17:51:38.053
cmgsafjyu027ch9i6x3btkax2	Abuelo y nieto	Abuelo y nieto	Abuelo y nieto		Carlos Maureira y nieto Jorge Maureira	1974	1970	El Arrayán	Pirque	3	Margarita Gana	Procultura	2025-10-15 17:51:42.295	2025-10-15 17:51:42.295
cmgsafkvj027jh9i6jpahe9km	Dos niños	Dos niños	Dos niños		Juan Maureira y tía Silvia Gana	1971	1970	El Arrayán	Cerro en El arrayan	3	Margarita Gana	Procultura	2025-10-15 17:51:43.472	2025-10-15 17:51:43.472
cmgsafnlg027qh9i6nwa3cjsd	Canal junto a camino de tierra	Canal junto a camino de tierra	Canal junto a camino de tierra en La Dehesa	Al frente del actual Mampato, bordeando Camino Turístico		1990-2000	1990	La Dehesa	Década de 1990. La Dehesa	3	Rocio Muñoz	Procultura	2025-10-15 17:51:46.997	2025-10-15 17:51:46.997
cmgsafrp60284h9i6g5tcxhy1	Cuatro personas y adorno de botellas	Cuatro personas y adorno de botellas	Cuatro personas y adorno de botellas		María Dotte, Rosa Alcaíno, Patricia Dotte, Juan Carlos Muñoz	hacia 1980	1980			2	Patricia Dotte	Procultura	2025-10-15 17:51:52.315	2025-10-15 17:51:52.315
cmgsaft4y028bh9i6ipgq4n4u	Graduación de peluquería	Graduación de peluquería	Graduación de peluquería en Providencia	1980. Providencia, Román Díaz	Ximena Riveros	1980	1980	Santiago	1980. Providencia, Román Díaz	2	Ximena Riveros de Araya	Procultura	2025-10-15 17:51:54.178	2025-10-15 17:51:54.178
cmgsagakn028ih9i6ns3aptqf	Hombre con dos caballos en laguna	Hombre con dos caballos en laguna	Hombre con dos caballos en laguna en Las Ortigas, hacia la Yegua Helá	en la montaña	Jorge Maureira Gana	2018	2010	El Arrayán	2018. Yendo por Las Ortigas, hacia la Yegua Helá	2	Margarita Gana	Procultura	2025-10-15 17:52:16.774	2025-10-15 17:52:16.774
cmgsagyxr028wh9i6r9j80odt	Foto de curso adolescente femenino	Foto de curso adolescente femenino	Foto de curso adolescente femenino en Calle Garrido	Antigua Sección femenina del colegio San Rafael	Colegio Santa Loreto	2000-2010	2000	Pueblo de Lo Barnechea	ML. Década de 2000. Calle Garrido	2	Rocío Muñoz	Procultura	2025-10-15 17:52:48.351	2025-10-15 17:52:48.351
cmgsah02t0293h9i65dr1f4ir	Mujer joven	Mujer joven	Mujer joven en Pueblo de Lo Barnechea		Luciana Gonzalez	hacia 2000	2000	Pueblo de Lo Barnechea	circa 2000. Pueblo de Lo Barnechea	2	Carmen Pino	Procultura	2025-10-15 17:52:49.829	2025-10-15 17:52:49.829
cmgsah1bv029ah9i6pzf695ry	Mujeres en parque	Mujeres en parque	Mujeres en parque en Parque de las Rosas		Funcionaria de la Municipalidad, Edith Quiroz. Abajo las sobrinas Jimena Varas Quiroz y Alejandra Varas Quiroz	hacia 2001	2000	San Enrique/La Ermita/Las Condes	Circa 2001. Parque de las Rosas	2	Familia Quiroz Mendoza	Procultura	2025-10-15 17:52:51.451	2025-10-15 17:52:51.451
cmgsah70a029vh9i6asbbbzuo	Partido de fútbol	Partido de fútbol	Partido de fútbol en El Arrayán		A la izquierda Rodolfo Gutierrez, al arco Max Verru, de blanco inclinado Marcelo Coulon, de rosado Cristian Ferrer, a la derecha Felipe Gutierrez	1990	1990	El Arrayán	1990. El Arrayán	2	Rodolfo Gutierrez	Procultura	2025-10-15 17:52:58.81	2025-10-15 17:52:58.81
cmgsah8m202a2h9i6l9fuvlo1	Partido de fútbol	Partido de fútbol	Partido de fútbol frente a la casa de la familia Gutiérrez		Felipe Gutierrez, Rodolfo Gutierrez, Max Berru, pareja Vivi, Gonzalo Gutierrez, Rafael Gutierrez atrás suyo; nn, agachado Marcelo Coulon. Abajo niño, Pollo Otarola, Claudio Gutierrez, Reggi Coulon  	1990	1990	El Arrayán	1990. Frente de la casa Gutierrez	2	Rodolfo Gutierrez	Procultura	2025-10-15 17:53:00.889	2025-10-15 17:53:00.889
cmgsahybr02anh9i69v2n7cez	Dos mujeres mayores	Dos mujeres mayores	Dos mujeres mayores en una casa en la Calle Lastra	Fotografía ampliada del original antiguo	María Magdalena Moreno e Inés Soto	hacia 1995	1990	Pueblo de Lo Barnechea	Circa 1995. Casa en Calle Lastra	2	Pamela Araya	Procultura	2025-10-15 17:53:34.214	2025-10-15 17:53:34.214
cmgsai0ut02auh9i6cj0zktoq	Grupo de mujeres en evento musical	Grupo de mujeres en evento musical	Grupo de mujeres en evento musical en Pueblo de Lo Barnechea		Elba Troncoso, Carmen, Fresia, Carmen Pino, María Chavez, Elba Torrejón, Irene. Abajo Yolanda Cáceres, Eugenia. 	1994	1990	Pueblo de Lo Barnechea	1994. Pueblo de Lo Barnechea	2	Yolanda Cáceres	Procultura	2025-10-15 17:53:37.494	2025-10-15 17:53:37.494
cmgsai56u02b8h9i63g7k2zem	Escolares frente a muro de piedra	Escolares frente a muro de piedra	Escolares frente a muro de piedra		Catequistas: Daniela Gana y Margarita Maureira	1990-2000	1990	El Arrayán	Capilla de Emaus	2	Margarita Gana	Procultura	2025-10-15 17:53:43.11	2025-10-15 17:53:43.11
cmgsai7wi02bfh9i6bvht5tfx	Graduación Jardín Infantil Cruz Roja	Graduación Jardín Infantil Cruz Roja	Graduación Jardín Infantil Cruz Roja en Pueblo de Lo Barnechea		ext derecha Pedro Araya	1990	1990	Pueblo de Lo Barnechea	1990. Pueblo de Lo Barnechea	2	Ximena Riveros de Araya	Procultura	2025-10-15 17:53:46.627	2025-10-15 17:53:46.627
cmgsaica202bth9i61xsxibns	Conjunto cantando con guitarra	Conjunto cantando con guitarra	Conjunto cantando con guitarra en Población Nido de Águilas		Conjunto Centro de Madres 	1990-2000	1990	Pueblo de Lo Barnechea	Década de 1990. Población Nido de Águilas	2	María Chavez	Procultura	2025-10-15 17:53:52.298	2025-10-15 17:53:52.298
cmgsaimbw02csh9i64xhm479y	Tres hombres a caballo	Tres hombres a caballo	Tres hombres a caballo en Medialuna		José Montenergo, Juan Montenegro, Lorenzo Montenegro	1980-1990	1980	Pueblo de Lo Barnechea	Década 1980. Medialuna	2	Lorenzo Montenegro	Procultura	2025-10-15 17:54:05.306	2025-10-15 17:54:05.306
cmgsainqw02czh9i6pjkq4zzd	Niña haciendo tareas	Niña haciendo tareas	Niña haciendo tareas en su casa en Los Patos		Mariela Bravo y José Bravo	1985	1980	Pueblo de Lo Barnechea	1985. Casa en pasaje Los Patos	2	Mariela Bravo	Procultura	2025-10-15 17:54:07.16	2025-10-15 17:54:07.16
cmgsaip3502d6h9i6v6czgp7h	Siete jinetes en paseo a la cordillera	Siete jinetes en paseo a la cordillera	Siete jinetes en paseo a la cordillera 	Llevaban 3 o 4 mulas cargadas	Verónica Dominguez, Carlos Araya, Nelson Ortega, Juan Polanco, Cristina Araya, Victor Araya, Fabiola Polanco	1985	1980		1985. Subiendo, llevaban 3 o 4 mulas cargadas. Paseo al cerro	2	Carlos Araya	Procultura	2025-10-15 17:54:08.898	2025-10-15 17:54:08.898
cmgsaiqbb02ddh9i6m31jn43q	Fila de jinetes subiendo el cerro	Fila de jinetes subiendo el cerro	Fila de jinetes subiendo el cerro		Carlos Araya, Victor Araya, Alejandro Araya (papá), Berta Polanco	1985	1980		Paseo al cerro	2	Carlos Araya	Procultura	2025-10-15 17:54:10.488	2025-10-15 17:54:10.488
cmgsairq802dkh9i620lzjqq8	Familia almorzando en el cerro	Familia almorzando en el cerro	Familia almorzando en el cerro	Comían sandwich, bebida	Por la izquierda, Alejandro Araya, Berta Polanco, Fabiola Polanco. Niños adelante: Carlos Araya y Juan Polanco. Verónica Dominguez (ahijada de Berta), Nelson Ortega (esposos), Victor Araya.	1985	1980		Paseo al cerro	2	Carlos Araya	Procultura	2025-10-15 17:54:12.321	2025-10-15 17:54:12.321
cmgsaisw202drh9i6jpj67qy4	Jóvenes frente a multicancha	Jóvenes frente a multicancha	Jóvenes frente a multicancha 	Jugaban basketball	Al centro de blanco Paulina Valencia	1981	1980	Pueblo de Lo Barnechea	Carmen nacio el 55, igual que Hilda. 1981. Jugaban basketball	2	Yoconda Moya	Procultura	2025-10-15 17:54:13.826	2025-10-15 17:54:13.826
cmgsaiudu02dyh9i6vausjrpb	Joven en uniforme militar	Joven en uniforme militar	Joven en uniforme militar en Pueblo de Lo Barnechea		Juan Carlos Valencia Moya	1980	1980	Pueblo de Lo Barnechea	1980. Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 17:54:15.762	2025-10-15 17:54:15.762
cmgsaiwzq02ech9i6ugff8wkj	Graduación escolar femenina	Graduación escolar femenina	Graduación escolar femenina en Pueblo de Lo Barnechea	“3ºC Liceo Cervantes 1980”		1980	1980	Pueblo de Lo Barnechea	1980. Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 17:54:19.142	2025-10-15 17:54:19.142
cmgsaiy6p02ejh9i68g2d4n7y	Novia con su abuela	Novia con su abuela	Novia con su abuela		Celestina Dotte y Rosa Alcaíno	hacia 1985	1980			2	Patricia Dotte	Procultura	2025-10-15 17:54:20.689	2025-10-15 17:54:20.689
cmgsaj3ph02f4h9i69nla49nh	Dos hombres con bebé	Dos hombres con bebé	Dos hombres con bebé en El Arrayán		Patricio Dotte con niño	1980-1990	1980	El Arrayán	Década 1980. El Arrayán	2	Patricia Dotte	Procultura	2025-10-15 17:54:27.845	2025-10-15 17:54:27.845
cmgsaj95f02fph9i6j1h4wqh7	Dos niñas disfrazadas	Dos niñas disfrazadas	Dos niñas disfrazadas en Pueblo de Lo Barnechea		Macarena Soto y Karla Gallardo (primas)	1984	1980	Pueblo de Lo Barnechea	Julio 1984. Pueblo de Lo Barnechea	2	Familia Soto Torreblanca	Procultura	2025-10-15 17:54:34.899	2025-10-15 17:54:34.899
cmgsajb0h02fwh9i6mw1b11cn	Graduación Jardín Infantil	Graduación Jardín Infantil	Graduación en el Jardín Infantil de la Cruz Roja		Niño al centro adelante, Juan Escárate. Niña con vestido rosado a la derecha, Macarena Soto. Hoy están casados.	1984	1980	Pueblo de Lo Barnechea	1984. Jardín Infantil de la Cruz Roja	2	Familia Soto Torreblanca	Procultura	2025-10-15 17:54:37.313	2025-10-15 17:54:37.313
cmgsajcgd02g3h9i67j7c5azu	Primera comunión	Primera comunión	Primera comunión en la capilla El Arrayán		María de los Ángeles Soto Mesa, Francisca Soto Mesa, Macarena Soto Torreblanca,  Karla Gallardo, Pia Soto Mesa, Nicolás Ramírez (abajo). En brazos María Ignacia Mesa. A la derecha abuela María Inés Soto y tía Carmen Salinas.	1988	1980	El Arrayán	1988. Capilla El Arrayán	2	Familia Soto Torreblanca	Procultura	2025-10-15 17:54:39.182	2025-10-15 17:54:39.182
cmgsajdnq02gah9i6lg2arlch	Dos mujeres en matrimonio	Dos mujeres en matrimonio	Dos mujeres en matrimonio		María Araya Espinosa (sobrina) y María Araya Pinto (tía)	hacia 1985	1980			2	María Araya	Procultura	2025-10-15 17:54:40.742	2025-10-15 17:54:40.742
cmgsajj8h02goh9i6wxljji9t	Presentación de baile	Presentación de baile	Presentación de baile en Aniversario del club de la católica		María Araya Rojas y Ramón Mesa	1980-1990	1980		Década 1980. Aniversario del club de la católica	2	María Araya	Procultura	2025-10-15 17:54:47.969	2025-10-15 17:54:47.969
cmgsajku702gvh9i6plga5xrk	Casa	Casa	Casa en El Arrayán		Casa familia Gutierrez antes de ser decorada y sin ampliaciones	1984	1980	El Arrayán	1984. El Arrayán	2	Rodolfo Gutierrez	Procultura	2025-10-15 17:54:50.048	2025-10-15 17:54:50.048
cmgsajnz902h9h9i6vvzf1wpw	Jóvenes jugando futbol	Jóvenes jugando futbol	Jóvenes jugando fútbol en El Arrayán		Rafael Becerra, nn, Mauricio Gutierrez, Pablo Gutierrez, Ricardo Gutierrez Schwerter, Franggio Zapata, Felipe Gutierrez, Gonzalo Gutierrez Schwerter, Vicente Gutierrez Schwerter. Abajo Cristian Gutierrez, José Vicente Gutierrez Schwerter, Alvaro Gutierrez, Rafael Gutierrez, Rodolfo Gutierrez Schwerter, Claudio Gutierrez	1986	1980	El Arrayán	1986. El Arrayán	2	Rodolfo Gutierrez	Procultura	2025-10-15 17:54:54.116	2025-10-15 17:54:54.116
cmgsaivoc02e5h9i60j4z2zs8	Sacerdote y acólito en Cuasimodo	Sacerdote y acólito en Cuasimodo	Sacerdote y acólito en Cuasimodo en Pueblo de Lo Barnechea	“Fiesta Huasa”	Padre Jimmy Turner, acólito “Tito”, hoy es sacerdote	1980	1980	Pueblo de Lo Barnechea	Abril 1980. Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 17:54:17.436	2025-10-15 17:54:17.436
cmgsaiyyg02eqh9i6n078md32	Foto carnet	Foto carnet	Foto carnet		Patricio Dotte	1980	1980			2	Patricia Dotte	Procultura	2025-10-15 17:54:21.688	2025-10-15 17:54:21.688
cmgsaj19902exh9i6cl4v9ki4	Hombre con bebé	Hombre con bebé	Hombre con bebé en El Arrayán		Patricio Dotte con niña	1980-1990	1980	El Arrayán	Década 1980. El Arrayán	2	Patricia Dotte	Procultura	2025-10-15 17:54:24.668	2025-10-15 17:54:24.668
cmgsaj5y702fbh9i6rufc52fs	Licenciatura de jardín infantil	Licenciatura de jardín infantil	Licenciatura de jardín infantil en Pueblo de Lo Barnechea		Karla Gallardo	1984	1980	Pueblo de Lo Barnechea	1984. Pueblo de Lo Barnechea	2	Familia Soto Torreblanca	Procultura	2025-10-15 17:54:30.752	2025-10-15 17:54:30.752
cmgsaj79k02fih9i642eu08ys	Dos niñas con viejo pascuero	Dos niñas con viejo pascuero	Dos niñas con viejo pascuero en Navidad	Las llevaban al cementerio y a tomar helado.	Macarena Soto y Karla Gallardo (primas)	hacia 1987	1980	Pueblo de Lo Barnechea	Circa 1987. Después de la navidad, las llevaban al cementerio y a tomar helado.	2	Familia Soto Torreblanca	Procultura	2025-10-15 17:54:32.456	2025-10-15 17:54:32.456
cmgsajh5802ghh9i6e68mdlnn	Hombre con dos niños	Hombre con dos niños	Hombre con dos niños en una casa en Av. Barnechea	“Tata /Cristián /Nikolas”. Casa Araya	Nikolas DiPhilippi, Ramiro Araya, Cristian DiPhilippi (bisnietos)	1987	1980	Pueblo de Lo Barnechea	María y Ramiro Araya eran primos hermanos, se casaron porque iban a tener un hijo pero ninguno de los dos quería. Marzo 1987. Entrada de la casa Araya en av Barnechea	2	María Araya	Procultura	2025-10-15 17:54:45.26	2025-10-15 17:54:45.26
cmgsajmeo02h2h9i6k0uqsgya	Hombre frente a casa nevada	Hombre frente a casa nevada	Hombre frente a casa nevada en El Arrayán		Rafael Gutierrez	1984	1980	El Arrayán	1984. El Arrayán	2	Rodolfo Gutierrez	Procultura	2025-10-15 17:54:52.08	2025-10-15 17:54:52.08
cmgsajpq302hgh9i6v1z203v0	Padre e hijos	Padre e hijos	Padre e hijos en la casa de la familia Gutiérrez		Mónica, Felipe, Rodolfo y Rafael Gutierrez	1983	1980	El Arrayán	1983. Casa familia Gutierrez	2	Rodolfo Gutierrez	Procultura	2025-10-15 17:54:56.378	2025-10-15 17:54:56.378
cmgsajrkc02hnh9i6l97jkkxm	Matrimonio Civil	Matrimonio Civil	Matrimonio Civil en el Registro Civil de Las Condes		Jorge Cubillos y Veronica Gonzalez, firma Carlos Gonzalez	hacia 1980	1980	San Enrique/La Ermita/Las Condes	Circa 1980. Registri civil Las Condes	2	Carmen Pino	Procultura	2025-10-15 17:54:58.744	2025-10-15 17:54:58.744
cmgsaju5g02huh9i63pe2athb	Abuelo y nietas	Abuelo y nietas	Abuelo y nietas en El Arrayán		Juan Contreras y nietos Jessica, Daniela y Ana María Espinoza Contreras (izq a der)	hacia 1984	1980	El Arrayán	Circa 1984. Casa en El Arrayan	2	Juan Contreras Valdivia	Procultura	2025-10-15 17:55:02.117	2025-10-15 17:55:02.117
cmgsajvcf02i1h9i6m4kl7uqb	Carnet escolar	Carnet escolar	Carnet escolar en Pueblo de Lo Barnechea			1988	1980	Pueblo de Lo Barnechea	1988. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 17:55:03.664	2025-10-15 17:55:03.664
cmgsajwib02i8h9i6fq2o8tjk	Reverso carnet escolar	Reverso carnet escolar	Reverso carnet escolar en Pueblo de Lo Barnechea			1988	1980	Pueblo de Lo Barnechea	1988. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 17:55:05.171	2025-10-15 17:55:05.171
cmgsajz1002ifh9i6caudywxd	Autoridades sentadas durante desfile	Autoridades sentadas durante desfile	Autoridades sentadas durante desfile en Calle Barnechea			hacia 1980	1980	Pueblo de Lo Barnechea	Circa 1980. Calle Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 17:55:08.436	2025-10-15 17:55:08.436
cmgsak1l802imh9i6rg56vei9	Desfile Defensa Civil de Chile Lo Barnechea 	Desfile Defensa Civil de Chile Lo Barnechea 	Desfile Defensa Civil de Chile Lo Barnechea en Calle Barnechea			hacia 1980	1980	Pueblo de Lo Barnechea	Circa 1980. Calle Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 17:55:11.756	2025-10-15 17:55:11.756
cmgsak32602ith9i65ry6b83v	Hombres subiendo con mulas	Hombres subiendo con mulas	Hombres subiendo con mulas en Cajón del Arrayán	en la montaña	Olegario Gana Hernández, Antonio Gana Valdivia, José Gana Fajardo (primo de Antonio) 	1988	1980	El Arrayán	27-12-88. Cajón del Arrayán	2	Margarita Gana	Procultura	2025-10-15 17:55:13.662	2025-10-15 17:55:13.662
cmgsak4i202j0h9i6ia801t1g	Dos niños con ratón disfrazado	Dos niños con ratón disfrazado	Dos niños con ratón disfrazado en Tierra Amarilla	en la montaña, en el sector de las fondas	Jorge Maureira y Margarita Maureira	hacia 1980	1980	El Arrayán	Circa 1980. Sector de fondas en Tierras Amarilla	2	Margarita Gana	Procultura	2025-10-15 17:55:15.53	2025-10-15 17:55:15.53
cmgsak5yo02j7h9i6cobx2zxb	Té familiar de primera comunión	Té familiar de primera comunión	Té familiar de primera comunión en El Arrayán		Jimena Gana, Custodio Gana Hernández, América Gana, Claudio Gana, Margarita Gana, Uberlinda Gana Hernández, Margarita Maureira, Noemí Gana, Eliana Gana, Alexis Yañez, Felipe Castro	1980	1980	El Arrayán	1980. Casa en El Arrayan	2	Margarita Gana	Procultura	2025-10-15 17:55:17.425	2025-10-15 17:55:17.425
cmgsak7f302jeh9i6277g390r	Primera comunión de niña	Primera comunión de niña	Primera comunión de niña en El Arrayán		Abuelo Carlos Maureira, Jorge Maureira, Alexis Yañez, Margarita Maureira, Rodrigo Yañez	1980	1980	El Arrayán	1980. Casa en El Arrayan	2	Margarita Gana	Procultura	2025-10-15 17:55:19.311	2025-10-15 17:55:19.311
cmgsaka0u02jlh9i65saeyb2u	Grupo en matrimonio	Grupo en matrimonio	Grupo en matrimonio		Custodio Gana, José Gana, Noemí Gana, Héctor Castro, Mercedes Moreno, Graciela Fajardo, Carlos Paz,Niño. 	1983	1980	El Arrayán		2	Margarita Gana	Procultura	2025-10-15 17:55:22.687	2025-10-15 17:55:22.687
cmgsakcrb02jsh9i6bttujrt2	Tía Abuela y novia	Tía Abuela y novia	Tía Abuela y novia		 Blanca Saldívar y Noemí Gana	1983	1980	El Arrayán	Capilla de Emaús	2	Margarita Gana	Procultura	2025-10-15 17:55:26.231	2025-10-15 17:55:26.231
cmgsakfgn02jzh9i6vq6brhnc	Pareja de novios bailando	Pareja de novios bailando	Pareja de novios bailando		Noemí Gana y Héctor Castro	1983	1980	El Arrayán	Capilla de Emaús	2	Margarita Gana	Procultura	2025-10-15 17:55:29.733	2025-10-15 17:55:29.733
cmgsaki7202k6h9i6xtyjn18s	Grupo en matrimonio	Grupo en matrimonio	Grupo en matrimonio		Custodio Gana, Guido Davila, Noemi Gana, Margarita Gana, Hector Castro, Nancy Davila, Graciela Fajardo, Mercedes Moreno	1983	1980	El Arrayán		2	Margarita Gana	Procultura	2025-10-15 17:55:33.279	2025-10-15 17:55:33.279
cmgsakjof02kdh9i6qyxar91x	Mujer con olla	Mujer con olla	Mujer con olla	Lavando ollas en el canal, el día después del matrimonio de su hermana	América Gana	1983	1980	El Arrayán	Lavando ollas en el canal, el día después del matrimonio de su hermana	2	Margarita Gana	Procultura	2025-10-15 17:55:35.199	2025-10-15 17:55:35.199
cmgsaklhm02kkh9i6czz2f3up	Tres mujeres en camino de tierra	Tres mujeres en camino de tierra	Tres mujeres en camino de tierra	Camino a Centro de Madres en Emaus	Loreto Gana, Margarita Gana y Graciela Fajardo	1988	1980	El Arrayán	Camino a Centro de Madres en Emaus	2	Margarita Gana	Procultura	2025-10-15 17:55:37.546	2025-10-15 17:55:37.546
cmgsakn3i02krh9i63sh5x9bz	Dos niños	Dos niños	Abuelo y nietas en Casa en El Arrayán		Cristobal Vega y Felipe Castro	1980-1990	1980	El Arrayán	Década de 1980. Casa en El Arrayan	2	Margarita Gana	Procultura	2025-10-15 17:55:39.631	2025-10-15 17:55:39.631
cmgsakoju02kyh9i6ohvr22xq	Hombre con dos niños	Hombre con dos niños	Hombre con dos niños en El Arrayán		Nicolás Castro (sobrino), Jorge Maureira, hija Margarita Maureira	1982	1980	El Arrayán	12-12-82. El Arrayán	2	Margarita Gana	Procultura	2025-10-15 17:55:41.515	2025-10-15 17:55:41.515
cmgsaks7002lch9i61pv4lsu4	Mujer disfrazada	Mujer disfrazada	Mujer disfrazada en el actual colegio Fermín Vivaceta	Había cursos de peluquería y hacían desfiles	Ximena Riveros	1982	1980	Pueblo de Lo Barnechea	1982. Actual colegio Fermin Vivaceta, había cursos de peluquería y hacían desfiles	2	Ximena Riveros de Araya	Procultura	2025-10-15 17:55:46.235	2025-10-15 17:55:46.235
cmgsakxdc02lxh9i6g16vsyms	Participantes de cumpleaños infantil	Participantes de cumpleaños infantil	Participantes de cumpleaños infantil en Pueblo de Lo Barnechea			1987	1980	Pueblo de Lo Barnechea	1987. Pueblo de Lo Barnechea	2	Ximena Riveros de Araya	Procultura	2025-10-15 17:55:52.944	2025-10-15 17:55:52.944
cmgsakz8302m4h9i6hz0wqb9n	Jardin infantil Cruz Roja	Jardin infantil Cruz Roja	Jardin infantil Cruz Roja en Pueblo de Lo Barnechea		abajo izq Christian Ponce, Jennifer Araya, María José. Tía Mari	1987	1980	Pueblo de Lo Barnechea	1987. Pueblo de Lo Barnechea	2	Ximena Riveros de Araya	Procultura	2025-10-15 17:55:55.347	2025-10-15 17:55:55.347
cmgsal52a02mwh9i6pk0ewdsj	Grupo del brazo	Grupo del brazo	Grupo del brazo durante un matrimonio en una casa de la calle Vecinal		Enrique Torres, Norma Bustamante, Rodolfo Ocampo, Maria Chavez, Adan Llano, Lidia Barrera. Abajo: Luis Ocampo Chavez, María de Lourdes Ocampo Chavez	1980-1990	1980	Pueblo de Lo Barnechea	Década de 1980. Matrimonio en casa de calle Vecinal	2	María Chavez	Procultura	2025-10-15 17:56:02.914	2025-10-15 17:56:02.914
cmgsal8q902nah9i6kclptklp	Novios junto a pareja	Novios junto a pareja	Novios junto a pareja en Casa en calle El Esfuerzo		María Chavez, novio , Alejandra Tolosa Meneses, Rodolfo Ocampo	hacia 1985	1980	Pueblo de Lo Barnechea	Circa 1985. Casa en calle El Esfuerzo	2	María Chavez	Procultura	2025-10-15 17:56:07.665	2025-10-15 17:56:07.665
cmgsala2r02nhh9i6enw1rnvx	Hombre comiendo	Hombre comiendo	Hombre comiendo en Casa en calle El Esfuerzo		Rodolfo Ocampo	hacia 1985	1980	Pueblo de Lo Barnechea	Circa 1985. Casa en calle El Esfuerzo	2	María Chavez	Procultura	2025-10-15 17:56:09.412	2025-10-15 17:56:09.412
cmgsalbmy02noh9i65qiqvphx	Profesora y alumna	Profesora y alumna	Profesora y alumna en Escuela 177		Profesor, Isolina Quiroz	hacia 1980	1980	Pueblo de Lo Barnechea	Circa 1980. Escuela 177	2	Familia Quiroz Mendoza	Procultura	2025-10-15 17:56:11.434	2025-10-15 17:56:11.434
cmgsale9i02o2h9i6mqo66z3j	Mujer esquiando	Mujer esquiando	Mujer esquiando en Farellones		Edith Quiroz	hacia 1982	1980	Farellones	Circa 1982. Farellones	2	Familia Quiroz Mendoza	Procultura	2025-10-15 17:56:14.838	2025-10-15 17:56:14.838
cmgsalhvd02ogh9i6y5noy38l	Pareja abrazada en la calle	Pareja abrazada en la calle	Pareja abrazada en la calle Los Patos		Benjamín Valencia y su hija Paula Valencia	1980-1990	1980	Pueblo de Lo Barnechea	Década de 1980. Calle Los Patos	2	Yoconda Moya	Procultura	2025-10-15 17:56:19.512	2025-10-15 17:56:19.512
cmgsalmeh02ouh9i6irtjndrg	Grupo vestido elegante	Grupo vestido elegante	Grupo vestido elegante en una presentación en Escuela Militar		Renato Meza (presidente del club), Carlos Moya, Digna Cruz (vicepresidenta del club, a cargo de la rama femenina), Victor Barrea, Manuel "Flaco Memo" Muñoz (carnicero)	hacia 1975	1970	Santiago	ML (porque son notables las pintas ). Circa 1975. Presentación, en Escuela Militar	2	Eliseo Villarroel	Procultura	2025-10-15 17:56:25.385	2025-10-15 17:56:25.385
cmgsam38b02qeh9i6wsyd8oqo	Dos jovenes en celebración	Dos jovenes en celebración	Dos jóvenes en celebración en Pueblo de Lo Barnechea		De chaleco rosado, Pedro Valencia	1977	1970	Pueblo de Lo Barnechea	Agosto 1977. Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 17:56:47.195	2025-10-15 17:56:47.195
cmgsam7fa02qsh9i6ynnoqy0g	Cuatro niños	Cuatro niños	Cuatro niños cerca del Policlínico		Clara Valencia, Paula Valencia, y sus primos Alejandro Ortiz y Luis Ortiz	hacia 1970	1970	Pueblo de Lo Barnechea	Circa 1970. Cerca del Policlinico	2	Yoconda Moya	Procultura	2025-10-15 17:56:52.63	2025-10-15 17:56:52.63
cmgsamcuv02r6h9i6fu846d5j	Grupo en comida aniversario	Grupo en comida aniversario	Grupo en comida aniversario en Pueblo de Lo Barnechea		arrodillado a la izq Salcedo, a su derecha Luis Ortiz. De polera con tiras, Clara Valencia.  arriba mirando a la niña otro Salcedo. 2Da mujer a la izq Rosalia Moya, con gorrito Angelica Salcedo. Mirando a su derecha, Raul Maturana.  Al centro de bigote José Salcedo, arriba suyo María Eugenia Tobar. Atrás de ella, escondido. Con afro Corina, a su derecha Rosita Emilia.  Atras de ella Juan Bravo. A la derecha Eliana , Ana, Sergio Salcedo.	1979	1970	Pueblo de Lo Barnechea	22 de Diciembre de 1979. Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 17:56:59.672	2025-10-15 17:56:59.672
cmgsamq5002sqh9i6licnoiey	Hombres emparejando cancha de futbol	Hombres emparejando cancha de futbol	Hombres emparejando cancha de futbol en la parcela de la familia Gutiérrez		Rodolfo Gutierrez, Santiago Larrain (vecino)	1976	1970	El Arrayán	Enero 1976. Parcela familia Gutierrez	2	Rodolfo Gutierrez	Procultura	2025-10-15 17:57:16.884	2025-10-15 17:57:16.884
cmgsamsze02t4h9i6jxqlicwz	Dos hermanos	Dos hermanos	Dos hermanos en El Arrayán		Rafael y Felipe Gutierrez	1976	1970	El Arrayán	1976. El Arrayán	2	Rodolfo Gutierrez	Procultura	2025-10-15 17:57:20.571	2025-10-15 17:57:20.571
cmgsamywa02twh9i6def223yy	Familia	Familia	Familia Gutiérrez en su casa		Rafael y Felipe Gutierrez, Liliana Pereira, Rodolfo Gutierrez	1976	1970	El Arrayán	1976. Casa familia Gutierrez	2	Rodolfo Gutierrez	Procultura	2025-10-15 17:57:28.233	2025-10-15 17:57:28.233
cmgsankkb02uah9i62amepee0	Despedida de Pedro Araya	Despedida de Pedro Araya	Despedida de Pedro Araya en lo Barnechea	Organizada x grupo de amigos	Luis Villarroel Gomez, Pablo Gisen (gerente Sando, pdte honorario de Barnehcea), Pepe Alvarez “Cortisona”, Pedro Araya, patricio Villarroel, Tito Valencia con gorro, Jorge Valencia, Olga valencia	1970	1970	Pueblo de Lo Barnechea	importante x pedro araya. 1970. Casa familiar en av lo Barnechea	2	Patricio Villarroel	Procultura	2025-10-15 17:57:56.315	2025-10-15 17:57:56.315
cmgsannz402uoh9i6bg198r08	Joven con trofeo	Joven con trofeo	Joven con trofeo en carrera de Ciclistas		Con trofeo, Carlos Galindo, ciclista. A la der Juan Salas	1977	1970	Pueblo de Lo Barnechea	21 Mayo 1977. Carrera de Ciclistas 	2	Juan Carlos Salas	Procultura	2025-10-15 17:58:00.737	2025-10-15 17:58:00.737
cmgsanun302vgh9i6ji5pmb47	Carnet de niño	Carnet de niño	Carnet de niño			1977	1970	Pueblo de Lo Barnechea	1977. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 17:58:09.376	2025-10-15 17:58:09.376
cmgsao1zf02w1h9i63n1pp3k9	Retrato de mujer	Retrato de mujer	Retrato de mujer en Pueblo de Lo Barnechea	"Foto Marion"	Rosa Eliana Diaz 	1976	1970	Pueblo de Lo Barnechea	26 de mayo 1976. Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 17:58:18.891	2025-10-15 17:58:18.891
cmgsao3ne02w8h9i6jvpjg055	Retrato de señora 1	Retrato de señora 1	Retrato de señora en Pueblo de Lo Barnechea	Fotovelkon. Ahumada 340, Santiago		1978	1970	Pueblo de Lo Barnechea	6 abril 1978. Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 17:58:21.051	2025-10-15 17:58:21.051
cmgsaoalv02wth9i6vukatwgf	Entrega de regalos	Entrega de regalos	Entrega de regalos en el local "El pollo al cognac"		Juan Salas	hacia 1977	1970	Pueblo de Lo Barnechea	Circa 1977. Local Pollo al Cognac	2	Juan Carlos Salas	Procultura	2025-10-15 17:58:30.067	2025-10-15 17:58:30.067
cmgsb48kt045xh9i62tt42ylw	Mamá e hija	Mamá e hija	Mamá e hija en Farellones		Liliana Fernández, María Álvarez	1980	1980	Farellones	Farellones	2	Familia Gallardo	Procultura	2025-10-15 18:10:53.934	2025-10-15 18:10:53.934
cmgsakqob02l5h9i6aqilybwg	Mujer con dos niños en sillon	Mujer con dos niños en sillon	Mujer con dos niños en el sillón en El Arrayán		Eduardo Vega, América Gana, Cristóbal Vega (hijos)	1987	1980	El Arrayán	9-3-87. Casa en El Arrayan	2	Margarita Gana	Procultura	2025-10-15 17:55:44.267	2025-10-15 17:55:44.267
cmgsaku1702ljh9i63520q8i3	Graduación curso de peluquería	Graduación curso de peluquería	Graduación del curso de peluquería en el Colegio Fermín Vivaceta		Alicia, 3ra Carmen Pino, profesora Marina, ultima es Ximena Riveros	1983	1980	Pueblo de Lo Barnechea	1983. Colegio Fermin Vivaceta	2	Ximena Riveros de Araya	Procultura	2025-10-15 17:55:48.618	2025-10-15 17:55:48.618
cmgsal3he02mph9i6bm757uum	Grupo frente a imagen de la virgen	Grupo frente a imagen de la virgen	Grupo frente a imagen de la virgen en Parroquia Santa Rosa		 Atrás de oscuro Juan Wenchual, Flor Viveros Sanhueza, Maria Chavez, hilda Viveros. Fila del centro Monica Wenchual Viveros, Ricardo Wenchual Viveros, Mireya NN Sanhueza. Abajo: Christian Fernando Ocampo Chavez, Rafael Esteban Ocampo Chavez	hacia 1980	1980	Pueblo de Lo Barnechea	Circa 1980. Parroquia Santa Rosa	2	María Chavez	Procultura	2025-10-15 17:56:00.867	2025-10-15 17:56:00.867
cmgsalgb102o9h9i6t2pq3lln	Huaso bailando con su madre	Huaso bailando con su madre	Huaso bailando con su madre en una casa en la calle Lastra		Aurelia Meneses y Juan "Pelé" Araya	1989	1980	Pueblo de Lo Barnechea	4-11-1989. Casa en calle Lastra	2	Familia Araya Meneses	Procultura	2025-10-15 17:56:17.485	2025-10-15 17:56:17.485
cmgsalydm02pth9i6l7oj974g	Primera comunión	Primera comunión	Primera comunión		Rocío Muñoz y Camila Muñoz	1974	1970			2	Familia Muñoz Dotte	Procultura	2025-10-15 17:56:40.906	2025-10-15 17:56:40.906
cmgsam4mt02qlh9i6lrqeeslg	Grupo celebrando	Grupo celebrando	Grupo celebrando en Pueblo de Lo Barnechea		Segundo a la izquierda, Pedro Valencia, atrás suyo Pacheco	1977	1970	Pueblo de Lo Barnechea	Agosto 1977. Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 17:56:49.013	2025-10-15 17:56:49.013
cmgsamfrq02rdh9i637n8anup	Grupo tomando un ponche	Grupo tomando un ponche	Grupo tomando ponche y jugando lotería en el Club Barnechea		Al centro Bernarda Bravo, izq Yoconda Moya, atrás entre ellas Jaime Rojas. Con un jarro Pedro Valencia.	1977	1970	Pueblo de Lo Barnechea	19 de Febrero de 1977. Jugando lotería en el Club Barnechea	2	Yoconda Moya	Procultura	2025-10-15 17:57:03.447	2025-10-15 17:57:03.447
cmgsamke302ryh9i6pgy0t7nr	Carnet del Club deportivo las Condes	Carnet del Club deportivo las Condes	Carnet del Club deportivo las Condes 		Patricio Dotte	1979	1970	San Enrique/La Ermita/Las Condes	1979. San Enrique/La Ermita/Las Condes	2	Patricia Dotte	Procultura	2025-10-15 17:57:09.436	2025-10-15 17:57:09.436
cmgsamn4p02sch9i65tof9oq2	Grupo en base naval	Grupo en base naval	Grupo en la base naval Antártica		Con barba y chaleco a rayas, Pedro Araya, junto a otros marinos	1970-1980	1970	Otro	Década 1970. Antártica	2	María Araya	Procultura	2025-10-15 17:57:12.985	2025-10-15 17:57:12.985
cmgsamrj802sxh9i673i059ai	Familia en auto	Familia en auto	Familia en auto en la casa Gutiérrez, camino Los Refugios		Rafael y Felipe Gutierrez atrás, adelante Lili Pereira y Mónica Gutierrez	1978	1970	El Arrayán	1978. Afuera del porton de la casa Gutierrez, camino Los Refugios	2	Rodolfo Gutierrez	Procultura	2025-10-15 17:57:18.692	2025-10-15 17:57:18.692
cmgsamudn02tbh9i637z78py2	Niños jugando en bicicleta	Niños jugando en bicicleta	Niños en bicicleta jugando en la calle, camino Refugios del Arrayán		Monica, Rafael y Felipe Gutierrez	1979	1970	El Arrayán	1979. Jugando en la calle, camino Refugios del Arrayan	2	Rodolfo Gutierrez	Procultura	2025-10-15 17:57:22.38	2025-10-15 17:57:22.38
cmgsanj3202u3h9i6sirt3mbj	Grupo posando	Grupo posando	Grupo posando en El Tranque	Fotografía ampliada del original antiguo	Hermanos Guerra Moreno y Poblete Moreno	hacia 1970	1970	La Dehesa	Circa 1970. El Tranque	2	Pamela Araya	Procultura	2025-10-15 17:57:54.398	2025-10-15 17:57:54.398
cmgsanmhc02uhh9i6qh9x0afl	Pareja bailando	Pareja bailando	Pareja bailando en "El pollo al cognac"		Eliana Diaz 	1970-1980	1970	Pueblo de Lo Barnechea	Década de 1970. Pollo al Cognac. 	2	Juan Carlos Salas	Procultura	2025-10-15 17:57:58.8	2025-10-15 17:57:58.8
cmgsao0bm02vuh9i6eo1nynr6	Niño	Niño	Niño en Pueblo de Lo Barnechea		Guillermo Alfredo	hacia 1970	1970	Pueblo de Lo Barnechea	Circa 1970. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 17:58:16.739	2025-10-15 17:58:16.739
cmgsaodfw02x0h9i6bdmyn00t	Mujer recibiendo regalo	Mujer recibiendo regalo	Mujer recibiendo regalo en el local "El pollo al cognac"		Juan Salas	hacia 1977	1970	Pueblo de Lo Barnechea	Circa 1977. Local Pollo al Cognac	2	Juan Carlos Salas	Procultura	2025-10-15 17:58:33.74	2025-10-15 17:58:33.74
cmgsaofnv02x7h9i6tjbznx8i	Comida de comerciantes	Comida de comerciantes	Comida de comerciantes en Pueblo de Lo Barnechea		Al fondo Rubén. Desde la derecha Pedro Herrera, Gastón Moreno.  A la izq de ruben vemos  Juan salas, extremo izq Pancho Aránguiz, 	1970-1980	1970	Pueblo de Lo Barnechea	Década de 1970. Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 17:58:36.619	2025-10-15 17:58:36.619
cmgsaonaq02xsh9i64wmlau61	Mujeres vestidas elegante	Mujeres vestidas elegante	Mujeres vestidas elegante en el local "El pollo al cognac"		2da María Eugenia Salas	1970-1980	1970	Pueblo de Lo Barnechea	Década 1970. Pollo al Cognac. 	2	Juan Carlos Salas	Procultura	2025-10-15 17:58:46.514	2025-10-15 17:58:46.514
cmgsapx9902yrh9i6xnrochap	Reverso foto LBCH951	Reverso foto LBCH951	Reverso foto LBCH951 	en la montaña		1971	1970	El Arrayán	En El Arrayan habia parcelas grandes (esta era la 20, y queda casi en Santuario de la Naturaleza), quedaban espaciadas unas de otras, se podía cuidar animales ahí. 1971. El Arrayán	2	Margarita Gana	Procultura	2025-10-15 17:59:46.077	2025-10-15 17:59:46.077
cmgsapygm02yyh9i6lsrvomvd	Tres niños	Tres niños	Tres niños en el Colegio Camilo López Pinto, El Arrayán	en la montaña	Juan Maureira, Enrique Rodriguez, Victor Davila (primos)	1974	1970	El Arrayán	13-4-74. Colegio Camilo Lopez Pinto, El Arrayan	2	Margarita Gana	Procultura	2025-10-15 17:59:47.638	2025-10-15 17:59:47.638
cmgsaq22v02zjh9i6aw88r1fw	Niña con bebé en brazos	Niña con bebé en brazos	Niña con bebé en brazos en El Arrayán	"Con todo cariño para Silvita, de su regalón Enriquito"	Silvia Gana Fajardo y Enrique Rodriguez Gana (primos)	1971	1970	El Arrayán	Marzo 1971. Casa en El Arrayan	2	Margarita Gana	Procultura	2025-10-15 17:59:52.327	2025-10-15 17:59:52.327
cmgsaq4j602zxh9i6hkia6i2h	Niño con rosario	Niño con rosario	Niño con rosario	Parroquia Santa Rosa	Claudio Gana	1970	1970	El Arrayán	Parroquia Santa Rosa	2	Margarita Gana	Procultura	2025-10-15 17:59:55.507	2025-10-15 17:59:55.507
cmgsaq6nc030bh9i6rg8v1inz	Niña con amigos en primera comunión	Niña con amigos en primera comunión	Niña con amigos en su primera comunión en la Parroquia Santa Rosa		Verónica Rivera, Walter Rivera, Ximena Riveros, Jorge Rivera	1973	1970	Pueblo de Lo Barnechea	1973. Parroquia Santa Rosa	2	Ximena Riveros de Araya	Procultura	2025-10-15 17:59:58.248	2025-10-15 17:59:58.248
cmgsakvzf02lqh9i6gm6cvs83	Equipo de la católica	Equipo de la católica	Equipo de la Católica en Cuatro Canchas, actual costanera		Club Deportivo Juventud Católica	1985	1980	Pueblo de Lo Barnechea	1985. Cuatro canchas, actual costanera	2	Ximena Riveros de Araya	Procultura	2025-10-15 17:55:51.148	2025-10-15 17:55:51.148
cmgsal0o402mbh9i6nhspy5z8	Mujer amamantando	Mujer amamantando	Mujer amamantando en una casa en Los Patos, hoy la Divina Comida		Mariana Bravo y Javier Maira Bravo	hacia 1984	1980	Pueblo de Lo Barnechea	Circa 1984. Casa en Los Patos, hoy la Divina Comida	2	Ana Matteo Rojas	Procultura	2025-10-15 17:55:57.22	2025-10-15 17:55:57.22
cmgsal26h02mih9i60ze8qdpq	Novios en sillon	Novios en sillon	Novios en sillón en la casa de la madre de la novia, calle Nebraska		Beatriz, Andrés Sepúlveda (novio), María Chavez	1980-1990	1980	Población Nebraska	Década de 1980. Casa de la madre de la novia, calle Nebraska	2	María Chavez	Procultura	2025-10-15 17:55:59.177	2025-10-15 17:55:59.177
cmgsal6pm02n3h9i6a0uqcrpm	Pareja con trajes mexicanos	Pareja con trajes mexicanos	Pareja con trajes mexicanos en Instituto Estados Americanos	Representaban a Mexico en la semana de la Primavera	Profesora Ana, Paolo Cifuentes, Paula Cifuentes, Rafael Ocampo	1982	1980	Pueblo de Lo Barnechea	Circa 1981. Colegio (actuales Carabineros)	2	María Chavez	Procultura	2025-10-15 17:56:05.05	2025-10-15 17:56:05.05
cmgsalcxv02nvh9i6d4kjtpxt	Familia en traje de esquí	Familia en traje de esquí	Familia en traje de esquí en Farellones		Edith Quiroz, Verónica Martínez, Carolina Martínez, Ester Quiroz	hacia 1982	1980	Farellones	Circa 1982. Farellones	2	Familia Quiroz Mendoza	Procultura	2025-10-15 17:56:13.123	2025-10-15 17:56:13.123
cmgsaljj202onh9i61jze4xz6	Jóvenes sentados en escalera de piedra	Jóvenes sentados en escalera de piedra	Jóvenes sentados en escalera de piedra en la playa de Viña del Mar		Sandra, Luis, nn, abajo Marcela	1980-1990	1980	Otro	Década 1980. Playa en Viña del Mar	2	Yoconda Moya	Procultura	2025-10-15 17:56:21.662	2025-10-15 17:56:21.662
cmgsaloc002p1h9i60niz1chf	Grupo celebrando junto a mesa de pool	Grupo celebrando junto a mesa de pool	Grupo celebrando junto a mesa de pool en la sede del club Barnechea	Posiblemente un aniversario	Jugadores del campeonato regional	hacia 1978	1970	Pueblo de Lo Barnechea	Circa 1978. Sede del club Barnechea	2	Eliseo Villarroel	Procultura	2025-10-15 17:56:27.888	2025-10-15 17:56:27.888
cmgsalq8d02p8h9i6gevxn6qx	Grupo junto a mesa de pool	Grupo junto a mesa de pool	Grupo junto a mesa de pool en la sede del club Barnechea		Jugadores del campeonato regional	hacia 1978	1970	Pueblo de Lo Barnechea	Circa 1978. Sede del club Barnechea	2	Eliseo Villarroel	Procultura	2025-10-15 17:56:30.349	2025-10-15 17:56:30.349
cmgsalt7t02pfh9i6f6fnxdvp	Comida oficial	Comida oficial	Comida oficial en La Cerámica, en el salón atrás de la Iglesia		A la izq “Flaco” Onell, su esposa, Pablo, presidente Renato Mesa, presidente de Miramonte (otro club, del estadio israelita pa adentro), nn, señora Amanda Chacón, Joaquín Moya (su esposa)	hacia 1970	1970	Pueblo de Lo Barnechea	* sede actual la compramos el 73. Circa 1970. La Cerámica, salón atrás de la Iglesia	2	Eliseo Villarroel	Procultura	2025-10-15 17:56:34.217	2025-10-15 17:56:34.217
cmgsalw4h02pmh9i61inht8tz	Hombres mostrando diploma	Hombres mostrando diploma	Hombres mostrando diploma en Pueblo de Lo Barnechea	“Tía Anita”	Luis “Neno” Meza, nn arquero, Victor Conejera, Efraín “Pitilla” Bravo	hacia 1971	1970	Pueblo de Lo Barnechea	Circa 1971. Pueblo de Lo Barnechea	2	Eliseo Villarroel	Procultura	2025-10-15 17:56:37.984	2025-10-15 17:56:37.984
cmgsam0bc02q0h9i6kgqp2k8r	Dos cuasimodistas	Dos cuasimodistas	Dos cuasimodistas	Cuasimodo, sector San Enrique	Juan Luis Morales y Alejandro Araya	1979	1970			2	Carlos Araya	Procultura	2025-10-15 17:56:43.417	2025-10-15 17:56:43.417
cmgsam1sl02q7h9i6t9hmkj6z	Grupo celebrando	Grupo celebrando	Grupo celebrando en Aniversario del Club Barnechea, en la sede del Club			1977	1970	Pueblo de Lo Barnechea	Agosto 1977. Aniversario del Club Barnechea, en la sede del Club	2	Yoconda Moya	Procultura	2025-10-15 17:56:45.333	2025-10-15 17:56:45.333
cmgsama9302qzh9i65h7ar8vj	Equipo de fútbol	Equipo de fútbol	Equipo de fútbol en Pueblo de Lo Barnechea	“Campeones invictos del campeonato de viejos craks de 1970.” Sigue la lista de nombres. Luego abajo al centro “José Salcedo Medias”.	Cortes, Jorquera, Salcedo, Orellana, Aracena, Montoya, Meneses, Zúñiga, Vargas, Barrera, Cotón, E. Bravo, Peres, Peres, Espinoza	1970	1970	Pueblo de Lo Barnechea	31 de octubre de 1970. Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 17:56:56.295	2025-10-15 17:56:56.295
cmgsamgmk02rkh9i6jw2kreiz	Joven en su servicio militar	Joven en su servicio militar	Joven en su servicio militar		Patricio Dotte	1971	1970			2	Patricia Dotte	Procultura	2025-10-15 17:57:04.557	2025-10-15 17:57:04.557
cmgsamjfo02rrh9i6c6gd4zsn	Grupo en matrimonio	Grupo en matrimonio	Grupo en el matrimonio Arce Salazar		Mujer, Alfredo Arce, Gloria Salazar Dotte, Patricio Dotte	hacia 1977	1970		1977 circa. Matrimonio Arce Salazar	2	Patricia Dotte	Procultura	2025-10-15 17:57:08.197	2025-10-15 17:57:08.197
cmgsamlx202s5h9i6ogoqajhr	Grupo celebrando	Grupo celebrando	Grupo celebrando	“36 Aniversario Club Dptvo Juventud Católica 1976” Vladimir de niño vivía solo en el pueblo porque el criadero donde trabajaba se fueron y lo dejaron solo. Se hizo amigo de Eduardo por el fútbol. La familia Araya terminó armándole un dormitorio en sus pesebreras, cuando le dio una infección en una muela y necesitó tratamiento ya se quedó en la casa, y fue como otro hermano para ellos.  	A la izquierda nn, Adriana Serrano, Eduardo Araya, Vladimir Ibañez y su esposa Juana Gallardo	1976	1970			2	María Araya	Procultura	2025-10-15 17:57:11.414	2025-10-15 17:57:11.414
cmgsamook02sjh9i6fomkxj47	Tres hombres de huaso	Tres hombres de huaso	Tres hombres de huaso		Eduardo Araya, Pedro Araya (padre), Ernesto Gallardo (compadre)	hacia 1970	1970			2	María Araya	Procultura	2025-10-15 17:57:14.997	2025-10-15 17:57:14.997
cmgsamvtk02tih9i6zyagrkkc	Familia con bicicleta y coche de muñecas	Familia con bicicleta y coche de muñecas	Familia con bicicleta y coche de muñecas en El Arrayán		Rafael Gutierrez, Felipe Gutierrez, Lili Pereira, Mónica Gutierrez	1979	1970	El Arrayán	1979. El Arrayán	2	Rodolfo Gutierrez	Procultura	2025-10-15 17:57:24.248	2025-10-15 17:57:24.248
cmgsamx8g02tph9i6dclutool	Familia frente a su casa	Familia frente a su casa	Familia frente a su casa en Casa familia Gutierrez		Lili Pereira, Rafael Gutierrez, Monica Gutierrez, Felipe Gutierrez	1979	1970	El Arrayán	1979. Casa familia Gutierrez	2	Rodolfo Gutierrez	Procultura	2025-10-15 17:57:26.08	2025-10-15 17:57:26.08
cmgsanpvf02uvh9i6o9jrq6tb	Mesa de novios	Mesa de novios	Mesa de novios en Pueblo de Lo Barnechea		Desde la izq Adriana Encina, Juan Salas, Rosa Eliana Diaz. En primer plano maria Soledad Sorrel Salas. Penultima en la mesa María , junto a Luis Villarroel	1970-1980	1970	Pueblo de Lo Barnechea	preguntar a don cheo. Década de 1970. Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 17:58:03.196	2025-10-15 17:58:03.196
cmgsansl502v2h9i6l9u8f2u2	Matrimonio	Matrimonio	Matrimonio en Pasaje los Patos	Casa de Quena Moya	Carmen Pino, Nene Salcedo, Carlos Gonzalez, Eugenia Moya, Victor Savando	1972	1970	Pueblo de Lo Barnechea	30-9-72. Casa de Quena Moya en Pasaje los Patos	2	Carmen Pino	Procultura	2025-10-15 17:58:06.714	2025-10-15 17:58:06.714
cmgsanton02v9h9i6upnpoy0p	Graduación	Graduación	Graduación en el colegio parroquial		Viviana Gonzalez y profesora Alicia	1975	1970	Pueblo de Lo Barnechea	1975. Graduacion colegio parroquial	2	Carmen Pino	Procultura	2025-10-15 17:58:08.136	2025-10-15 17:58:08.136
cmgsbbmof04ikh9i6kz6xxe7o	Dos huasos con banderas	Dos huasos con banderas	Dos huasos con banderas							2	Rocío Muñoz	Procultura	2025-10-15 18:16:38.799	2025-10-15 18:16:38.799
cmgsanvkq02vnh9i60fqkpfmq	Reverso carnet de niño	Reverso carnet de niño	Reverso carnet de niño			1977	1970	Pueblo de Lo Barnechea	1977. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 17:58:10.586	2025-10-15 17:58:10.586
cmgsao5bi02wfh9i6t1fd7uv4	Retrato de señora 2	Retrato de señora 2	Retrato de señora en Pueblo de Lo Barnechea	Fotovelkon. Ahumada 340, Santiago		1978	1970	Pueblo de Lo Barnechea	6 abril 1978. Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 17:58:23.215	2025-10-15 17:58:23.215
cmgsao7zb02wmh9i6tt2u9huz	Trabajadores pollo al cognac 2	Trabajadores pollo al cognac 2	Trabajadores del local "El pollo al cognac"			1973	1970	Pueblo de Lo Barnechea	Febrero 1973. Local Pollo al Cognac	2	Juan Carlos Salas	Procultura	2025-10-15 17:58:26.663	2025-10-15 17:58:26.663
cmgsaohzp02xeh9i6esxa25zc	Comida en Pollo Al Cognac 	Comida en Pollo Al Cognac 	Comida en el local "El pollo al cognac"			1970-1980	1970	Pueblo de Lo Barnechea	Década 1970. Restaurante Pollo al Cognac	2	Juan Carlos Salas	Procultura	2025-10-15 17:58:39.637	2025-10-15 17:58:39.637
cmgsaovrh02xzh9i6gmljov5z	Jóvenes recibiendo medallas	Jóvenes recibiendo medallas	Jóvenes recibiendo medallas en Pueblo de Lo Barnechea	Posiblemente un campeonato de ciclismo	Juan Salas entregando medallas	hacia 1970	1970	Pueblo de Lo Barnechea	Circa 1970. Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 17:58:57.485	2025-10-15 17:58:57.485
cmgsapsdj02ykh9i67102gsm7	Dos mujeres jóvenes	Dos mujeres jóvenes	Dos mujeres jóvenes en casa de una amiga, antiguo centro lector		Lucía Solis y Ana Matteo (cuñadas)	hacia 1978	1970	Pueblo de Lo Barnechea	Circa 1978. Casa de una amiga,  antiguo centro lector	2	Ana Matteo Rojas	Procultura	2025-10-15 17:59:39.751	2025-10-15 17:59:39.751
cmgsaq17002zch9i6uvf5djce	Niño 	Niño 	Niño celebrando su segundo cumpleaños en El Arrayán		Jorge Maureira Gana	1975	1970	El Arrayán	22 de Julio de 1975. Celebrando su segundo cumpleaños en casa en El Arrayan	2	Margarita Gana	Procultura	2025-10-15 17:59:51.18	2025-10-15 17:59:51.18
cmgsaokem02xlh9i66uq7a8j3	Evento familiar en Pollo Al Cognac 	Evento familiar en Pollo Al Cognac 	Evento familiar en el local "El pollo al cognac"		Al centro con cadena larga Eliana Salas, atrás de los candelabros, Juan Arbuch, a la derecha, esposa de Pancho Franzini. 	1970-1980	1970	Pueblo de Lo Barnechea	Década 1970. Restaurante Pollo al Cognac	2	Juan Carlos Salas	Procultura	2025-10-15 17:58:42.765	2025-10-15 17:58:42.765
cmgsapayz02y6h9i64hdfegvs	Grupo brindando de gala	Grupo brindando de gala	Grupo de gala brindando en Lo Barnechea		Juan Salas	hacia 1970	1970	Pueblo de Lo Barnechea	Circa 1970. Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 17:59:17.174	2025-10-15 17:59:17.174
cmgsappj902ydh9i6wkhtumwe	Cueca	Cueca	Cueca en La Querencia, hostería en San Enrique		Juan Salas	1970-1980	1970	San Enrique/La Ermita/Las Condes	Década 1970. La Querencia, hostería en San Enrique	2	Juan Carlos Salas	Procultura	2025-10-15 17:59:36.069	2025-10-15 17:59:36.069
cmgsapzpq02z5h9i6qsg3v8nh	Niña con vestido	Niña con vestido	Niña con vestido en El Arrayán		Margarita Araceli Maureira Gana	1979	1970	El Arrayán	1979. El Arrayán	2	Margarita Gana	Procultura	2025-10-15 17:59:49.263	2025-10-15 17:59:49.263
cmgsaq34c02zqh9i6pnysdtqc	Niña parada en un banco	Niña parada en un banco	Niña parada en un banco en El Arrayán		Jimena Palacios a los dos años 9 meses	1978	1970	El Arrayán	29 marzo 1978. El Arrayán	2	Margarita Gana	Procultura	2025-10-15 17:59:53.676	2025-10-15 17:59:53.676
cmgsaq5mt0304h9i6pe1fjg4q	Niño con brazos a la espalda	Niño con brazos a la espalda	Niño en El Arrayán		Juan Maureira	1973	1970	El Arrayán	1973. El Arrayán	2	Margarita Gana	Procultura	2025-10-15 17:59:56.934	2025-10-15 17:59:56.934
cmgsaq7lv030ih9i6ricnfu5v	Niña en primera comunión con prima	Niña en primera comunión con prima	Niña en su primera comunión con su prima. 	Atrás cancha y población Quinchamalí. Ahora casas de Las Lomas 1, casas rojas	Ximena Riveros y Elisabeth Olivos	1973	1970	Pueblo de Lo Barnechea	importante porque se ve paisaje. 1973. Atrás cancha y población Quinchamalí. Ahora casas de Las Lomas 1, casas rojas	2	Ximena Riveros de Araya	Procultura	2025-10-15 17:59:59.491	2025-10-15 17:59:59.491
cmgsaq900030ph9i6kee946d0	Dos niñas en graduación de octavo	Dos niñas en graduación de octavo	Dos niñas en la graduación de octavo del Colegio Parroquial		Ximena Riveros , verónica Rivera	1978	1970	Pueblo de Lo Barnechea	1978. Graduación octavo colegio parroquial	2	Ximena Riveros de Araya	Procultura	2025-10-15 18:00:01.297	2025-10-15 18:00:01.297
cmgsaqbl6030wh9i6efxbmud8	Viejo Pascuero del Cerro 18	Viejo Pascuero del Cerro 18	Viejo Pascuero en el Cerro 18	Era pura naturaleza en ese tiempo. Ahí la municipalidad (de las Condes) organizaba la celebración de navidad	Niña alta, Evelyn Riveros, Ximena Riveros, Esteban Riveros, Luis Riveros	hacia 1972	1970	Cerro 18	Circa 1972. Cerro 18, era pura naturaleza en ese tiempo, pero ahí la municipalidad (de las Condes) organizaba la celebración de navidad	2	Ximena Riveros de Araya	Procultura	2025-10-15 18:00:04.65	2025-10-15 18:00:04.65
cmgsaqdv60313h9i6f2ic4owx	Escolares alrededor de la mesa	Escolares alrededor de la mesa	Escolares alrededor de una mesa en la sede del centro de Madres de la población San Antonio	hoy parte de Lo Ermita	Catequista: María Inés Gajardo. Niño: Luis .Niñas: Alicia, Sandra	1970-1980	1970	San Enrique/La Ermita/Las Condes	Década de 1970. Sede del centro de Madres de la población San Antonio; hoy parte de Lo Ermita	2	Ximena Riveros de Araya	Procultura	2025-10-15 18:00:07.602	2025-10-15 18:00:07.602
cmgsaqgid031ah9i62vkqbx3k	Monja junto a niños de primera comunión	Monja junto a niños de primera comunión	Monja junto a niños de primera comunión en Iglesia Santa Rosa	Reproducción de foto antigua	Susana Ibañez, Pedro Araya (Robi)	1977	1970	Pueblo de Lo Barnechea	1977. Iglesia Santa Rosa	2	Ximena Riveros de Araya	Procultura	2025-10-15 18:00:11.029	2025-10-15 18:00:11.029
cmgsaqxew031hh9i6q37c51ag	Familia posando frente a pared de madera	Familia posando frente a pared de madera	Familia posando frente a pared de madera en San Antonio		Ivan Riveros, Ximena Riveros, Evelyn Riveros, Luis Riveros (padre), Esteban Riveros, María Inés Gajardo, Máximo Riveros	1978	1970	Pueblo de Lo Barnechea	1978. Casa en San Antonio	2	Ximena Riveros de Araya	Procultura	2025-10-15 18:00:32.936	2025-10-15 18:00:32.936
cmgsar05i031oh9i6y8uwvaoq	Pareja abordando un avion	Pareja abordando un avion	Pareja abordando un avión	Viajaban a ver su hijo Patricio a Australia	Ernesto Maira y Valentina Rojas	hacia 1977	1970	Otro	Circa 1977. Viajando a ver su hijo patricio a Australia	2	Ana Matteo Rojas	Procultura	2025-10-15 18:00:36.486	2025-10-15 18:00:36.486
cmgsar2rj031vh9i65uqhtyga	Novios y dos personas	Novios y dos personas	Novios y dos personas en una casa en Los Patos, hoy "La Divina Comida"		Petronila Olivares, Angélica Salcedo, Alejandro Maira, Oscar Maira (tío)	hacia 1975	1970	Pueblo de Lo Barnechea	Circa 1975. Casa en Los Patos, hoy la Divina Comida	2	Ana Matteo Rojas	Procultura	2025-10-15 18:00:39.871	2025-10-15 18:00:39.871
cmgsar56m0322h9i6vyft5ybr	Mujeres conversando	Mujeres conversando	Mujeres conversando en Pueblo de Lo Barnechea		Alicia Del'l Orto, al centro Ana Matteo, amiga	hacia 1970	1970	Pueblo de Lo Barnechea	Circa 1970. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:00:43.006	2025-10-15 18:00:43.006
cmgsar7k00329h9i6bsx0p3v8	Tres amigas	Tres amigas	Tres amigas en Pueblo de Lo Barnechea		Alicia Dell'Orto, Veronica Caro, amiga	hacia 1970	1970	Pueblo de Lo Barnechea	Circa 1970. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:00:46.081	2025-10-15 18:00:46.081
cmgsara12032gh9i680ct0oid	Hombre Joven	Hombre Joven	Hombre Joven en Pueblo de Lo Barnechea		Alejandro Maira Rojas	hacia 1970	1970	Pueblo de Lo Barnechea	Circa 1970. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:00:49.285	2025-10-15 18:00:49.285
cmgsarclk032nh9i6mx73z8zy	Novios	Novios	Novios en Parroquia Santa Rosa		Angélica Salcedo y Alejandro maira	hacia 1975	1970	Pueblo de Lo Barnechea	Circa 1975. Parroquia Santa Rosa	2	Ana Matteo Rojas	Procultura	2025-10-15 18:00:52.616	2025-10-15 18:00:52.616
cmgsardr9032uh9i6aj3lc9qr	Niño y perro	Niño y perro	Niño y perro en Pueblo de Lo Barnechea		Guillermo Alfredo Orrego Matteo y su perro	1977	1970	Pueblo de Lo Barnechea	Octubre 1977. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:00:54.117	2025-10-15 18:00:54.117
cmgsarew20331h9i6yxogsojb	Mujer frente a casa	Mujer frente a casa	Mujer frente a casa familiar en Los Patos, actual restaurante "Divina Comida"		Ana Matteo	1977	1970	Pueblo de Lo Barnechea	Agosto 1977. Casa familiar en Los Patos, actual restaurante Divina Comida	2	Ana Matteo Rojas	Procultura	2025-10-15 18:00:55.586	2025-10-15 18:00:55.586
cmgsarg150338h9i6y90ltdsa	Dos mujeres	Dos mujeres	Dos mujeres en Pueblo de Lo Barnechea		Ana Matteo y Marcela, profesora de su hijo	1977	1970	Pueblo de Lo Barnechea	Agosto 1977. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:00:57.065	2025-10-15 18:00:57.065
cmgsargyz033fh9i6vmvyf3rw	Dos hombres en cancha de futbol	Dos hombres en cancha de futbol	Dos hombres en cancha de fútbol de Lo Barnechea		Alberto Meneses y Roberto Castro	1970-1980	1970	Pueblo de Lo Barnechea	Década de 1970. Pueblo de Lo Barnechea	2	Alberto Meneses	Procultura	2025-10-15 18:00:58.283	2025-10-15 18:00:58.283
cmgsaribq033mh9i6q1ih2g85	Equipo viejos crack 	Equipo viejos crack 	Equipo de fútbol en las canchas abajo de la iglesia	Equipo ¿viejos crack?	Manue Araya,  De Roja, Reyes, Soto, Huerta, Aracena, NN, NN, de camisa celeste Alberto Chico Meneses (DT). Abajo: Chito Soto, Conejera, NN, NN, Cheo Villarroel	hacia 1971	1970	Pueblo de Lo Barnechea	Circa 1971. Canchas abajo de la iglesia	2	Alberto Meneses	Procultura	2025-10-15 18:01:00.038	2025-10-15 18:01:00.038
cmgsas683033th9i60ri2354f	Diploma de Honor Deportes Barnechea	Diploma de Honor Deportes Barnechea	Diploma de Honor Deportes Barnechea 		Alberto Meneses	1971	1970	Pueblo de Lo Barnechea	1971. Pueblo de Lo Barnechea	2	Alberto Meneses	Procultura	2025-10-15 18:01:31.011	2025-10-15 18:01:31.011
cmgsasj5x034zh9i62646f70m	Huaso a caballo	Huaso a caballo	Huaso a caballo en Calla Lastra		Jorge Guerra	hacia 1975	1970	Pueblo de Lo Barnechea	Circa 1975. Calla Lastra	2	Jorge Guerra	Procultura	2025-10-15 18:01:47.781	2025-10-15 18:01:47.781
cmgsassla0365h9i6e0zmnfyn	Joven con dos caballos	Joven con dos caballos	Joven con dos caballos en Pueblo de Lo Barnechea		Juan "Pelé" Araya	1978	1970	Pueblo de Lo Barnechea	1978. Pueblo de Lo Barnechea	2	Familia Araya Meneses	Procultura	2025-10-15 18:01:59.999	2025-10-15 18:01:59.999
cmgsasu68036ch9i6g9bws37r	Joven en camión	Joven en camión	Joven en camión	era de Viña, sobrino de su esposo, pasaba las vacaciones en Barnechea. Esta en Puerto Williams, trabajaba en la marina	José	1977	1970	Pueblo de Lo Barnechea	Febrero 1977. era de Viña, sobrino de su esposo, pasaba las vacaciones en Barnechea. Esta en Puerto Williams, trabajaba en la marin	2	Yoconda Moya	Procultura	2025-10-15 18:02:02.049	2025-10-15 18:02:02.049
cmgsat0a1036qh9i6hydq8x2a	Mesa completa	Mesa completa	Mesa completa en Pueblo de Lo Barnechea			hacia 1965	1960	Pueblo de Lo Barnechea	En el centro de las culturas, es de cemento, eso lo hicieron ahora. (Lease: no sirve pa na). Circa 1968. Pueblo de Lo Barnechea	2	Eliseo Villarroel	Procultura	2025-10-15 18:02:09.961	2025-10-15 18:02:09.961
cmgsat352036xh9i6hjiuclrd	Vista de una comida	Vista de una comida	Vista de una comida en Pueblo de Lo Barnechea		Extremo izq Renato Mesa (presidente), Oscar, Flaco Nell, Esposa, Alberto Salazar (mecánico), esposa de Gilberto Araya, Gilberto Araya, hija de Gilberto Araya, Ernesto Pizarro (lentes), Roberto Gonzalez, María Cristina Villarroel, Pablo, Blanca Galvez. Por el frente de la mesa, al centro María Galvez , Anita Galvez (blanco), Benjamin Valencia, Yoconda Moya, Carmen Pino. 	hacia 1965	1960	Pueblo de Lo Barnechea	ML (porque muestra las celebraciones del club y de esta tenemos  todos los nombres). 1990 aprox. Pueblo de Lo Barnechea	2	Eliseo Villarroel	Procultura	2025-10-15 18:02:13.67	2025-10-15 18:02:13.67
cmgsat62k0374h9i608h91mix	Mozos atendiendo la comida	Mozos atendiendo la comida	Mozos atendiendo la comida en Pueblo de Lo Barnechea	“Luis Ortiz Valencia”		hacia 1965	1960	Pueblo de Lo Barnechea	Circa 1959. Pueblo de Lo Barnechea	2	Eliseo Villarroel	Procultura	2025-10-15 18:02:17.468	2025-10-15 18:02:17.468
cmgsatbvi037ih9i619trnk2k	Equipo de mujeres frente a Escuela Militar	Equipo de mujeres frente a Escuela Militar	Equipo de básquetbol femenino "Las cafeteras" frente a la Escuela Militar 		Al centro de traje, señorita Digna Cruz, directora de las damas del club	hacia 1968	1960	Santiago	ML (esta o una de las que siguen, para visibilizar deporte femenino). Circa 1968. Escuela Militar, “Las cafeteras” Jugaban Basquetbol	2	Eliseo Villarroel	Procultura	2025-10-15 18:02:24.99	2025-10-15 18:02:24.99
cmgsau6gc03a8h9i6n3rqvuzp	Dos hombres frente a parrilla	Dos hombres frente a parrilla	Dos hombres frente a parrilla en Pueblo de Lo Barnechea		Héctor Torreblanca (izquierda)	1960-1970	1960	Pueblo de Lo Barnechea	Década 1960. Pueblo de Lo Barnechea	2	Familia Soto Torreblanca	Procultura	2025-10-15 18:03:04.621	2025-10-15 18:03:04.621
cmgsau91903afh9i64z6jnsk2	Grupo de niños frente a una mesa	Grupo de niños frente a una mesa	Grupo de niños frente a una mesa en Pueblo de Lo Barnechea	“Cumpleaños de Gaby”	Juan Rafael "Pele" Araya, Raquel Torreblanca, Antonia Araya, Elia Torreblanca, Alejandra Araya, Ana Wanda Herrera, Gabriela Araya, Yanko Herrera, Ana Iris, Mario Araya, Pilar y hermana	1963	1960	Pueblo de Lo Barnechea	1963. Pueblo de Lo Barnechea	2	Familia Soto Torreblanca	Procultura	2025-10-15 18:03:07.965	2025-10-15 18:03:07.965
cmgsauetl03ath9i6wydul3ot	Tres arqueros del juventud católica	Tres arqueros del juventud católica	Tres arqueros del Juventud Católica en el estadio Vitacura	Copa Perú, organizada por embajada del Perú. Estadio Vitacura, actual Saint George.	Patricio Villarroel, Heriberto Erazo, Carlos Zamorano	hacia 1967	1960	Santiago	Circa 1967. Copa Peru, organizada por embajada del peru, en el estadio Vitacura, actual Saint George	2	Patricio Villarroel	Procultura	2025-10-15 18:03:15.466	2025-10-15 18:03:15.466
cmgsaugqn03b0h9i6zh3t7e39	Equipo infantil de futbol	Equipo infantil de futbol	Equipo infantil de fútbol en Pueblo de Lo Barnechea			1960-1970	1960	Pueblo de Lo Barnechea	Década de 1950 o 1960. Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:03:17.951	2025-10-15 18:03:17.951
cmgsaul5o03beh9i6oiug2ekc	Tres hombres junto a reina de la FISA	Tres hombres junto a reina de la FISA	Tres hombres junto a reina de la FISA en Pueblo de Lo Barnechea		Derecha Juan salas	hacia 1967	1960	Pueblo de Lo Barnechea	Circa 1967. Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:03:23.677	2025-10-15 18:03:23.677
cmgsaurum03bzh9i691un8wcj	Matrimonio sentados	Matrimonio sentados	Matrimonio sentados en casa familiar en Nebraska		3ra Eloisa Contreras, Juan Contreras, Novia Iris Contreras Dotte, marido Luis Aravena, atrás niño Augusto Contreras, Olga (mamá de la novia)	hacia 1965	1960	Población Nebraska	Circa 1965. Casa familiar en Nebraska	2	Juan Contreras Valdivia	Procultura	2025-10-15 18:03:32.35	2025-10-15 18:03:32.35
cmgsauwre03ckh9i67ox2qzmi	Reverso carnet de salud	Reverso carnet de salud	Reverso carnet de salud en Pueblo de Lo Barnechea			1968	1960	Pueblo de Lo Barnechea	1968. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:03:38.714	2025-10-15 18:03:38.714
cmgsav4gr03d5h9i6huj0cn4f	Tres hombres en Pollo al Cognac	Tres hombres en Pollo al Cognac	Tres hombres en el restaurante "El pollo al cognac" 		Adicionista del local, Juan Salas, Raul Salas	1960-1970	1960	Pueblo de Lo Barnechea	Década de 1960. Restaurante Pollo al Cognac	2	Juan Carlos Salas	Procultura	2025-10-15 18:03:48.7	2025-10-15 18:03:48.7
cmgsas89d0340h9i62izt0uwz	Mujer entregando diploma a hombre	Mujer entregando diploma a hombre	Mujer entregando diploma a hombre en la sede del club El Esfuerzo	Premio por ser un buen dirigente del club	María Chavez y compadre Juan Sepúlveda	hacia 1977	1970	Pueblo de Lo Barnechea	Circa 1977. Sede del club El Esfuerzo	2	María Chavez	Procultura	2025-10-15 18:01:33.65	2025-10-15 18:01:33.65
cmgsasb4u0347h9i6gcvvdevp	Estudiante junto a dos mujeres	Estudiante junto a dos mujeres	Estudiante junto a dos mujeres en la graduación del Colegio 177		Isolina Quieroz, profesora Lila Mercado y Cecilia Quiroz	1978	1970	Pueblo de Lo Barnechea	ML. 1978. Graduación del colegio 177 	2	Familia Quiroz Mendoza	Procultura	2025-10-15 18:01:37.374	2025-10-15 18:01:37.374
cmgsasfhz034lh9i6tbamb39u	Hombre con caballo	Hombre con caballo	Hombre con caballo en el Santiago Paperchase Club, en La Pirámide		Carlos Quiroz Pérez	hacia 1973	1970	Santiago	Circa 1973. Santiago Pepperchase club en La Pirámide	2	Familia Quiroz Mendoza	Procultura	2025-10-15 18:01:43.031	2025-10-15 18:01:43.031
cmgsashs2034sh9i6lwb6r4wq	Cumpleaños de niño	Cumpleaños de niño	Cumpleaños de un niño en casa en Gran Avenida		Elizabeth Zuñiga, Patricia Zuñiga, atrás Carlos Quiroz, Rosa Quiroz, José Catalan, Alicia, Lorena, Ana Quiroz, Romualda Pérez (abuela), NN. Niños: NN, Chini, José Catalán "Giyo", Francisco, NN. 	hacia 1976	1970	Santiago	Circa 1976. Casa en Gran Avenida	2	Familia Quiroz Mendoza	Procultura	2025-10-15 18:01:45.986	2025-10-15 18:01:45.986
cmgsaslre035dh9i67zukssbv	Hombre en caballo de cuasimodo	Hombre en caballo de cuasimodo	Hombre en caballo de cuasimodo en Calla Lastra		Jorge Guerra	hacia 1975	1970	Pueblo de Lo Barnechea	C. Garrido 97 Barnechea era un fotógrafo, iba a los eventos a sacar fotos y luego las iba a dejar a la casa. . Circa 1975. Calla Lastra	2	Jorge Guerra	Procultura	2025-10-15 18:01:51.146	2025-10-15 18:01:51.146
cmgsasplb035rh9i6sqnqyry1	Serie hombre a caballo 4	Serie hombre a caballo 4	Caballo en Kempo, cerca del Río Colorado en la cordillera de Lo Barnechea		Juan "Pelé" Araya	1975	1970	Farellones	1975. Quempo, cordillera de Lo Barnechea cerca del río Colorado	2	Familia Araya Meneses	Procultura	2025-10-15 18:01:56.111	2025-10-15 18:01:56.111
cmgsasqst035yh9i6uoz5uy58	Cuatro cuasimodista a caballo	Cuatro cuasimodista a caballo	Cuatro cuasimodistas a caballo en Pueblo de Lo Barnechea		Raul Meza, Rodrigo Noriega, Adrian Yañez, Juan "Pelé" Araya	1976	1970	Pueblo de Lo Barnechea	1976. Pueblo de Lo Barnechea	2	Familia Araya Meneses	Procultura	2025-10-15 18:01:57.677	2025-10-15 18:01:57.677
cmgsasx7i036jh9i6y31tg6cb	Mesa a medio ocupar	Mesa a medio ocupar	Mesa a medio ocupar en Salón "La Cerámica" de la iglesia	Aniversario del Barnechea		hacia 1965	1960	Pueblo de Lo Barnechea	Que sea  un lugar donde la gente del pueblo se junte. . Circa 1965. Salón "La Cerámica" de la iglesia	2	Eliseo Villarroel	Procultura	2025-10-15 18:02:05.982	2025-10-15 18:02:05.982
cmgsat964037bh9i676te9j9n	Hombres conversando	Hombres conversando	Hombres conversando en Pueblo de Lo Barnechea	“Aniversario en la Ceramica”	Renato Mesa, Dirigente de Miramonte (equipo al lado del estadio Israelita), Tito	hacia 1965	1960	Pueblo de Lo Barnechea	Circa 1956. Pueblo de Lo Barnechea	2	Eliseo Villarroel	Procultura	2025-10-15 18:02:21.483	2025-10-15 18:02:21.483
cmgsatewp037ph9i6mq4oehwf	Matrimonio junto a los padres de la novia.	Matrimonio junto a los padres de la novia.	Novios junto a los padres de la novia	Matrimonio de Domingo Rodríguez e Hilda Rosa Vera Reyes. Se casaron en Parroquia Santa Rosa, celebraron en su casa en calle Maira 93.	Domingo Rodríguez, Hilda Rosa Vera Reyes. Izquierda Rosa Ester Reyes Miranda, madre de la novia, Juan Vera Pino.	1962	1960	Pueblo de Lo Barnechea	28 de abril de 1962. Se casaron en Parroquia Santa Rosa, celebraron en su casa en calle Maira 93.	2	Mariela Bravo	Procultura	2025-10-15 18:02:28.922	2025-10-15 18:02:28.922
cmgsatjg10383h9i6rn4wcmxz	Tres niñas	Tres niñas	Tres niñas en Casa de Gioconda Moya en Los Patos	Año debe estar mal (decía "1995" pero lo borré. Es muy antigua la foto. Confirmarlo en la planilla original del archivo de Procultura.	Hilda Valencia Moya, Carmen Moya, Rosa Leonor Moya (tías)	1965	1960	Pueblo de Lo Barnechea	1965. Casa de Gioconda Moya en Los Patos	2	Yoconda Moya	Procultura	2025-10-15 18:02:34.801	2025-10-15 18:02:34.801
cmgsato7x038hh9i65mmsxwvd	Mujer sentada entre dos hombres	Mujer sentada entre dos hombres	Mujer sentada entre dos hombres en Pueblo de Lo Barnechea		“Cotón”, Gladys Moya, Benjamín Valencia	1960-1970	1960	Pueblo de Lo Barnechea	Década 1960. Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:02:40.99	2025-10-15 18:02:40.99
cmgsatqqv038oh9i62a6zac6z	Niña en primera comunión	Niña en primera comunión	Niña en primera comunión en Parroquia Santa Rosa		Hilda Valencia Moya	hacia 1964	1960	Pueblo de Lo Barnechea	Circa 1964. Parroquia Santa Rosa	2	Yoconda Moya	Procultura	2025-10-15 18:02:44.263	2025-10-15 18:02:44.263
cmgsaty3o039gh9i6un9n8ir8	Tres niños en primera comunión	Tres niños en primera comunión	Tres niños en primera comunión en Iglesia de Barnechea		Ana Torreblanca, Raquel Torreblanca, Elia Torreblanca, Renato Torreblanca (hermanos)	1969	1960	Pueblo de Lo Barnechea	Familia Soto Torreblanca. 14 Diciembre 1969. Iglesia de Barnechea	2	Familia Soto Torreblanca	Procultura	2025-10-15 18:02:53.796	2025-10-15 18:02:53.796
cmgsau1u5039uh9i6yno4rw5z	Niña en cuarto año	Niña en cuarto año	Niña en cuarto año en Pueblo de Lo Barnechea		Elia Torreblanca	1968	1960	Pueblo de Lo Barnechea	1968. Pueblo de Lo Barnechea	2	Familia Soto Torreblanca	Procultura	2025-10-15 18:02:58.637	2025-10-15 18:02:58.637
cmgsauiuo03b7h9i6la3nmwed	Pareja en baile	Pareja en baile	Pareja en baile en Posiblemente La Querencia		María Eugenia Salas y José "Pepe" Soto	1960-1970	1960	San Enrique/La Ermita/Las Condes	Década de 1960. Posiblemente La Querencia	2	Juan Carlos Salas	Procultura	2025-10-15 18:03:20.688	2025-10-15 18:03:20.688
cmgsauz3z03crh9i6i8psjyt9	Hombre junto a reina de la FISA	Hombre junto a reina de la FISA	Hombre junto a reina de la FISA, Cerrillos		Juan 	1968	1960	Santiago	1968. Local de la FISA, Cerrillos	2	Juan Carlos Salas	Procultura	2025-10-15 18:03:41.759	2025-10-15 18:03:41.759
cmgsav1xm03cyh9i66hvauf9t	Novia junto a grupo	Novia junto a grupo	Novia junto a grupo en Pueblo de Lo Barnechea		Juan Salas, Vivente, Maria Eugenia Salas, Vilda Arbuch,  Francisco Franzini, novio Patricio Salas, Reinaldo Llanos (abuelo Vilda), a la derecha Rosa Eliana Díaz	1967	1960	Pueblo de Lo Barnechea	1967. Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:03:45.417	2025-10-15 18:03:45.417
cmgsav90m03djh9i6lomt148d	Cinco personas almorzando	Cinco personas almorzando	Cinco personas almorzando en "El pollo al cognac"	C. Garrido 97 Barnechea	2do Luis Oscar Sorrell, Maria Eugenia Salas, señora chicana, Rosa Emilia. Garzón Victor Sabando	hacia 1963	1960	Pueblo de Lo Barnechea	Circa 1963. Pollo al Cognac. 	2	Juan Carlos Salas	Procultura	2025-10-15 18:03:54.598	2025-10-15 18:03:54.598
cmgsavbmd03dqh9i6yi164qg3	Tres personas almorzando y mozo	Tres personas almorzando y mozo	Tres personas almorzando y mozo en "El pollo al cognac"	C. Garrido 97 Barnechea	2do Luis Oscar Sorrell, Maria Eugenia Salas	hacia 1963	1960	Pueblo de Lo Barnechea	preguntar a chicanos. Circa 1963. Pollo al Cognac. 	2	Juan Carlos Salas	Procultura	2025-10-15 18:03:57.974	2025-10-15 18:03:57.974
cmgsavgsa03e4h9i6pwjnz9ek	Pareja soplando velas	Pareja soplando velas	Pareja soplando velas en "El pollo al cognac"	C. Garrido 97 Barnechea	María Eugenia, mamá de las chicanas, Rosa Eliana Diaz, Juan Salas. 	hacia 1963	1960	Pueblo de Lo Barnechea	Circa 1963. Pollo al Cognac. 	2	Juan Carlos Salas	Procultura	2025-10-15 18:04:04.667	2025-10-15 18:04:04.667
cmgsasdwn034eh9i6r47tf2q0	Matrimonio del brazo	Matrimonio del brazo	Matrimonio del brazo en una casa en Gran Avenida		Isolina Quiroz, Cecilia Quiroz, Arturo Zuñiga (novio), Alicia (novia), Manuel Martínez, María Ester Quiroz, Edith Quiroz, Angélica Quiroz	1978	1970	Santiago	1978. Casa en Gran Avenida	2	Familia Quiroz Mendoza	Procultura	2025-10-15 18:01:40.967	2025-10-15 18:01:40.967
cmgsaskfh0356h9i6drf8g5uq	Huaso de frente	Huaso de frente	Huaso de frente en Calla Lastra		Jorge Guerra	hacia 1975	1970	Pueblo de Lo Barnechea	Circa 1975. Calla Lastra	2	Jorge Guerra	Procultura	2025-10-15 18:01:49.422	2025-10-15 18:01:49.422
cmgsaso6v035kh9i6xrm9heg2	Amigos en mesa	Amigos en mesa	Amigos en mesa en un matrimonio en la calle Cuatro Vientos	Matrimonio del Chico Reyes	Juan Bonavena, Raul Macaya, Fira Cortés, Exequiel Molina, Manuel "Mula" Araya, Marco, Alfonso Molina, Juan "Pele" Araya, Isabel Meza, Raul Meza	1979	1970	Pueblo de Lo Barnechea	1979. Casamiento del Chico Reyes en calle Cuatro Vientos	2	Familia Araya Meneses	Procultura	2025-10-15 18:01:54.295	2025-10-15 18:01:54.295
cmgsathuk037wh9i67edoh6bp	Grupo de personas	Grupo de personas	Grupo de personas en Pueblo de Lo Barnechea	Matrimonio de Domingo Rodríguez e Hilda Rosa Vera Reyes	Familia del novio, Domingo "Chumita" Rodríguez. Al centro su padre Santiago Rodríguez, a su izquierda Rosa Ester Reyes.	1962	1960	Pueblo de Lo Barnechea	28 de abril de 1962. Pueblo de Lo Barnechea	2	Mariela Bravo	Procultura	2025-10-15 18:02:32.733	2025-10-15 18:02:32.733
cmgsatlau038ah9i6udhv7fmi	Hombres frente a mesa al aire libre	Hombres frente a mesa al aire libre	Hombres frente a mesa al aire libre en Pueblo de Lo Barnechea	“Foto Studio Social. 24 Mar 1963”	Armando Gomez, Benjamin Valencia, Miguel Maira, el de atrás nn	1963	1960	Pueblo de Lo Barnechea	1963. Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:02:37.205	2025-10-15 18:02:37.205
cmgsatt96038vh9i6vpo6y534	Celebración de Primera Comunión	Celebración de Primera Comunión	Celebración de Primera Comunión en Casa del pasaje Los Patos		Niña Hilda Valencia Moya y sus amigos	hacia 1964	1960	Pueblo de Lo Barnechea	Circa 1964. Casa en pasaje Los Patos	2	Yoconda Moya	Procultura	2025-10-15 18:02:47.514	2025-10-15 18:02:47.514
cmgsatvy90392h9i6fc2f83pv	Bebé frente a pino	Bebé frente a pino	Bebé frente a pino en Pueblo de Lo Barnechea		Paulina Valencia Moya	1962	1960	Pueblo de Lo Barnechea	1962. Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:02:51.009	2025-10-15 18:02:51.009
cmgsatwvf0399h9i6daxifeeq	Grupo de jóvenes en una vereda	Grupo de jóvenes en una vereda	Grupo de jóvenes en una vereda en Pueblo de Lo Barnechea		Al centro abajo, Pedro Barrera?	1960-1970	1960	Pueblo de Lo Barnechea	Década del 1960. Pueblo de Lo Barnechea	2	Patricia Dotte	Procultura	2025-10-15 18:02:52.203	2025-10-15 18:02:52.203
cmgsatzqj039nh9i6buqs1ho6	Dos niñas disfrazadas	Dos niñas disfrazadas	Dos niñas disfrazadas en Pueblo de Lo Barnechea		Raquel Torreblanca, Gabriela Araya	1965	1960	Pueblo de Lo Barnechea	1965. Pueblo de Lo Barnechea	2	Familia Soto Torreblanca	Procultura	2025-10-15 18:02:55.916	2025-10-15 18:02:55.916
cmgsau3kf03a1h9i6m7usw1y7	Tres niñas disfrazadas	Tres niñas disfrazadas	Tres niñas disfrazadas en Pueblo de Lo Barnechea		Raquel Torreblanca, nn, Elia Torreblanca	1960-1970	1960	Pueblo de Lo Barnechea	Década 1960. Pueblo de Lo Barnechea	2	Familia Soto Torreblanca	Procultura	2025-10-15 18:03:00.879	2025-10-15 18:03:00.879
cmgsaubmx03amh9i6syczlhwk	Niña y monja	Niña y monja	Niña y monja en Pueblo de Lo Barnechea		Raquel Torreblanca, Madre Nancy	1969	1960	Pueblo de Lo Barnechea	14 Diciembre 1969. Pueblo de Lo Barnechea	2	Familia Soto Torreblanca	Procultura	2025-10-15 18:03:11.337	2025-10-15 18:03:11.337
cmgsaumfv03blh9i6s3btu3zc	Mujer india junto a tres hombres	Mujer india junto a tres hombres	Mujer india junto a tres hombres en Pueblo de Lo Barnechea		4to Juan Salas	1960-1970	1960	Pueblo de Lo Barnechea	Década de 1960. Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:03:25.339	2025-10-15 18:03:25.339
cmgsaup8a03bsh9i6tsk4uetm	Tres personas en mesa de restaurante	Tres personas en mesa de restaurante	Tres personas en mesa de restaurante del local "El pollo al cognac" en FISA		Juan Carlos Salas junto a promotoras	1960-1970	1960	Pueblo de Lo Barnechea	Década de 1960. Local Pollo al Cognac en FISA	2	Juan Carlos Salas	Procultura	2025-10-15 18:03:28.954	2025-10-15 18:03:28.954
cmgsauulr03c6h9i67wq09w1m	Matrimonio	Matrimonio	Matrimonio en casa familiar en Nebraska		Hernan Contreras, Eloisa Contreras, Luis Aravena, Iris Contreras, Graciela Dotte, Juan Contreras. Abajo niño Contreras y hermana Graciela Contreras	hacia 1965	1960	Población Nebraska	Circa 1965. Casa familiar en Nebraska	2	Juan Contreras Valdivia	Procultura	2025-10-15 18:03:35.919	2025-10-15 18:03:35.919
cmgsauvmo03cdh9i6qwws1r6q	Carnet de salud	Carnet de salud	Carnet de salud en Pueblo de Lo Barnechea		Ernesto Maira Maira	1968	1960	Pueblo de Lo Barnechea	1968. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:03:37.249	2025-10-15 18:03:37.249
cmgsav6h703dch9i6prsb4865	Pareja bailando	Pareja bailando	Pareja bailando en Pueblo de Lo Barnechea	Foto Nuñez. Miraflores 353 - Tel. 80633 Santiago	Juan Salas y amiga Niza	hacia 1964	1960	Pueblo de Lo Barnechea	Circa 1964. Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:03:51.308	2025-10-15 18:03:51.308
cmgsave6h03dxh9i6dna13frq	Cuatro personas a la mesa	Cuatro personas a la mesa	Cuatro personas a la mesa en "El pollo al cognac"	C. Garrido 97 Barnechea	Juan Carlos Salas, niña de los Chicanos	hacia 1963	1960	Pueblo de Lo Barnechea	Circa 1963. Pollo al Cognac. 	2	Juan Carlos Salas	Procultura	2025-10-15 18:04:01.289	2025-10-15 18:04:01.289
cmgsavx2903ebh9i6w2q8skej	Reina de la FISA	Reina de la FISA	Reina de la FISA en Pueblo de Lo Barnechea		Juan Salas junto a reina de la FISA 	1968	1960	Pueblo de Lo Barnechea	1968. Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:04:25.736	2025-10-15 18:04:25.736
cmgsavxz803eih9i6rc4c2dog	Pareja de abuelos	Pareja de abuelos	Pareja de abuelos en Pueblo de Lo Barnechea			1969	1960	Pueblo de Lo Barnechea	importante por linda. Abril 1969. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:04:26.948	2025-10-15 18:04:26.948
cmgsavzej03eph9i6nmkjzcui	Pareja y dos niños	Pareja y dos niños	Pareja y dos niños en Pueblo de Lo Barnechea			1968	1960	Pueblo de Lo Barnechea	Julio 1968. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:04:28.796	2025-10-15 18:04:28.796
cmgsaw0y703ewh9i6a7971j7s	Dos niños frente a planta	Dos niños frente a planta	Dos niños frente a planta en Pueblo de Lo Barnechea			1968	1960	Pueblo de Lo Barnechea	Julio 1968. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:04:30.8	2025-10-15 18:04:30.8
cmgsawi4l03f3h9i6bl5mfrmi	Grupo de hombres y mulas	Grupo de hombres y mulas	Grupo de hombres y mulas en Camino a Yerba Loca	en la montaña	Olegario Gana y su hijo Antonio Gana	hacia 1960	1960	El Arrayán	Foto con rayas de lápiz pasta. Circa 1960. Camino a Yerba Loca	2	Margarita Gana	Procultura	2025-10-15 18:04:53.06	2025-10-15 18:04:53.06
cmgsawkgi03fah9i63s494y0v	Hombre montado subiendo la montaña	Hombre montado subiendo la montaña	Hombre montado subiendo la montaña en El Arrayán	en la montaña	Custodio Gana	hacia 1960	1960	El Arrayán	Circa 1960. El Arrayán	2	Margarita Gana	Procultura	2025-10-15 18:04:56.083	2025-10-15 18:04:56.083
cmgsawn6s03foh9i60jjd04vo	Hombre con mula con los ojos tapados	Hombre con mula con los ojos tapados	Hombre con mula con los ojos tapados en El Arrayán	en la montaña	Olegario Gana	1960-1970	1960	El Arrayán	Década de 1960. El Arrayán	2	Margarita Gana	Procultura	2025-10-15 18:04:59.62	2025-10-15 18:04:59.62
cmgsawln403fhh9i64olu1nd8	Hombre sentado en el cerro	Hombre sentado en el cerro	Hombre sentado en el cerro en Mina San Rafael	en la montaña	Olegario Gana 	hacia 1960	1960	El Arrayán	Circa 1960. Mina San Rafael	2	Margarita Gana	Procultura	2025-10-15 18:04:57.617	2025-10-15 18:04:57.617
cmgsawotd03fvh9i6zzosl6oa	Mineros	Mineros	Mineros en Mina La Elena	en la montaña. Atrás cerrada con una piedra grande	2do de coipa roja José Gana Fajardo, nn, Antonio Gana Valdivia, NN, Olegario Gana Hernández	1960-1970	1960	El Arrayán	Década 1960. Mina La Elena, atrás tapada con una piedra grande (la dejan cerrada)	2	Margarita Gana	Procultura	2025-10-15 18:05:01.729	2025-10-15 18:05:01.729
cmgsawqay03g2h9i67bf54sej	Hombres de noche en cerro	Hombres de noche en cerro	Hombres de noche en cerro visitando la animita de Manuel Dávila en el cajón del Arrayán	en la montaña	José Gana, Miguel Dávila, Omar Gana	hacia 1967	1960	El Arrayán	Circa 1967. Visitando la animita de Manuel Dávila en el cajón del Arrayá	2	Margarita Gana	Procultura	2025-10-15 18:05:03.658	2025-10-15 18:05:03.658
cmgsawrex03g9h9i6n7qh79ry	Jugador de futbol	Jugador de futbol	Jugador de fútbol en Club Condoritos, sector La Ermita, San Enrique	en la montaña	Jorge Maureira	1960-1970	1960	San Enrique/La Ermita/Las Condes	Década 1960. Club Condoritos, sector La Ermita, San Enrique	2	Margarita Gana	Procultura	2025-10-15 18:05:05.098	2025-10-15 18:05:05.098
cmgsawso403ggh9i6ainrra8i	Escolares	Escolares	Escolares en Colegio El campanario, Estoril		Extremo der arriba Eliana Gana	hacia 1967	1960	El Arrayán	Circa 1967. Colegio El campanario, Estoril	2	Margarita Gana	Procultura	2025-10-15 18:05:06.724	2025-10-15 18:05:06.724
cmgsawvrj03gnh9i6pzurkart	Grupo en matrimonio 3	Grupo en matrimonio 3	Grupo en matrimonio 3		Custodio Gana, Verónica, Agustín Fajardo, Graciela Fajardo	1960-1970	1960	El Arrayán		2	Margarita Gana	Procultura	2025-10-15 18:05:10.735	2025-10-15 18:05:10.735
cmgsawxcw03guh9i6orf70hek	Familia en la calle	Familia en la calle	Familia afuera de la parroquia Santa Rosa para Cuasimodo	Papel de postal	Margarita Gana, Jorge Maureira, Guillermina Gana (prima), Juan Maureira	1969	1960	El Arrayán	1969. Salida de la parroquia Santa Rosa para Cuasimodo	2	Margarita Gana	Procultura	2025-10-15 18:05:12.801	2025-10-15 18:05:12.801
cmgsawz5h03h1h9i6654252rh	Niña bebé	Niña bebé	Niña bebé en casa sector San Antonio, actual Lo Hermita		Ximena Riveros	1964	1960	San Enrique/La Ermita/Las Condes	1964. Casa sector San Antonio, actual Lo Hermita	2	Ximena Riveros de Araya	Procultura	2025-10-15 18:05:15.124	2025-10-15 18:05:15.124
cmgsax0dl03h8h9i6h33jwbes	Niño con planta	Niño con planta	Niño con planta en Pueblo de Lo Barnechea		Guillermo Alfredo Orrego Matteo	hacia 1969	1960	Pueblo de Lo Barnechea	Circa 1969. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:05:16.713	2025-10-15 18:05:16.713
cmgsax3ba03hfh9i6xnhnpom6	Mujer disfrazada de española	Mujer disfrazada de española	Mujer disfrazada de española en Casa de don Jorge	Foto se la sacó el pintor Jorge Everbeck, amigo de sus papás, para pintarla. Él iba a la cordillera a tomar fotos y luego las pintaba. En Bellas Artes debe haber cuadros. 	Ana Matteo	hacia 1962	1960	Pueblo de Lo Barnechea	vivía en club de campo (estadio) en el límite con santiago, que es de la corfo ahora. Circa 1962. Casa de don Jorge	2	Ana Matteo Rojas	Procultura	2025-10-15 18:05:20.518	2025-10-15 18:05:20.518
cmgsax47v03hmh9i6tpkdbovv	Cabeza de niña con vestido blanco	Cabeza de niña con vestido blanco	Cabeza de niña con vestido blanco en Pueblo de Lo Barnechea		Griselda Maira	hacia 1960	1960	Pueblo de Lo Barnechea	Circa 1960. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:05:21.691	2025-10-15 18:05:21.691
cmgsax56d03hth9i6z1y6w81l	Niña con vestido blanco	Niña con vestido blanco	Niña con vestido blanco		Griselda Maira	hacia 1960	1960			2		Procultura	2025-10-15 18:05:22.934	2025-10-15 18:05:22.934
cmgsax6pn03i0h9i6ldqyl8c3	Dos bebés en brazos dándose un beso	Dos bebés en brazos dándose un beso	Dos bebés en brazos dándose un beso en Pueblo de Lo Barnechea		Vestido a lunares Lucía Solis de Maira, en brazos Andrea Maira Solis; Ana Matteo tiene en brazos a Guillermo Alfredo Orrego	1968	1960	Pueblo de Lo Barnechea	Agosto 1968. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:05:24.923	2025-10-15 18:05:24.923
cmgsax86s03i7h9i67hnkke9d	Niño meciendo cuna con bebé	Niño meciendo cuna con bebé	Niño meciendo cuna con bebé en Pueblo de Lo Barnechea		Guillermo Alfredo Orrego meciendo a Andrea Maira	1968	1960	Pueblo de Lo Barnechea	Agosto 1968. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:05:26.836	2025-10-15 18:05:26.836
cmgsaxafa03ilh9i6khle3fgi	Niño pequeño frente a gruta de la virgen	Niño pequeño frente a gruta de la virgen	Niño pequeño frente a gruta de la virgen en Casa familiar en Los Patos, actual restaurante Divina Comida		Guillermo Alfredo Orrego Matteo	1968	1960	Pueblo de Lo Barnechea	CHEQUEAR. 21-6-68. Casa familiar en Los Patos, actual restaurante Divina Comida	2	Ana Matteo Rojas	Procultura	2025-10-15 18:05:29.734	2025-10-15 18:05:29.734
cmgsaxbfr03ish9i6p26bnvvi	Cumpleaños	Cumpleaños	Cumpleaños en Pueblo de Lo Barnechea			hacia 1969	1960	Pueblo de Lo Barnechea	Circa 1969. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:05:31.047	2025-10-15 18:05:31.047
cmgsaxe4z03j6h9i69wef6w7f	Jovenes echados	Jovenes echados	Jovenes echados en Pueblo de Lo Barnechea		Ernesto Maira jr, Fernando Garay, Hector Pato Maira, Pedro Araya, Ernesto Maira, Jaime Manrique	1969	1960	Pueblo de Lo Barnechea	14-9-1969. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:05:34.547	2025-10-15 18:05:34.547
cmgsaxlve03k5h9i6vc97ytyg	Grupo con niña bautizada	Grupo con niña bautizada	Grupo con niña bautizada en Casa en Tabancura	C Garrido 97 Barnechea	Dominga Ocampo Verdugo de Durán, María Chavez Sanhuesa (madre), madrina Luz, bebé María de Lourdes Ocampo Chavez, Juan Durán, Narcisa Ocampo, Rodolfo Emilio Ocampo Arcila	1964	1960		Borda, canta, escribe canciones, tiene una cueca sobre Barnechea. . Casa en Tabancura	2	María Chavez	Procultura	2025-10-15 18:05:44.571	2025-10-15 18:05:44.571
cmgsaxq5i03kjh9i67ko7xu91	Tres hermanos	Tres hermanos	Tres hermanos en Casa de unos tíos en José Joaquín Pérez		Cecilia Quiroz, Alejandro Miranda, Antonio Miranda	hacia 1965	1960	Población Nebraska	Circa 1965. Casa de unos tíos en José Joaquín Pérez	2	Familia Quiroz Mendoza	Procultura	2025-10-15 18:05:50.118	2025-10-15 18:05:50.118
cmgsaxs4u03kqh9i69olenjov	Niña con muñeca	Niña con muñeca	Niña con muñeca en casa en población Nebraska		Isolina Quiroz 	1968	1960	Población Nebraska	1968. Casa en población Nebraska	2	Familia Quiroz Mendoza	Procultura	2025-10-15 18:05:52.686	2025-10-15 18:05:52.686
cmgsaxvtp03l4h9i6bbvadevz	Ordenanzas del club Santiago Pepperchase	Ordenanzas del club Santiago Pepperchase	Ordenanzas del Santiago Pepperchase Club en un concurso de equitación		Carlos Quiroz, Alfredo Quiroz, 	hacia 1968	1960	Población Nebraska	circa 1968. Club Santiago Pepperchase, concurso de equitación	2	Familia Quiroz Mendoza	Procultura	2025-10-15 18:05:57.469	2025-10-15 18:05:57.469
cmgsaxxav03lbh9i63tru1ojg	Niños de primera comunión con sus padres	Niños de primera comunión con sus padres	Niños de primera comunión con sus padres en Casa Pasaje 5		Germán Araya Silva, Germán Araya Mallea, Olga Araya Mallea, Clorinda Mallea Olguín	1969	1960	Población Nebraska	21-12-1969. Casa Pasaje 5	2	Gema Araya	Procultura	2025-10-15 18:05:59.384	2025-10-15 18:05:59.384
cmgsax95k03ieh9i6n27n7nwa	Cumpleaños	Cumpleaños	Cumpleaños en Pueblo de Lo Barnechea			hacia 1969	1960	Pueblo de Lo Barnechea	Circa 1969. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:05:28.088	2025-10-15 18:05:28.088
cmgsaxchi03izh9i6dd2j5eir	Hombre a caballo	Hombre a caballo	Hombre a caballo en Medialuna Maipú		Guillermo Orrego	1962	1960	Cerro 18	1962. Medialuna Maipú	2	Ana Matteo Rojas	Procultura	2025-10-15 18:05:32.406	2025-10-15 18:05:32.406
cmgsaxftq03jdh9i675ug5p46	Tres hombres tomando vino	Tres hombres tomando vino	Tres hombres tomando vino en Quinta La Querencia	Foto Reportaje Social "Relámpago". E. Hoffstetter. Grajales 2152- Stgo.	Adrian "Nano" Meneses, Fernando "Rusio" Sosa, Alberto "Chico" Meneses 	1960-1970	1960	San Enrique/La Ermita/Las Condes	Década de 1960. Quinta La Querencia	2	Alberto Meneses	Procultura	2025-10-15 18:05:36.734	2025-10-15 18:05:36.734
cmgsaxgpe03jkh9i606y1pej0	Primer equipo de Barnechea	Primer equipo de Barnechea	Primer equipo de Barnechea 		Jaime Alvarez, Chaucha Ete, Anibal Legal, Efrain Bravo, "Cochino" Alarcon, Humberto Figueroa, Flaco Alvarez. Abajo: Carlos Legal, Juan Valledares, Antonio Pino, Estuardo, Julio Soto, Alberto Meneses.	1961	1960	Pueblo de Lo Barnechea	1961. Pueblo de Lo Barnechea	2	Alberto Meneses	Procultura	2025-10-15 18:05:37.874	2025-10-15 18:05:37.874
cmgsaxi7803jrh9i66exizyi4	Seis hombres sentados en cancha de futbol	Seis hombres sentados en cancha de futbol	Seis hombres sentados en una cancha de fútbol en La Calera (fueron a parchar)	Esperando el partido.	Antonio Alberto Meneses, Julio Soto, Antonio Pino, Efrain Bravo, Juan Valledares, Chaucha Ete, Tamaño. 	hacia 1960	1960		Circa 1960. La Calera (fueron a parchar)	2	Alberto Meneses	Procultura	2025-10-15 18:05:39.813	2025-10-15 18:05:39.813
cmgsaxj4p03jyh9i6e0sjbze1	Dos hombres en la nieve	Dos hombres en la nieve	Dos hombres en la nieve en Mina La Disputada	Juan trabajaba sacando cobre, Rodolfo manejaba un jeep	 Rodolfo Emilio Ocampo Arcila y Juan Durán	1960-1970	1960	Farellones	* No sabe escribir. Década de 1960. Mina La Disputada	2	María Chavez	Procultura	2025-10-15 18:05:41.018	2025-10-15 18:05:41.018
cmgsaxoj603kch9i6w7r5so66	Hombre y niño	Hombre y niño	Hombre y niño en Fuente de Soda de la Tia Elvira (única que había en el pueblo)		Ramon Meza Pinto y Ramon Meza Cortes	hacia 1962	1960	Pueblo de Lo Barnechea	Circa 1962. Fuente de Soda de la Tia Elvira (única que había en el pueblo)	2	Familia Meza Cortés	Procultura	2025-10-15 18:05:48.019	2025-10-15 18:05:48.019
cmgsaxt4g03kxh9i6y74n78q6	Grupo frente a pared de ladrillo	Grupo frente a pared de ladrillo	Grupo frente a pared de ladrillo en Pasaje 5 en Nebraska		Isolina Quiroz, María Isolina Mendoza, abuelita Adelaida Espina, María, Luz Angélica Quiroz, Arturo Zuñiga	hacia 1967	1960	Población Nebraska	Circa 1967. Pasaje 5 en Nebraska	2	Familia Quiroz Mendoza	Procultura	2025-10-15 18:05:53.968	2025-10-15 18:05:53.968
cmgsaxyxo03lih9i62n0b36eu	Niños de primera comunión junto a imagen de la Virgen	Niños de primera comunión junto a imagen de la Virgen	Niños de primera comunión junto a imagen de la Virgen en Parroquia Santa Rosa	Hoy es sacerdote	Germán Araya Mallea, Olga Araya Mallea	1969	1960	Pueblo de Lo Barnechea	21-12-1969. Parroquia Santa Rosa	2	Gema Araya	Procultura	2025-10-15 18:06:01.501	2025-10-15 18:06:01.501
cmgsaxzua03lph9i6nolfznic	Serie hombre a caballo 1	Serie hombre a caballo 1	Serie hombre a caballo 1 en Calla Lastra		Jorge Guerra	1960	1960	Pueblo de Lo Barnechea	1960. Calla Lastra	2	Jorge Guerra	Procultura	2025-10-15 18:06:02.674	2025-10-15 18:06:02.674
cmgsay0va03lwh9i67tsrm6wn	Cuasimodista en cancha	Cuasimodista en cancha	Cuasimodista en cancha debajo de la iglesia		Jorge Guerra	1968	1960	Pueblo de Lo Barnechea	22-4-68. Cancha debajo de la iglesia	2	Jorge Guerra	Procultura	2025-10-15 18:06:04.006	2025-10-15 18:06:04.006
cmgsay1os03m3h9i6ipplzdci	Serie hombre a caballo 3	Serie hombre a caballo 3	Serie hombre a caballo 3 en Calla Lastra		Jorge Guerra	1960	1960	Pueblo de Lo Barnechea	1960. Calla Lastra	2	Jorge Guerra	Procultura	2025-10-15 18:06:05.069	2025-10-15 18:06:05.069
cmgsay2id03mah9i6tgsuagng	Serie hombre a caballo 4	Serie hombre a caballo 4	Serie hombre a caballo 4 en Calla Lastra		Jorge Guerra	1960	1960	Pueblo de Lo Barnechea	1960. Calla Lastra	2	Jorge Guerra	Procultura	2025-10-15 18:06:06.134	2025-10-15 18:06:06.134
cmgsay3ai03mhh9i6hls5u4yf	Serie hombre a caballo 5	Serie hombre a caballo 5	Serie hombre a caballo 5 en Calla Lastra		Jorge Guerra	1960	1960	Pueblo de Lo Barnechea	1960. Calla Lastra	2	Jorge Guerra	Procultura	2025-10-15 18:06:07.146	2025-10-15 18:06:07.146
cmgsay46x03moh9i6l03qypre	Dos niños frente a casona	Dos niños frente a casona	Dos niños frente a casona en Pueblo de Lo Barnechea		Pedro Juan Garrido Medina junto al hijo de los propietarios	1961	1960	Pueblo de Lo Barnechea	1961. Pueblo de Lo Barnechea	2	Cristian Garrido	Procultura	2025-10-15 18:06:08.313	2025-10-15 18:06:08.313
cmgsay7k503mvh9i6d7er1xob	Familia sentada en el pasto	Familia sentada en el pasto	Familia sentada en el pasto en Plaza San Enrique		Pedro Juan Garrido Medina junto a su madre Amelia Rosa Medina Leiva y primos	1961	1960	San Enrique/La Ermita/Las Condes	1961. Plaza San Enrique	2	Cristian Garrido	Procultura	2025-10-15 18:06:12.677	2025-10-15 18:06:12.677
cmgsay8nx03n2h9i6jgnc24br	Dos niños junto a auto de juguete	Dos niños junto a auto de juguete	Dos niños junto a auto de juguete en Casona de Las Condes		Pedro Juan Garrido Medina	1962	1960	San Enrique/La Ermita/Las Condes	1962. Casona de Las Condes	2	Cristian Garrido	Procultura	2025-10-15 18:06:14.11	2025-10-15 18:06:14.11
cmgsay9t403n9h9i6bus4tzmf	Mujer con niño en brazos	Mujer con niño en brazos	Mujer con niño en brazos en Pueblo de Lo Barnechea		Pedro Juan Garrido Medina junto a su madre Amelia Rosa Medina Leiva	1962	1960	Pueblo de Lo Barnechea	1962. Pueblo de Lo Barnechea	2	Cristian Garrido	Procultura	2025-10-15 18:06:15.592	2025-10-15 18:06:15.592
cmgsayb4603ngh9i6fgzwrd91	Pareja con niño	Pareja con niño	Pareja con niño en Casona de Las Condes		Juan de Dios Garrido Guajardo, Pedro Juan Garrido Medina, Amelia Rosa Medina Leiva	1962	1960	San Enrique/La Ermita/Las Condes	1962. Casona de Las Condes	2	Cristian Garrido	Procultura	2025-10-15 18:06:17.286	2025-10-15 18:06:17.286
cmgsayctp03nnh9i6djjvvjo1	Niño junto a triciclo	Niño junto a triciclo	Niño junto a triciclo en Pueblo de Lo Barnechea		Pedro Juan Garrido Medina	1963	1960	Pueblo de Lo Barnechea	1963. Pueblo de Lo Barnechea	2	Cristian Garrido	Procultura	2025-10-15 18:06:19.501	2025-10-15 18:06:19.501
cmgsayf0h03nuh9i6zzref5n2	Niño con flotador	Niño con flotador	Niño con flotador en Tranque La Dehesa		Pedro Juan Garrido Medina	1965	1960	La Dehesa	1965. Tranque La Dehesa	2	Cristian Garrido	Procultura	2025-10-15 18:06:22.337	2025-10-15 18:06:22.337
cmgsayi2p03o1h9i60vzveh1v	Niños disfrazados	Niños disfrazados	Niños disfrazados en Colegio parroquial		a la derecha, Pedro Juan Garrido Medina	1966	1960	Pueblo de Lo Barnechea	24-6-66. Colegio parroquial	2	Cristian Garrido	Procultura	2025-10-15 18:06:26.306	2025-10-15 18:06:26.306
cmgsayj5p03o8h9i6afvp16yp	Niño con auto de lata	Niño con auto de lata	Niño con auto de lata en Pueblo de Lo Barnechea		Pedro Juan Garrido Medina	1962	1960	Pueblo de Lo Barnechea	1962. Pueblo de Lo Barnechea	2	Cristian Garrido	Procultura	2025-10-15 18:06:27.709	2025-10-15 18:06:27.709
cmgsaylkh03ofh9i6ranmmzq7	Cuatro niños con gorro	Cuatro niños con gorro	Cuatro niños con gorro en Pueblo de Lo Barnechea	C. Garrido 97	2da niña Ginette Tapia Wittersen, a su lado Pedro Juan garrido Medina. Fueron amigos desde chicos y luego se casaron	hacia 1967	1960	Pueblo de Lo Barnechea	Circa 1967. Pueblo de Lo Barnechea	2	Cristian Garrido	Procultura	2025-10-15 18:06:30.834	2025-10-15 18:06:30.834
cmgsbbpw804irh9i6sgp3mwln	Novia bajando del auto	Novia bajando del auto	Novia bajando del auto							2	Rocío Muñoz	Procultura	2025-10-15 18:16:42.968	2025-10-15 18:16:42.968
cmgsayo8x03omh9i69e3rw5xy	Niño junto a monja	Niño junto a monja	Niño junto a monja en Parroquia Santa Rosa		Pedro Juan Garrido Medina	1967	1960	Pueblo de Lo Barnechea	1967. Parroquia Santa Rosa	2	Cristian Garrido	Procultura	2025-10-15 18:06:34.305	2025-10-15 18:06:34.305
cmgsayw8r03peh9i67qv8ssvz	Mujer con flores junto a hombre	Mujer con flores junto a hombre	Mujer con flores junto a hombre en Viña del Mar		Aurelia Meneses y José "Lelo" Araya	1968	1960	Otro	1968. Viña del Mar	2	Familia Araya Meneses	Procultura	2025-10-15 18:06:44.667	2025-10-15 18:06:44.667
cmgsayyv103plh9i6zpc125gf	Niña en primera comunión junto a niños	Niña en primera comunión junto a niños	Niña en primera comunión junto a niños en Casa de los abuelos en Lastra		Rosita Verdugo, Alejandra Araya, Antonia Araya, Cristian Araya, Elia Torreblanca, Juan Araya, Gabriela Araya, Mario Araya, Sara Bozo. Atrás: Adrian Yañez, Manuel Ramirez, Betty Verdugo, Juana Bozo	1964	1960	Pueblo de Lo Barnechea	1964. Casa de los abuelos en Lastra	2	Familia Araya Meneses	Procultura	2025-10-15 18:06:48.062	2025-10-15 18:06:48.062
cmgsaz0v403psh9i6kihpe4vz	Madre con niñas	Madre con niñas	Madre con niñas en Frente al río	Bebé en brazos murió en el río un año después	María Cecilia Vera Solis, Eduardo Vera Solis, Brigida Vera Solis, Rosa Emilia Solis Solis, en brazos Elda Vera Solis.	1964	1960		1964. Frente al río. Fotografía antigua digitalizada	2	UNCAF	Procultura	2025-10-15 18:06:50.656	2025-10-15 18:06:50.656
cmgsaz46e03q6h9i6e7o9nxi8	Pareja con niño detrás	Pareja con niño detrás	Pareja con niño detrás en Cerro 18, iban de paseo		José Vicente Bravo Galvez, Hilda Vera Reyes. El niño es Francisco Oliva Cano, vecino.	1956	1950	Cerro 18	1956. Cerro 18, iban de paseo	2	Mariela Bravo	Procultura	2025-10-15 18:06:54.95	2025-10-15 18:06:54.95
cmgsaz60003qkh9i6ph2pkj2n	Cazadores de conejos con sus presas	Cazadores de conejos con sus presas	Cazadores de conejos con sus presas en Pueblo de Lo Barnechea	Revisar lugar. y año No aparenta ser el Pueblo y fecha debe ser posterior a 1955.		hacia 1955	1950	Pueblo de Lo Barnechea	1955 circa. Pueblo de Lo Barnechea. H	2	Yoconda Moya	Procultura	2025-10-15 18:06:57.312	2025-10-15 18:06:57.312
cmgsaz6xe03qrh9i6a0ozwifa	Cazadores de conejos descansan con sus presas	Cazadores de conejos descansan con sus presas	Cazadores de conejos descansan con sus presas en Pueblo de Lo Barnechea	Revisar lugar. y año No aparenta ser el Pueblo y fecha debe ser posterior a 1955.		hacia 1955	1950	Pueblo de Lo Barnechea	1955 circa. Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:06:58.515	2025-10-15 18:06:58.515
cmgsazbri03rch9i6jpqdbtf5	Niño en el campo	Niño en el campo	Niño en el campo en Pastor Fernández		Patricio Dotte	1953	1950	El Arrayán	1953. Pastor Fernández	2	Patricia Dotte	Procultura	2025-10-15 18:07:04.782	2025-10-15 18:07:04.782
cmgsazfvg03rxh9i6m6e3w10f	Joven marino	Joven marino	Joven marino	Es de Puente Alto	“El grume”	hacia 1954	1950			2	María Araya	Procultura	2025-10-15 18:07:10.108	2025-10-15 18:07:10.108
cmgsazu0g03s4h9i60xeopc0n	Jóvenes jugando a tocar el arpa	Jóvenes jugando a tocar el arpa	Jóvenes jugando a tocar el arpa en el teatro de la Católica, en una velada artística		Pedro Araya y María Araya	hacia 1957	1950		Circa 1957. Jugando con el arpa en el teatro de la Católica, en la velada artística	2	María Araya	Procultura	2025-10-15 18:07:28.432	2025-10-15 18:07:28.432
cmgsb05z403thh9i6y7znw41z	Hombre de traje frente a su puerta	Hombre de traje frente a su puerta	Hombre de traje frente a su puerta en Casona en San Enrique		Ruben Diaz Lira	1957	1950	San Enrique/La Ermita/Las Condes	1957. Casona en San Enrique	2	Juan Carlos Salas	Procultura	2025-10-15 18:07:43.935	2025-10-15 18:07:43.935
cmgsb0i9q03unh9i6xwzfl6xr	Candidatas a reina con hombre sentado	Candidatas a reina con hombre sentado	Candidatas a reina con hombre sentado en Pueblo de Lo Barnechea	Timbre: C.D. JUVENTUD CATOLICA /FDO. 27 DE JULIO DE 1940 / BARNECHEA LAS CONDES /// Otro timbre: FOTO REPORTAJE SOCIAL "RELAMPAGO" E. Hoffstetter. Grajales 2152- Stgo.	Maria Serrano, Eduvigis Ulloa, Ana Matteo, NN, NN, Jorge Labbe (rey feo)	1959	1950	Pueblo de Lo Barnechea	27 de Febrero 1959. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:07:59.87	2025-10-15 18:07:59.87
cmgsb0m6k03v8h9i68a7ezg49	Carro alegórico de guitarra	Carro alegórico de guitarra	Carro alegórico de guitarra en Pueblo de Lo Barnechea		Ana Matteo y Gustavo Gonzalez junto a candidatas	1959	1950	Pueblo de Lo Barnechea	1959. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:08:04.94	2025-10-15 18:08:04.94
cmgsb0pba03vmh9i6jt6gcg4r	Reyes bailando de frente	Reyes bailando de frente	Reyes bailando de frente en Pueblo de Lo Barnechea		Ana Matteo y Gustavo Gonzalez (rey feo, vivia en Puente Nuevo)	1959	1950	Pueblo de Lo Barnechea	1959. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:08:08.998	2025-10-15 18:08:08.998
cmgsb0se803w0h9i6clrmmpt6	Reverso Carnet Asociación deportiva Las Condes	Reverso Carnet Asociación deportiva Las Condes	Reverso Carnet Asociación deportiva Las Condes 		Antonio Alberto Meneses	1953	1950	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Alberto Meneses	Procultura	2025-10-15 18:08:12.992	2025-10-15 18:08:12.992
cmgsb0u4s03w7h9i6j9w04hea	carnet Asociacion deportiva Las Condes	carnet Asociacion deportiva Las Condes	Carnet Asociación deportiva Las Condes 		Antonio Alberto Meneses	1953	1950	Pueblo de Lo Barnechea	Trabajó como obrero, pintor. Cuando eran chicos su mamá tenia un negocio frente a los Araya. Fueron 10 hermanos. . 1953. Pueblo de Lo Barnechea	2	Alberto Meneses	Procultura	2025-10-15 18:08:15.243	2025-10-15 18:08:15.243
cmgsb0x4e03wsh9i68uqm73qg	Hombre con caballos	Hombre con caballos	Hombre con caballos en el Santiago Pepperchase Club en Av. Ossa		Carlos Quiroz Pérez	hacia 1950	1950	Santiago	Circa 1950. Santiago Pepperchase club en Av. Ossa	2	Familia Quiroz Mendoza	Procultura	2025-10-15 18:08:19.118	2025-10-15 18:08:19.118
cmgsb10b603x6h9i6ylqog3jq	Cuatro jóvenes en desfile	Cuatro jóvenes en desfile	Cuatro jóvenes en la procesión de la Virgen del Carmen, cerca de Plaza de Armas.	Él estudiaba en la Gratitud Nacional	Luis Rivas (jugador de Colocolo), Luis Godoy, Jorgue Guerra, Juan Saavedra	1958	1950	Santiago	6-10-58. Cerca de Plaza de Armas, era la procesión de la Virgen del Camrne. Él estudiaba en la gratitud nacional	2	Jorge Guerra	Procultura	2025-10-15 18:08:23.25	2025-10-15 18:08:23.25
cmgsb13k903xdh9i6ln2ze02b	Matrimonio	Matrimonio	Matrimonio en Parroquia Santa Rosa		José Gabriel "Lelo" Araya Astudillo, Aurelia Meneses León	1951	1950	Pueblo de Lo Barnechea	29-3-1951. Parroquia Santa Rosa	2	Familia Araya Meneses	Procultura	2025-10-15 18:08:27.465	2025-10-15 18:08:27.465
cmgsb194703xyh9i6kae3wy5b	Hombres junto a ataud	Hombres junto a ataud	Hombres junto a ataud en Cementerio Católico		Funeral de Rafael Araya	1957	1950	Santiago	23-11-1957. Cementerio Católico	2	Familia Araya Meneses	Procultura	2025-10-15 18:08:34.664	2025-10-15 18:08:34.664
cmgsb1b3o03y5h9i6udknkxn7	Comitiva de hombres en cementerio	Comitiva de hombres en cementerio	Comitiva de hombres en cementerio en Cementerio Católico		Funeral de Rafael Araya	1957	1950	Santiago	23-11-1957. Cementerio Católico	2	Familia Araya Meneses	Procultura	2025-10-15 18:08:37.236	2025-10-15 18:08:37.236
cmgsb1is903yqh9i6jl3f4tdn	Niño en triciclo	Niño en triciclo	Niño en triciclo en Pueblo de Lo Barnechea	Papel postcard	Juan Gastón Vera Reyes	1941	1940	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Mariela Bravo	Procultura	2025-10-15 18:08:47.192	2025-10-15 18:08:47.192
cmgsb1lkr03z4h9i6x86konla	Dos mujeres con niña	Dos mujeres con niña	Dos mujeres con niña en Pueblo de Lo Barnechea		Rosa Eliana Diaz, Maria Eugenia Salas, María Calderón	1941	1940	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:08:50.812	2025-10-15 18:08:50.812
cmgsayr7y03oth9i6t6u8mdax	Familia en quinta de recreo	Familia en quinta de recreo	Familia en Quinta de recreo Las Rosas		Antonio Araya, Eliana Gonzalez, Cristian Araya; de terno Luis (músico ciego que tocaba piano en la quinta Las Rosas), De huaso al centro José "Lelo" Araya, Juan Vasquez, Kerima Ayala (profesora de la escuela de ciegos), Gabriela Araya. Con un vaso, Aurelia "Lela" Meneses, en brazos Juan "Pele" Araya, niña; Lucía. 	hacia 1961	1960	Pueblo de Lo Barnechea	ML. Circa 1961. Quinta de recreo Las Rosas	2	Familia Araya Meneses	Procultura	2025-10-15 18:06:38.158	2025-10-15 18:06:38.158
cmgsaz2s103pzh9i69b5xacui	Grupo frente a mesones	Grupo frente a mesones	Grupo frente a mesones	"Rodeo La Dehesa"	Segundo a la izquierda, Luis Vera. Al centro con chaqueta blanca, Manuel Carrasco, trabajaba en el campo cuidando los animales. A la derehca con chamanto con rayas Luis Santibañez. Todos trabajadores del campo La Dehesa.	hacia 1960	1960		Fotografía antigua digitalizada	2	UNCAF	Procultura	2025-10-15 18:06:53.137	2025-10-15 18:06:53.137
cmgsaz53403qdh9i69uu1i9ea	Cazadores desayunando	Cazadores desayunando	Cazadores desayunando en Pueblo de Lo Barnechea	Revisar lugar. y año No aparenta ser el Pueblo y fecha debe ser posterior a 1955.	A la izquierda de lado Gildo Pavez, gorro blanco mirando la frente, Nibaldo Villaseca, Benjamin Valencia, Carlos Moya, Joaquin Moya	hacia 1955	1950	Pueblo de Lo Barnechea	1955 circa. Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:06:56.128	2025-10-15 18:06:56.128
cmgsazv5o03sbh9i67z088hgx	Madre e hijo	Madre e hijo	Madre e hijo		Lucía Cruz y Emiliano Olmos	1953	1950			2	María Araya	Procultura	2025-10-15 18:07:29.916	2025-10-15 18:07:29.916
cmgsazxda03sih9i6imlsuvqc	Candidatas a reina tomando bebida	Candidatas a reina tomando bebida	Candidatas a reina tomando bebida en Pueblo de Lo Barnechea	Foto Reportaje Social "Relámpago". E. Hoffstetter. Grajales 2152- Stgo.	3ra Gloria Querol. Extremo derecho Juan Salas	1958	1950	Pueblo de Lo Barnechea	preguntarle a . 28 Febrero 1958. Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:07:32.783	2025-10-15 18:07:32.783
cmgsazzst03sph9i672sgocs6	Grupo en un restaurante	Grupo en un restaurante	Grupo en un restaurante en Sector San Enrique, entonces llamado Las Condes.		A la izq Adriana Encina. Hombre a la izq en primer plano Alfredo Aranguiz, lo sigue otro Aranguiz. Asomado, Gaston Diaz. Con lentes Arturo Cristi Catani. A la derecha con corbata, el 2do es Carreño. 	1950-1960	1950	San Enrique/La Ermita/Las Condes	Club Condor era el club de Las Condes, actual sector San Enrique. Década de 1950. Sector San Enrique, entonces llamado Las Condes. 	2	Juan Carlos Salas	Procultura	2025-10-15 18:07:35.933	2025-10-15 18:07:35.933
cmgsb01so03swh9i6bd69j9ca	Mujer con niño y bebé	Mujer con niño y bebé	Mujer con niño y bebé en Pueblo de Lo Barnechea		María Calderón con Arturo Cristi Calderón y Luis Cristi Calderón	hacia 1955	1950	Pueblo de Lo Barnechea	Circa 1955. Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:07:38.521	2025-10-15 18:07:38.521
cmgsb04jj03tah9i6o3fr7x4k	Mujer frente a muro de ladrillos	Mujer frente a muro de ladrillos	Mujer frente a muro de ladrillos en la Hosteria La Montaña, av Barnechea		Rosa Eliana Diaz Lira	hacia 1954	1950	Pueblo de Lo Barnechea	Circa 1954. Frente a Hosteria La Montana, av Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:07:42.08	2025-10-15 18:07:42.08
cmgsb07lf03toh9i6hhs2k1rt	Acto escolar 1	Acto escolar 1	Acto escolar 1 en Pueblo de Lo Barnechea			hacia 1956	1950	Pueblo de Lo Barnechea	importante, sale el cura y escenario. Circa 1956. Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:07:46.035	2025-10-15 18:07:46.035
cmgsb0b0403u2h9i647j87441	Grupo disfrazado frente a verja	Grupo disfrazado frente a verja	Grupo disfrazado frente a verja en la casa de la familia Díaz Lira	Papel Tarjeta Postal		1950-1960	1950	Pueblo de Lo Barnechea	Década de 1950. Frente a la casa de la familia Diaz Lira	2	Juan Carlos Salas	Procultura	2025-10-15 18:07:50.452	2025-10-15 18:07:50.452
cmgsb0gth03ugh9i6oirq1621	Adultos en celebración de primera comunión	Adultos en celebración de primera comunión	Adultos en celebración de primera comunión en Pueblo de Lo Barnechea		Arriba izq Juan Salas, 3ro Arturo Cristi, abajo a la derecha Rosa Eliana. Al centro con collar, María Calderón	1959	1950	Pueblo de Lo Barnechea	Domingo 6 de Diciembre 1959. Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:07:57.99	2025-10-15 18:07:57.99
cmgsb0ko603v1h9i6raelvo8g	Tractor bulldozer	Tractor bulldozer	Mujer con bebé	Hubo un rodado gigante que tapó toda Disputada	Está despejando el camino	1953	1950	Farellones	importante pq aparece La disputada. 1953. Kempo, cordillera de Lo Barnechea cerca del río Colorado	2	Ana Matteo Rojas	Procultura	2025-10-15 18:08:02.982	2025-10-15 18:08:02.982
cmgsb0qob03vth9i63fn9iilg	Mujer con flor	Mujer con flor	Mujer con flor en Pueblo de Lo Barnechea		Ana Matteo	1958	1950	Pueblo de Lo Barnechea	1958. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:08:10.763	2025-10-15 18:08:10.763
cmgsb0w4a03wlh9i6dm4vzyek	Dos niños	Dos niños	Dos niños en calle Bilbao, Las Condes		María Isolina Mendoza y Carlos Quillermo Quiroz Pérez con Daniel Cristian Quiroz Mendoza, Luz Angelica Quiroz Mendoza	1955	1950	Santiago	1955. calle Bilbao, Las Condes	2	Familia Quiroz Mendoza	Procultura	2025-10-15 18:08:17.818	2025-10-15 18:08:17.818
cmgsb14kq03xkh9i6e4hlf9x0	Dos jinetes en cuasimodo	Dos jinetes en cuasimodo	Dos jinetes en Cuasimodo en cancha de Barnechea		Gerardo Gonzalez, NN	1950-1960	1950	Pueblo de Lo Barnechea	Década de 1950. Cuasimodo en cancha de Barnechea	2	Familia Araya Meneses	Procultura	2025-10-15 18:08:28.778	2025-10-15 18:08:28.778
cmgsb16x703xrh9i6w50jeqdi	Carro fúnebre llegando al cementerio	Carro fúnebre llegando al cementerio	Carro fúnebre llegando al cementerio en Cementerio Católico		Funeral de Rafael Araya	1957	1950	Santiago	23-11-1957. Cementerio Católico	2	Familia Araya Meneses	Procultura	2025-10-15 18:08:31.819	2025-10-15 18:08:31.819
cmgsb1d3r03ych9i6sqz5moyr	Comitiva de hombres junto a ataúd	Comitiva de hombres junto a ataúd	Comitiva de hombres junto a ataúd en Cementerio Católico		Funeral de Rafael Araya	1957	1950	Santiago	23-11-1957. Cementerio Católico	2	Familia Araya Meneses	Procultura	2025-10-15 18:08:39.831	2025-10-15 18:08:39.831
cmgsb1nc003zbh9i68wseaocj	Rostro de mujer	Rostro de mujer	Rostro de mujer en Pueblo de Lo Barnechea	"Con todo cariño para Elianita. De Luchy". 		1940	1940	Pueblo de Lo Barnechea	17 Diciembre 1940. Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:08:53.088	2025-10-15 18:08:53.088
cmgsb1pwx03zph9i65q9azngo	Abuela con nieta en brazos	Abuela con nieta en brazos	Abuela con nieta en brazos en Coelemu		Francisca Lopez Cervellera y Ana Matteo Rojas 	1942	1940	Otro	Coelemu	2	Ana Matteo Rojas	Procultura	2025-10-15 18:08:56.434	2025-10-15 18:08:56.434
cmgsb2auz0419h9i6wb8raxq8	Familia posando con escenificación de Valparaíso	Familia posando con escenificación de Valparaíso	Familia posando con escenificación de Valparaíso		Luis Diaz, Mercedes Lira. Hijos Gastón, Rubén y Rosa Eliana	1930-1940	1930	Otro	Década de 1930. Otro	2	Juan Carlos Salas	Procultura	2025-10-15 18:09:23.577	2025-10-15 18:09:23.577
cmgsayt6303p0h9i69566r8nv	Niño en silla	Niño en silla	Niño en silla en Pueblo de Lo Barnechea		Juan Rafael Araya Meneses	1960	1960	Pueblo de Lo Barnechea	1960. Pueblo de Lo Barnechea	2	Familia Araya Meneses	Procultura	2025-10-15 18:06:40.683	2025-10-15 18:06:40.683
cmgsayusw03p7h9i6osph7pv8	Dos escolares con carteras	Dos escolares con carteras	Dos escolares con carteras en Calle Lastra		Juan "Pele" Araya, Guillermo Leon	1966	1960	Pueblo de Lo Barnechea	ML. 1966. Calle Lastra	2	Familia Araya Meneses	Procultura	2025-10-15 18:06:42.8	2025-10-15 18:06:42.8
cmgsaz9dj03qyh9i60zttlyp2	Niña frente a casa	Niña frente a casa	Niña frente a casa en Casa de su padrino		Hilda Valencia Moya	hacia 1957	1950	Pueblo de Lo Barnechea	Circa 1957. Casa de su padrino	2	Yoconda Moya	Procultura	2025-10-15 18:07:01.687	2025-10-15 18:07:01.687
cmgsazaed03r5h9i6l0xc5orq	Niño y niña	Niño y niña	Niño y niña en En la playa, en el paseo que siempre se hacía		Irma Dotte y Virginio Dotte (hermanos)	hacia 1950	1950	Otro	1950 circa. En la playa, en el paseo que siempre se hacía	2	Patricia Dotte	Procultura	2025-10-15 18:07:03.013	2025-10-15 18:07:03.013
cmgsazclg03rjh9i67qqskbzk	Familia	Familia	Familia	“con el mas cincero – amiga Rosa de Dotte – su amiga Carm-”	Al centro Rosa Alcaíno, con suspensores adelante Patricio Dotte, a la derecha Margarita Dotte (pareja de Virginio y Rosa tuvieron 7 hijos)	1958	1950			2	Patricia Dotte	Procultura	2025-10-15 18:07:05.86	2025-10-15 18:07:05.86
cmgsaze6b03rqh9i6qzwzj5t2	Jóvenes junto a bandera	Jóvenes junto a bandera	Jóvenes junto a bandera en Gimnasio de la Católica en Santa Rosa	Presentación anual de los clubes	Tomás Sosa, Ana María, Minu Claudet, Lucía Cruz, Chantal Claudet. Inclinada, Gina Schicharini.	hacia 1958	1950		Circa 1958. Gimnasio de la Católica en Santa Rosa	2	María Araya	Procultura	2025-10-15 18:07:07.907	2025-10-15 18:07:07.907
cmgsb03bn03t3h9i649abgpq7	Hombre y tres mujeres de blanco	Hombre y tres mujeres de blanco	Hombre y tres mujeres de blanco en Quinta en San Enrique	"Con todo cariño a mi querida prima dedico esta insignificante foto. Agueda E."	Mercedes Lira, Luis Diaz, 	1950-1960	1950	San Enrique/La Ermita/Las Condes	Década de 1950. Quinta en San Enrique	2	Juan Carlos Salas	Procultura	2025-10-15 18:07:40.5	2025-10-15 18:07:40.5
cmgsb09d603tvh9i6b98pslub	Acto escolar 4	Acto escolar 4	Acto escolar 4 en Pueblo de Lo Barnechea			hacia 1956	1950	Pueblo de Lo Barnechea	Circa 1956. Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:07:48.33	2025-10-15 18:07:48.33
cmgsb0dy703u9h9i6kv1arfay	Niños celebrando primera comunión	Niños celebrando primera comunión	Niños celebrando primera comunión en Pueblo de Lo Barnechea		Cucho Cristi, al centro. Niño arriba a la izq es Vicente Salas. 	1959	1950	Pueblo de Lo Barnechea	importante buena foto. Domingo 6 de Diciembre 1959. Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:07:54.271	2025-10-15 18:07:54.271
cmgsb0jg703uuh9i6hmxtdjvn	Hombre con niño junto a silla	Hombre con niño junto a silla	Hombre con niño junto a silla en Poblacion San Antonio, rivera del río		Luis Riveros Riveros con Luis Riveros Gajardo	hacia 1955	1950	Pueblo de Lo Barnechea	Circa 1955. Poblacion San Antonio, rivera del río 	2	Ximena Riveros de Araya	Procultura	2025-10-15 18:08:01.399	2025-10-15 18:08:01.399
cmgsb0ns603vfh9i63twkbajc	Reyes bailando	Reyes bailando	Reyes bailando en Pueblo de Lo Barnechea		Ana Matteo y Gustavo Gonzalez (rey feo, vivia en Puente Nuevo)	1959	1950	Pueblo de Lo Barnechea	1959. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:08:07.014	2025-10-15 18:08:07.014
cmgsb0vfu03weh9i65gj58fka	Pase Libre Asociaciòn de Microbuses Mapocho Las Condes	Pase Libre Asociaciòn de Microbuses Mapocho Las Condes	Pase Libre Asociaciòn de Microbuses Mapocho Las Condes en San Enrique/La Ermita/Las Condes		Antonio Alberto Meneses	1959	1950	San Enrique/La Ermita/Las Condes	1959. San Enrique/La Ermita/Las Condes	2	Alberto Meneses	Procultura	2025-10-15 18:08:16.939	2025-10-15 18:08:16.939
cmgsb0yij03wzh9i6cjz764gz	Hombre con  en pesebrera	Hombre con  en pesebrera	Hombre con en pesebrera en el Santiago Pepperchase Club en Av. Ossa		Carlos Quiroz	hacia 1959	1950	Santiago	Circa 1959. Club Santiago Pepperchase en Av. Ossa	2	Familia Quiroz Mendoza	Procultura	2025-10-15 18:08:20.923	2025-10-15 18:08:20.923
cmgsb1gpy03yjh9i6cbmxlvxm	Grupo en primera comuniòn	Grupo en primera comuniòn	Grupo en Primera Comunión en casa de su mamá, pasaje en Los Patos		Amanda Chacón, Purísima Moya, Lucrecia Moya Riveros, atrás Petronila Moya, Orfilia, Inés Moya Riveros, Magdalena Jara, Gladys Moya,Zulema Maureira. Niña de la izquierda, Victoria Carrasco. Abajo niños Belisario, nn, Gladys Moya, Hildita Valencia. Niño de la primera comunión Carlos Moya, Carmen Moya, Teresita y nn Jara León, NN, Eugenia Moya,Corina Salcedo, Luisa Bello, Rosalía Moya	1957	1950	Pueblo de Lo Barnechea	1 diciembre 1957. Primera comunión en casa de su mamá, pasaje en Los Patos	2	Yoconda Moya	Procultura	2025-10-15 18:08:44.518	2025-10-15 18:08:44.518
cmgsb1jyg03yxh9i67ioexkdy	Hombre y niña	Hombre y niña	Hombre y niña en San Enrique		Juan Salas y su hija Maria Eugenia Salas	hacia 1943	1940	San Enrique/La Ermita/Las Condes	Circa 1943. San Enrique	2	Juan Carlos Salas	Procultura	2025-10-15 18:08:48.713	2025-10-15 18:08:48.713
cmgsb1oui03zih9i65w1xdzue	Mujer con abrigo	Mujer con abrigo	Mujer con abrigo en Pueblo de Lo Barnechea		Rosa Eliana Diaz Lira	1940-1950	1940	Pueblo de Lo Barnechea	Década de 1940. Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:08:55.051	2025-10-15 18:08:55.051
cmgsb1u440403h9i63xzc1gvr	Niña con abrigo	Niña con abrigo	Niña con abrigo en Pueblo de Lo Barnechea		Anita	1945	1940	Pueblo de Lo Barnechea	CHEQUEAR. 1945. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:09:01.877	2025-10-15 18:09:01.877
cmgsb202k040hh9i67drr90ak	Hombre frente a casa con hortensias	Hombre frente a casa con hortensias	Hombre frente a casa con hortensias en calle Medina	La casa se cayó con un terremoto.	Patricio Bustamante, patriarca de la familia	1941-1942	1940	Pueblo de Lo Barnechea	1941-42. Casa con hortensias azules maravillosas, calle Medina. Se cayó con un terremoto.. Fotografía antigua digitalizada	2	UNCAF	Procultura	2025-10-15 18:09:09.597	2025-10-15 18:09:09.597
cmgsb2345040oh9i6q1b10u2w	Niña en primera comunión	Niña en primera comunión	Niña en Primera Comunión en Parroquia Santa Rosa		Emilia Rosa Solis Solis a los 7 años	1945	1940	Pueblo de Lo Barnechea	Parroquia Santa Rosa. Fotocopia de foto	2	UNCAF	Procultura	2025-10-15 18:09:13.541	2025-10-15 18:09:13.541
cmgsb2clf041gh9i6a3rkh8y2	Rostro de hombre joven	Rostro de hombre joven	Rostro de hombre joven en Pueblo de Lo Barnechea		Gaston Diaz	hacia 1934	1930	Pueblo de Lo Barnechea	Circa 1934. Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:09:25.827	2025-10-15 18:09:25.827
cmgsb2jom0421h9i65pbf63pk	Hombre montando	Hombre montando	Hombre montando en desembocadura del río en Concón	Expedición a caballo	Carlos Quiroz	hacia 1937	1930	Otro	Circa 1937. Desembocadura del río en Concón, fueron a caballo en una expedición	2	Familia Quiroz Mendoza	Procultura	2025-10-15 18:09:35.015	2025-10-15 18:09:35.015
cmgsb30mw043eh9i6s46gukxi	Familia frente  a una carreta	Familia frente  a una carreta	Familia frente a una carreta en Raúl Labbé		A la derecha, Elisa Celis Bustamante. Al centro Danial Bustamante (su padre).	hacia 1930	1930	Pueblo de Lo Barnechea	Circa 1930. Raúl Labbé. Fotografía antigua digitalizada	2	UNCAF	Procultura	2025-10-15 18:09:56.985	2025-10-15 18:09:56.985
cmgsb1si403zwh9i605drjpsy	Matrimonio y pajes	Matrimonio y pajes	Matrimonio y pajes en Pueblo de Lo Barnechea		Valentina Rojas Caparroz y Miguel Matteo de Francesco y Capri. Niños Carlos Rojas Guerrero y Manuel Rojas Espinoza. Niñas Delia Contreras y Carmen Contreras	1942	1940	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:08:59.789	2025-10-15 18:08:59.789
cmgsb1y4a040ah9i6yj86hlhb	Dos niños en primera comunión	Dos niños en primera comunión	Dos niños en primera comunión en Parroquia Santa Rosa		Jorge y Augusto Guerra	hacia 1948	1940	Pueblo de Lo Barnechea	Circa 1948. Lo recuerda porque les decían que cuando se terminara la guerra (Segunda Guerra Mundial) harían la primera comunión. . Parroquia Santa Rosa	2	Jorge Guerra	Procultura	2025-10-15 18:09:07.066	2025-10-15 18:09:07.066
cmgsb25an040vh9i65g3mh16v	Madre e hijas	Madre e hijas	Madre e hijas en patio de la casa a la orilla del río		Amanda Chacón, Gioconda, Gladys, Eugenia y Rosalía Moya.	1943	1940	Pueblo de Lo Barnechea	Patio de la casa a la orilla del río.	2	Yoconda Moya	Procultura	2025-10-15 18:09:16.367	2025-10-15 18:09:16.367
cmgsb27fb0412h9i61xk9zzf8	Recuerdo de primera comunión	Recuerdo de primera comunión	Recuerdo de primera comunión en Pueblo de Lo Barnechea		Magdalena Lastra	1931	1930	Pueblo de Lo Barnechea	28 de Marzo 1931. Pueblo de Lo Barnechea	2	Familia Soto Torreblanca	Procultura	2025-10-15 18:09:19.127	2025-10-15 18:09:19.127
cmgsb2g5s041nh9i6py1vmurl	Foto de curso de niñas	Foto de curso de niñas	Foto de curso de niñas en Carmelitas de Providencia		Tercera fila, la nro 5 de derecha a izquieda es Rosa Eliana Diaz Lira	1934	1930	Santiago	importante por lo antigua. 1934. Carmelitas de Providencia. 	2	Juan Carlos Salas	Procultura	2025-10-15 18:09:30.448	2025-10-15 18:09:30.448
cmgsb2hz0041uh9i6x5zkbvco	Hombre frente a monumento	Hombre frente a monumento	Hombre frente a monumento en Pueblo de Lo Barnechea	Tarjeta Postal Unión Universal de Correos. Espacio para estampilla dice Casa Hans Frey	Luis Díaz Lira	1930-1940	1930	Pueblo de Lo Barnechea	Década 1930. Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:09:32.796	2025-10-15 18:09:32.796
cmgsb2msu0428h9i6j9gi2zhs	Huaso con un vaso en la mano	Huaso con un vaso en la mano	Huaso con un vaso en la mano en Cuasimodo	Después se hacía la fiesta huasa en la Medialuna	Joaquín Mallea Mallea	hacia 1937	1930	Población Nebraska	ML. Circa 1937. Cuasimodo, después se hacía la fiesta huasa en la Medialuna 	2	Gema Araya	Procultura	2025-10-15 18:09:39.054	2025-10-15 18:09:39.054
cmgsb2ohp042fh9i6xyw4eunt	Rostro de mujer	Rostro de mujer	Rostro de mujer en Pueblo de Lo Barnechea	Papel Carte Postale. Dice "A mi queridisima Mercedes, dedico este recuerdo con todo cariño, para que nunca te olvides de tu Mary. Santiago, 16 de septiembre de 1935. Campoamor 2904		1935	1930	Pueblo de Lo Barnechea	16-9-1935. Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:09:41.245	2025-10-15 18:09:41.245
cmgsb2qgw042mh9i6bfkywk8r	Mujer apoyada en silla	Mujer apoyada en silla	Mujer apoyada en silla en Pueblo de Lo Barnechea		Amelia Rosa Medina Leiva	hacia 1939	1930	Pueblo de Lo Barnechea	hoy tiene 105. Circa 1939. Pueblo de Lo Barnechea	2	Cristian Garrido	Procultura	2025-10-15 18:09:43.808	2025-10-15 18:09:43.808
cmgsb2ta8042th9i6rye3wb50	Niño en primera comunión	Niño en primera comunión	Niño en Primera comunión	Parroquia de Lo Barnechea, se nota la pirca de piedra	Jaime Cornejo León	1932	1930		Primera comunión. Fotografía antigua digitalizada	2	UNCAF	Procultura	2025-10-15 18:09:47.457	2025-10-15 18:09:47.457
cmgsb2vv80430h9i62snl6goe	Hombre a caballo junto a niño	Hombre a caballo junto a niño	Hombre a caballo junto a niño en Raúl Labbé, cerca de la iglesia		Tito Celis	1939	1930	Pueblo de Lo Barnechea	Raúl Labbé, cerca de la iglesia. Fotografía antigua digitalizada	2	UNCAF	Procultura	2025-10-15 18:09:50.804	2025-10-15 18:09:50.804
cmgsb2yjl0437h9i69y96w5kk	Patriarca de la familia Bustamante	Patriarca de la familia Bustamante	Patriarca de la familia Bustamante frente a la iglesia		Daniel Bustamante	hacia 1930	1930		mamá dice que se llama Daniel, hija dice que Patricia. Circa 1930. Frente a la iglesia. Fotografía antigua digitalizada	2	UNCAF	Procultura	2025-10-15 18:09:54.273	2025-10-15 18:09:54.273
cmgsb34ut043lh9i695frnuhl	Hombre montando mula	Hombre montando mula	Hombre montando mula		Victor Vera Orellana. Se dedicaba a cazar conejos en La Dehesa, y los llevaba en mula a la Vega.	hacia 1930	1930		Fotografía antigua digitalizada	2	UNCAF	Procultura	2025-10-15 18:10:02.454	2025-10-15 18:10:02.454
cmgsb36sj043sh9i6zlcjwyyv	Dama con blusa blanca	Dama con blusa blanca	Dama con blusa blanca en Pueblo de Lo Barnechea		Lucía Villarroel	1920-1930	1920	Pueblo de Lo Barnechea	Década 1920. Pueblo de Lo Barnechea	2	Familia Soto Torreblanca	Procultura	2025-10-15 18:10:04.963	2025-10-15 18:10:04.963
cmgsb386l043zh9i6rnezb780	Mujer y niña	Mujer y niña	Mujer y niña en Pueblo de Lo Barnechea		la niña es Rosa Eliana Diaz Lira	hacia 1929	1920	Pueblo de Lo Barnechea	Circa 1929. Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:10:06.766	2025-10-15 18:10:06.766
cmgsb3a0g0446h9i6wzqx1c3i	Niño en juguete de león	Niño en juguete de león	Niño en juguete de león en Pueblo de Lo Barnechea		Juan de Dios Garrido Guajardo	1928	1920	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Cristian Garrido	Procultura	2025-10-15 18:10:09.137	2025-10-15 18:10:09.137
cmgsb3dc1044dh9i60cnw0vft	Hombre y niño	Hombre y niño	Hombre y niño en Pueblo de Lo Barnechea	Papel Postcard	Padre (Elidio Torreblanca?) e hijo.	hacia 1910	1910	Pueblo de Lo Barnechea	Circa 1910. Pueblo de Lo Barnechea	2	Familia Soto Torreblanca	Procultura	2025-10-15 18:10:13.441	2025-10-15 18:10:13.441
cmgsb3f09044kh9i64jzei1ux	Hombre sentado	Hombre sentado	Hombre sentado en Casona de Farellones, sector de Lo Hermida (aprox km 11)		Pedro Garrido Castillo	1900	1900	Farellones	Casona de Farellones, sector de Lo Hermida (aprox km 11)	2	Cristian Garrido	Procultura	2025-10-15 18:10:15.61	2025-10-15 18:10:15.61
cmgsb3i2g044rh9i6v7l37ven	Funeral con carroza	Funeral con carroza	Funeral con carroza		Segundo desde la izquieda, David Araya	hacia 1890	1890			2	María Araya	Procultura	2025-10-15 18:10:19.575	2025-10-15 18:10:19.575
cmgsb3jmc044yh9i66nfsgzvh	Pareja con niño recién bautizado	Pareja con niño recién bautizado	Pareja con niño recién bautizado en Pueblo de Lo Barnechea		Paulina Valencia Moya (madrina), Daniel (papá)	hacia 1990	1990	Pueblo de Lo Barnechea	1990 circa. Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:10:21.588	2025-10-15 18:10:21.588
cmgsb43ea0455h9i6zhufot50	Cuartel de Bomberos	Cuartel de Bomberos	Cuartel de Bomberos en Cuatro Vientos esquina Barnechea		19 Compañía de Bomberos	1990-2000	1990	Pueblo de Lo Barnechea	Década de 1990. Cuatro Vientos esquina Barnechea	2	Familia Meza Cortés	Procultura	2025-10-15 18:10:47.216	2025-10-15 18:10:47.216
cmgsb44sl045ch9i6om640vy1	Competidor en carrera del colegio farellones	Competidor en carrera del colegio farellones	Competidor en carrera del colegio farellones en Cancha El Colorado, Farellones		Luis Alberto Gallardo	hacia 1985	1980	Farellones	ca.1985. Cancha El Colorado, Farellones	2	Familia Gallardo	Procultura	2025-10-15 18:10:49.029	2025-10-15 18:10:49.029
cmgsb45zt045jh9i6x0kw7owg	Grupo familiar	Grupo familiar	Grupo familiar en casa en pueblo de Farellones		Liliana Fernández, Luis Encina, María Álvarez, Rafael Gallardo, Luis Gallardo	1980	1980	Farellones	Casa familiar en pueblo de Farellones	2	Familia Gallardo	Procultura	2025-10-15 18:10:50.585	2025-10-15 18:10:50.585
cmgsb47hi045qh9i6s2w9uci6	Niño esquiando	Niño esquiando	Niño esquiando en Colorado	Vivían en El Colorado	Maxel Herrera	1985	1980	Farellones	Colorado	2	Familia Gallardo	Procultura	2025-10-15 18:10:52.519	2025-10-15 18:10:52.519
cmgsb49si0464h9i61mf4r6fb	Tres niños en la nieve	Tres niños en la nieve	Tres niños en la nieve en Farellones	Luis es tío de las niñas	Maiga Gallardo, Luis Gallardo, Ani Gallardo	1987	1980	Farellones	Farellones	2	Familia Gallardo	Procultura	2025-10-15 18:10:55.506	2025-10-15 18:10:55.506
cmgsb4wb0046ph9i669azpjqz	Joven subiendo a la cordillera	Joven subiendo a la cordillera	Joven subiendo a la cordillera en Sector Cancha de Carreras, Fundo Potrero Grande		Alfonso Campos,  de 14-15 años	1985	1980	Farellones	Sector Cancha de Carreras, Fundo Potrero Grande	2	Alfonso Campos	Procultura	2025-10-15 18:11:24.683	2025-10-15 18:11:24.683
cmgsb53rf0473h9i6ahod9gv3	Graduación de hombres	Graduación de hombres	Graduación de hombres en Colegio Parroquial		Graduado Enrique Meza, profesor Alejandro Pinto. Maestro de ceremonias Ramon Meza Pinto	1980	1980	Pueblo de Lo Barnechea	Colegio Parroquial	2	Familia Meza Cortés	Procultura	2025-10-15 18:11:34.348	2025-10-15 18:11:34.348
cmgsb576x047hh9i672qx0126	Tres niños en Santiago	Tres niños en Santiago	Tres niños en Centro de Santiago		Guillermo Gallardo, Adela Gallardo, Rafael Gallardo	1978	1970	Santiago	Centro de Santiago	2	Familia Gallardo	Procultura	2025-10-15 18:11:38.793	2025-10-15 18:11:38.793
cmgsb5gpa0482h9i658tseb01	Tres jóvenes	Tres jóvenes	Tres jóvenes en Pastor Fernández		José Antonio (sobrino), Pedro Barrera, Patricio Dotte (tío)	hacia 1975	1970	El Arrayán	Circa 1975. Pastor Fernández	2	Patricia Dotte	Procultura	2025-10-15 18:11:51.118	2025-10-15 18:11:51.118
cmgsb5lag048gh9i6tkx9xd6v	Niños bailando cueca	Niños bailando cueca	Niños bailando cueca	Colegio Camilo Lopez Pinto, El Arrayan	Juan Maureira Gana y profesora Ana	1975	1970	El Arrayán	Colegio Camilo Lopez Pinto, El Arrayan. 18-9-75	2	Margarita Gana	Procultura	2025-10-15 18:11:57.065	2025-10-15 18:11:57.065
cmgsb4bb0046bh9i69rjevfs1	Vista de El Colorado	Vista de El Colorado	Vista de El Colorado en El Colorado	Se ve casa roja que ya no existe		hacia 1988	1980	Farellones	ca. 1988. El Colorado	2	Familia Gallardo	Procultura	2025-10-15 18:10:57.469	2025-10-15 18:10:57.469
cmgsb4cfo046ih9i6csmhzxgb	Niñas afuera de una casa de piedra	Niñas afuera de una casa de piedra	Niñas afuera de una casa de piedra en Farellones		Juan Hernández, Adela Gallardo, Ani Fernández	1980	1980	Farellones	Farellones	2	Familia Gallardo	Procultura	2025-10-15 18:10:58.932	2025-10-15 18:10:58.932
cmgsb55v3047ah9i6xzhq3a5s	Grupo de niños junto a caballo de madera	Grupo de niños junto a caballo de madera	Grupo de niños junto a caballo de madera en Centro de Santiago	Las dos primeras niñas son gemelas	Jaqueline Fernández Álvarez, Liliana Fernández Álvarez, Guillermo Gallardo Álvarez, Rafael Gallardo Álvarez, Adela Gallardo Álvarez, Rafael Gallardo Álvarez	1977	1970	Santiago	Centro de Santiago	2	Familia Gallardo	Procultura	2025-10-15 18:11:37.071	2025-10-15 18:11:37.071
cmgsb5adw047oh9i619sde7zd	Hombre junto a una chimenea	Hombre junto a una chimenea	Hombre junto a una chimenea en El Arrayán		Elidio Montenegro, cuidador de una parcela en el Arrayan	hacia 1970	1970	El Arrayán	circa 1970. El Arrayan	2	Clemira Montenegro	Procultura	2025-10-15 18:11:42.932	2025-10-15 18:11:42.932
cmgsb5jop0489h9i6sv26uv45	Novios junto a un tío	Novios junto a un tío	Novios junto a un tío		Gloria Salazar, Alfredo Arce, Patricio Dotte (tío de la novia)	hacia 1977	1970			2	Patricia Dotte	Procultura	2025-10-15 18:11:54.985	2025-10-15 18:11:54.985
cmgsb4zyy046wh9i6rgkbyjgr	Grupo en la cocina de un evento	Grupo en la cocina de un evento	Grupo en la cocina de un evento en Casa de Amanda Chacón		Der: Luis Moraga, Luis Ortiz, Savando, señora Digna, Yoconda Moya	1984	1980	Pueblo de Lo Barnechea	1 de Diciembre de 1984. Casa de Amanda Chacon	2	Yoconda Moya	Procultura	2025-10-15 18:11:29.434	2025-10-15 18:11:29.434
cmgsb5faw047vh9i6kmpgfz8r	Viajero y guía frente a una laguna	Viajero y guía frente a una laguna	Viajero y guía frente a la Laguna de Castro, El Arrayán		Elidio Montenegro Morales, "don Juanito", venia de paseo a la cordillera	hacia 1970	1970	El Arrayán	ML. circa 1970. Laguna de Castro, El Arrayan con Los Andes	2	Clemira Montenegro	Procultura	2025-10-15 18:11:49.304	2025-10-15 18:11:49.304
cmgsb69fi048nh9i6gjsl023u	Adultos y niños frente a caseta del andarivel	Adultos y niños frente a caseta del andarivel	Adultos y niños frente a caseta del andarivel en Cancha el Embudo	El motorista del andarivel vivía y trabajaba en la caseta de piedra del andarivel. Los dos adultos son hermanos, y están cada uno con su hijo/a.	María Álvarez, Carlos Hernández Álvarez, María Eugenia Fernández Álvarez, Eugenio Fernández	hacia 1960	1960	Farellones	ca. 1960. Cancha el Embudo	2	Familia Gallardo	Procultura	2025-10-15 18:12:28.35	2025-10-15 18:12:28.35
cmgsb6b85048uh9i6ai7gcvq4	Dirigente sindical de la Disputada	Dirigente sindical de la Disputada	Dirigente sindical de la Mina Disputada en la mina	Foto ampliada.	Pedro Blas Cortes Jelvez, dirigente sindical de la Mina Disputada, asesinado el 76 por represión militar, juntoa otros dirigentes de la mina.	hacia 1970	1970	Farellones	Circa 1970. Mina Disputada. 	2	Familia Meza Cortés	Procultura	2025-10-15 18:12:30.677	2025-10-15 18:12:30.677
cmgsb6bo90491h9i6mbntdhsw	Pareja sentada a la mesa	Pareja sentada a la mesa	Pareja sentada a la mesa en Panchulo	Trabajaba en un andarivel, en la mina de cobre.	Mamá de Clemira junto al hijo de los Gana, Panchulo, Francisco	hacia 1960	1960		Ca. 1960. Panchulo trabajaba en un andarivel, en la mina de cobre.	2	Clemira Montenegro	Procultura	2025-10-15 18:12:31.258	2025-10-15 18:12:31.258
cmgsb6g740498h9i6upsl6a00	Hombres y caballo	Hombres y caballo	Hombres y caballo en Sector La Quesería, fundo Potrero Grande		Tomás Campos; atrás Carlos Regular, campero.	1962-1965	1960	Farellones	1962-65. Sector La Quesería, fundo Potrero Grande	2	Alfonso Campos	Procultura	2025-10-15 18:12:37.121	2025-10-15 18:12:37.121
cmgsb6l5f049fh9i6467cdfdg	Rodeo de caballos	Rodeo de caballos	Rodeo de caballos en Majada de los Ojos de agua, fundo Potrero Grande			1960-1970	1960	Farellones	Década de 1960. Majada de los Ojos de agua, fundo Potrero Grande. Rodeo de caballos para hacer la domadura. Yeguas de cría, reproductoras. Los caballos subían tambien en la veranada.	2	Alfonso Campos	Procultura	2025-10-15 18:12:43.538	2025-10-15 18:12:43.538
cmgsb6qi2049mh9i6nc2c0arj	Paisaje de rocas	Paisaje de rocas	Paisaje de rocas en Fundo Potrero Grande			1960-1970	1960	Farellones	Década de 1960. Fundo Potrero Grande. Rocas , en ese filo del cerro pasan hoy las torres de alta tensión. Actualmente se le conoce como ruta del condor.	2	Alfonso Campos	Procultura	2025-10-15 18:12:50.474	2025-10-15 18:12:50.474
cmgsb6vjd049th9i6dnjixt8n	Caballos tras la cerca	Caballos tras la cerca	Caballos tras la cerca en Fundo Potrero Grande			1960-1970	1960	Farellones	Década de 1960. Fundo Potrero Grande. Corral de los rodeos	2	Alfonso Campos	Procultura	2025-10-15 18:12:57.002	2025-10-15 18:12:57.002
cmgsb71sb04a0h9i6qyaos8tt	Caballos tras la cerca	Caballos tras la cerca	Caballos tras la cerca en Fundo Potrero Grande			1960-1970	1960	Farellones	Década de 1960. Fundo Potrero Grande. Corral de los rodeos	2	Alfonso Campos	Procultura	2025-10-15 18:13:05.099	2025-10-15 18:13:05.099
cmgsb78mi04a7h9i6rtdvhqeg	Trabajador frente a paisaje de rocas	Trabajador frente a paisaje de rocas	Trabajador frente a paisaje de rocas en Fundo Potrero Grande		Froilán Mandujano, “el cuatro dientes”,	1960-1970	1960	Farellones	Década de 1960. Fundo Potrero Grande	2	Alfonso Campos	Procultura	2025-10-15 18:13:13.962	2025-10-15 18:13:13.962
cmgsb7k4c04aeh9i6hz4wpqx0	Dos hombres a caballo	Dos hombres a caballo	Dos hombres a caballo en Fundo Potrero Grande		Juan Mandujano y a la der Ricardo Campos.	1965	1960	Farellones	Fundo Potrero Grande	2	Alfonso Campos	Procultura	2025-10-15 18:13:28.859	2025-10-15 18:13:28.859
cmgsb7l2x04alh9i6uslk95xj	Profesor y alumnos en bote	Profesor y alumnos en bote	Profesor y alumnos en un paseo en bote en Valparaíso		Ramón Meza Pinto con tres alumnos del colegio parroquial	1960-1970	1960	Otro	Década de 1960. Paseo a Valparaiso	2	Familia Meza Cortés	Procultura	2025-10-15 18:13:30.105	2025-10-15 18:13:30.105
cmgsb7o1b04ash9i6l3izjv4w	Profesor y alumnos de media	Profesor y alumnos de media	Profesor y alumnos de media en Colegio Parroquial Santa Rosa	C. Garrido 97 LB	Profesor Ramón Meza, a la der Alberto Alvarez, al centro Galvita.	1960-1970	1960	Pueblo de Lo Barnechea	Década 1960. Colegio Parroquial Santa Rosa. 	2	Familia Meza Cortés	Procultura	2025-10-15 18:13:33.935	2025-10-15 18:13:33.935
cmgsb7p6604azh9i68ejs1zow	Hombre en cancha de futbol	Hombre en cancha de futbol	Hombre en cancha de fútbol de Lo Barnechea		Ramon Meza Pinto con camiseta de Juventud catolica	hacia 1960	1960	Pueblo de Lo Barnechea	Circa 1960. Cancha de Lo Barnechea	2	Familia Meza Cortés	Procultura	2025-10-15 18:13:35.407	2025-10-15 18:13:35.407
cmgsb7rlh04b6h9i6m8g6txmt	Niña en kinder	Niña en kinder	Niña en kinder en Colegio parroquial		Andrea Meza Cortes	1968	1960	Pueblo de Lo Barnechea	Colegio parroquial	2	Familia Meza Cortés	Procultura	2025-10-15 18:13:38.55	2025-10-15 18:13:38.55
cmgsb7tm904bdh9i6azz9hv2f	Niño en Quinto	Niño en Quinto	Niño en Quinto en Colegio parroquial		Ramón Meza Cortes	hacia 1966	1960	Pueblo de Lo Barnechea	Circa 1966. Colegio parroquial	2	Familia Meza Cortés	Procultura	2025-10-15 18:13:41.17	2025-10-15 18:13:41.17
cmgsb7ve004bkh9i62h1jx6pa	Grupo frente a imagen de Santa Rosa	Grupo frente a imagen de Santa Rosa	Grupo frente a imagen de Santa Rosa en Parroquia Santa Rosa		Ramón Meza Pinto, Andrea Meza Cortes, Ramon Meza Cortes, Ester Mesa Cortes, Rosa Ester Cortes, Enrique Meza Cortes	hacia 1968	1960	Pueblo de Lo Barnechea	Circa 1968. Parroquia Santa Rosa	2	Familia Meza Cortés	Procultura	2025-10-15 18:13:43.465	2025-10-15 18:13:43.465
cmgsb8g7b04brh9i6bd9zxdkf	Dos hombres sentados	Dos hombres sentados	Dos hombres sentados en Santiago	Eran compadres. Guillermo era de la Ermita y trabajaba en las máquinas motoniveladoras.	Guillermo Polanco, Rafael Gallardo Ramos	hacia 1950	1950	Santiago	ca.1950. Santiago	2	Familia Gallardo	Procultura	2025-10-15 18:14:10.438	2025-10-15 18:14:10.438
cmgsb8h8304byh9i6hdrho43q	Hombre y niña jugando	Hombre y niña jugando	Hombre y niña jugando en casa en calle El León		Ana María Aguilera, Gustavo Gonzalez	hacia 1957	1950	Pueblo de Lo Barnechea	Circa 1957. Casa en calle El León	2	Familia Meza Cortés	Procultura	2025-10-15 18:14:11.763	2025-10-15 18:14:11.763
cmgsb8j3104c5h9i6fx6ebx3b	Comida	Comida	Comida en casa de familia Cortés Jelvez, calle el León 	La casa fue demolida	“lolin” Salfate, Alfredo “Troni” Lobos (pintor), Carmen Cortes, Rosa Ester Cortes, Ramon Meza Pinto, Patricia Martinez, Alberto Espinoza, David Lobos, NN, Jaime Pizarro (papa del jugador de futbol)	hacia 1957	1950	Pueblo de Lo Barnechea	Troni Lobos vive como en la 3ra casa en El Gabino. Circa 1957. Casa de familia Cortes Jelvez, calle el Leon (demolida)	2	Familia Meza Cortés	Procultura	2025-10-15 18:14:14.174	2025-10-15 18:14:14.174
cmgsb8mzd04cch9i6049qc4ol	Novia entrando a la iglesia	Novia entrando a la iglesia	Novia entrando a la iglesia en Parroquia Santa Rosa		Ester Cortes	1957	1950	Pueblo de Lo Barnechea	30/8/1957.. Parroquia Santa Rosa	2	Familia Meza Cortés	Procultura	2025-10-15 18:14:19.225	2025-10-15 18:14:19.225
cmgsb8qzs04cjh9i66ou2uko8	Matrimonio	Matrimonio	Matrimonio en Parroquia Santa Rosa		Padre Alfredo Arteaga, Ramon Meza Hormazabal, Ramon Meza Pinto, Rosa Cortes Jelvez, Benita Pinto Gonzalez	1957	1950	Pueblo de Lo Barnechea	importante pq aparece padre arteaga. 21062. Parroquia Santa Rosa	2	Familia Meza Cortés	Procultura	2025-10-15 18:14:24.424	2025-10-15 18:14:24.424
cmgsb97ek04dbh9i6b4u2g88d	Cuasimodista y caballo	Cuasimodista y caballo	Cuasimodista y caballo	Hermano de Clemira		hacia 1940	1940		ca. 1940. Hermano de Clemira	2	Clemira Montenegro	Procultura	2025-10-15 18:14:45.69	2025-10-15 18:14:45.69
cmgsb8vae04cqh9i6lpa65hv1	Novia pasando bajo pasacalle	Novia pasando bajo pasacalle	Novia pasando bajo pasacalle en Parroquia Santa Rosa		Ramon Meza Hormazabal, y Ester Cortes. Hacen el pasacalle los integrantes del Club Católica.	1957	1950	Pueblo de Lo Barnechea	importante por mostrar vida del club catolica. 21062. Parroquia Santa Rosa. Pascalle con ramitas de colitas de zorro.	2	Familia Meza Cortés	Procultura	2025-10-15 18:14:29.99	2025-10-15 18:14:29.99
cmgsb8yz604cxh9i62fo2bc2r	Equipo femenino de Basquetball	Equipo femenino de Basquetball	Equipo femenino de Basquetball en la cancha de fútbol	Posiblemente se trataba de un desfile	Arriba: Norma Cortez, Maria Martínez Pinto, Sofia Silva, Paula Astaburuaga. Abajo:  Ester Corte,z Maria Araya, Petronila Araya. Técnico Luis Olivares “Paco Lucho”	1950-1960	1950	Población Nebraska	preguntar a Maria Araya. Década de 1950. Posiblemente desfile, en la cancha de futbol	2	Familia Meza Cortés	Procultura	2025-10-15 18:14:34.771	2025-10-15 18:14:34.771
cmgsb93ej04d4h9i6cds3447t	Familia con hombre sentado	Familia con hombre sentado	Familia con hombre sentado	Familia Gana era de sector El Arrayán. Mamá de Clemira llegó a vivir donde ellos, luego de que falleciera su papá en Los Andes.	Ana de Gana, Lucrecia Jara, mamá, con Lorenzo Montenegro. Sentado, Francisco Gana con Panchulo en brazos.	hacia 1940	1940	El Arrayán	ca. 1940. Familia Gana era de sector El Arrayan. Mamá de Clemira llegó a vivir donde ellos, luego de que falleciera su papá en Los Andes.	2	Clemira Montenegro	Procultura	2025-10-15 18:14:40.507	2025-10-15 18:14:40.507
cmgsb99nz04dih9i6j3tx171x	Primera comiunion	Primera comiunion	Primera comunión en Parroquia Santa Rosa		Ester Cortes	1942	1940	Pueblo de Lo Barnechea	Parroquia Santa Rosa	2	Familia Meza Cortés	Procultura	2025-10-15 18:14:48.624	2025-10-15 18:14:48.624
cmgsb9b7w04dph9i6hq5qfa9q	Niño en primera comunión con abuela	Niño en primera comunión con abuela	Niño en primera comunión con abuela en Parroquia en Santiago Centro	Papel Post Card	Benita Gonzalez y su nieto Ramon Meza Pinto	hacia 1943	1940	Santiago	Circa 1943. Parroquia en Santiago Centro. 	2	Familia Meza Cortés	Procultura	2025-10-15 18:14:50.636	2025-10-15 18:14:50.636
cmgsb9cca04dwh9i6ue9fmj5o	Grupo frente a cerro en Farellones	Grupo frente a cerro en Farellones	Grupo frente a cerro en Farellones 		Adela Gallardo, Guillermo Gallardo, *amiga de Valparaiso*, Liliana Gallardo, Rafael Gallardo	hacia 1980	1980	Farellones	ML. ca.1980. Pueblo de farellones	2	Familia Gallardo	Procultura	2025-10-15 18:14:52.09	2025-10-15 18:14:52.09
cmgsb9epm04e3h9i6gfd2u3tt	Saludo desde un coche de cuasimodo	Saludo desde un coche de cuasimodo	Saludo desde un coche de cuasimodo							2	Clemira Montenegro	Procultura	2025-10-15 18:14:55.162	2025-10-15 18:14:55.162
cmgsb9ib304eah9i6jo9mseye	Mujer jinete en Cuasimodo	Mujer jinete en Cuasimodo	Mujer jinete en Cuasimodo							2	Clemira Montenegro	Procultura	2025-10-15 18:14:59.823	2025-10-15 18:14:59.823
cmgsb9nda04ehh9i6pxnmfokk	Cuasimodista frente a iglesia blanca	Cuasimodista frente a iglesia blanca	Cuasimodista frente a iglesia blanca							2	Clemira Montenegro	Procultura	2025-10-15 18:15:06.348	2025-10-15 18:15:06.348
cmgsb9q7s04eoh9i6kdbri21d	Pareja de niños bailando cueca	Pareja de niños bailando cueca	Pareja de niños bailando cueca							2	Rocio Muñoz	Procultura	2025-10-15 18:15:10.072	2025-10-15 18:15:10.072
cmgsb9syk04evh9i6v5i4vii0	Niño en su primera comunión	Niño en su primera comunión	Niño en su primera comunión							2	Rocio Muñoz	Procultura	2025-10-15 18:15:13.629	2025-10-15 18:15:13.629
cmgsb9wqu04f2h9i6ukq7votf	Equipo de fútbol	Equipo de fútbol	Equipo de fútbol en Cancha de Barnechea		Otro equipo de la asociación			Pueblo de Lo Barnechea	Cancha de Barnechea	2	Eliseo Villarroel	Procultura	2025-10-15 18:15:18.534	2025-10-15 18:15:18.534
cmgsb9yvv04f9h9i684o0rkbx	Equipo fútbol con cerro detrás	Equipo fútbol con cerro detrás	Equipo fútbol con cerro detrás en Cancha de Barnechea	Papel Postcard	Equipo de Juventud Católica			Pueblo de Lo Barnechea	Cancha de Barnechea	2	Eliseo Villarroel	Procultura	2025-10-15 18:15:21.307	2025-10-15 18:15:21.307
cmgsba0is04fgh9i66nj3k9ii	Equipo de fútbol con dos pelotas	Equipo de fútbol con dos pelotas	Equipo de fútbol con dos pelotas en Pueblo de Lo Barnechea	“Víctor Conejeros”	Eliseo Villarroel, Roberto Castro "poquita fe", Negro Madrid, Moroco Figueroa, Pepe Gutierrez, Lucho Aracena, Roberto Galvez, Victor Barrera, Lucho Bahamondes, Chico Améstica, Oscar Molina			Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Eliseo Villarroel	Procultura	2025-10-15 18:15:23.427	2025-10-15 18:15:23.427
cmgsba2h004fnh9i64fzvtkch	Tres hombres conversando	Tres hombres conversando	Tres hombres conversando en Pueblo de Lo Barnechea	“Oscar Acuña (tesorero) Alberto Saavedra, Romero””Beto Saavedra”		1979	1970	Pueblo de Lo Barnechea	“24 febrero 1979”. Pueblo de Lo Barnechea	2	Eliseo Villarroel	Procultura	2025-10-15 18:15:25.956	2025-10-15 18:15:25.956
cmgsba61h04fuh9i64t16vybw	Jóvenes con diplomas	Jóvenes con diplomas	Jóvenes con diplomas en La Cerámica, salón atrás de la Iglesia	“pedro Galvez Molina”	Roberto Castro, Ramón Silva, nn, Sergio Salcedo, nn, Victor Conejera. Abajo: “cabeza de fierro chico” Gálvez, “Chico” Améstica, Eduardo Figueroa “Moroco”, José Gutiérrez “Pepe”	1972	1970	Pueblo de Lo Barnechea	“1972”. La Cerámica, salón atrás de la Iglesia	2	Eliseo Villarroel	Procultura	2025-10-15 18:15:30.582	2025-10-15 18:15:30.582
cmgsba9vb04g1h9i6beurmq10	Niño junto a sacerdote	Niño junto a sacerdote	Niño junto a sacerdote							2	Rocio Muñoz	Procultura	2025-10-15 18:15:35.543	2025-10-15 18:15:35.543
cmgsbaec204g8h9i6t749hwf1	Cinco jóvenes en una construcción	Cinco jóvenes en una construcción	Cinco jóvenes en una construcción							2	Rocio Muñoz	Procultura	2025-10-15 18:15:41.329	2025-10-15 18:15:41.329
cmgsbahhh04gfh9i690btdwp1	Niño recibe trofeo de deportes	Niño recibe trofeo de deportes	Niño recibe trofeo de deportes							2	Rocio Muñoz	Procultura	2025-10-15 18:15:45.413	2025-10-15 18:15:45.413
cmgsbajp304gmh9i6xfp7rj06	Bebé niña	Bebé niña	Bebé niña							2	Rocio Muñoz	Procultura	2025-10-15 18:15:48.279	2025-10-15 18:15:48.279
cmgsbam5b04gth9i6dfp8o2il	Novios junto a un grupo	Novios junto a un grupo	Novios junto a un grupo							2	Rocio Muñoz	Procultura	2025-10-15 18:15:51.456	2025-10-15 18:15:51.456
cmgsbaobd04h0h9i6ac2tbwi0	Grupo en matrimonio	Grupo en matrimonio	Grupo en matrimonio							2	Rocio Muñoz	Procultura	2025-10-15 18:15:54.265	2025-10-15 18:15:54.265
cmgsbaray04h7h9i6do56oz12	Mujer y niña reciben regalo del viejo pascuero	Mujer y niña reciben regalo del viejo pascuero	Mujer y niña reciben regalo del viejo pascuero							2	Rocio Muñoz	Procultura	2025-10-15 18:15:58.138	2025-10-15 18:15:58.138
cmgsbb7h504heh9i653zkb3c6	Pareja bailando	Pareja bailando	Pareja bailando		Doña Tina y su marido					2	Rocio Muñoz	Procultura	2025-10-15 18:16:19.096	2025-10-15 18:16:19.096
cmgsbb9pi04hlh9i6nt42rjr0	Podio  jóvenes ganadores	Podio  jóvenes ganadores	Podio de jóvenes ganadores		A la izq Adasme (ciclismo)					2	Rocío Muñoz	Procultura	2025-10-15 18:16:21.99	2025-10-15 18:16:21.99
cmgsbbbvu04hsh9i680b761ad	Grupo exhibiendo premios	Grupo exhibiendo premios	Grupo exhibiendo premios		Club Deportivo Real San Antonio					2	Rocío Muñoz	Procultura	2025-10-15 18:16:24.81	2025-10-15 18:16:24.81
cmgsbbdkr04hzh9i6r3edl1q3	Arco y marcador	Arco y marcador	Arco y marcador							2	Rocío Muñoz	Procultura	2025-10-15 18:16:27.003	2025-10-15 18:16:27.003
cmgsbbgmz04i6h9i6nleqji7r	Capitanes y árbitros	Capitanes y árbitros	Capitanes y árbitros							2	Rocío Muñoz	Procultura	2025-10-15 18:16:30.971	2025-10-15 18:16:30.971
cmgsbbjmu04idh9i6c3c2kppk	Desfile escolar de lado	Desfile escolar de lado	Desfile escolar de lado							2	Rocío Muñoz	Procultura	2025-10-15 18:16:34.854	2025-10-15 18:16:34.854
cmgsbbt7304iyh9i61r5w30jp	Vista de Cuasimodo en medialuna Cerro 18	Vista de Cuasimodo en medialuna Cerro 18	Vista de Cuasimodo en medialuna del Cerro 18					Cerro 18	Cerro 18	2	Rocío Muñoz	Procultura	2025-10-15 18:16:47.247	2025-10-15 18:16:47.247
cmgsbbzoc04jjh9i6316ib22t	Hombre disfrazado junto a niños	Hombre disfrazado junto a niños	Hombre disfrazado junto a niños							2	Rocío Muñoz	Procultura	2025-10-15 18:16:55.644	2025-10-15 18:16:55.644
cmgsbc1xk04jqh9i6fe2x4geu	Asamblea Club Deportivo Barnechea	Asamblea Club Deportivo Barnechea	Asamblea Club Deportivo Barnechea							2	Rocío Muñoz	Procultura	2025-10-15 18:16:58.569	2025-10-15 18:16:58.569
cmgsbc8ht04kbh9i69v86m2fd	Dos mujeres frente a auto decorado por Cuasimodo	Dos mujeres frente a auto decorado por Cuasimodo	Dos mujeres frente a auto decorado por Cuasimodo							2	Rocío Muñoz	Procultura	2025-10-15 18:17:07.072	2025-10-15 18:17:07.072
cmgsbcc4w04kwh9i6hgh945ug	Joven conscripto	Joven conscripto	Joven conscripto	a los 18 ahora tiene 62	Manuel Herrera					2	Familia Muñoz Dotte	Procultura	2025-10-15 18:17:11.792	2025-10-15 18:17:11.792
cmgsbcg3c04lah9i6xuqsxyyw	Tres hombres tomando vino	Tres hombres tomando vino	Tres hombres tomando vino en Restaurante Las Delicias, en San Enrique		Pablo Astorga Vera, nn, Juan Gastón Vera Reyes.	1960-1970	1960	San Enrique/La Ermita/Las Condes	Las Delicias, preguntar por fotos. Dècada del 1960. Restaurante Las Delicias, en San Enrique	2	Mariela Bravo	Procultura	2025-10-15 18:17:16.921	2025-10-15 18:17:16.921
cmgsbci5c04lhh9i682754n2l	Equipo de futbol	Equipo de futbol	Equipo de fútbol en Pueblo de Lo Barnechea	Foto cortada. Muy antigua pero mal estado	Benjamin Valencia, loreto, Jaime Alvarez. Abajo: Enrique Besares, Flaco Alvarez, Jaime Alvarez			Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:17:19.585	2025-10-15 18:17:19.585
cmgsbckrv04m2h9i6g6w87xmq	Dos niñas	Dos niñas	Dos niñas en casa de su bisabuela en Los Patos	Año debe estar mal. Es muy antigua la foto. Confirmarlo en la planilla original del archivo de Procultura.	Cristel Mendoza Valencia y Carola Barrera			Pueblo de Lo Barnechea	Circa 1995. Casa de su bisabuela en Los Patos	2	Yoconda Moya	Procultura	2025-10-15 18:17:22.988	2025-10-15 18:17:22.988
cmgsbco3404mnh9i6u8dbw9yx	Cazadores de conejos	Cazadores de conejos	Cazadores de conejos en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:17:27.28	2025-10-15 18:17:27.28
cmgsbcrf904n1h9i67cweofq7	Cazadores de conejos comiendo	Cazadores de conejos comiendo	Cazadores de conejos comiendo en Pueblo de Lo Barnechea	Revisar lugar. y año No aparenta ser el Pueblo y fecha debe ser posterior a 1955.	Tercero: Cheo Cuarto: Lucho Negro Con sombrero: Gildo Pavez. Niño de gorro. Luego Carlos Moya. Extremo derecho de pie, Joaquin Moya. Sentado de blanco, Florito Arriagada.			Pueblo de Lo Barnechea	Min nació 1922. . Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:17:31.606	2025-10-15 18:17:31.606
cmgsbcv4y04nfh9i6ntwxltk8	Grupo de cazadores con sus presas detrás	Grupo de cazadores con sus presas detrás	Grupo de cazadores con sus presas detrás en Pueblo de Lo Barnechea	Revisar lugar. y año No aparenta ser el Pueblo y fecha debe ser posterior a 1955.	Hincado: Peirula. De pie de blanco, Joaquin Moya. Con gorro de lana: Gancho Che. Luego Florito Arriagada, Carlos Moya, Benjamin Madrid. Abajo Jerez.			Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:17:36.418	2025-10-15 18:17:36.418
cmgsbd9pl04oeh9i6dd0bbndk	Cazadores comiendo	Cazadores comiendo	Cazadores comiendo en Pueblo de Lo Barnechea	Revisar lugar. y año No aparenta ser el Pueblo y fecha debe ser posterior a 1955.				Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:17:55.297	2025-10-15 18:17:55.297
cmgsbdkui04osh9i63o55rr54	Padre e hija jugando	Padre e hija jugando	Padre e hija jugando en Pueblo de Lo Barnechea		Eugenia Moya y Benjamin Valencia (cuñado)	1972	1970	Pueblo de Lo Barnechea	“28 Noviembre 1972”. Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:18:09.738	2025-10-15 18:18:09.738
cmgsbea9e04q5h9i6rp8u6j3y	Mujer recibiendo regalo	Mujer recibiendo regalo	Mujer recibiendo regalo en Sede del club Barnechea		Manuel Jorquera y Ana			Pueblo de Lo Barnechea	Sede del club Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:18:42.674	2025-10-15 18:18:42.674
cmgsbeiza04qqh9i6zr3vg6c4	Jovencita escuchando con audífonos	Jovencita escuchando con audífonos	Joven con micrófono en Pueblo de Lo Barnechea		Enrique Manriquez y Carmen Moya			Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:18:53.974	2025-10-15 18:18:53.974
cmgsbf06f04rih9i6eokzhjsg	Novios junto a pareja	Novios junto a pareja	Novios junto a pareja en Pueblo de Lo Barnechea		Amanda Chacón, Luis Moraga,  Gladys Moya, Joaquín Moya			Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:19:16.263	2025-10-15 18:19:16.263
cmgsbg15c04tgh9i64e63fr27	Grupo de personas en fiesta	Grupo de personas en fiesta	Grupo de personas en fiesta en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	=C550. Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:20:04.175	2025-10-15 18:20:04.175
cmgsbbvg904j5h9i602lfqfwp	Presentador en reunión CD Lo Barnechea	Presentador en reunión CD Lo Barnechea	Presentador en reunión CD Lo Barnechea							2	Rocío Muñoz	Procultura	2025-10-15 18:16:50.169	2025-10-15 18:16:50.169
cmgsbcj0d04loh9i6cia0yfci	Niña en primera comunión	Niña en primera comunión	Niña en primera comunión en Pueblo de Lo Barnechea	Año debe estar mal (decía "1995" pero lo borré. Es muy antigua la foto. Confirmarlo en la planilla original del archivo de Procultura.	Cristel Mendoza Valencia			Pueblo de Lo Barnechea	Circa 1995. Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:17:20.701	2025-10-15 18:17:20.701
cmgsbclyt04m9h9i69jziw4p7	Dos niños en primera comunión	Dos niños en primera comunión	Dos niños en primera comunión en Pueblo de Lo Barnechea		Jaime Valencia y su hermano Gastón Valencia			Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:17:24.533	2025-10-15 18:17:24.533
cmgsbcn9b04mgh9i6v7j71ym4	Dos hombres cargando un caballo	Dos hombres cargando un caballo	Dos hombres cargando un caballo para ir a cazar		Joaquín Moya atrás del caballo			Pueblo de Lo Barnechea	Iban a cazar	2	Yoconda Moya	Procultura	2025-10-15 18:17:26.208	2025-10-15 18:17:26.208
cmgsbcxcu04nmh9i6op4qmnch	Cazadores limpiando la mesa	Cazadores limpiando la mesa	Cazadores limpiando la mesa en Pueblo de Lo Barnechea	Revisar lugar. y año No aparenta ser el Pueblo y fecha debe ser posterior a 1955.				Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:17:39.294	2025-10-15 18:17:39.294
cmgsbd11804o0h9i6kr4dbxag	Cazadores descansando	Cazadores descansando	Cazadores descansando en Pueblo de Lo Barnechea	Revisar lugar. y año No aparenta ser el Pueblo y fecha debe ser posterior a 1955.				Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:17:44.06	2025-10-15 18:17:44.06
cmgsbdeak04olh9i67hy2u3gl	Equipo de fútbol de rojo	Equipo de fútbol de rojo	Equipo de fútbol de rojo en Pueblo de Lo Barnechea		Chancadora, nn, nn, Ortiz, nn, Patricio Salas, Nano Bravo. Abajo: Cachuzo, nn, Chico Meneses, nn.			Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:18:01.244	2025-10-15 18:18:01.244
cmgsbduta04p6h9i6atjfth1s	Bautizo	Bautizo	Bautizo en Parroquia Santa Rosa		Bebé: Vitito. Padrinos Yoconda Moya y Benjamín Valencia. Sacerdote Alfredo Arteaga			Pueblo de Lo Barnechea	ML (aparece padre arteaga). . Parroquia Santa Rosa	2	Yoconda Moya	Procultura	2025-10-15 18:18:22.655	2025-10-15 18:18:22.655
cmgsbdxu204pdh9i6qs2qdtoa	Familia con recién bautizado	Familia con recién bautizado	Familia con recién bautizado en Parroquia Santa Rosa		Izquierda Carmen Moya, Victor Herrera. Padrinos Yoconda Moya y Benjamin Valencia.			Pueblo de Lo Barnechea	=C506. Parroquia Santa Rosa	2	Yoconda Moya	Procultura	2025-10-15 18:18:26.57	2025-10-15 18:18:26.57
cmgsbe1w504pkh9i6z5jcxrya	Niño bautizado	Niño bautizado	Niño bautizado en Pueblo de Lo Barnechea		Vitito			Pueblo de Lo Barnechea	=C506. Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:18:31.828	2025-10-15 18:18:31.828
cmgsbe7lw04pyh9i6956fdxy7	Mujer con regalo	Mujer con regalo	Mujer con regalo en Sede del club Barnechea	En el club se celebraban todas las fiestas	Pachecho y señora María			Pueblo de Lo Barnechea	Sede del club Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:18:39.237	2025-10-15 18:18:39.237
cmgsbeg2p04qjh9i60hty84z4	Tres hombres vestidos de formal	Tres hombres vestidos de formal	Tres hombres vestidos de formal en Pueblo de Lo Barnechea		Cortes, Pacheco, Benjamín Valencia			Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:18:50.208	2025-10-15 18:18:50.208
cmgsbemv404qxh9i6880cxiq7	Joven con micrófono	Joven con micrófono	Jovencita escuchando con audífonos en Pueblo de Lo Barnechea		Enrique Manriquez			Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:18:59.008	2025-10-15 18:18:59.008
cmgsbeqqq04r4h9i64oc5dns1	Hombres jóvenes sentados a la mesa	Hombres jóvenes sentados a la mesa	Hombres jóvenes sentados a la mesa en Pueblo de Lo Barnechea		Der Segundo Moya , nn, Efraín Bravo, Benjamín Valencia, “Ño Chispa”, esposa			Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:19:04.034	2025-10-15 18:19:04.034
cmgsbf5qk04rph9i68hp1ouf4	Novios con dos hombres	Novios con dos hombres	Novios con dos hombres en Pueblo de Lo Barnechea		Benjamin Valencia, Luis Moraga, Gladys Moya, amigo			Pueblo de Lo Barnechea	=C533. Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:19:23.468	2025-10-15 18:19:23.468
cmgsbfivx04sah9i6nlecac7v	Grupo en comida de matrimonio	Grupo en comida de matrimonio	Grupo en comida de matrimonio en Sede del club Barnechea		A la der Toño Diaz, Joaquin Moya, Benjamin Valencia, Yoconda Moya, Carlos Perez, Renato Mesa, Blanca Galvez			Pueblo de Lo Barnechea	Sede del club Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:19:40.509	2025-10-15 18:19:40.509
cmgsbfrtw04t2h9i6pwnfda96	Tres jóvenes juegan en fiesta	Tres jóvenes juegan en fiesta	Tres jóvenes juegan en fiesta en Pueblo de Lo Barnechea		Luis Ubierna, Paulina Valencia, carabinero			Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:19:52.101	2025-10-15 18:19:52.101
cmgsbbxie04jch9i6ivydyurw	Lectora en reunión CD Lo Barnechea	Lectora en reunión CD Lo Barnechea	Lectora en reunión CD Lo Barnechea							2	Rocío Muñoz	Procultura	2025-10-15 18:16:52.838	2025-10-15 18:16:52.838
cmgsbc49g04jxh9i6ahifcqea	Hombres muestran la camiseta "Raul Labbe"	Hombres muestran la camiseta "Raul Labbe"	Hombres muestran la camiseta "Raúl Labbé" en Club deportivo Raúl Labbé					Pueblo de Lo Barnechea	Club deportivo Raul Labbe	2	Rocío Muñoz	Procultura	2025-10-15 18:17:01.589	2025-10-15 18:17:01.589
cmgsbc6bm04k4h9i65uywyowf	Mujer bailando en fonda	Mujer bailando en fonda	Mujer bailando en fonda							2	Rocío Muñoz	Procultura	2025-10-15 18:17:04.258	2025-10-15 18:17:04.258
cmgsbc9tj04kih9i6t925l6m5	Arquero atajando	Arquero atajando	Arquero atajando							2	Rocío Muñoz	Procultura	2025-10-15 18:17:08.791	2025-10-15 18:17:08.791
cmgsbcb2v04kph9i64wv0jd4x	Escena de gol	Escena de gol	Escena de gol							2	Rocío Muñoz	Procultura	2025-10-15 18:17:10.423	2025-10-15 18:17:10.423
cmgsbcdpm04l3h9i662j5zpq1	Bebé	Bebé	Bebé		Alfredo Tapia					2	Familia Muñoz Dotte	Procultura	2025-10-15 18:17:13.834	2025-10-15 18:17:13.834
cmgsbcjv004lvh9i6mxvovl4z	Grupo en primera comuniòn	Grupo en primera comuniòn	Grupo en primera comuni+on en Pueblo de Lo Barnechea	Año debe estar mal (decía "1995" pero lo borré. Es muy antigua la foto. Confirmarlo en la planilla original del archivo de Procultura.	Cristel Mendoza Valencia y amigos de las casas vecinas. Corina Salcedo Muñoz, María Eugenia Valencia Tobar, Cristel, nn. Abajo Luis Ortiz, Alejandro Ortiz.			Pueblo de Lo Barnechea	Circa 1995. Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:17:21.805	2025-10-15 18:17:21.805
cmgsbcpql04muh9i6265n1z3b	Cazadores de conejos posando	Cazadores de conejos posando	Cazadores de conejos posando en Pueblo de Lo Barnechea	Revisar lugar. y año No aparenta ser el Pueblo y fecha debe ser posterior a 1955.	Arriba a la izquierda Gildo Pavez, nn, Benjamin Valencia, Pololito, Fernando Cortes.  Abajo Juan Valladares, Carlos Moya, Patricio Salas (del Pollo al Cognac),			Pueblo de Lo Barnechea	Yoconda nació el 37. . Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:17:29.421	2025-10-15 18:17:29.421
cmgsbct7s04n8h9i6uuunq6mc	Cazadores posando frente al camión	Cazadores posando frente al camión	Cazadores posando frente al camión en Pueblo de Lo Barnechea	“Foto Maros. Independencia 328 Santiago”				Pueblo de Lo Barnechea	Hilda, Pedro, paulina, Juan carlos, Clara. . Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:17:33.928	2025-10-15 18:17:33.928
cmgsbcz4j04nth9i6zj098qan	Cazadores junto a su parrilla	Cazadores junto a su parrilla	Cazadores junto a su parrilla en Pueblo de Lo Barnechea	Revisar lugar. y año No aparenta ser el Pueblo y fecha debe ser posterior a 1955.				Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:17:41.587	2025-10-15 18:17:41.587
cmgsbd4vg04o7h9i6y1wwzmsr	Grupo de cazadores	Grupo de cazadores	Cazadores en Pueblo de Lo Barnechea	Revisar lugar. y año No aparenta ser el Pueblo y fecha debe ser posterior a 1955.				Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:17:49.036	2025-10-15 18:17:49.036
cmgsbdowm04ozh9i6xqxin98k	Entierro	Entierro	Entierro en Pueblo de Lo Barnechea	Papel de postal	Entierro de un niño que llegó del sur a hacer el servicio militar, y en la caballería un caballo lo pateó y lo mató			Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:18:14.995	2025-10-15 18:18:14.995
cmgsbe4vo04prh9i6uuesx79f	Pareja de recién casados	Pareja de recién casados	Pareja de recién casados en Club Barnechea		Victor Barrera y Edna ¿Araneda?			Pueblo de Lo Barnechea	Club Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:18:35.701	2025-10-15 18:18:35.701
cmgsbecwe04qch9i64w1sjm8x	Grupo en una banca	Grupo en una banca	Grupo en una banca en Policlínico	Estaban sentados un día domingo, y pasó el fotógrafo don Juanito, lo llamamos y nos sacó una foto	Gladys Moya, Yoconda Moya, Benjamín Valencia, Eugenia Moya			Pueblo de Lo Barnechea	Policlínico	2	Yoconda Moya	Procultura	2025-10-15 18:18:46.094	2025-10-15 18:18:46.094
cmgsbevpw04rbh9i6djjkse7v	Pareja de jóvenes	Pareja de jóvenes	Pareja de jóvenes en Pueblo de Lo Barnechea		Mónica, Hugo Bahamondes			Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:19:10.482	2025-10-15 18:19:10.482
cmgsbfb6r04rwh9i6hc1ymo1t	Grupo en matrimonio	Grupo en matrimonio	Grupo en matrimonio en Pueblo de Lo Barnechea		De blanco Luis Ortiz, y su hijo; a su derecha Victor Sabando, Benjamin Valencia			Pueblo de Lo Barnechea	=C533. Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:19:30.467	2025-10-15 18:19:30.467
cmgsbfgds04s3h9i6jrm27ew2	Grupo en comida de matrimonio	Grupo en comida de matrimonio	Grupo en comida de matrimonio en Club Barnechea		Desde la der mujer, Andres, Carlos Perez, Carmen Pino, Yoconda Moya, Benjamin Valencia			Pueblo de Lo Barnechea	Club Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:19:37.265	2025-10-15 18:19:37.265
cmgsbfkt404shh9i6ijmpq2hc	Mesa en comida de matrimonio	Mesa en comida de matrimonio	Mesa en comida de matrimonio en Posiblemente Pollo al Cognaco	“C Garrido 97 Lo Barnechea”	Derecha Efrain Galvez, Isabel, Benjamin Valencia, Yoconda Moya?, presidente Ernesto Pizarro, mujer, otro presidente			Pueblo de Lo Barnechea	Posiblemente Pollo al Cognaco	2	Yoconda Moya	Procultura	2025-10-15 18:19:43.001	2025-10-15 18:19:43.001
cmgsbfmjm04soh9i647pv4pl5	Tres hombres en comida de matrimonio	Tres hombres en comida de matrimonio	Tres hombres en comida de matrimonio en Sede del club Barnechea		Benjamin Valencia, Carlos Moya, Luis Ortiz			Pueblo de Lo Barnechea	Sede del club Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:19:45.25	2025-10-15 18:19:45.25
cmgsbfotl04svh9i6mzyysqhy	Mesa en comida de matrimonio	Mesa en comida de matrimonio	Mesa en comida de matrimonio en Sede del club Barnechea		Izq Efrain Galvez, Isabel (amiga estadounidense de Gladys) Gladys Moya, Humberto, Eugenia Moya			Pueblo de Lo Barnechea	Sede del club Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:19:48.201	2025-10-15 18:19:48.201
cmgsbfwpt04t9h9i650grodtl	Grupo de personas en una fiesta	Grupo de personas en una fiesta	Grupo de personas en una fiesta en Pueblo de Lo Barnechea		Der arriba Carmen Moya, Gladys Moya, Eugenia Moya, Juan marido Eugenia, Nona Moya, Rosalia Moya. Abajo Yoconda Moya, Carlos Moya			Pueblo de Lo Barnechea	=C550. Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:19:58.433	2025-10-15 18:19:58.433
cmgsbg3wl04tnh9i6eqr72356	Pareja bailando en una fiesta	Pareja bailando en una fiesta	Pareja bailando en una fiesta en Pueblo de Lo Barnechea		Nona Moya, Lucho Ubierna			Pueblo de Lo Barnechea	=C550. Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:20:07.708	2025-10-15 18:20:07.708
cmgsbg7ff04tuh9i6q595uqis	Joven dándole torta a otro	Joven dándole torta a otro	Joven dándole torta a otro en Pueblo de Lo Barnechea		Der Jorge Valencia			Pueblo de Lo Barnechea	=C550. Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:20:12.315	2025-10-15 18:20:12.315
cmgsbgakw04u1h9i66s17cclf	Pareja	Pareja	Pareja en Pueblo de Lo Barnechea		Luis Ubierna, Clara Valencia			Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:20:16.4	2025-10-15 18:20:16.4
cmgsbgcxz04u8h9i6gup8horn	Grupo	Grupo	Grupo en Pueblo de Lo Barnechea		Victor Barrera, Luis Ortiz, Luis Moraga, Eliana, Eliseo Villarroel, Benjamin Valencia, Antonio Diaz, Joaquin Moya			Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:20:19.462	2025-10-15 18:20:19.462
cmgsbgf6x04ufh9i6hnla6pzu	Novia con jóvenes	Novia con jóvenes	Novia con jóvenes en Pueblo de Lo Barnechea		no conoce a nadie			Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:20:22.377	2025-10-15 18:20:22.377
cmgsbgjvc04umh9i6p1vih8qe	Grupo familiar en un funeral	Grupo familiar en un funeral	Grupo familiar en un funeral en Cementerio General, sector de las familias italianas		Al centro, a la izq de la cruz de flores, Pedro Dotte Villar (nacido en 1900)				Cementerio General, sector de las familias italianas	2	Patricia Dotte	Procultura	2025-10-15 18:20:28.436	2025-10-15 18:20:28.436
cmgsbgnom04v0h9i6wqru2hkl	Jóvenes bailando	Jóvenes bailando	Jóvenes bailando en Pueblo de Lo Barnechea		no conoce a nadie			Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:20:33.382	2025-10-15 18:20:33.382
cmgsbgs2t04veh9i6r5iivlua	Joven bailando	Joven bailando	Joven bailando en Pueblo de Lo Barnechea		Pedro Valencia, Luis Ubierna			Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:20:39.077	2025-10-15 18:20:39.077
cmgsbgwp304vsh9i6uj8hhx90	Pareja y tres niños	Pareja y tres niños	Pareja y tres niños en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Familia Soto Torreblanca	Procultura	2025-10-15 18:20:45.06	2025-10-15 18:20:45.06
cmgsbh4hy04wdh9i6e669kbz5	Dos jóvenes	Dos jóvenes	Dos jóvenes							2	María Araya	Procultura	2025-10-15 18:20:55.174	2025-10-15 18:20:55.174
cmgsbi08404x5h9i64otxivo4	Dos mujeres con vestido marinero	Dos mujeres con vestido marinero	Dos mujeres con vestido marinero en Pueblo de Lo Barnechea	"Salamanca III 28/1929?				Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:21:36.292	2025-10-15 18:21:36.292
cmgsbi3va04xjh9i6fb0j5ya1	Dos mujeres frente a casa	Dos mujeres frente a casa	Dos mujeres frente a casa en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	interesante pq se ve la sombra del fotografo. . Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:21:41.014	2025-10-15 18:21:41.014
cmgsbicn804ybh9i6xvmc7i9r	Dos mujeres apoyadas en banca	Dos mujeres apoyadas en banca	Dos mujeres apoyadas en banca en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:21:52.388	2025-10-15 18:21:52.388
cmgsbglnq04uth9i6raq2q9wt	Personas tomando té	Personas tomando té	Personas tomando té en casa de Laura y Lindor		Lindor Álvarez, Benjamín Valencia, Laura Solis (esposa de Lindor)			Pueblo de Lo Barnechea	Casa de Laura y Lindor	2	Yoconda Moya	Procultura	2025-10-15 18:20:30.758	2025-10-15 18:20:30.758
cmgsbgpvb04v7h9i6c0vdjn5f	Cuatro jóvenes en fiesta	Cuatro jóvenes en fiesta	Cuatro jóvenes en fiesta en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:20:36.214	2025-10-15 18:20:36.214
cmgsbgu6204vlh9i68hc2ppnt	Tres jóvenes en fiesta	Tres jóvenes en fiesta	Tres jóvenes en fiesta en Casa de Amanda Chacón, abuela de Pedro		Luis Ubiera, Pedro Valencia Moya, Antonio Gomez			Pueblo de Lo Barnechea	Casa de Amanda Chacon, abuela de Pedro	2	Yoconda Moya	Procultura	2025-10-15 18:20:41.786	2025-10-15 18:20:41.786
cmgsbgzii04vzh9i614nvn75h	Grupo frente a Virgen del Carmen	Grupo frente a Virgen del Carmen	Grupo frente a Virgen del Carmen en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Familia Soto Torreblanca	Procultura	2025-10-15 18:20:48.713	2025-10-15 18:20:48.713
cmgsbhuam04wkh9i6qmejqcgc	Sobremesa de hombres	Sobremesa de hombres	Sobremesa de hombres en Pueblo de Lo Barnechea		Por el lazo izquierdo de la foto, el ultimo es Juan Salas, a su izquierda, Carreño. El primero es Alfredo Aránguiz. Al lado derecho, al fondo, Luis Robles. 			Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:21:28.605	2025-10-15 18:21:28.605
cmgsbi6zb04xqh9i6rrkry3iw	Pareja bailando	Pareja bailando	Pareja bailando en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	=C695. Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:21:45.046	2025-10-15 18:21:45.046
cmgsbiaz604y4h9i6nakxuy7v	Hombre en una banca 	Hombre en una banca 	Hombre en una banca en Casona en San Enrique		Luis Diaz 	1920-1930	1920	San Enrique/La Ermita/Las Condes	Dècada de 1920 o 1930. Cason en San Enrique	2	Juan Carlos Salas	Procultura	2025-10-15 18:21:50.226	2025-10-15 18:21:50.226
cmgsbifht04yih9i6dya6nhdl	Mujer y niña	Mujer y niña	Mujer y niña en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:21:56.081	2025-10-15 18:21:56.081
cmgsbihof04yph9i6qrkp2d59	Grupo de hombres	Grupo de hombres	Grupo de hombres en Pueblo de Lo Barnechea		De blanco a la izquierda Rubén Diaz, Juan Salas. Con sombrero atrás, Froilán Contreras. De terno oscuro y corbata, atrás a la izq del hombre de blanco con sombrero, Nano Aranguiz. Penultimo de izq a der sentado abajo, José Soto. 			Pueblo de Lo Barnechea	según Juan Contreras. . Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:21:58.912	2025-10-15 18:21:58.912
cmgsbh2wb04w6h9i6jph0eu5o	Niño recibiendo un premio de una pareja de huasos	Niño recibiendo un premio de una pareja de huasos	Niño recibiendo un premio de una pareja de huasos en Fiesta Huasa en Escuela Militar	Fiesta Huasa en Escuela Militar, para alcaldes que visitaban. El caballo del niño ganó el premio al más dócil	Eugenio Dapena (animador), Juana Gallardo (tía), Pedro Araya					2	María Araya	Procultura	2025-10-15 18:20:53.099	2025-10-15 18:20:53.099
cmgsbhumw04wrh9i6g9tzue71	Pedro Araya	Pedro Araya	Pedro Araya en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Club Católica	Procultura	2025-10-15 18:21:29.048	2025-10-15 18:21:29.048
cmgsbhx6c04wyh9i6uxyyez7f	Grupo en escenario	Grupo en escenario	Grupo en escenario en Pueblo de Lo Barnechea		NN, Tencha Cortés, Peta Araya, Silvia Leiva, Juan Salas			Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:21:32.34	2025-10-15 18:21:32.34
cmgsbi28o04xch9i68nrav36o	Grupo en la montaña	Grupo en la montaña	Grupo en la montaña						Pueblo Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:21:38.905	2025-10-15 18:21:38.905
cmgsbi8is04xxh9i6f874249v	Hombre	Hombre	Hombre en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:21:47.045	2025-10-15 18:21:47.045
cmgsbik9d04ywh9i652bwbig2	Hombre y niña	Hombre y niña	Hombre y niña en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	=C725. Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:22:02.255	2025-10-15 18:22:02.255
cmgsbil6l04z3h9i6gjda120c	Mujer sentada en el pasto	Mujer sentada en el pasto	Mujer sentada en el pasto en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:22:03.453	2025-10-15 18:22:03.453
cmgsbinj304zah9i66nv8hggz	Tres adultos y niña junto a árbol	Tres adultos y niña junto a árbol	Tres adultos y niña junto a árbol en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:22:06.495	2025-10-15 18:22:06.495
cmgsbiq6n04zhh9i67ixvyu8q	Grupo en el río junto a puente	Grupo en el río junto a puente	Grupo en el río junto a puente en Puente San Enrique					San Enrique/La Ermita/Las Condes	Puente San Enrique	2	Juan Carlos Salas	Procultura	2025-10-15 18:22:09.935	2025-10-15 18:22:09.935
cmgsbistg04zoh9i6klqmewjn	Niño paseando a caballo en el Mampato	Niño paseando a caballo en el Mampato	Niño paseando a caballo en el Mampato en La Dehesa					La Dehesa	La Dehesa	2	Juan Carlos Salas	Procultura	2025-10-15 18:22:13.348	2025-10-15 18:22:13.348
cmgsbivbe04zvh9i6g4krqvaf	Grupo en matrimonio	Grupo en matrimonio	Grupo en matrimonio en Sede Club Barnechea		Izq: Chepa Galvez, Benjamin Valencia. Penultimo a la derecha arriba, Luis Ortiz (inclinandose) a su izq, Figueroa, a su izq Luciano. A la derecha abajo Vicente Bravo. Atràs con una mano en el hombro, Labarca. De bigote estirando el brazo, Juan Salazar "Micheli". Entre él y la novia, "Rusio" Mesa. A la izq de la novia, Nano Molina.  Extremo derecho arriba, Guatón Salcedo. 	1970-1980	1970	Pueblo de Lo Barnechea	preguntarle a don Cheo. Dècada de 1970. Sede Club Barnechea	2	Carmen Pino	Procultura	2025-10-15 18:22:16.586	2025-10-15 18:22:16.586
cmgsbiy3x0502h9i6a2rfhg79	Dos mujeres disfrazadas	Dos mujeres disfrazadas	Dos mujeres disfrazadas en Pueblo de Lo Barnechea	Papel Postcard				Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:22:20.203	2025-10-15 18:22:20.203
cmgsbj0et0509h9i6v3nqtwqq	Monjitas en misa	Monjitas en misa	Monjitas en misa en Pueblo de Lo Barnechea	Foto Reportaje Social "Relámpago". E. Hoffstetter. Grajales 2152- Stgo.	Iglesia Santa Rosa, hacia el lado derecho se ponían las monjitas profesoras del colegio, estudiantes y apoderados. 			Pueblo de Lo Barnechea	importante por monjas. . Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:22:23.189	2025-10-15 18:22:23.189
cmgsbj47n050gh9i6rbehqrxe	Grupo numeroso	Grupo numeroso	Grupo numeroso en Pueblo de Lo Barnechea	Recuerdo de mi mamá				Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:22:28.115	2025-10-15 18:22:28.115
cmgsbj65a050nh9i62v5v9zgm	Dos niños pequeños 	Dos niños pequeños 	Dos niños pequeños  en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:22:30.622	2025-10-15 18:22:30.622
cmgsbj89p050uh9i6xzfi0xqg	Joven en moto	Joven en moto	Joven en moto en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:22:33.374	2025-10-15 18:22:33.374
cmgsbj9s60511h9i6hw5d7os3	Familia sentada en ventada	Familia sentada en ventada	Familia sentada en ventada en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:22:35.333	2025-10-15 18:22:35.333
cmgsbjbii0518h9i6cehh7va1	Niño colgado de un árbol	Niño colgado de un árbol	Niño colgado de un árbol en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:22:37.578	2025-10-15 18:22:37.578
cmgsbjd3g051fh9i6c3zmdzjp	Camioneta celeste	Camioneta celeste	Camioneta celeste en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:22:39.629	2025-10-15 18:22:39.629
cmgsbjen7051mh9i66kd1hac9	Jóvenes echados	Jóvenes echados	Jóvenes echados en Pueblo de Lo Barnechea			1960-1972	1960	Pueblo de Lo Barnechea	=C844. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:22:41.635	2025-10-15 18:22:41.635
cmgsbjg3n051th9i6ez09ow4k	Padre e hijo en escalera	Padre e hijo en escalera	Padre e hijo en escalera en Pueblo de Lo Barnechea			1960-1973	1960	Pueblo de Lo Barnechea	=C844. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:22:43.523	2025-10-15 18:22:43.523
cmgsbjhjg0520h9i64fnz8isz	Tres jóvenes en patas de elefante	Tres jóvenes en patas de elefante	Tres jóvenes en patas de elefante en Pueblo de Lo Barnechea			1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:22:45.388	2025-10-15 18:22:45.388
cmgsbjj5f0527h9i6hjwgit5p	Jóvenes con cables	Jóvenes con cables	Jóvenes con cables en Pueblo de Lo Barnechea			1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:22:47.475	2025-10-15 18:22:47.475
cmgsbjkpq052eh9i60a8hyv1c	Niño y perro	Niño y perro	Niño y perro en Pueblo de Lo Barnechea			1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:22:49.502	2025-10-15 18:22:49.502
cmgsbjm0o052lh9i6w7jskjzz	Cumpleaños infantil	Cumpleaños infantil	Cumpleaños infantil en Pueblo de Lo Barnechea			1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:22:51.192	2025-10-15 18:22:51.192
cmgsbjnjb052sh9i6ag2epwql	Hombres frente a camión	Hombres frente a camión	Hombres frente a camión en Pueblo de Lo Barnechea			1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:22:53.159	2025-10-15 18:22:53.159
cmgsbjorv052zh9i6s3m7iwbk	Dos niños	Dos niños	Dos niños en Pueblo de Lo Barnechea			1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:22:54.763	2025-10-15 18:22:54.763
cmgsbjqg00536h9i6t5o3zx04	Grupo frente a un buggy	Grupo frente a un buggy	Grupo frente a un buggy en Pueblo de Lo Barnechea			1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:22:56.928	2025-10-15 18:22:56.928
cmgsbjsbe053dh9i6al88twgq	Niña frente a gran árbol	Niña frente a gran árbol	Niña frente a gran árbol en Pueblo de Lo Barnechea			1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:22:59.354	2025-10-15 18:22:59.354
cmgsbjvgn053rh9i68xkg6ghq	Mujer con dos niños frente a muro	Mujer con dos niños frente a muro	Mujer con dos niños frente a muro en Pueblo de Lo Barnechea	Sr Mario Mancilla		1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:23:03.431	2025-10-15 18:23:03.431
cmgsbk2yt055bh9i6rh158kdz	Grupo frente a colina	Grupo frente a colina	Grupo frente a colina en Pueblo de Lo Barnechea			1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:23:13.157	2025-10-15 18:23:13.157
cmgsbk3l7055ih9i6hc6hqo7x	Mujeres apoyadas en un monumento	Mujeres apoyadas en un monumento	Mujeres apoyadas en un monumento en Pueblo de Lo Barnechea			1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:23:13.963	2025-10-15 18:23:13.963
cmgsbk5ov0563h9i6t9w1newi	Dos mujeres en una esquina	Dos mujeres en una esquina	Dos mujeres en una esquina en Pueblo de Lo Barnechea			1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:23:16.687	2025-10-15 18:23:16.687
cmgsbkbe1056oh9i6ktbndgq6	Niño en carro del viejo pascuero	Niño en carro del viejo pascuero	Niño en carro del viejo pascuero en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:23:24.073	2025-10-15 18:23:24.073
cmgsbki340579h9i6hww1ugma	Novios y jóvenes	Novios y jóvenes	Novios y jóvenes en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	=C886. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:23:32.752	2025-10-15 18:23:32.752
cmgsbklyk057nh9i6ro3iloaq	Novios del brazo y señoras	Novios del brazo y señoras	Novios del brazo y señoras en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	=C886. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:23:37.773	2025-10-15 18:23:37.773
cmgsbl19d0588h9i6zy3610cy	Grupo elegante con niño al centro	Grupo elegante con niño al centro	Grupo elegante con niño al centro en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:23:57.601	2025-10-15 18:23:57.601
cmgsblhi80590h9i6qkxzzgg1	Niña bebé con vestido blanco 2	Niña bebé con vestido blanco 2	Niña bebé con vestido blanco 2							2		Procultura	2025-10-15 18:24:18.657	2025-10-15 18:24:18.657
cmgsblkgv059eh9i61ako5ai7	Mujer y bebé junto a planta	Mujer y bebé junto a planta	Mujer y bebé junto a planta en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:24:22.496	2025-10-15 18:24:22.496
cmgsblmrq059lh9i6hf5y6s2c	Sacerdote Predicando	Sacerdote Predicando	Sacerdote Predicando en Población Nebraska	Con dedicatoria atrás. / C Garrido 97 	Mario Rojas Ramirez			Población Nebraska	13/9/1964.. Población Nebraska	2	Familia Meza Cortés	Procultura	2025-10-15 18:24:25.479	2025-10-15 18:24:25.479
cmgsblqbt05a6h9i665xoa4ja	Dos mujeres en un puente	Dos mujeres en un puente	Dos mujeres en un puente en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	ML. . Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:24:30.09	2025-10-15 18:24:30.09
cmgsblwdj05b5h9i6mfe4ughy	Grupo de fumadores	Grupo de fumadores	Grupo de fumadores en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:24:37.927	2025-10-15 18:24:37.927
cmgsblxvn05bch9i6x0w9kpvh	Pareja bailando	Pareja bailando	Pareja bailando en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:24:39.875	2025-10-15 18:24:39.875
cmgsblzx505bqh9i6dx1fewht	Mujer en jardín	Mujer en jardín	Mujer en jardín en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:24:42.522	2025-10-15 18:24:42.522
cmgsbm3uv05cih9i6ffuffyk3	Dos mujeres en roca	Dos mujeres en roca	Dos mujeres en roca en Pueblo de Lo Barnechea		A la der, Amelia Rosa Medina Leiva			Pueblo de Lo Barnechea	Vivían en la cordillera, eran 21 hermanos, los cuatreros se escondían en su casa y a cambio de eso la temporada sgte les llevaban ropa. Desconocida. Pueblo de Lo Barnechea	2	Cristian Garrido	Procultura	2025-10-15 18:24:47.624	2025-10-15 18:24:47.624
cmgsbm8mn05d3h9i65w13wnkc	Familia junto a su cosecha	Familia junto a su cosecha	Familia junto a su cosecha en Sector Raúl Labbé		Familia Bustamante Celis, hijos y sus esposas.	hacia 1931	1930	Pueblo de Lo Barnechea	"gente era cariñosa, no habia nadie egoista, nadie tenia mas que otro" Brigida: se hacia trueque, si algo te faltaba… todo se convidaba antiguamente. Rosa: No había egoísmo como ahora. Pienso que nunca más irá a cambiar como era antes. Brígida: Nosotros vivimos como veinte años en el río, teníamos patio, todo para jugar, saltar... Toda la cuadra Medina se la heredó la mamá de Rosa, que lo compró; la mitad con su esfuerzo, y la otra mitad con una polla que se ganó, 50 pesos. Así pudo heredar terrenos a sus cinco hijos. Brigida: con su carpeta, con todo al día.1931 o 32. Sector Raúl Labbé.. Fotografía antigua digitalizada	2	UNCAF	Procultura	2025-10-15 18:24:53.807	2025-10-15 18:24:53.807
cmgsbjtqb053kh9i64knt52r7	Niños en balneario	Niños en balneario	Niños en balneario en Pueblo de Lo Barnechea			1960-1970	1960	Pueblo de Lo Barnechea	=C862. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:23:01.187	2025-10-15 18:23:01.187
cmgsbjyxp054ch9i64hgpu5po	Grupo en unas rocas	Grupo en unas rocas	Grupo en unas rocas en Pueblo de Lo Barnechea			1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:23:07.933	2025-10-15 18:23:07.933
cmgsbk0re054qh9i6wnqyxuun	Grupo en la playa	Grupo en la playa	Grupo en la playa en Pueblo de Lo Barnechea			1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:23:10.299	2025-10-15 18:23:10.299
cmgsbk1n7054xh9i6pf1dioqe	Grupo en un bote	Grupo en un bote	Grupo en un bote en Pueblo de Lo Barnechea			1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:23:11.443	2025-10-15 18:23:11.443
cmgsbk49h055ph9i6vwb6l71i	Niños frente a muro	Niños frente a muro	Niños frente a muro en Pueblo de Lo Barnechea			1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:23:14.837	2025-10-15 18:23:14.837
cmgsbk51a055wh9i6sxsvjd2q	Mujer en la playa	Mujer en la playa	Mujer en la playa 			1960-1970	1960	Otro	Otro	2	Ana Matteo Rojas	Procultura	2025-10-15 18:23:15.839	2025-10-15 18:23:15.839
cmgsbkdhv056vh9i6uixqyi47	Joven con novia en brazos	Joven con novia en brazos	Joven con novia en brazos en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:23:26.804	2025-10-15 18:23:26.804
cmgsbkjys057gh9i6q11s656m	Novia sentada entre hombres	Novia sentada entre hombres	Novia sentada entre hombres en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	=C886. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:23:35.188	2025-10-15 18:23:35.188
cmgsbko49057uh9i6k21ji8h0	Mujer disfrazada de gitana	Mujer disfrazada de gitana	Mujer disfrazada de gitana en Pueblo de Lo Barnechea	C. Garrido 97 Barnechea				Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:23:40.569	2025-10-15 18:23:40.569
cmgsblgpj058th9i6xa52m107	Grupo disfrazado con serpentinas 	Grupo disfrazado con serpentinas 	Grupo disfrazado con serpentinas 						C Garrido 97 Barnechea	2		Procultura	2025-10-15 18:24:17.624	2025-10-15 18:24:17.624
cmgsbljfk0597h9i661d6ejop	Pareja Sentada	Pareja Sentada	Pareja Sentada							2		Procultura	2025-10-15 18:24:21.153	2025-10-15 18:24:21.153
cmgsbjwmm053yh9i6bp6utbj8	Joven con falda escocesa	Joven con falda escocesa	Joven con falda escocesa en Pueblo de Lo Barnechea			1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:23:04.942	2025-10-15 18:23:04.942
cmgsbjxpt0545h9i6t6iucnun	Pareja junto a salto de agua	Pareja junto a salto de agua	Pareja junto a salto de agua			1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:23:06.353	2025-10-15 18:23:06.353
cmgsbk011054jh9i6ymugp5rr	Grupo en unas rocas 2	Grupo en unas rocas 2	Grupo en unas rocas 2 en Pueblo de Lo Barnechea			1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:23:09.349	2025-10-15 18:23:09.349
cmgsbk2b70554h9i67ork0qvk	Grupo sentado en playa	Grupo sentado en playa	Grupo sentado en playa en Otro			1960-1970	1960	Otro	Otro	2	Ana Matteo Rojas	Procultura	2025-10-15 18:23:12.307	2025-10-15 18:23:12.307
cmgsbk71y056ah9i6r1aoj787	Vista de cerro y torres de alta tensión	Vista de cerro y torres de alta tensión	Vista de cerro y torres de alta tensión en Pueblo de Lo Barnechea			1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:23:18.454	2025-10-15 18:23:18.454
cmgsbk94d056hh9i6zw2m1o24	Grupo en mesa con serpentinas	Grupo en mesa con serpentinas	Grupo en mesa con serpentinas en Pueblo de Lo Barnechea	C Garrido 97 Barnechea		1960-1970	1960	Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:23:21.133	2025-10-15 18:23:21.133
cmgsbkfq30572h9i6nhzgcu6y	Sacerdote casando a pareja	Sacerdote casando a pareja	Sacerdote casando a pareja en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	=C886. Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:23:29.691	2025-10-15 18:23:29.691
cmgsbkqbt0581h9i69kemod14	Pareja disfrazada bailando de la mano	Pareja disfrazada bailando de la mano	Pareja disfrazada bailando de la mano en Pueblo de Lo Barnechea	C. Garrido 97 Barnechea				Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Ana Matteo Rojas	Procultura	2025-10-15 18:23:43.434	2025-10-15 18:23:43.434
cmgsbl3ic058fh9i68a881haw	Grupo familiar	Grupo familiar	Grupo familiar					El Arrayán	borrar	2	Margarita Gana	Procultura	2025-10-15 18:24:00.516	2025-10-15 18:24:00.516
cmgsbleqr058mh9i6p10m9ay8	Grupo escolar	Grupo escolar	Grupo escolar							2		Procultura	2025-10-15 18:24:15.075	2025-10-15 18:24:15.075
cmgsblnvp059sh9i6yujbx6at	Dos mujeres con niño	Dos mujeres con niño	Dos mujeres con niño en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:24:26.917	2025-10-15 18:24:26.917
cmgsblp54059zh9i6lhynfigz	Hombre de traje sentado	Hombre de traje sentado	Hombre de traje sentado en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:24:28.552	2025-10-15 18:24:28.552
cmgsblr2705adh9i64ei3eli8	Pareja abrazada	Pareja abrazada	Pareja abrazada en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:24:31.026	2025-10-15 18:24:31.026
cmgsblsmo05akh9i6y2sq8avm	Grupo en una cocina	Grupo en una cocina	Grupo en una cocina en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:24:33.073	2025-10-15 18:24:33.073
cmgsbltzc05arh9i63bw4trp2	Pareja abrazada frente a ventana	Pareja abrazada frente a ventana	Pareja abrazada frente a ventana en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:24:34.824	2025-10-15 18:24:34.824
cmgsblv7k05ayh9i6q4ij4orm	Señoras posando con niño	Señoras posando con niño	Señoras posando con niño en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:24:36.417	2025-10-15 18:24:36.417
cmgsblz5l05bjh9i6jb1w5btx	Mujer en el cerro	Mujer en el cerro	Mujer en el cerro en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:24:41.53	2025-10-15 18:24:41.53
cmgsbm0u505bxh9i6zpwsws50	Niño caminando	Niño caminando	Niño caminando en Pueblo de Lo Barnechea					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Juan Carlos Salas	Procultura	2025-10-15 18:24:43.71	2025-10-15 18:24:43.71
cmgsbm1pu05c4h9i6dczxw0yp	Carnet (y reverso)	Carnet (y reverso)	Carnet (y reverso) en Pueblo de Lo Barnechea		Luisa Correa, 2da esposa de Pedro Garrido			Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Cristian Garrido	Procultura	2025-10-15 18:24:44.85	2025-10-15 18:24:44.85
cmgsbm2bq05cbh9i6c39k8cdg	Niño frente a escalera	Niño frente a escalera	Niño frente a escalera en Pueblo de Lo Barnechea		Pedro Juan Garrido Medina			Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Cristian Garrido	Procultura	2025-10-15 18:24:45.638	2025-10-15 18:24:45.638
cmgsbm4zr05cph9i65tce9yyu	Tres huasos a caballo	Tres huasos a caballo	Tres huasos a caballo	Probablemente cuasimodistas		1990-2000	1990			2		Procultura	2025-10-15 18:24:49.095	2025-10-15 18:24:49.095
cmgsbm74105cwh9i6a0xl90cr	Cuasimodo	Cuasimodo	Cuasimodo			1990-2000	1990			2		Procultura	2025-10-15 18:24:51.841	2025-10-15 18:24:51.841
cmgsbm9wa05dah9i6678voouo	Grupo de jóvenes del brazo	Grupo de jóvenes del brazo	Grupo de jóvenes del brazo en Fiesta en casa de su abuela		Juan Carlos Valencia Moya, Antonio Gomez atrás, Paulina Valencia Moya, nn, nn.			Pueblo de Lo Barnechea	Fiesta en casa de su abuela	2	Yoconda Moya	Procultura	2025-10-15 18:24:55.451	2025-10-15 18:24:55.451
cmgsbmb4l05dhh9i6qzlv2z8b	Equipo femenino	Equipo femenino	Equipo femenino en Club Barnechea					Pueblo de Lo Barnechea	Club Barnechea	2	Yoconda Moya	Procultura	2025-10-15 18:24:57.045	2025-10-15 18:24:57.045
cmgsbmdjm05doh9i6d7pe4skt	Grupo sentado en una banca	Grupo sentado en una banca	Grupo sentado en una banca afuera de la sede del Club deportivo	Grupo de amigos después de una comida	NN, María Aracena,  Héctor, Amanda Chacón, Pedro Valencia (nieto de Amanda), de pie vestida oscuro Tani Pino			Pueblo de Lo Barnechea	Afuera de la sede del Club deportivo, después de una comida. Grupo de amigos.	2	Yoconda Moya	Procultura	2025-10-15 18:25:00.178	2025-10-15 18:25:00.178
cmgsbmele05dvh9i6m66tr5ch	Abuelo y nieta jugando	Abuelo y nieta jugando	Abuelo y nieta jugando en patio de la casa en Los Patos		Clarita Valencia Moya, Joaquin Moya			Pueblo de Lo Barnechea	Patio dela casa en Los Patos	2	Yoconda Moya	Procultura	2025-10-15 18:25:01.538	2025-10-15 18:25:01.538
cmgsbmgtc05e2h9i6jud89dhf	Familia frente a casa	Familia frente a casa	Familia frente a casa	Hay otra fotografia de esta familia en otra carpeta				Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Yolanda Cáceres	Procultura	2025-10-15 18:25:04.417	2025-10-15 18:25:04.417
cmgsbmin605e9h9i6u5pm7ka6	Grupo con bebé	Grupo con bebé	Grupo con bebé					Pueblo de Lo Barnechea	Pueblo de Lo Barnechea	2	Yolanda Cáceres	Procultura	2025-10-15 18:25:06.786	2025-10-15 18:25:06.786
cmgsbmkmp05egh9i6a26tnltk	Representación de navidad	Representación de navidad	Representación de navidad		Celebración de los vecinos de Calle Álvarez	hacia 1994	1990	Pueblo de Lo Barnechea		2	Rocío Muñoz	Procultura	2025-10-15 18:25:09.346	2025-10-15 18:25:09.346
cmgsbmlpo05enh9i6knu1hly1	Coro tocando en centro de Santiago	Coro tocando en centro de Santiago	Coro tocando en centro de Santiago		Coro de Pancho Villa	1992	1990	Santiago	Pancho Villa era el profesor contratado por la Municipalidad. 1992. Centro de Santiago	1	Yolanda Cáceres	Procultura	2025-10-15 18:25:10.765	2025-10-15 18:25:10.765
cmgsbmprj05f8h9i6trz6nwk3	Dos mujeres en escalera	Dos mujeres en escalera	Dos mujeres en escalera en Aeropuerto de Santiago		Edith y Cecilia Quiroz 	hacia 1989	1980	Santiago	Circa 1989. Aeropuerto de Santiago	1	Familia Quiroz Mendoza	Procultura	2025-10-15 18:25:16.015	2025-10-15 18:25:16.015
cmgsbmmv405euh9i6zfosbim2	Familia en el mar	Familia en el mar	Familia en el mar en Playa en Cahuil	Paseo de centro de Madres de Cema Chile	Inés Soto con dos nietas en brazos: Macarena Soto, Karla Gallardo	1985	1980	Otro	1985. Playa en Cahuil	1	Familia Soto Torreblanca	Procultura	2025-10-15 18:25:12.256	2025-10-15 18:25:12.256
cmgsbmnlb05f1h9i6d2p2e1zf	Mujer con dos perros	Mujer con dos perros	Mujer con dos perros en Casa en El Arrayán		Lotte Lebriesch	1980-1990	1980	El Arrayán	Década de 1980. Casa en El Arrayan	1	Familia Quiroz Mendoza	Procultura	2025-10-15 18:25:13.199	2025-10-15 18:25:13.199
cmgsbmy6m05geh9i6jqi9odgb	Niño en caballo de juguete	Niño en caballo de juguete	Niño en caballo de juguete en Parque Metropolitano		Jorge Maureira	1976	1970	El Arrayán	1976. Plaza en parque metropolitano	1	Margarita Gana	Procultura	2025-10-15 18:25:26.926	2025-10-15 18:25:26.926
cmgsbn1zv05h6h9i6v67wuixn	Mujer con largavistas	Mujer con largavistas	Mujer con largavistas 	Probablemente Punta Arenas	Lotte Lebriesch	1970-1980	1970	Otro	Década de 1970. Probablemente Punta Arenas	1	Familia Quiroz Mendoza	Procultura	2025-10-15 18:25:31.867	2025-10-15 18:25:31.867
cmgsbn75z05hyh9i6t8p7lzi0	Mesas preparadas para una comida	Mesas preparadas para una comida	Mesas preparadas para una comida en Pueblo de Lo Barnechea			hacia 1965	1960	Pueblo de Lo Barnechea	Fotos de Yoco: iban a cazar  a Longotoma, puros amigos de Barnechea, que llegaba hasta comandante malbec asi que todos se conocia,. . Fiesta. septiembre. Pueblo de Lo Barnechea	1	Eliseo Villarroel	Procultura	2025-10-15 18:25:38.568	2025-10-15 18:25:38.568
cmgsbna0k05ich9i6pxqdl4sd	Mujer con dos niños en la playa	Mujer con dos niños en la playa	Mujer con dos niños en la playa		Yoconda Moya, Juan Carlos Valencia, junto a una prima	hacia 1960	1960	Otro	Circa 1960. Otro	1	Yoconda Moya	Procultura	2025-10-15 18:25:42.261	2025-10-15 18:25:42.261
cmgsbne1k05ixh9i6tmmnroha	Cinco hermanos	Cinco hermanos	Cinco hermanos en Casa en calle Bilbao		Luz Angelica, Edith, Daniel, Ester, Cecilia Quiroz Mendoza	hacia 1964	1960	Santiago	Circa 1964. Casa en calle Bilbao	1	Familia Quiroz Mendoza	Procultura	2025-10-15 18:25:47.48	2025-10-15 18:25:47.48
cmgsbnhdw05jih9i6upf90nmr	Niño en la nieve	Niño en la nieve	Niño en la nieve en Farellones	Fallecido	Luis Gallardo	1980	1980	Farellones	Farellones	1	Familia Gallardo	Procultura	2025-10-15 18:25:51.812	2025-10-15 18:25:51.812
cmgsbnle505jwh9i6isnxeghf	Paisaje  de cordillera	Paisaje  de cordillera	Paisaje de cordillera en Fundo Potrero Grande			1985	1980	Farellones	Fundo Potrero Grande	1	Alfonso Campos	Procultura	2025-10-15 18:25:57.006	2025-10-15 18:25:57.006
cmgsbnme805k3h9i6bjsudyip	Pareja frente al andarivel	Pareja frente al andarivel	Pareja frente al andarivel 	A sus espaldas, cancha de novicios o de los tontos	Rafael Gallardo, María Álvarez	hacia 1970	1970	Farellones	ca.1970. A sus espaldas, cancha de novicios o de los tontos	1	Familia Gallardo	Procultura	2025-10-15 18:25:58.304	2025-10-15 18:25:58.304
cmgsbnuoi05lgh9i63p6hicbd	Mujer en la playa	Mujer en la playa	Mujer en la playa en Otro					Otro	Otro	1	Juan Carlos Salas	Procultura	2025-10-15 18:26:09.043	2025-10-15 18:26:09.043
cmgsbnwlf05luh9i6q8eck0ui	Familia en Santiago	Familia en Santiago	Familia en Santiago		Rafael Gallardo Álvarez, Rafael Gallardo Ramos, María Álvarez Pichilef, Guillermo Gallardo Álvarez	1972	1970	Santiago	imagen repetida. Igual a LBCH008	\N	Familia Gallardo	Procultura	2025-10-15 18:26:11.523	2025-10-15 18:26:11.523
cmgsbmqub05ffh9i6zpayz43z	Hombre sobre roca	Hombre sobre roca	Hombre sobre roca en Carrizal, Buenos Aires		Benjamín Valencia Osorio	1980-1990	1980	Otro	Década de 1980. Carrizal, Buenos Aires	1	Yoconda Moya	Procultura	2025-10-15 18:25:17.412	2025-10-15 18:25:17.412
cmgsbmsw405fmh9i6cst12azc	Club de adultas mayores frente a una cabaña	Club de adultas mayores frente a una cabaña	Club de adultas mayores frente a una cabaña en Punta de Tralca		de falda amarilla, Berta Soza (suegra de Lorenzo Montenegro), a la derecha abajo, Mercedes	hacia 1975	1970	Otro	circa 1975. Punta de Tralca	1	Lorenzo Montenegro	Procultura	2025-10-15 18:25:20.068	2025-10-15 18:25:20.068
cmgsbmw5305g0h9i6ub04phdb	Hombre y niños sentado en una cocina	Hombre y niños sentado en una cocina	Hombre y niños sentado en una cocina en Casa de Yoconda Moya en Los Patos	“Bautizo Raquel y Alejandro”	Pedro Valencia, Benjamín Valencia (padre), Paula Valencia	1971	1970	Pueblo de Lo Barnechea	13 de Marzo de 1971. Casa de Yoconda Moya en Los Patos	1	Yoconda Moya	Procultura	2025-10-15 18:25:24.279	2025-10-15 18:25:24.279
cmgsbmys805glh9i6ryj1x1yd	Niña en primera comunion con su madre	Niña en primera comunion con su madre	Niña en Primera comunión con su madre en Pueblo de Lo Barnechea		Ximena Riveros y Maria Ines Gajardo	1973	1970	Pueblo de Lo Barnechea	1973. Pueblo de Lo Barnechea	1	Ximena Riveros de Araya	Procultura	2025-10-15 18:25:27.705	2025-10-15 18:25:27.705
cmgsbn01605gsh9i6oxq73vrm	Foto de colegio	Foto de colegio	Foto de colegio en Escuela Técnica Carmen Arriarán, en Departamental		Última es Edith Quiroz	1977	1970	Población Nebraska	1977. Escuela Técnica Carmen Arriarán, en Departamental	1	Familia Quiroz Mendoza	Procultura	2025-10-15 18:25:29.323	2025-10-15 18:25:29.323
cmgsbn12205gzh9i6o07wqbma	Mujer pescando en lago	Mujer pescando en lago	Mujer pescando en lago		Lotte Lebriesch	1970-1980	1970	El Arrayán	Década de 1970. El Arrayán	1	Familia Quiroz Mendoza	Procultura	2025-10-15 18:25:30.651	2025-10-15 18:25:30.651
cmgsbn2zr05hdh9i672ph0f5n	Dos niños agachados	Dos niños agachados	Dos niños agachados en casa de una tía en Matucana		Angelica Quiroz, Alejandro Miranda 	1970	1970	Población Nebraska	1970. Casa de una tía en Matucana	1	Familia Quiroz Mendoza	Procultura	2025-10-15 18:25:33.159	2025-10-15 18:25:33.159
cmgsbn50g05hrh9i6uz6qod3i	Niño en triciclo	Niño en triciclo	Niño en triciclo en Casa de una tía en Matucana		Alejandro Miranda	1970	1970	Santiago	1970. Casa de una tía en Matucana	1	Familia Quiroz Mendoza	Procultura	2025-10-15 18:25:35.776	2025-10-15 18:25:35.776
cmgsbnbd205ijh9i61rbmvjk7	Grupo en Viña del Mar	Grupo en Viña del Mar	Grupo en restaurante de Juan Salas en Viña	Edificio Montecarlo, san Martin con 7 Norte		1966	1960	Otro	marzo 17 de 1966. Restaurante de Juan Salas en Viña, edificio Montecarlo, san Martin con 7 Norte	1	Juan Carlos Salas	Procultura	2025-10-15 18:25:44.006	2025-10-15 18:25:44.006
cmgsbnddc05iqh9i6kbrm103t	Bautizo	Bautizo	Bautizo en Melipilla		Reinaldo Loyola, Blanca Mendoza, esposa, Benjamín Loyala, sacerdote de Melipilla	1960-1970	1960	Población Nebraska	Llegarona  LB porque les salió una casa acá, antes vivían en Bilbao. Década de 1960. Melipilla	1	Familia Quiroz Mendoza	Procultura	2025-10-15 18:25:46.609	2025-10-15 18:25:46.609
cmgsbney305j4h9i65ekcjxao	Grupo en la playa	Grupo en la playa	Grupo en la playa		A la derecha Eugenia Moya, Efraín Bravo, Juanita Moya, Yoconda Moya, Rosalía Moya. Abajo a la derecha Alamiro Moya, Nano Bravo, Juan Carlos Valencia	hacia 1959	1950	Otro	Carlos ahora tiene 63. Circa 1959. Otro	1	Yoconda Moya	Procultura	2025-10-15 18:25:48.652	2025-10-15 18:25:48.652
cmgsbngbg05jbh9i64un58w8x	Grupo sentado	Grupo sentado	Grupo sentado	Foto cortada. “Valparaíso”	Oscar Martinez, Juan Pinto. Julia Pinto (hija)	1957	1950			1	María Araya	Procultura	2025-10-15 18:25:50.429	2025-10-15 18:25:50.429
cmgsbnn3c05kah9i6e4u5o3cl	Familia en Santiago	Familia en Santiago	Familia en Santiago		Rafael Gallardo Álvarez, Rafael Gallardo Ramos, María Álvarez Pichilef, Guillermo Gallardo Álvarez	1972	1970	Santiago	Santiago	1	Familia Gallardo	Procultura	2025-10-15 18:25:59.209	2025-10-15 18:25:59.209
cmgsbnomc05koh9i6tkzjcegd	Grupo de niños junto a Lucía Hiriart	Grupo de niños junto a Lucía Hiriart	Grupo de niños junto a Lucía Hiriart en Villa Militar en Farellones		Eugenio Fernández, Sandra Polanco, Susana Polanco, Lucía Hiriart, Adela Gallardo, Luis Gallardo, Rafael Gallardo, Guillermo Gallardo, Liliana Fernández	1978	1970	Farellones	Villa Militar en Farellones	1	Familia Gallardo	Procultura	2025-10-15 18:26:01.188	2025-10-15 18:26:01.188
cmgsbnq5005kvh9i622yndl6w	Bebé sentado en toalla	Bebé sentado en toalla	Bebé sentado en toalla							1	Rocio Muñoz	Procultura	2025-10-15 18:26:03.156	2025-10-15 18:26:03.156
cmgsbnvvx05lnh9i63nnzvbto	Postal Río Constitución	Postal Río Constitución	Postal Río Constitución en Otro					Otro	Otro	1	Juan Carlos Salas	Procultura	2025-10-15 18:26:10.606	2025-10-15 18:26:10.606
cmgsbmtzr05fth9i62gpk6ocp	Grupo de ancianas	Grupo de ancianas	Grupo de ancianas en Club deportivo	Las dos mujeres de la izquierda vivían a la orilla del río, cuidaban las canchas	Ana Galvez Cornejo (tenía un quiosco), Maria Ignacia Galvez Cornejo, Casilda Galvez?(prima)	1970-1980	1970	Pueblo de Lo Barnechea	La señora quiere una copia de esta foto. Le gusta mucho porque está su suegra.. Década 1970. Club deportivo	1	Mariela Bravo	Procultura	2025-10-15 18:25:21.495	2025-10-15 18:25:21.495
cmgsbmwwl05g7h9i6bdbxeurn	Mujer y niño	Mujer y niño	Mujer y niño en Paseo al zoológico		Margarita Gana y Juan Maureira	1973	1970	Santiago	21-12-73. Paseo al zoologico	1	Margarita Gana	Procultura	2025-10-15 18:25:25.269	2025-10-15 18:25:25.269
cmgsbn40505hkh9i6krvswxmo	Dos niños riendo	Dos niños riendo	Dos niños riendo en Casa de su abuela en Gran Avenida		Francisco Quiroz y Isolina Quiroz (primos)	hacia 1972	1970	Santiago	Circa 1972. Casa de su abuela en Gran Avenida	1	Familia Quiroz Mendoza	Procultura	2025-10-15 18:25:34.469	2025-10-15 18:25:34.469
cmgsbn81305i5h9i6s3bv9vv4	Grupo en la playa	Grupo en la playa	Grupo en la playa en Cartagena		Mujer de pie, Eugenia Moya, al centro Carlos Moya, a la izquierda Sergio Salcedo. Sentadas, Carmen Moya, Lorena Moraga Moya	hacia 1965	1960	Otro	Min se caso a los 30 , Yoconda 15. circa 1965. Cartagena	1	Yoconda Moya	Procultura	2025-10-15 18:25:39.687	2025-10-15 18:25:39.687
cmgsbniec05jph9i6c1h7g6cf	Bebé	Bebé	Bebé en Farellones		Maxel Herrera	1984	1980	Farellones	Farellones	1	Familia Gallardo	Procultura	2025-10-15 18:25:53.125	2025-10-15 18:25:53.125
cmgsbnntp05khh9i6zerms45a	Abuela, nieto e hija	Abuela, nieto e hija	Abuela, nieto e hija en Pitrufquén	Juana era de Pitrufquén	 María Álvarez, Carlos Hernández, Juana Pichilef,	hacia 1975	1970	Otro	ca. 1975. Pitrufquén	1	Familia Gallardo	Procultura	2025-10-15 18:26:00.158	2025-10-15 18:26:00.158
cmgsbnrsq05l2h9i6m0qsdqb9	Cuatro jóvenes conversando	Cuatro jóvenes conversando	Cuatro jóvenes conversando							1	Rocio Muñoz	Procultura	2025-10-15 18:26:05.306	2025-10-15 18:26:05.306
cmgsbntba05l9h9i6htm1dy3r	Cazadores comiendo con sus perros	Cazadores comiendo con sus perros	Cazadores comiendo con sus perros en Pueblo de Lo Barnechea	Revisar lugar. y año No aparenta ser el Pueblo y fecha debe ser posterior a 1955.				Pueblo de Lo Barnechea	=C486. Pueblo de Lo Barnechea	1	Yoconda Moya	Procultura	2025-10-15 18:26:07.27	2025-10-15 18:26:07.27
cmgscffsq05m1h9i6xzezowaq	test	test picture	test description	test notes	test people	2025	2020	test zone	test previous data	4	test owner	test cultural fund	2025-10-15 18:47:35.939	2025-10-15 18:47:35.939
\.


--
-- TOC entry 3451 (class 0 OID 25060)
-- Dependencies: 220
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: ccbl
--

COPY public.users (id, email, password, name, surname, role, "lastConnection", "createdAt", "updatedAt", "refreshToken") FROM stdin;
cmgs7owz00000h96wpfkoj0ns	guillermo.torres@tchile.com	$2b$10$Z1RyW.ODPE5s82v3qBR44ePxRDXJ3gNha0dea./OecAC3LLElSfwq	Guilllermo	Torres	ADMIN	2025-10-15 16:35:04.963	2025-10-15 16:35:00.204	2025-10-15 16:35:04.965	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6ImNtZ3M3b3d6MDAwMDBoOTZ3cGZrb2owbnMiLCJpYXQiOjE3NjA1NDYxMDQsImV4cCI6MTc2MDYzMjUwNH0.LaNK3FZkvDJVDAxWBJlLHP4h_1DcoHQDG6_UKHm_nOc
\.


--
-- TOC entry 3294 (class 2606 OID 25038)
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: ccbl
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 3296 (class 2606 OID 25051)
-- Name: image_variants image_variants_pkey; Type: CONSTRAINT; Schema: public; Owner: ccbl
--

ALTER TABLE ONLY public.image_variants
    ADD CONSTRAINT image_variants_pkey PRIMARY KEY (id);


--
-- TOC entry 3298 (class 2606 OID 25059)
-- Name: images images_pkey; Type: CONSTRAINT; Schema: public; Owner: ccbl
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT images_pkey PRIMARY KEY (id);


--
-- TOC entry 3301 (class 2606 OID 25068)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: ccbl
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3299 (class 1259 OID 25069)
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: ccbl
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- TOC entry 3302 (class 2606 OID 25070)
-- Name: image_variants image_variants_imageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ccbl
--

ALTER TABLE ONLY public.image_variants
    ADD CONSTRAINT "image_variants_imageId_fkey" FOREIGN KEY ("imageId") REFERENCES public.images(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3458 (class 0 OID 0)
-- Dependencies: 5
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: ccbl
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


-- Completed on 2025-10-15 19:39:21 UTC

--
-- PostgreSQL database dump complete
--

\unrestrict dYqZECjTP8XkDbkVPRQLUQE6RdlpW3P6Q1wnNnGuJSdAIkf7VJ77PK4G6ktVMoI

